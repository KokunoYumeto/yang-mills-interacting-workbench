# Complete available Yang-Mills source packet, 16 September 2026

Start at yang-mills/consolidation/20260916/README.md. The 297-page PDF, editable TeX, full available source notes, foundation papers, scoped checkers, historical receipts, fresh validation and bounded mathematical reviews are included. Earlier downloaded ZIPs are not needed for the available mathematical source closure.

SOURCE_COVERAGE.md records the four missing attachment families; their absence is not hidden by the word cumulative. FOLLOWUP_PROMPT.md is the prepared source-recovery and unfinished-continuation prompt. The s6/ directory preserves the repository companion referenced by the early refinement note; its externally hosted full archive is identified by its existing guide. No private transcript or credential is included.

Run python -B tools/verify_ym_consolidation.py for source identity. Read the reader README for Pandoc/XeLaTeX build dependencies, and VALIDATION.md for original Linux/WSL replay commands and scope. PACKET_CONTENTS.json lists every other ZIP member and its SHA-256.
