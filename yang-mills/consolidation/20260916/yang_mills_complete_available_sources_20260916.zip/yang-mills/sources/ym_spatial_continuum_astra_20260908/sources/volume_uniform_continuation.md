---
title: "Volume-independent local estimates in the full SU(2) Wilson vacuum"
date: "8 September 2026"
geometry: margin=25mm
header-includes:
  - \usepackage{mathrsfs}
---

# 1. Original Hamiltonian, physical state, and geometric input

Fix an integer \(L\ge2\). The vertices are
\(\mathsf V_L=\{-L,\ldots,L\}^3\). A physical link
\(e=(n,i)\) is oriented from \(n\) to \(n+\mathbf e_i\) whenever
both endpoints are vertices. Its independent variable is \(U_e\in SU(2)\);
an inverse traversal contributes \(U_e^{-1}\). Every contained elementary
face \(p=(n;i,j)\), \(i<j\), is included, with
\[
W_p=\operatorname{tr}\left[
 U_i(n)U_j(n+\mathbf e_i)U_i(n+\mathbf e_j)^{-1}U_j(n)^{-1}
\right].                                                    \tag{1.1}
\]
Write \(\mathsf E_L,\mathsf P_L\) for these complete sets, and
\[
N=3(2L)(2L+1)^2,\qquad M=3(2L)^2(2L+1).
\]
The Hilbert space is \(\mathcal H_L=L^2(SU(2)^{\mathsf E_L},dU)\),
with product Haar probability measure and inner product conjugate-linear
in its first entry. The differential operators and all physical constants are
\[
T_a=-i\sigma_a/2,\quad
X_{e,a}f=\left.\frac{d}{dt}f(\ldots,e^{tT_a}U_e,\ldots)\right|_{t=0},
\quad E_e=-\sum_{a=1}^3X_{e,a}^2,
\]
\[
H=\kappa\sum_{e\in\mathsf E_L}E_e
       +b\sum_{p\in\mathsf P_L}(2-W_p),\qquad
\kappa=\frac{2g_{\rm YM}^2}{a},\quad
b=\frac{1}{2g_{\rm YM}^2a},\quad
\xi=\frac b\kappa=\frac1{4g_{\rm YM}^4},\quad a,g_{\rm YM}>0.       \tag{1.2}
\]
In the original metric \(c(X,Y)=-\operatorname{tr}(XY)/2\), the
orthonormal frame is \(2T_a\), so \(\Delta_e^c=4\Delta_e^T\).
Thus the electric term in (1.2) also equals
\(-g_{\rm YM}^2\sum_e\Delta_e^c/(2a)\). No coefficient or energy
origin is changed. In particular the scalar \(2bM\) remains in \(H\).

The original geometric condition remains
\[
\operatorname{Im}\tau
\left(\operatorname{Im}\beta-
\frac{6(\operatorname{Im}\mu)^2}{\operatorname{Im}\tau}\right)\ne0.
                                                               \tag{1.3}
\]
The input magnetic patch uses
\(L_T=\operatorname{Im}\tau_T,\ q_T=-\operatorname{Im}\beta_T,
m_T=\operatorname{Im}\mu_T,\ D=L_Tq_T+6m_T^2>0\) and
\(\theta=2\pi a^2/D\). Its exact projected small-angle state, proved
in the parent source, is
\[
\chi_\theta=-\frac23\theta^2 v_{w^{\rm nat}}+O_{H^1}(\theta^4),
\qquad w^{\rm nat}_{(n,1)}=n_2^2,\quad
w^{\rm nat}_{(n,2)}=w^{\rm nat}_{(n,3)}=0.                         \tag{1.4}
\]
The angle remainder in (1.4) is a fixed-regulator input, not a bound
claimed uniform here. The result below concerns its actual electric
state with the exact original weights.

The product Laplacian on this compact connected manifold has domain
\(H^2\), form domain \(H^1\), and compact resolvent. Its smooth bounded
potential preserves these domains. A lowest form minimizer can be
chosen nonnegative by the gradient inequality for the modulus, obtained
at its zeros by approximation with \(\sqrt{|f|^2+\epsilon^2}\).
Elliptic regularity and the strong maximum principle make it smooth and
strictly positive. Write it as \(\psi>0\), with
\(\int\psi^2dU=1\), and write its physical energy as \(\mathcal E\).
Integration by parts using \(H\psi=\mathcal E\psi\) gives
\[
\mathfrak q_{H-\mathcal E}[\psi F]
 =\kappa\sum_{e,a}\int\psi^2|X_{e,a}F|^2dU.                    \tag{1.5}
\]
A second ground eigenfunction divided by \(\psi\) would have all
derivatives zero in (1.5), hence be constant. This proves simplicity.
The gauge action \(U_e\mapsto g_{s(e)}U_eg_{t(e)}^{-1}\) preserves
the operator, form, and positive unit vector; consequently \(\psi\)
is gauge invariant. All states below are formed from this same vacuum.

For each link set
\[
r_e=\#\{p:e\in\partial p\},\quad
W_e^{\star}=\sum_{p\ni e}W_p,\quad
t_{ef}=\#\{p:e,f\in\partial p\},\quad
\gamma_e=\langle\psi,E_e\psi\rangle,\quad v_e=(E_e-\gamma_e)\psi.
\]
Here \(2\le r_e\le4\), including boundary links. Define the actual matrices
\[
C_{ef}=\langle v_e,v_f\rangle,\qquad
\mathcal N_{ef}=\langle v_e,(H-\mathcal E)v_f\rangle.             \tag{1.6}
\]
They are real symmetric positive-semidefinite matrices. Smoothness of
\(\psi\) supplies every operator and form domain used in (1.6).

# 2. A local projection and an exact comparison operator

Let \(S\subset\mathsf E_L\) be a nonempty set of links. It need not be
connected. Define
\[
\mathsf J(S)=\{p:\partial p\cap S\ne\varnothing\},\quad
m_S=|\mathsf J(S)|,\quad
W_S=\sum_{p\in\mathsf J(S)}W_p,\quad H_S=\sum_{e\in S}E_e,
\]
\[
H_{\rm ext,S}=\kappa\sum_{e\notin S}E_e
       +b\sum_{p\notin\mathsf J(S)}(2-W_p).                    \tag{2.1}
\]
The last operator acts on the exterior tensor factor only. Its bottom
energy is \(\mathcal E_{\rm ext,S}\); if that factor is empty it is the
zero operator on \(\mathbb C\). The exact decomposition is
\[
H=\kappa H_S+H_{\rm ext,S}+2bm_S-bW_S.                          \tag{2.2}
\]
Every face meeting \(S\), including faces crossing its boundary, is
present in \(W_S\). Every other face is present in \(H_{\rm ext,S}\).
The constant terms total \(2bM\) in both (1.2) and (2.2).

The map
\[
(P_S f)(U_{S^c})=\int f(U_S,U_{S^c})\,dU_S,\qquad Q_S=I-P_S    \tag{2.3}
\]
is understood with its output lifted as a function constant on \(S\).
Fubini proves \(P_S=P_S^*=P_S^2\). Its range is
\(\mathbb C1_S\otimes L^2(SU(2)^{S^c})\), and its kernel consists
of functions of zero conditional Haar integral on \(S\).
It commutes with all link Casimirs and with exterior operators, and
preserves smooth functions and Sobolev domains. Each plaquette in
\(W_S\) contains a link of \(S\) exactly once in the fundamental or
inverse fundamental representation. Integration of that link is zero:
the substitution \(U\mapsto -U\) changes its matrix entries' signs.
Therefore
\[
P_SW_SP_S=0.                                                   \tag{2.4}
\]
This is an operator identity, not a statement that the interacting
vacuum has a Haar marginal. Haar invariance under endpoint left/right
multiplication also proves that \(P_S,Q_S\) intertwine the gauge action.

Take as a trial vector the constant on \(S\) tensored with an exterior
ground vector. Equation (2.4) makes its \(W_S\) expectation zero.
The full variational principle gives
\[
\mathcal E\le\mathcal E_{\rm ext,S}+2bm_S.
\]
Consequently the exterior self-adjoint operator
\[
K_S=H_{\rm ext,S}+2bm_S-\mathcal E\quad\hbox{satisfies }K_S\ge0.
                                                               \tag{2.5}
\]
No gap of \(K_S\) is assumed or needed. Put
\(B_S=\kappa H_S+K_S\). It is a sum of nonnegative operators on
different tensor factors. Their spectral resolutions strongly commute;
the operator domain of their sum is their domain intersection. The
full smooth vacuum belongs to that domain, and its exact equation is
\[
B_S\psi=bW_S\psi.                                             \tag{2.6}
\]
This identity retains the original interaction and exterior vacuum
dependence. It is not a free-vacuum eigen-equation.

The single-link eigenvalues of \(E_e\) are \(j(j+1)\),
\(j=0,\frac12,1,\ldots\), with the constant as its unique zero vector.
Indeed the Pauli matrices give \(-\sum_aT_a^2=3I/4\) on the
fundamental representation, and the spin raising/lowering matrices give
\(j(j+1)\) on each higher representation. Completeness of their
matrix coefficients under product Haar measure gives the joint spectral
decomposition. Thus \(H_S\ge(3/4)Q_S\).
On \(Q_S\mathcal H_L\), \(B_S\ge3\kappa/4\). Define
\[
R_S=Q_S(B_S|_{Q_S\mathcal H_L})^{-1}Q_S.
\]
Joint spectral calculus gives, without a Neumann expansion,
\[
\|R_S\|\le\frac4{3\kappa},\qquad
\|E_eR_S\|\le\frac1\kappa\quad(e\in S).                      \tag{2.7}
\]
For the latter assertion the multiplier is
\(\lambda_e/(\kappa\sum_{f\in S}\lambda_f+k)\le1/\kappa\)
for \(\lambda_f,k\ge0\). This also proves that the displayed composition
has a bounded extension on the full Hilbert space. Applying \(Q_S\)
to (2.6) now gives the exact local-resolvent equation
\[
Q_S\psi=bR_SW_S\psi.                                          \tag{2.8}
\]

# 3. Local electric moments at every positive coupling

**Theorem 3.1.** For every box \(L\ge2\), every \(a,g_{\rm YM}>0\),
every link \(e\), and every nonempty finite link set \(S\),
\[
\|E_e\psi\|\le2r_e\xi,\qquad
0\le\gamma_e\le\frac{16}{3}r_e^2\xi^2,                         \tag{3.1}
\]
\[
\|Q_S\psi\|\le q_S\xi,\qquad
q_S=\frac83\left(\sum_{e\in S}r_e^2\right)^{1/2}
\le\frac{32}{3}\sqrt{|S|}.                                    \tag{3.2}
\]
The constants have no dependence on the number of exterior links or faces.

**Proof.** Use \(S=\{e\}\) in (2.6). Its local interaction satisfies
\(\|W_S\|\le2r_e\). For the joint nonnegative spectral variables
of \(\kappa E_e\) and \(K_S\), their sum is at least the first
variable. Squaring this scalar inequality and integrating against the
spectral measure of \(\psi\) proves
\[
\kappa\|E_e\psi\|\le\|B_S\psi\|
 =b\|W_e^{\star}\psi\|\le2br_e.
\]
Since each nonzero eigenvalue of \(E_e\) is at least \(3/4\),
the spectral inequality \(E_e\le(4/3)E_e^2\) gives the second bound
in (3.1). The commuting projections onto nonconstant individual link
factors obey \(Q_S\le\sum_{e\in S}Q_{\{e\}}\) in their joint
zero/one eigenvalues. Also \(Q_{\{e\}}\le(16/9)E_e^2\).
Taking expectations and using (3.1) gives
\[
\|Q_S\psi\|^2\le\frac{16}{9}\sum_{e\in S}\|E_e\psi\|^2
 \le\frac{64}{9}\xi^2\sum_{e\in S}r_e^2.
\]
This proves (3.2). All estimates used the actual normalized vacuum;
no estimate on its full-box distance from the constant was used. \(\square\)

For later use, let \(F\) be any bounded multiplication operator depending
only on \(S\), with full Haar mean \(\overline F\). With
\(\eta=P_S\psi,\ u=Q_S\psi,\ q=\|u\|\), Fubini gives
\(\langle\eta,F\eta\rangle=\overline F\|\eta\|^2\).
Expanding all four terms of \(\langle\eta+u,F(\eta+u)\rangle\)
and using \(\|\eta\|^2=1-q^2\) therefore gives
\[
\left|\langle\psi,F\psi\rangle-\overline F\right|
 \le2\|F\|q+2\|F\|q^2.                                      \tag{3.3}
\]
This is a proved bound on a marginal expectation. It does not replace
the marginal by Haar measure.

# 4. An edge-star resolvent with an explicit state-vector remainder

Take
\[
S_e=\bigcup_{p\ni e}\partial p,\qquad m_e^{\star}=m_{S_e}.
\]
Each face at \(e\) adds at most three other links, so
\( |S_e|\le1+3r_e\le13\). Each link meets at most four faces,
hence \(m_e^{\star}\le4|S_e|\le52\). Equation (3.2) gives
\(q_{S_e}\le32\sqrt{13}/3<39\). These counts hold also at every
boundary of the open box.

**Theorem 4.1.** Simultaneously for all links and all boxes, on the explicit
interval \(0<\xi\le1/64\),
\[
\left\|E_e\psi-\frac\xi4W_e^{\star}\psi\right\|
 \le4200\xi^2.                                                 \tag{4.1}
\]
This compares two vectors in the same full interacting Hilbert space.

**Proof.** In Section 2 take \(S=S_e\) and abbreviate its operators
as \(P,Q,K,B,R\). Write \(\eta=P\psi,\ u=Q\psi\), with
\(\|u\|\le q_S\xi\). Applying \(P\) to (2.6) and using (2.4)
gives
\[
K\eta=bPW_Su,\qquad \|K\eta\|\le2bm_Sq_S\xi.                 \tag{4.2}
\]
Since \(E_eP=0\), equation (2.8) gives
\[
E_e\psi=bE_eRW_S\eta+bE_eRW_Su.                               \tag{4.3}
\]
Its second term has norm at most \(2m_Sq_S\xi^2\), by (2.7).
For a face not containing \(e\), \(E_eW_p\eta=0\). For a face
containing \(e\), all four boundary links lie in \(S\), and
\[
E_eW_p\eta=\frac34W_p\eta,\qquad H_SW_p\eta=3W_p\eta.
\]
Here the four fundamental Casimirs contribute separately, with exterior
variables untouched. Multiplication by such \(W_p\) commutes with \(K\).
The bounded map \(\zeta\mapsto W_p\zeta\) from the exterior space
to the local four-fundamental sector intertwines \(3\kappa+K\)
with \(B\). Its image is in \(Q\mathcal H_L\). Resolvent intertwining
and (4.3) thus give the exact identity
\[
bE_eRW_S\eta=\frac{3b}{4}
 W_e^{\star}(3\kappa+K)^{-1}\eta.
\]
The exterior inverse exists because \(K\ge0\). Subtracting
\((\xi/4)W_e^{\star}\eta\), while retaining \(K\), gives
\[
-\frac\xi4W_e^{\star}(3\kappa+K)^{-1}K\eta,
\]
whose norm by (4.2) is at most
\(r_em_Sq_S\xi^3/3\). Replacing \(\eta\) by \(\psi\) in the
comparison term has the additional norm cost
\(r_eq_S\xi^2/2\). We have proved the more detailed bound
\[
\left\|E_e\psi-\frac\xi4W_e^{\star}\psi\right\|
\le (2m_S+r_e/2)q_S\xi^2
       +\frac{r_em_Sq_S}{3}\xi^3
\le4134\xi^2+2704\xi^3.                                      \tag{4.4}
\]
For \(\xi\le1/64\) the last coefficient is
\(4134+2704/64=16705/4<4200\). This proves (4.1).
Equations (4.2)--(4.4) exhibit every discarded-in-an-estimate term
as an exact retained term with a bound; none is set to zero. \(\square\)

# 5. Uniform local Wilson and connected electric covariances

For elementary faces \(p,q\), Haar integration gives
\(\int W_pW_qdU=\delta_{pq}\). For unequal faces a link occurs in
only one support; its central sign change annihilates the integral.
For equal faces Haar invariance reduces the integral to
\(\int_{SU(2)}(\operatorname{tr}U)^2dU=1\). In quaternion coordinates
the latter is \(4\int u_0^2=1\), since the four coordinate second
moments on the unit three-sphere equal \(1/4\).

The function \(W_pW_q\) has norm at most \(4\) and uses at most eight
links. Equations (3.2)--(3.3), with
\(q_S\le32\sqrt8/3<31\), prove, for \(0<\xi\le1/64\),
\[
|\langle W_pW_q\rangle_\psi-\delta_{pq}|
 \le248\xi+7688\xi^2\le370\xi.                              \tag{5.1}
\]
This remains valid for faces at any separation; no finite-range assertion
about their true correlations is imposed.

For an individual face choose any one boundary link \(e\) and decompose
\(\psi=P_{\{e\}}\psi+Q_{\{e\}}\psi\). The first-first matrix
element of \(W_p\) vanishes by integration over \(e\). Equation (3.2)
gives \(q\le32\xi/3\), and the other three terms give
\[
|\langle W_p\rangle_\psi|\le4q+2q^2
 \le\left(\frac{128}{3}+\frac{32}{9}\right)\xi<47\xi.
\]
Consequently the connected Wilson moment obeys
\[
|\langle W_pW_q\rangle_\psi
 -\langle W_p\rangle_\psi\langle W_q\rangle_\psi-\delta_{pq}|
 \le410\xi.                                                   \tag{5.2}
\]
Indeed (5.1) and \(47^2\xi^2\le(2209/64)\xi\) give a smaller
constant than \(410\).

**Theorem 5.1.** On the same interval, simultaneously for all boxes and links,
\[
\left|C_{ef}-\frac{\xi^2}{16}t_{ef}\right|\le42500\xi^3.       \tag{5.3}
\]

**Proof.** Set \(u_e=E_e\psi\) and
\(a_e=(\xi/4)W_e^{\star}\psi\). The preceding bounds give
\[
\|u_e\|\le8\xi,\quad \|a_e\|\le2\xi,\quad
\|u_e-a_e\|\le4200\xi^2.
\]
Using the exact difference
\(\langle u_e-a_e,u_f\rangle+\langle a_e,u_f-a_f\rangle\),
its absolute value is at most \(42000\xi^3\). Also
\[
\langle a_e,a_f\rangle
 =\frac{\xi^2}{16}\sum_{p\ni e,q\ni f}\langle W_pW_q\rangle_\psi.
\]
There are at most sixteen ordered pairs in this sum. Its difference
from \(\xi^2t_{ef}/16\) is at most \(370\xi^3\), by (5.1).
Finally (3.1) bounds the exact centering term by
\[
|\gamma_e\gamma_f|\le\frac{65536}{9}\xi^4
 \le\frac{1024}{9}\xi^3<114\xi^3.
\]
The sum \(42000+370+114=42484<42500\) proves (5.3).
No odd Taylor coefficient has been asserted nonzero: this is an
absolute real-coupling remainder bound. The fixed-box evenness theorem
is compatible with (5.3); without an additional uniform analytic
argument it does not improve this bound to order \(\xi^4\). \(\square\)

# 6. Energy entries and a volume-independent weighted numerator estimate

Put \(A=H-\mathcal E\). The product rule, with the original sign
of \(E_f\), gives on the smooth vacuum
\[
AE_f\psi=[H,E_f]\psi
=b\left(\frac34W_f^{\star}\psi-2D_f\psi\right),\qquad
D_f\psi=\sum_{p\ni f,a}(X_{f,a}W_p)X_{f,a}\psi.                \tag{6.1}
\]
The electric sum commutes with \(E_f\). The potential contribution is
\(b[E_f,W_f^{\star}]\), retaining its first-derivative term in full.

For any one occurrence of a link in a simple Wilson loop, cyclically
basing the holonomy at that occurrence writes its derivative as
\(\operatorname{tr}(T_aU)\), or its negative, with a possible adjoint
rotation of the index \(a\). Quaternion coordinates then give
\[
\sum_a|X_{f,a}W_p|^2=1-W_p^2/4\le1.                           \tag{6.2}
\]
Pointwise Cauchy--Schwarz, followed by integration, bounds each
plaquette contraction in \(D_f\psi\) by
\((\sum_a\|X_{f,a}\psi\|^2)^{1/2}=\sqrt{\gamma_f}\).
Thus (3.1) gives
\[
\|D_f\psi\|\le r_f\sqrt{\gamma_f}
 \le\frac4{\sqrt3}r_f^2\xi\le\frac{64}{\sqrt3}\xi<37\xi.     \tag{6.3}
\]

**Theorem 6.1.** For \(0<\xi\le1/64\), all boxes, and all links,
\[
\left|\mathcal N_{ef}-\frac{3\kappa\xi^2}{16}t_{ef}\right|
 \le27000\kappa\xi^3.                                        \tag{6.4}
\]
For every real edge weight \(w\), including weights depending on \(L\)
and \(\xi\),
\[
\left|w^T\mathcal Nw-\frac{3\kappa\xi^2}{16}\|\mathsf Iw\|_2^2\right|
 \le351000\kappa\xi^3\|w\|_2^2,\qquad
 (\mathsf Iw)_p=\sum_{e\in\partial p}w_e.                     \tag{6.5}
\]

**Proof.** Since \(A\psi=0\), centering does not change
\(\mathcal N_{ef}=\langle E_e\psi,AE_f\psi\rangle\).
Insert (6.1). Replacing \(E_e\psi\) by \(a_e\) in the first term
costs at most \(6\cdot4200\kappa\xi^3=25200\kappa\xi^3\),
because \(\|W_f^{\star}\psi\|\le8\). The comparison of its
remaining Wilson products to Haar costs at most \(1110\kappa\xi^3\)
by (5.1). The full derivative term is at most
\(2\kappa\xi(8\xi)(37\xi)=592\kappa\xi^3\).
Their sum is \(26902\kappa\xi^3<27000\kappa\xi^3\), proving (6.4).

To prove the weighted conclusion without extending the entry bound
to an unjustified operator bound, expand the double commutator:
\[
\mathcal N_{ef}
 =\tfrac12\langle\psi,[E_e,[H,E_f]]\psi\rangle
 =\frac b2\sum_{p:e,f\in\partial p}
 \langle\psi,[E_e,[2-W_p,E_f]]\psi\rangle.                     \tag{6.6}
\]
The first identity follows from commutation of \(E_e,E_f\), the
vacuum equation at both endpoints, and reality of the two equal
cross terms. In the second, a face absent from \(f\) has zero inner
commutator. A face containing \(f\) but absent from \(e\) has
coefficients and derivatives commuting with \(E_e\). This proves
exact support on shared faces. A link has at most \(1+3r_e\le13\)
partners, counting itself. The remainder in (6.4) has the same support.
For its real symmetric matrix \(R\),
\[
|w^TRw|\le\sum_{e,f}|R_{ef}|\frac{w_e^2+w_f^2}{2}
 \le13\cdot27000\kappa\xi^3\sum_ew_e^2.
\]
Finally \(t=\mathsf I^T\mathsf I\) by its definition. This proves
(6.5), with no factor of \(M\), \(N\), or \(L\) in its constant. \(\square\)

# 7. Actual states, arbitrary weights, and the entire leading kernel

For real \(w\) write
\(\Gamma_w=\sum_ew_eE_e,\ v_w=(\Gamma_w-\langle\Gamma_w\rangle_\psi)\psi\).
These operators and states preserve the gauge constraint; all products
are taken on smooth \(\psi\). Equations (5.3) and (6.5) give simultaneously
\[
\left|\|v_w\|^2-\frac{\xi^2}{16}\|\mathsf Iw\|_2^2\right|
 \le42500\xi^3\|w\|_1^2,                                    \tag{7.1}
\]
\[
\left|\mathfrak q_A[v_w]-\frac{3\kappa\xi^2}{16}\|\mathsf Iw\|_2^2\right|
 \le351000\kappa\xi^3\|w\|_2^2.                              \tag{7.2}
\]
The \(\ell^1\) norm in (7.1) is not replaced by an \(\ell^2\) norm.
The long-distance covariance entries are retained. Equations (7.1)--(7.2)
are genuine full-vacuum inequalities at fixed nonzero coupling, not
coefficients interpreted outside a finite-box perturbation disk.
Section 12 proves an additional \(\ell^2\) upper bound by a convergent
full-vacuum cluster construction. Sections 13--14 subsequently prove
absolute distance decay and the stronger two-sided \(\ell^2\) remainder
(14.5). Equation (7.1) remains valid on its original larger interval.

On the entire real kernel \(\mathsf Iw=0\), a sharper order statement
follows from the vector calculation. Summing (4.1) gives exactly
\(\Gamma_w\psi=\sum_ew_e(E_e\psi-a_e)\), since
\(\sum_ew_eW_e^{\star}=\sum_p(\mathsf Iw)_pW_p=0\).
Projection perpendicular to \(\psi\) is a contraction, so
\[
\|v_w\|^2\le17640000\xi^4\|w\|_1^2.                          \tag{7.3}
\]
In the sum of (6.1), the same cancellation gives
\(A\Gamma_w\psi=-2b\sum_ew_eD_e\psi\).
Using (6.3) and (4.1), without dividing by a possibly small state norm,
proves
\[
0\le\mathfrak q_A[v_w]\le310800\kappa\xi^4\|w\|_1^2.         \tag{7.4}
\]
The constants are \(4200^2=17640000\) and \(2\cdot4200\cdot37=310800\).
These estimates preserve the already calculated nonzero fourth-order
kernel forms. They do not assert a new lower bound on those forms.
The uniform fourth-order identification and a positive lower bound on
the entire incidence kernel are proved below in (16.21)--(16.24),
using the retained coefficients and a smaller explicit coupling interval.

There is also a uniform, quantitative local Rayleigh result. For any single
link \(e\) and
\[
0<\xi\le\frac1{680000},                                      \tag{7.5}
\]
(5.3), \(r_e\ge2\), and \(42500/680000=1/16\) give
\[
C_{ee}\ge\frac{r_e}{32}\xi^2>0.
\]
Equations (5.3) and (6.4) therefore imply
\[
\left|\frac{\mathfrak q_A[v_e]}{\|v_e\|^2}-3\kappa\right|
 \le\frac{4944000}{r_e}\kappa\xi
 \le2472000\kappa\xi.                                       \tag{7.6}
\]
The numerator in this calculation satisfies
\(|\mathcal N_{ee}-3\kappa C_{ee}|\le154500\kappa\xi^3\),
which supplies the constant in (7.6). This is the energy of the actual
smooth nonzero gauge-invariant local trial vector. By the spectral
variational principle its quotient is an upper bound on the physical
finite-box excitation gap, not a lower bound on that gap.
The explicit range (7.5) is equivalently
\(g_{\rm YM}^4\ge170000\), retaining \(\xi=1/(4g_{\rm YM}^4)\).
Neither \(a\) nor \(L\) appears in this range.
Section 15 proves the matching volume-uniform lower threshold for the
physical operator and every nonzero signed electric state; together they
bound the attained minimum over the entire actual electric-state family.

# 8. Propagation to the original native magnetic state

For the unchanged \(n_2^2\) weights in (1.4), set
\[
\mathcal A_L=\frac{L^2(2L+1)}{15}
 (24L^4+24L^3+8L^2-4L+3),
\]
\[
S_{1,L}=\frac{2L^2(L+1)(2L+1)^2}{3},\qquad
S_{2,L}=\frac{2L^2(L+1)(2L+1)^2(3L^2+3L-1)}{15}.
\]
The exact identities are
\(\|\mathsf Iw^{\rm nat}\|_2^2=4\mathcal A_L\),
\(\|w^{\rm nat}\|_1=S_{1,L}\), and
\(\|w^{\rm nat}\|_2^2=S_{2,L}\). To check them with all boundary
terms, direction-1 links have \(2L\) first coordinates and \(2L+1\)
third coordinates, so the latter two sums are
\(2L(2L+1)\sum_{t=-L}^Lt^2\) and
\(2L(2L+1)\sum_{t=-L}^Lt^4\).
The exact sums are
\(L(L+1)(2L+1)/3\) and
\(L(L+1)(2L+1)(3L^2+3L-1)/15\), respectively; their formulas follow
by taking the difference under \(L\mapsto L+1\) and checking \(L=0\).
For face sums the \(12\) profile is \(t^2+(t+1)^2\), the \(13\)
profile is \(2t^2\), and the \(23\) profile is zero. Counting their
allowed lower corners gives
\[
\mathcal A_L=2L(2L+1)\sum_{t=-L}^{L-1}(t^2+t+1/2)^2
                  +4L^2\sum_{t=-L}^{L}t^4.
\]
The first sum is \(L(4L^4+1)/10\), checked by the two added endpoint
terms and its value at \(L=1\); substitution gives the displayed polynomial.

Equations (7.1)--(7.2) now yield the explicit new remainders
\[
\left|\|v_{w^{\rm nat}}\|^2-\frac{\xi^2}{4}\mathcal A_L\right|
 \le42500\xi^3 S_{1,L}^2,                                    \tag{8.1}
\]
\[
\left|\mathfrak q_A[v_{w^{\rm nat}}]
          -\frac{3\kappa\xi^2}{4}\mathcal A_L\right|
 \le351000\kappa\xi^3 S_{2,L}.                               \tag{8.2}
\]
All native weights are nonnegative, so on each face
\((\sum w_e)^2\ge\sum w_e^2\); summing faces gives
\(4\mathcal A_L\ge\sum_e r_e(w_e^{\rm nat})^2\ge2S_{2,L}\).
Consequently the relative error in the native energy numerator is at most
\(936000\xi\), independently of \(L\). In particular on
\(0<\xi\le1/1872000\) it is at most one half of that numerator's
positive leading term. This is a proved fixed-coupling extensive energy
estimate, not a volume-shrinking perturbative statement.

The upper error-to-leading-term ratio furnished by (8.1) alone
is \(170000\xi S_{1,L}^2/\mathcal A_L\). Its \(L^3\) growth is
visible in the exact polynomials. This bound does not give a uniform
relative error for the native denominator. No step through Section 8 proves
summability of the separated electric correlations, and the
fourth-order leading kernel is not discarded. The proved local covariance
and weighted numerator estimates therefore do not yet establish the
fixed-coupling minimum over every extensive weight or its continuum limit.
This statement records the scope of the inequalities actually proved;
it is not an assertion that the remaining correlations have no relation
to the native state.
Sections 11--12 below prove a uniform full spectral lower bound and
an extensive covariance upper bound on an explicit smaller nonempty
interval. Sections 13--14 then prove a uniform two-sided remainder
by controlling the separated correlations. In particular (14.8) replaces
the \(L^3\) relative loss by the explicitly vanishing \(8\epsilon_\xi\),
and (14.7) applies to the native electric-state quotient. These later
estimates do not change the original coefficients in (8.1)--(8.2).
The gauge-equivariant calculation in Section 15 additionally proves the
uniform signed-state minimum (15.21) and improves the native extensive
upper bound to (15.17); the stronger lower threshold is not obtained by
discarding a small native or signed covariance denominator.

The full physical coefficient conversions are
\[
\xi^2=\frac1{16g_{\rm YM}^8},\quad
\xi^3=\frac1{64g_{\rm YM}^{12}},\quad
\kappa\xi^2=\frac1{8g_{\rm YM}^6a},\quad
\kappa\xi^3=\frac1{32g_{\rm YM}^{10}a}.
\]
Thus, for example, the right side of (8.2) is exactly
\(351000S_{2,L}/(32g_{\rm YM}^{10}a)\).
The actual vacuum energy includes \(2bM=M/(g_{\rm YM}^2a)\)
throughout. The proof does not exchange any spatial, coupling, cusp,
or continuum limits.

# 9. Primary literature, exact dictionaries, and provenance

The local projection method is related to the Feshbach--Schur
reconstruction map, not claimed as a new general projection principle.
Dusson--Sigal--Stamm, *The Feshbach--Schur map and perturbation theory*,
arXiv:2105.02058v1, Theorem 1.2, equation (1.11), and Lemma 2.1 give
the complement inverse and eigenvector reconstruction mechanism
([primary source](https://arxiv.org/abs/2105.02058)). Their finite-rank
perturbation theorem is not used as a volume-uniform hypothesis.
Here \(P=P_S\) has infinite rank when the exterior is nonempty.
For an exact operator dictionary, set
\[
A_S^Q=Q_S(H-\mathcal E)Q_S|_{Q_S\mathcal H_L}
 =B_S|_{Q_S\mathcal H_L}-bQ_SW_SQ_S.
\]
On its domain, when \(2m_S\xi<3/4\), the bound
\(A_S^Q\ge\kappa(3/4-2m_S\xi)>0\) proves its bounded inverse.
The \(Q_S\) block of the full eigen-equation gives exactly
\[
Q_S\psi=b(A_S^Q)^{-1}Q_SW_SP_S\psi.                            \tag{9.1}
\]
The retained block is then
\[
\left[K_S-b^2P_SW_SQ_S(A_S^Q)^{-1}Q_SW_SP_S\right]P_S\psi=0.   \tag{9.2}
\]
Equations (9.1)--(9.2) follow directly by substitution, including the
minus sign and complete exterior operator. Their domains are the
exterior domain of \(K_S\) and its image under the bounded reconstruction
correction. The off-diagonal factors are bounded, so the effective
correction in (9.2) is bounded on the exterior Hilbert space.
Conversely a vector in that domain solving (9.2), inserted into (9.1),
lies in the full domain and solves the original zero-eigenvalue equation.
Applying \(P_S\) to this reconstruction recovers the original exterior
vector; its kernel is therefore zero. This proves the exact bijection
of the two kernels. The estimates in Sections 3--8 instead use (2.8),
whose inverse needs no smallness condition on \(b\); (9.1) explains the
precise relation between the two complement-resolvent presentations.

The canonical corpus also routes Henheik--Teufel--Wessel, *Local stability
of ground states in locally gapped and weakly interacting quantum spin
systems*, arXiv:2106.13780v3, Section 2 and Theorem 7
([primary source](https://arxiv.org/abs/2106.13780)). It permits
infinite-dimensional single-site spaces and unbounded on-site operators.
Its locality constants are existential in the statements read; none is
assigned a numerical value in this note.
The exact model dictionary can be given without changing physical
coordinates. Associate the edge \((n,i)\) to the indexing site
\(x(e)=2n+\mathbf e_i\in\mathbb Z^3\), retaining this map's inverse
on its image: the unique odd coordinate identifies \(i\), and then
\(n=(x-\mathbf e_i)/2\). Attach \(L^2(SU(2))\) and on-site
\(h_{x(e)}=\kappa E_e\) to that site. The on-site gap is
\(3\kappa/4\). Assign a face \(p=(n;i,j)\), \(i<j\), to
its edge \((n,i)\). Its other three indexing sites have \(\ell^1\)
distance \(2\) from \(x(n,i)\). At most two faces are assigned to one
edge, so
\(\Phi_{x(e)}=b\sum_{p\ {\rm assigned\ to}\ e}(2-W_p)\)
has norm at most \(8b\) and range \(2\).
The tensor-permutation unitary defined on elementary tensor functions
by this bijection intertwines the complete Hamiltonian with
\(\sum_xh_x+\sum_x\Phi_x\), including all scalar terms.
The indexing map is not a physical rescaling: the original midpoint is
exactly \(a\,x(e)/2\). The source's small-interaction theorem is not
invoked to supply the explicit constants (3.1)--(8.2); those were proved
above for this precise model.

The local source identities and conventions were read in full in:

- `magnetic_translation_true_vacuum.md`, Sections 1--9, especially
  (1.1), (1.4), (5.3), and (8.1)--(8.5);
- `local_energy_current_true_vacuum.md`, Sections 1--6;
- `wilson_variation/ELECTRIC_COVARIANCE_UNSIGNED_INCIDENCE_20260908.md`,
  Sections 1--8, especially (2.8)--(2.9), (5.7), (6.5), and (7.13);
- `wilson_variation/BULK_PLAQUETTE_EXTENSION.md`, Sections 1--10,
  especially the explicit box-dependent disk and conditional-form maps.

Their common root is `../ym_gap_primary_20260908`.
The complete finite incidence-kernel and second-order coefficient
calculations are preserved there. This note does not repeat those
calculations or promote their \(O_L\) constants to uniform ones.
Its new input to that chain is the independently proved quantitative
local-resolvent control and the resulting estimates above.
The machine-readable lane route records the canonical query results,
primary TeX locators, exact reading coverage, and remaining source reads.

# 10. A uniform score bound and coercivity of the actual conditional operator

The full vacuum equation also controls the conditional density without a
small-coupling expansion. This gives a second volume-independent estimate
useful in the exact elimination construction. It does not presuppose a
spectral gap for the full interacting system.

Use the product Riemannian metric for which the three \(T_a\) fields at
each link are orthonormal; write \(\nabla_e,\Delta_e\) for its link
gradient and Laplacian, and \(\Delta=\sum_e\Delta_e=-\sum_eE_e\).
This is precisely the metric already used in (1.2), not a new physical
metric. In quaternion coordinates \(U=u_0I+i\sum_a u_a\sigma_a\), its
metric is four times the metric of the unit three-sphere: the tangent
vector \(T_a\) at the identity has quaternion Euclidean length \(1/2\),
while its specified Riemannian length is 1. Left multiplication is
orthogonal on quaternions, so this identity holds at every point.
Consequently a link factor is isometric to the round sphere of radius 2.
Its sectional curvature is \(1/4\), Ricci tensor is \(g/2\), and diameter
is \(2\pi\). The curvature coefficient also follows from the second
fundamental form of the radius-2 sphere: its normal derivative has
magnitude \(1/2\), the Gauss equation gives sectional curvature \(1/4\),
and summing the two transverse sectional curvatures gives \(1/2\).
These computations retain the factor four relative to \(c\).

Put \(u=\log\psi\), a globally smooth real function because \(\psi>0\).
Dividing the eigen-equation by the same positive \(\psi\), with its
original unit norm left unchanged, yields the exact nonlinear equation
\[
\Delta u+|\nabla u|^2=\frac{V-\mathcal E}{\kappa},
\qquad V=b\sum_{p\in\mathsf P_L}(2-W_p).                         \tag{10.1}
\]
For each fixed link \(e\) define \(w_e=|\nabla_eu|^2\), and let
\(\nabla_f\nabla_eu\) denote the covariant derivative, in factor \(f\),
of the factor-\(e\) gradient. On the product manifold the partial
Bochner identity is
\[
\Delta w_e
=2\sum_f|\nabla_f\nabla_eu|_{\rm HS}^2
 +2\langle\nabla_eu,\nabla_e\Delta u\rangle+w_e.                  \tag{10.2}
\]
Here is its coordinate derivation. Take orthonormal geodesic frames
in every factor at the point under consideration. Applying each
second derivative in \(\Delta_f\) to the sum of squares of the three
components of \(\nabla_eu\) gives twice their squared first derivatives
plus twice their contraction with the second derivative of the vector.
For \(f\ne e\), the product connection has zero mixed curvature, so that
second derivative commutes with \(\nabla_e\). For \(f=e\), commuting
the covariant derivatives of the differential \(du\) gives
\[
\Delta_e^{\rm rough}\nabla_eu
=\nabla_e\Delta_eu+\operatorname{Ric}_e(\nabla_eu).
\]
This sign can equally be read from the positive sectional-curvature
Gauss formula above. The Ricci contraction in the differentiated norm
is \(2\operatorname{Ric}_e(\nabla_eu,\nabla_eu)=w_e\).
Adding the factor equations proves (10.2).
The scalar smooth Bochner identity, with the same sign of \(\Delta\),
is given in C. Villani, *Optimal Transport: Old and New*, Chapter 14,
equation (14.28), printed p.388 (PDF p.394 in the indexed local edition).
The partial-factor and vacuum substitutions used here are calculated
explicitly, rather than inferred from a dimension-independent constant
not stated there.

Let \(\mathcal D_u=\Delta+2\langle\nabla u,\nabla\,\cdot\,\rangle\).
Differentiating (10.1) and using the symmetry of the full Hessian gives
\[
\mathcal D_u w_e
=2\sum_f|\nabla_f\nabla_eu|_{\rm HS}^2+w_e
 +\frac2\kappa\langle\nabla_eu,\nabla_eV\rangle.                 \tag{10.3}
\]
In detail, the derivative of \(|\nabla u|^2\) in factor \(e\)
is \(2(\nabla^2u\,\nabla u)_e\). Its contraction with \(2\nabla_eu\)
in (10.2) is minus \(4\nabla^2u(\nabla u,\nabla_eu)\).
The drift applied to \(w_e\) is plus that same quantity. This proves
the cancellation with every mixed factor \(f\) included.

**Theorem 10.1.** For all \(L\ge2\), \(a,g_{\rm YM}>0\), and each link,
\[
\|\nabla_e\log\psi\|_\infty\le2r_e\xi,\qquad
\|\nabla_e\log\rho\|_\infty\le4r_e\xi,\qquad \rho=\psi^2.        \tag{10.4}
\]
In particular
\[
0\le\gamma_e\le4r_e^2\xi^2.                                   \tag{10.5}
\]
This improves the constant in the earlier valid bound (3.1).
All estimates (4.1)--(8.2) remain valid with their displayed constants.

**Proof.** Equation (6.2) gives \(|\nabla_eW_p|\le1\) for every
face at \(e\), and all other face derivatives vanish. Thus
\(|\nabla_eV|\le br_e\), without any factor \(M\).
The smooth nonnegative function \(w_e\) attains its maximum on the
compact product. At that point its full gradient vanishes and
\(\Delta w_e\le0\). Equation (10.3) therefore gives
\[
0\ge w_e-2r_e\xi\sqrt{w_e}.
\]
If the maximum is zero the conclusion is immediate. Otherwise dividing
by its positive square root gives \(\sqrt{w_e}\le2r_e\xi\).
This proves the first bound everywhere. Since \(\log\rho=2u\), the
second follows with its exact factor two. Finally integration by parts
gives
\(\gamma_e=\int|\nabla_e\psi|^2dU=\int\rho|\nabla_eu|^2dU\);
its probability integral and (10.4) prove (10.5). \(\square\)

To apply this to the actual conditional operator, fix a nonempty set
\(S\) of eliminated links and write \(r=U_{S^c}\), \(s=U_S\). Define
\[
\rho_{S^c}(r)=\int\rho(s,r)\,ds,\qquad
p_S(s\mid r)=\frac{\rho(s,r)}{\rho_{S^c}(r)},\qquad
\omega_S=8\pi\xi\sum_{e\in S}r_e.                              \tag{10.6}
\]
These are the marginal and conditional density of the same vacuum,
not a postulated Wilson Gibbs density. Holding \(r\) fixed and joining
two \(S\)-configurations one link at a time by minimizing geodesics,
(10.4) and the diameter \(2\pi\) give
\[
\sup_s\log p_S(s\mid r)-\inf_s\log p_S(s\mid r)\le\omega_S.      \tag{10.7}
\]
The denominator in (10.6) cancels from this oscillation. No differentiability
or uniform limit of the exterior marginal is assumed.

The product Haar Poincare inequality on \(S\), with its exact
single-link spectral coefficient, is
\[
\inf_{c\in\mathbb C}\int|F-c|^2ds
\le\frac43\sum_{e\in S}\int|\nabla_eF|^2ds.                     \tag{10.8}
\]
To prove it, expand \(F\) in the complete product matrix-coefficient
basis used in Section 2. Removing the constant leaves at least one
nonzero spin, so its total electric eigenvalue is at least \(3/4\).
Parseval gives (10.8) first for finite sums and then by form closure
for every \(H^1\) function.
For each exterior \(r\), let \(p_{\max},p_{\min}\) be the maximum
and minimum of its smooth positive conditional density on \(S\).
Minimize over \(c\), first bound the density above, apply (10.8), and
then bound it below in the energy integral. This gives the full
comparison calculation
\[
\begin{split}
\operatorname{Var}_{p_S(\cdot\mid r)}(F)
&\le p_{\max}\inf_c\int|F-c|^2ds\\
&\le\frac{4p_{\max}}3\sum_{e\in S}\int|\nabla_eF|^2ds\\
&\le\frac43 e^{\omega_S}
       \sum_{e\in S}\int|\nabla_eF|^2p_S(s\mid r)\,ds .
\end{split}                                                   \tag{10.9}
\]
The minimum characterization of variance is valid for complex functions
as well, with the complex mean as minimizer. This proof records the
entire density ratio; it is the bounded-density perturbation argument,
not a replacement of either measure.

Let \(\mathscr H_\rho=L^2(\rho\,dU)\), and define the exact isometry
\[
J_S:L^2(\rho_{S^c}\,dr)\longrightarrow\mathscr H_\rho,\qquad
(J_SF)(s,r)=F(r).
\]
Its adjoint is
\[
(J_S^*G)(r)=\int G(s,r)p_S(s\mid r)\,ds.
\]
Fubini verifies the inner-product identity for the adjoint and
\(J_S^*J_S=I\). Thus
\(P_S^\rho=J_SJ_S^*\) and \(Q_S^\rho=I-P_S^\rho\) are
orthogonal projections; \(\mathscr K_S^\rho=\ker J_S^*\)
is the conditional-mean-zero space. The multiplication map
\(U_\psi:G\mapsto\psi G\) is a unitary \(\mathscr H_\rho\to\mathcal H_L\).
The exact ground-state transform and its closed form are
\[
\mathscr L_\rho=U_\psi^{-1}(H-\mathcal E)U_\psi
 =-\kappa(\Delta+\langle\nabla\log\rho,\nabla\,\cdot\,\rangle),
\qquad
q_\rho[G]=\kappa\sum_e\int|\nabla_eG|^2\rho\,dU.                 \tag{10.10}
\]
At each fixed box the density and its reciprocal are smooth and bounded
on a compact space. Differentiating the conditional integral shows that
\(P_S^\rho,Q_S^\rho\) preserve \(H^1\): a retained derivative gives the
conditional integral of the input derivative and a bounded smooth
derivative of the conditional kernel; an eliminated derivative of the
output is zero. The constants in this domain-preservation statement
need not be uniform, and are not used for the coercivity bound below.
Applying \(Q_S^\rho\) to smooth \(H^1\) approximants proves that
\(H^1\cap\mathscr K_S^\rho\) is the form closure of its smooth elements
and dense in \(\mathscr K_S^\rho\).

Define \(C_S^\rho\) as the self-adjoint operator of the restricted
closed form \(q_\rho|_{H^1\cap\mathscr K_S^\rho}\). Explicitly its
domain consists of those \(G\) in that form space for which there is
\(h\in\mathscr K_S^\rho\) satisfying
\(q_\rho(F,G)=\langle F,h\rangle_\rho\) for every \(F\) in the form
space, and \(C_S^\rho G=h\). This definition makes no unproved claim
about the domain of a formal operator product.

**Theorem 10.2.** For every positive coupling and every finite box,
\[
C_S^\rho\ge\frac{3\kappa}{4}e^{-\omega_S}I,\qquad
\|(C_S^\rho)^{-1}\|\le\frac4{3\kappa}e^{\omega_S}.              \tag{10.11}
\]
In particular for a single eliminated link \(e\),
\[
C_{\{e\}}^\rho\ge\frac{3\kappa}{4}e^{-8\pi r_e\xi}I
\ge\frac{3\kappa}{4}e^{-32\pi\xi}I.                            \tag{10.12}
\]
These single-link bounds are independent of all exterior volume and
valid for the actual interacting conditional density.

**Proof.** A vector \(G\in\mathscr K_S^\rho\) has zero conditional
mean for almost every \(r\). Apply (10.9) to its conditional slices
and multiply by \(\rho_{S^c}(r)\); integrate in \(r\). Fubini gives
\[
\|G\|_\rho^2\le\frac43 e^{\omega_S}
       \sum_{e\in S}\int|\nabla_eG|^2\rho\,dU
\le\frac4{3\kappa}e^{\omega_S}q_\rho[G].
\]
Smooth approximation extends this inequality to the entire restricted
form domain. The form representation and spectral theorem yield
(10.11); \(r_e\le4\) gives (10.12).
The unitary \(U_\psi\) carries this form onto the full physical
excitation form restricted to \(U_\psi\mathscr K_S^\rho\), so the
constant has not been transferred between different operators without
a domain map. Gauge transformations preserve the density and intertwine
conditional integration by endpoint Haar invariance. Consequently these
projections, forms, and inverses preserve the physical gauge-invariant
subspaces as well. \(\square\)

For comparison with the original parameters, the last bound in (10.12) is
\[
\frac{3g_{\rm YM}^2}{2a}
       \exp\!\left(-\frac{8\pi}{g_{\rm YM}^4}\right).
\]
For larger eliminated sets the bound is also explicit, but its dependence
on \(\sum_{e\in S}r_e\) is retained. No volume-independent extensive-block
bound is inferred by deleting that sum.
Nor does a uniform conditional one-link gap alone tensorize into a
uniform gap for the correlated full density. The proof has established
an inverse for the actual eliminated operator, not a separated-correlation
estimate or the Millennium spectral conclusion.
The full finite-box spectral bound proved in Section 12 uses an
independently convergent cluster construction, not an assumed
tensorization of these conditional inequalities.

The indexed Villani PDF has stable unit ID
\nolinkurl{PUBUNIT-3B56736161C0B49850EA7433}, SHA-256
\nolinkurl{3AE2DB61CBFFADFEEF0DE738742F4F3CE81B21874DACB1AD2991A7000434675D}.
Its contents and the complete printed pp.387--389, including equation
(14.28), were read directly; the book is cited, not copied into this
repository. The page reference is to that exact local edition rather
than an assumed page number in every edition.

# 11. An explicit convergent cluster coordinate construction for the full vacuum

The source method used here is the commuting creation-coordinate construction
in D. A. Yarotsky, *Quasi-particles in weak perturbations of non-interacting
quantum lattice systems*, arXiv:math-ph/0411042v1, Section 2, equations
labelled mmo, c1, vsum, thl and sumj in the retained source TeX
([primary source](https://arxiv.org/abs/math-ph/0411042)).
That section explicitly permits infinite-dimensional single-site spaces
and unbounded on-site operators. Its smallness constants are not numerical.
The following proof derives its own constants for the complete four-link
Wilson interaction. The method is not claimed new. No finite-spin
truncation is made, and no rescaling of the original Hamiltonian or
vacuum is made.

Write
\[
H_0=\kappa\sum_eE_e,\qquad V_p=-bW_p,\qquad
H=H_0+2bM+\sum_pV_p,\qquad \gamma=\frac{3\kappa}{4}.
                                                               \tag{11.1}
\]
Thus \(\|V_p\|\le J:=2b\), each face has \(s=4\) distinct links,
and each link belongs to at most \(d=4\) faces. The scalar \(2bM\)
remains in (11.1) and in the eigenvalue equation below. It commutes with
every coordinate transformation and has zero nonconstant component;
these facts, not deletion of its value, account for its absence from
the nonconstant fixed-point equation.

Let \(\Omega=1\) in the original product Haar probability space. For
\(I\subset\mathsf E_L\), put
\[
\mathcal H'_I=\bigotimes_{e\in I}
       \bigl(L^2(SU(2))\ominus\mathbb C1\bigr),\qquad
\mathcal H'_\varnothing=\mathbb C.
\]
The canonical orthogonal tensor decomposition gives a unitary map
\[
\mathcal T:\bigoplus_{I\subset\mathsf E_L}\mathcal H'_I
 \longrightarrow\mathcal H_L,\qquad
\mathcal T(z)=\sum_I z_I\otimes1_{I^c}.                         \tag{11.2}
\]
Its inverse component \(\Pi_I\) is obtained by Haar integration over
\(I^c\) and application of the nonconstant projection in every link
of \(I\). Product projections prove both inverse identities in (11.2).
For nonempty \(I\), set \(H_I=\kappa\sum_{e\in I}E_e\) on
\(\mathcal H'_I\). The separate nonzero spins prove
\[
H_I\ge\gamma |I|,\qquad
\|H_I^{-1}\|\le(\gamma |I|)^{-1}.                              \tag{11.3}
\]

For \(z_I\in\mathcal H'_I\), define the bounded operator, on the \(I\)
factor and tensored with the exterior identity, by
\[
\widehat z_I f=z_I\langle1_I,f\rangle_{L^2(SU(2)^I)}.
                                                               \tag{11.4}
\]
The inner product is the one fixed in Section 1, so (11.4) is linear
in \(f\). Its norm is \(\|z_I\|\). Integration of any one common
nonconstant link proves
\[
\widehat z_I\widehat y_K=
\begin{cases}
0,&I\cap K\ne\varnothing,\\
\widehat{z_I\otimes y_K},&I\cap K=\varnothing.
\end{cases}                                                   \tag{11.5}
\]
For entangled vectors the same calculation follows by approximation
by finite elementary tensors in \(\mathcal H'_I,\mathcal H'_K\);
operator norms converge by (11.4). In particular all these operators
commute. A product of more than \(N=|\mathsf E_L|\) nonempty
creation operators is zero.

Use the graph whose vertices are physical links and whose distinct
vertices are adjacent precisely when they share a face. For nonempty
\(I\), let \(\ell(I)\) be the smallest number of edges of a connected
subgraph containing \(I\); extra vertices are allowed. The finite
full-box graph is connected. Define
\[
\omega(I)=2^{\ell(I)+1}.
\]
Monotonicity under inclusion holds. For a face support \(p=\partial p\)
the induced graph is a four-vertex clique, so \(\ell(p)=3\) and
\(\omega(p)=16\). If each \(I_j\) meets \(p\), connected minimizing
subgraphs and a tree on \(p\) have connected union. Therefore
\[
\omega\left(p\cup\bigcup_{j=1}^n I_j\right)
 \le16\prod_{j=1}^n\omega(I_j).                               \tag{11.6}
\]
No replacement of physical coordinates is involved in this graph.

Take the Banach space of collections \(z=(z_I)_{I\ne\varnothing}\),
\(z_I\in\operatorname{Dom}(H_I)\), with norm
\[
\|z\|_*=\max_x\sum_{I\ni x}
     \omega(I)\frac{\|H_Iz_I\|}{\gamma}.
                                                               \tag{11.7}
\]
There are finitely many \(I\), and each energy norm is complete by
the bounded inverse in (11.3), so (11.7) is complete. In particular,
writing \(a_I=\omega(I)\|z_I\|\), one has
\[
\sup_x\sum_{I\ni x}|I|a_I\le\|z\|_*,
\qquad
\sum_{I:I\cap p\ne\varnothing}a_I\le s\|z\|_* .                \tag{11.8}
\]
Let \(C(z)=\sum_{I\ne\varnothing}\widehat z_I\).
It is bounded in each finite box. Its exponential and inverse are
the finite polynomials \(e^{C(z)}\) and \(e^{-C(z)}\) by (11.5).
On the full domain of \(H_0\),
\[
[H_0,\widehat z_I]=\widehat{H_Iz_I},\qquad
e^{-C(z)}H_0e^{C(z)}
 =H_0+\sum_{I\ne\varnothing}\widehat{H_Iz_I}.                  \tag{11.9}
\]
To check domains, the exterior part of \(H_0\) commutes with (11.4);
the local part annihilates the Haar bra, and its action on the ket
is \(H_Iz_I\). This first proves the commutator on finite spectral
tensors. Its bounded right-hand side extends it to the full graph
domain by approximation. Thus \(C(z)\), its powers, and both
exponentials preserve that domain. The second commutator in (11.9)
vanishes by (11.5), proving the exact conjugation formula.

The fixed-point map is
\[
\mathcal F(z)_I=-H_I^{-1}\Pi_I
  e^{-C(z)}\left(\sum_pV_p\right)e^{C(z)}\Omega,
       \qquad I\ne\varnothing.                              \tag{11.10}
\]
The projection output is an arbitrary vector of \(\mathcal H'_I\);
(11.3) places \(\mathcal F(z)_I\) in the correct operator domain.
We now bound (11.10), including all clusters, rather than assuming
the convergence estimate quoted in the source.

For a fixed face \(p\), expand
\[
e^{-C(z)}V_pe^{C(z)}
 =\sum_{n\ge0}\frac1{n!}
    [\cdots[[V_p,C(z)],C(z)],\ldots,C(z)].
                                                               \tag{11.11}
\]
Only indices \(I_j\) meeting \(p\) contribute: a creation operator
disjoint from \(p\) commutes with \(V_p\) and with all other creation
operators. Every \(n\)-fold nested commutator expands into \(2^n\)
ordered words. A nonzero word has disjoint creation supports on
each side of \(V_p\). Since they all meet the four-link support of
\(V_p\), there are at most four on either side. Thus (11.11)
actually ends at \(n=8\). Infinite exponential sums used below are
upper bounds for this finite exact polynomial.

There is a dimension-independent bound on the tensor-sector sum of
each word acting on \(\Omega\). Outside \(p\), \(V_p\) acts as
identity. A common outside link of two creation supports annihilates
the word, by integrating a nonconstant factor. Otherwise the outside
excitation set is exactly \((\bigcup_jI_j)\setminus p\).
Only the choice of excited links inside \(p\) varies in the output.
There are at most \(2^s=16\) such orthogonal sectors. Cauchy--Schwarz
and (11.4) give
\[
\sum_K\|\Pi_K(\hbox{word})\Omega\|
 \le2^{s/2}J\prod_{j=1}^n\|z_{I_j}\|
 =4J\prod_{j=1}^n\|z_{I_j}\|.                                \tag{11.12}
\]
The argument is unchanged for entangled creation vectors by the
elementary-tensor approximation already used in (11.5).

Each nonempty output sector \(K\) is contained in
\(p\cup\bigcup_jI_j\). To bound the anchored sum for \(x\in K\),
cover its possibilities by \(x\in p\) and \(x\in I_j\).
For the first possibility there are at most \(d\) choices of \(p\);
(11.8) bounds each remaining index sum by \(sR\), where
\(R=\|z\|_*\). For the second, choose \(j\), then \(I_j\ni x\).
At most \(d|I_j|\) faces meet that set; the first inequality in
(11.8) absorbs this full factor \(|I_j|\). Thus the respective
anchored bounds for the product sums are
\[
d(sR)^n,\qquad ndR(sR)^{n-1}.                                \tag{11.13}
\]
The second quantity is zero for \(n=0\).
Combining (11.6), (11.10)--(11.13), and the exact cancellation of
\(H_I\) against its inverse yields
\[
\|\mathcal F(z)\|_*
\le\frac{4Jd\,16}{\gamma}
 \sum_{n\ge0}\frac{2^n}{n!}
       \bigl[(sR)^n+nR(sR)^{n-1}\bigr]
=\frac{2048}{3}\xi(1+2R)e^{8R}.                              \tag{11.14}
\]
This anchor counting, rather than the norm of the full perturbation,
removes the factor \(M\).

For two collections in a ball of radius \(R\), telescope each
multilinear word in (11.11), inserting their difference in one
position at a time. The counting (11.13) holds with the norm of that
difference in its position, whether the anchor is there or elsewhere.
For the homogeneous degree-\(n\) bound this multiplies its coefficient
by \(nR^{n-1}\) instead of \(R^n\). Differentiating the positive
majorant series in (11.14) proves
\[
\|\mathcal F(z)-\mathcal F(y)\|_*
 \le\frac{2048}{3}\xi(10+16R)e^{8R}\|z-y\|_* .                \tag{11.15}
\]
This is a bound on the exact finite commutator map, not on a
truncated approximation to the vacuum.

Set \(R_*=1/16\). Since
\(\sum_{n\ge0}(1/2)^n/n!<\sum_{n\ge0}(1/2)^n=2\), (11.14)--(11.15)
give, on the explicit nonempty interval
\[
0<\xi\le\frac1{49152},                                      \tag{11.16}
\]
\[
\|\mathcal F(z)\|_*\le1536\xi\le\frac1{32}<R_*,
\qquad
\operatorname{Lip}(\mathcal F)\le\frac{45056}{3}\xi
 \le\frac{11}{36}<1.                                       \tag{11.17}
\]
Iteration from zero therefore converges in the complete ball to a
unique fixed point \(z\). More explicitly, successive increments
are bounded by a geometric series of ratio \(11/36\); the limit
solves (11.10) by continuity, and applying (11.15) to two fixed
points proves uniqueness. Complex conjugation preserves the real
Wilson potential, the Haar projections and the inverses \(H_I^{-1}\).
It commutes with the iteration, so \(z\), \(e^{C(z)}\Omega\), and
the eigenvalue below are real.

Equations (11.9)--(11.10) show that
\[
\phi=e^{C(z)}\Omega,\qquad
H\phi=\varepsilon\phi,\qquad
\varepsilon=2bM+
 \Pi_\varnothing e^{-C(z)}\left(\sum_pV_p\right)e^{C(z)}\Omega.
                                                               \tag{11.18}
\]
Every nonempty creation product has zero Haar integral, hence
\(\langle\Omega,\phi\rangle=1\), so \(\phi\ne0\).
The next section proves that \(\varepsilon=\mathcal E\), and identifies
the exact scalar relating \(\phi\) to the unchanged physical unit
vacuum. No equality of these differently specified vectors is presumed.

# 12. Uniform full spectral estimate and the extensive electric covariance

In this section (11.16) holds. Fix its constructed \(z\) and abbreviate
\(C=C(z)\). The bounded invertible similarity
\[
\widetilde H=e^{-C}(H-\varepsilon)e^C=H_0+\mathcal K,\qquad
\widetilde H\Omega=0                                       \tag{12.1}
\]
has the full domain of \(H_0\), by (11.9).
It is not asserted unitary. Both similarities and the exact physical
Hamiltonian, including its ground energy, remain explicit.

Give the finite orthogonal sector decomposition the additional norm
\[
\|f\|_{\oplus,1}=\sum_I\|\Pi_If\|,\qquad
\|f\|\le\|f\|_{\oplus,1}\le2^{N/2}\|f\|.                     \tag{12.2}
\]
The second inequality is Cauchy--Schwarz over all \(2^N\) sectors.
Thus the norm has exactly the same vectors and topology in each
fixed box. The equivalence constant depends on volume; no uniform
claim about that equivalence is used.

For \(u_I\in\operatorname{Dom}(H_I)\), (11.5), (11.9), (12.1)
and \(\widetilde H\Omega=0\) give exactly
\[
\mathcal K\,\widehat u_I\Omega
=e^{-C}\left[\sum_pV_p,\widehat u_I\right]e^C\Omega .
                                                               \tag{12.3}
\]
In detail, commute \(\widetilde H\) with \(\widehat u_I\);
the \(H_0\) commutator supplies \(H_Iu_I\), while the creation
sum in (11.9) commutes with \(\widehat u_I\). For the remaining
term, \(e^C\) commutes with \(\widehat u_I\), proving (12.3).
Faces disjoint from \(I\) have zero commutator, so at most
\(d|I|\) faces remain.

Expand each remaining conjugation as in (11.11). All additional
creation indices still have to meet \(p\): the derivation identity
and commutation with \(\widehat u_I\) allow the nested commutators
to be written as the commutator with \(\widehat u_I\) of the
corresponding conjugated \(V_p\).
The output outside \(p\) now has the fixed excited support
\((I\cup\bigcup_jI_j)\setminus p\), or the word vanishes.
Thus (11.12) applies with an extra factor \(\|u_I\|\).
The commutator with \(\widehat u_I\) contributes two words.
Using \(\sum_{K:K\cap p\ne\varnothing}\|z_K\|\le sR_*\) gives
\[
\|\mathcal K\widehat u_I\Omega\|_{\oplus,1}
\le 8Jd\,|I|\,e^{8R_*}\|u_I\|.
                                                               \tag{12.4}
\]
The bound also applies to the empty component with value zero.
Summing (12.4) and using (11.3) proves the relative operator bound
\[
\|\mathcal Kf\|_{\oplus,1}
\le c_\xi\|H_0f\|_{\oplus,1},\qquad
c_\xi=\frac{512}{3}\xi\le\frac1{288}<1,
       \quad f\in\operatorname{Dom}(H_0).                    \tag{12.5}
\]
Indeed \(8Jd/\gamma=256\xi/3\), and \(e^{8R_*}=e^{1/2}<2\).
The bound on finite spectral tensors extends in the graph norm;
all factors in (12.3) preserve the required domain as proved above.

Here is the resolvent argument with no appeal to a missing uniform
perturbation theorem. On every nonempty sector \(I\),
\(\operatorname{Spec}(H_I)\subset[\gamma|I|,\infty)\).
For real \(t<0\), functional calculus gives
\[
\|\mathcal K(H_0-t)^{-1}\|_{\oplus,1}
 \le c_\xi\sup_{\lambda\ge\gamma}
          \frac{\lambda}{\lambda-t}\le c_\xi<1.
\]
For \(0<t<(1-c_\xi)\gamma\), it gives instead
\[
\|\mathcal K(H_0-t)^{-1}\|_{\oplus,1}
 \le\frac{c_\xi\gamma}{\gamma-t}<1.                           \tag{12.6}
\]
The empty sector causes no term because \(\mathcal K\Omega=0\).
The geometric Neumann series for
\((I+\mathcal K(H_0-t)^{-1})^{-1}\), followed by
\((H_0-t)^{-1}\), is a bounded inverse of \(\widetilde H-t\).
The domain is verified by the resolvent's graph-domain image.
Norm equivalence (12.2) makes it also a bounded inverse in the
original Hilbert space, without changing the numerical spectral
exclusion (12.6). Similarity (12.1) transfers this inverse to
\(H-\varepsilon-t\).

The original \(H\) is self-adjoint, \(\varepsilon\) is its real
eigenvalue, and no spectrum lies below it by the \(t<0\) argument.
Thus \(\varepsilon=\mathcal E\). Its simple positive ground vector
was proved in Section 1. The exact identification is therefore
\[
\psi=\alpha e^C\Omega,\qquad
\alpha=\langle\Omega,\psi\rangle>0,\qquad
\alpha^2\|e^C\Omega\|^2=1.                                  \tag{12.7}
\]
This records the physical scalar and preserves the original unit
vacuum rather than replacing it with a coefficient-normalized vector.
The spectrum above it obeys the explicit volume-independent estimate
\[
(H-\mathcal E)\big|_{\psi^\perp}
 \ge\gamma(1-c_\xi)I
 =\frac{3\kappa}{4}\left(1-\frac{512}{3}\xi\right)I
 \ge\frac{287\kappa}{384}I .                                \tag{12.8}
\]
This follows from (12.6) and the spectral theorem, since the ground
eigenvalue is simple. Restricting the same inequality to the
gauge-invariant subspace retains it, because that closed subspace
reduces \(H\) and contains \(\psi\).
Section 15 proves that the cluster similarity itself intertwines this
constraint. Its restricted free threshold is exactly \(3\kappa\), so
(15.13) improves the physical restriction of (12.8), not the full-space
inequality or the numerical fixed-point constants.
In original parameters its range and last lower bound are
\[
g_{\rm YM}^4\ge12288,\qquad
\frac{287g_{\rm YM}^2}{192a}.
                                                               \tag{12.9}
\]
This is a strong-coupling, fixed-spatial-regulator theorem for the
full interacting finite boxes. No spatial continuum limit or
Millennium conclusion follows by deleting its coupling range.

The spectral estimate has an immediate quantitative consequence for
the previously unresolved extensive covariance upper bound.
Every \(v_w\) in Section 7 is perpendicular to \(\psi\), so the
spectral theorem and (12.8) imply
\[
\|v_w\|^2\le
\frac{4}{3\kappa(1-c_\xi)}\,\mathfrak q_{H-\mathcal E}[v_w].
\]
Combining this with the already proved all-weight estimate (7.2)
gives, for every real weight vector and every box,
\[
0\le w^TCw\le
\frac{\xi^2\|\mathsf Iw\|_2^2/4
             +468000\xi^3\|w\|_2^2}{1-512\xi/3}.
                                                               \tag{12.10}
\]
The norm of \(\mathsf I\) is at most 4: on each face,
\((\sum_{e\in\partial p}w_e)^2\le4\sum_{e\in\partial p}w_e^2\);
summing faces and retaining \(r_e\le4\) proves
\(\|\mathsf Iw\|_2^2\le16\|w\|_2^2\).
Consequently the fully extensive matrix upper bound is
\[
0\le C\le
\frac{4\xi^2+468000\xi^3}{1-512\xi/3}\,I_{\mathbb R^{\mathsf E_L}}.
                                                               \tag{12.11}
\]
This removes the \(\ell^1\)-squared volume loss from an upper bound
on the exact covariance. This argument alone does not assert the entrywise absolute
row summability of \(C\), or an \(\ell^2\) remainder of order
\(\xi^3\) around \(\xi^2\mathsf I^T\mathsf I/16\).
Positive-semidefinite order and absolute-value entry sums are not
interchanged.
Sections 13--14 prove the separate absolute-row and two-sided claims by
an explicit locality and spectral-filter calculation.

For the original native weights the exact substitution is
\[
\|v_{w^{\rm nat}}\|^2\le
\frac{\xi^2\mathcal A_L+468000\xi^3S_{2,L}}{1-512\xi/3}.
                                                               \tag{12.12}
\]
Using \(S_{2,L}\le2\mathcal A_L\), proved in Section 8, yields
\[
\|v_{w^{\rm nat}}\|^2\le
\xi^2\mathcal A_L
\frac{1+936000\xi}{1-512\xi/3}.
                                                               \tag{12.13}
\]
Unlike (8.1), this upper control has no \(L^3\) relative loss.
Equation (8.1) remains a valid two-sided remainder with its original
constants; (12.13) supplies a different, stronger extensive upper
control on the nonempty range (11.16).
On the entire leading kernel \(\mathsf Iw=0\), (12.10) also yields
\[
\|v_w\|^2\le\frac{468000\xi^3}{1-512\xi/3}\|w\|_2^2.
                                                               \tag{12.14}
\]
This complements, and does not discard, the fourth-order
\(\ell^1\)-weighted bound (7.3) and the parent's exact fourth-order
calculation. The upper bounds (12.10)--(12.14) alone do not give
a two-sided estimate for the minimum over all signed actual states.
The uniform minimum, as opposed to every individual signed quotient,
is obtained in (15.21) by the gauge-restricted spectral argument.
Equations (15.15)--(15.17) also strengthen these PSD upper bounds by a
factor of four. The original fourth-order kernel coefficients are
retained; (16.21) supplies their uniform covariance and energy remainders.

Finally the same result improves exact extensive elimination, not only
the electric variational family. For every nonempty eliminated set
\(S\), a vector \(G\in\ker J_S^*\) satisfies
\[
\int G\rho\,dU=\int (J_S^*G)(r)\rho_{S^c}(r)\,dr=0.
\]
Thus \(U_\psi G=\psi G\) is perpendicular to the actual ground
vector. Apply (12.8) to its form and use (10.10), first on smooth
vectors and then by the proved form closure. This yields
\[
C_S^\rho\ge\frac{3\kappa}{4}(1-512\xi/3)I
 \ge\frac{287\kappa}{384}I
 \quad\left(0<\xi\le\frac1{49152}\right),                    \tag{12.15}
\]
\[
\|(C_S^\rho)^{-1}\|
 \le\frac{4}{3\kappa(1-512\xi/3)}
 \le\frac{384}{287\kappa}.                                  \tag{12.16}
\]
Every constant in (12.15)--(12.16) is independent of the size,
shape and location of \(S\), as well as the exterior volume.
The operator is precisely the restricted full form \(C_S^\rho\)
defined in Section 10, containing derivatives in all link directions.
It is not replaced by a conditional-fibre differential operator
containing only eliminated derivatives. The all-positive-coupling
bound (10.11) remains available outside (11.16). On their common
range both lower bounds hold, so the larger of the two constants
may be used. The unitary and gauge maps remain exactly those
proved in Section 10.

For the reducing gauge-invariant conditional-complement space,
(15.22)--(15.23) prove the sharper inverse constant \(96/(287\kappa)\).
The projection and unitary supplying that restriction are explicit.

# 13. Absolute decay of the unbounded electric covariance

Throughout Sections 13--14, \(0<\xi\le1/49152\). Retain \(H,\psi\)
and \(E_e\) exactly as in Section 1, and set
\[
\Delta_*=\frac{287\kappa}{384},\qquad
Q_\psi=I-|\psi\rangle\langle\psi|,\qquad
\alpha_t(O)=e^{itH}Oe^{-itH}.
\]
Equation (12.8), not an additional assumption, gives
\(A|_{\psi^\perp}\ge\Delta_*\), where \(A=H-\mathcal E\).
Let \(d(e,f)\) be distance in the shared-face graph of Section 11.
We will prove
\[
|C_{ef}|\le1200\xi e^{-d(e,f)/4}\qquad(e\ne f).               \tag{13.1}
\]
This is a bound on the original electric operators, which are unbounded.
No finite-spin Hamiltonian or approximate ground state is introduced.

The two primary methods are B. Nachtergaele and R. Sims,
*On the dynamics of lattice systems with unbounded on-site terms in the
Hamiltonian*, arXiv:1410.8174v1, Sections 2--3, especially Proposition 2.1,
Lemma 2.2 and the proof of Theorem 3.1
([source](https://arxiv.org/abs/1410.8174v1)), and the same authors,
*Lieb-Robinson Bounds and the Exponential Clustering Theorem*,
Commun. Math. Phys. 265 (2006), 119--130,
arXiv:math-ph/0506030v3, Theorem 2, Section 3.2 and Lemma 1
([source](https://arxiv.org/abs/math-ph/0506030v3)).
The former explicitly repairs domain and strong-continuity issues in
earlier unbounded-on-site proofs. Both source TeX files are retained.
We prove the numerical bounds and the electric-operator passage below;
neither is obtained by assigning constants to an existential statement.

## 13.1. A second electric moment and an exact cutoff comparison

For \(S=\{e\}\), joint spectral calculus in (2.7) gives, for
\(f\in\operatorname{Dom}(E_e)\),
\[
\|E_e^2R_{\{e\}}f\|\le\kappa^{-1}\|E_ef\|.
\]
Indeed, on a nonconstant link sector the multiplier satisfies
\(\lambda_e^2/(\kappa\lambda_e+k)\le\lambda_e/\kappa\);
it vanishes on the constant link sector. Applying this to the smooth
vector \(W_e^\star\psi\) in (2.8), and noting \(E_e^2P_{\{e\}}\psi=0\),
proves
\[
\|E_e^2\psi\|\le\xi\|E_e(W_e^\star\psi)\|
\le\frac{3r_e}{2}\xi+8r_e^2\xi^2
\le6\xi+128\xi^2\le7\xi.                                   \tag{13.2}
\]
Here the full product rule is
\[
E_e(W_e^\star\psi)=\tfrac34W_e^\star\psi+
 W_e^\star E_e\psi-2D_e\psi.
\]
The three terms have bounds \(3r_e/2\), \(4r_e^2\xi\), and
\(4r_e^2\xi\), respectively: the last follows from
\(\|D_e\psi\|\le r_e\sqrt{\gamma_e}\le2r_e^2\xi\), using (10.5).
Thus the mixed derivative has been estimated, not omitted.

For any \(\Lambda>0\), define the bounded one-link observable
\[
B_e^\Lambda=E_e\mathbf1_{[0,\Lambda]}(E_e),\qquad
\|B_e^\Lambda\|\le\Lambda.
\]
It is a functional calculus of the original \(E_e\); it changes neither
\(H\) nor \(\psi\). For its spectral tail,
\(\lambda\mathbf1_{\lambda>\Lambda}\le\lambda^2/\Lambda\), hence
\[
\|(E_e-B_e^\Lambda)\psi\|\le7\xi/\Lambda,\qquad
\|Q_\psi B_e^\Lambda\psi\|\le\|B_e^\Lambda\psi\|
 \le\|E_e\psi\|\le8\xi.                                     \tag{13.3}
\]
Define
\(\operatorname{Cov}_\psi(O,P)=
\langle Q_\psi O\psi,Q_\psi P\psi\rangle\) for self-adjoint
observables with \(\psi\) in their domains.
Subtracting the two centered inner products, retaining both difference
terms, gives
\[
|C_{ef}-\operatorname{Cov}_\psi(B_e^\Lambda,B_f^\Lambda)|
\le112\xi^2/\Lambda.                                        \tag{13.4}
\]
Both original link Casimirs and their spectral projections commute with
endpoint gauge transformations; every cutoff observable is physical.

## 13.2. Locality for the complete dynamics

For bounded observables \(O_e,O_f\) on distinct links, we claim
\[
\|[\alpha_t(O_e),O_f]\|
\le2\|O_e\|\|O_f\|e^{-d(e,f)}
       (e^{v|t|}-1),\qquad v=192b.                           \tag{13.5}
\]
This intermediate statement holds at every positive coupling.
Here are the domain construction and the full counting proof.

For a finite link set \(X\), introduce the auxiliary self-adjoint operator
\[
H_X^0=H_0+2bM+\sum_{\partial p\subset X}V_p,\qquad V_p=-bW_p.
\]
It has the same \(H^2\) domain as \(H\), and its dynamics preserves
the algebra of bounded operators supported on \(X\). Its difference
from \(H\) is bounded. The propagator
\[
W_X(t,s)=e^{itH_X^0}e^{-i(t-s)H}e^{-isH_X^0}
\]
has inverse \(W_X(s,t)\), and on the common domain differentiating gives
\[
\partial_tW_X(t,s)=-iK_X(t)W_X(t,s),\qquad
K_X(t)=e^{itH_X^0}(H-H_X^0)e^{-itH_X^0}.
\]
This bounded self-adjoint generator is strongly continuous. Its vectorwise
Dyson integrals exist, and on each compact time interval their norms are
bounded by the exponential series with parameter
\(\sup_t\|K_X(t)\|\). Iteration of the integral equation gives the series;
iteration for the difference of two solutions gives zero, since its
\(n\)-th bound has a factorial denominator. Consequently the domain
derivative agrees with that strong solution on the whole Hilbert space.
This justifies the differentiation below for bounded observables without
assuming operator-norm continuity of the unbounded on-site evolution.

Let \(\beta_{X,t}(O)=W_X(0,t)OW_X(t,0)\), and let
\(\partial_{\mathsf P}X\) be the faces meeting both \(X\) and \(X^c\).
For \(O\) supported on \(X\), the strong commutator derivative and Jacobi
identity give
\[
\begin{split}
F(t)&=[\beta_{X,t}(O),O_f],\\
F'(t)&=i[L_X(t),F(t)]
   +i[\beta_{X,t}(O),[O_f,L_X(t)]],\\
L_X(t)&=\sum_{p\in\partial_{\mathsf P}X}\alpha_t(V_p).
\end{split}
\]
Terms outside \(X\) commute with \(O\), and terms inside \(X\) are already
in \(H_X^0\); the crossing faces are therefore exactly the stated ones.
Conjugate this equation by the unitary strong propagator generated by
\(-L_X(t)\). Integrating its remaining inhomogeneous term and taking
norms proves
\[
\|F(t)\|\le\|[O,O_f]\|+
 2\|O\|\sum_{p\in\partial_{\mathsf P}X}
 \int_0^{|t|}\|[\alpha_{\operatorname{sgn}(t)s}(V_p),O_f]\|\,ds.
\]
At any fixed final \(t\), insert
\(O=e^{itH_X^0}O_Xe^{-itH_X^0}\), which still has support \(X\)
and norm \(\|O_X\|\). This is a pointwise use of the already proved
inequality, not differentiation of a time-dependent initial observable.
It yields the recurrence
\[
\begin{split}
\|[\alpha_t(O_X),O_f]\|
&\le2\|O_X\|\|O_f\|\mathbf1_{f\in X}\\
&\quad+2\|O_X\|\sum_{p\in\partial_{\mathsf P}X}
 \int_0^{|t|}\|[\alpha_{\operatorname{sgn}(t)s}(V_p),O_f]\|\,ds .
\end{split}                                                   \tag{13.6}
\]
The Hilbert spaces here are separable. Every strongly continuous
commutator has a measurable norm, as the supremum over a countable
dense set of unit vectors; these scalar integrals are well-defined.

Iterate (13.6) from \(X=\{e\}\). A term reaching \(f\) in \(n\)
interactions is a chain of \(n\) faces, the first containing \(e\),
consecutive faces intersecting, and the last containing \(f\).
Such a chain gives a shared-face link path of at most \(n\) steps;
therefore \(n\ge d(e,f)\). There are at most \(4\) choices of the
first face and \(16\) choices of every subsequent face, since a face
contains four links and each link meets at most four faces. Each
interaction has norm at most \(2b\). The remainder after \(n\) iterations
is bounded by a constant times \((64b|t|)^n/n!\) and tends to zero.
Dropping only counted positive terms gives
\[
\|[\alpha_t(O_e),O_f]\|
\le2\|O_e\|\|O_f\|\sum_{n\ge d(e,f)}
 \frac{(64b|t|)^n}{n!}
\le2\|O_e\|\|O_f\|e^{-d(e,f)}
       (e^{64\exp(1)b|t|}-1).
\]
The last inequality uses \(\exp(n-d)\ge1\) for \(n\ge d\).
The series for \(\exp(1)\), with \(n!\ge2^{n-1}\) for \(n\ge2\)
and a strict inequality for \(n\ge3\), gives \(\exp(1)<3\).
This proves (13.5), including its explicit \(192b\).
The constant \(2bM\) has commuted through every displayed conjugation;
the original Hamiltonian and its energy origin remain unchanged.

## 13.3. Spectral filtering with the actual vacuum moments

Take bounded self-adjoint \(O_e,O_f\), set
\(q_e=Q_\psi O_e\psi,\ q_f=Q_\psi O_f\psi\), and put
\(s_0=\|q_e\|\|q_f\|\). For
\[
h(t)=\langle\psi,[O_e,\alpha_t(O_f)]\psi\rangle
=\langle q_e,e^{itA}q_f\rangle-\langle q_f,e^{-itA}q_e\rangle
\]
one has \(|h(t)|\le2s_0\). For \(\alpha>0\), introduce the scalar integral
\[
I_\alpha=\lim_{\epsilon\downarrow0}\frac1{2\pi}
 \int_{\mathbb R}\frac{e^{-\alpha t^2}h(t)}{\epsilon+it}\,dt.
\]
The limit is absolutely dominated: (13.5) makes \(h(t)=O(|t|)\)
at zero, while the Gaussian controls infinity. For \(\epsilon>0\),
use
\((\epsilon+it)^{-1}=\int_0^\infty e^{-\epsilon u-itu}\,du\)
and integrate the Gaussian in \(t\). Fubini is justified by its
integrable absolute majorant. Letting \(\epsilon\downarrow0\) gives
the bounded spectral multiplier
\[
F_\alpha(\lambda)=\frac1{\sqrt{4\pi\alpha}}
 \int_0^\infty e^{-(u-\lambda)^2/(4\alpha)}\,du
\]
and the exact identity
\[
I_\alpha=\langle q_e,F_\alpha(A)q_f\rangle
          -\langle q_f,F_\alpha(-A)q_e\rangle.
\]
The Gaussian transform itself follows by differentiating its integral
with respect to its Fourier variable, integrating by parts, and fixing
the constant at zero by the squared Gaussian integral.
For \(\lambda\ge\Delta_*\), substitution followed by
\((x+y)^2\ge x^2+y^2\) gives
\[
0\le1-F_\alpha(\lambda)=F_\alpha(-\lambda)
\le\tfrac12e^{-\Delta_*^2/(4\alpha)}.
\]
The total variation of a cross spectral measure is at most
\(\|q_e\|\|q_f\|\): on a disjoint measurable partition apply
Cauchy--Schwarz to the two sequences of spectral-projection norms.
Thus every spectral interchange above is controlled, and
\[
|\operatorname{Cov}_\psi(O_e,O_f)-I_\alpha|
\le s_0e^{-\Delta_*^2/(4\alpha)}.
\]
Splitting its time integral at \(T>0\), (13.5) controls the part
\(|t|\le T\), while \(2s_0\) controls the rest. The explicit estimates
\[
\frac{e^{vt}-1}{t}\le ve^{vt},\qquad
\int_T^\infty\frac{e^{-\alpha t^2}}t\,dt
\le\frac{e^{-\alpha T^2}}{2\alpha T^2}
\]
follow respectively by integrating the exponential derivative and by
using \(1/t\le t/T^2\). Choosing \(\alpha=\Delta_*/(2T)\) proves
\[
\begin{split}
|\operatorname{Cov}_\psi(O_e,O_f)|
&\le\frac{2\|O_e\|\|O_f\|}{\pi}
        vT e^{-d(e,f)+vT}\\
&\quad+s_0\left(1+\frac2{\pi\Delta_*T}\right)
        e^{-\Delta_*T/2}.
\end{split}                                                   \tag{13.7}
\]
The Gaussian is only an integral filter in this proof. The dynamics,
vacuum and interaction have never been replaced by Gaussian ones.

For \(d=d(e,f)\ge1\), now use
\[
O_e=B_e^\Lambda,\quad O_f=B_f^\Lambda,\quad
\Lambda=e^{d/4},\qquad T=\frac{d}{\Delta_*+2v}.
\]
The original parameters give exactly
\[
\frac v{\Delta_*}=\frac{73728}{287}\xi\le\frac3{574},\qquad
vT\le\frac{3d}{580}<\frac d{100},\qquad
\Delta_*T\ge\frac{287d}{290}.                                \tag{13.8}
\]
Consequently the first term in (13.7) is at most
\[
\frac{73728}{287}\xi d\,e^{-49d/100}
\le1100\xi e^{-d/4}.
\]
We used \(2/\pi<1\), and
\(d e^{-6d/25}\le25/6\), which follows from \(e^x\ge x\);
the exact remaining coefficient is \(307200/287<1100\).
By (13.3), \(s_0\le64\xi^2\). The second term in (13.7) is at most
\(192\xi^2e^{-d/4}\): its parenthesis is less than \(3\) for
\(d\ge1\) and \(\Delta_*T/2\ge287d/580>d/4\).
Finally (13.4) contributes at most \(112\xi^2e^{-d/4}\).
Their sum is bounded by
\((1100\xi+304\xi^2)e^{-d/4}\le1200\xi e^{-d/4}\).
This proves (13.1) for the original unbounded covariance.

# 14. A volume-uniform two-sided remainder and the original native quotient

Define the real symmetric remainder
\[
\mathscr R=C-\frac{\xi^2}{16}\mathsf I^{\mathsf T}\mathsf I.
\]
For every entry (5.3) gives \(|\mathscr R_{ef}|\le42500\xi^3\).
For \(d(e,f)\ge2\) there is no shared face, so
\(\mathscr R_{ef}=C_{ef}\) exactly and (13.1) applies.
These are two estimates of the same exact entries; no correlation
is set to zero.

The injective indexing map \(x(n,i)=2n+\mathbf e_i\) and its inverse
were proved in Section 9. Any two links on one face have indexing
\(\ell^1\) distance at most 2, as inspection of its four midpoints
shows. A graph ball of integer radius \(D\) therefore lies inside
the integer cube of coordinate side \(4D+1\), and contains at most
\((4D+1)^3\) links, including near the original box boundary.
For a shell of radius \(n\) we use the valid upper bound
\((4n+1)^3\), not a difference of two bounding cube volumes.
For every integer \(D\ge1\), this proves
\[
\sup_e\sum_f|\mathscr R_{ef}|
\le42500\xi^3(4D+1)^3+
1200\xi\sum_{n>D}(4n+1)^3e^{-n/4}.                           \tag{14.1}
\]

Here is a closed, explicit bound with no remaining infinite sum.
For \(0<q<1\) put
\[
G(A,q)=\frac{A^3}{1-q}
 +\frac{12A^2q}{(1-q)^2}
 +\frac{48Aq(1+q)}{(1-q)^3}
 +\frac{64q(1+4q+q^2)}{(1-q)^4}.
\]
The geometric series and its first three applications of \(q\,d/dq\)
give respectively
\[
\sum_{j\ge0}q^j=\frac1{1-q},\quad
\sum_{j\ge0}jq^j=\frac q{(1-q)^2},\quad
\sum_{j\ge0}j^2q^j=\frac{q(1+q)}{(1-q)^3},\quad
\sum_{j\ge0}j^3q^j=\frac{q(1+4q+q^2)}{(1-q)^4}.
\]
Termwise differentiation is justified by uniform convergence on each
compact subinterval of \((0,1)\). Expanding \((A+4j)^3\) and using
these four identities proves
\[
\sum_{n>D}(4n+1)^3q^n=q^{D+1}G(4D+5,q).                      \tag{14.2}
\]
Write \(z=\log(1/\xi)>0\), set \(D=\lceil8z\rceil\), and use
\(q=e^{-1/4}<4/5\), the latter following from \(e^{1/4}>1+1/4\).
Then \(q^D\le\xi^2\), \(4D+1\le32z+5\), and
\(4D+5\le32z+9\). All coefficients of \(G\) are positive.
Define the explicit cubic polynomial
\[
\mathcal P(z)=42500(32z+5)^3+1200G(32z+9,4/5),
\qquad \epsilon_\xi=\xi\mathcal P(\log(1/\xi)).              \tag{14.3}
\]
Equations (14.1)--(14.2) now prove
\[
\sup_e\sum_f|\mathscr R_{ef}|
\le\xi^3\mathcal P(\log(1/\xi))=\xi^2\epsilon_\xi.             \tag{14.4}
\]
The same bound holds for column sums by symmetry. For completeness,
Cauchy--Schwarz in the nonnegative weights \(|\mathscr R_{ef}|\)
gives
\[
\sum_e|(\mathscr Rw)_e|^2
\le\left(\sup_e\sum_f|\mathscr R_{ef}|\right)
 \sum_f|w_f|^2\sum_e|\mathscr R_{ef}|.
\]
Thus (14.4) bounds its operator norm on \(\ell^2(\mathsf E_L)\)
and yields the two-sided inequality
\[
\left|w^{\mathsf T}Cw-
          \frac{\xi^2}{16}\|\mathsf Iw\|_2^2\right|
\le\xi^2\epsilon_\xi\|w\|_2^2
\quad\text{for every real }w.                               \tag{14.5}
\]
In particular the absolute rows of \(C\) are uniformly summable:
\(\sum_ft_{ef}=4r_e\le16\), so
\(\sup_e\sum_f|C_{ef}|\le\xi^2(1+\epsilon_\xi)\).
The remainder has order
\(\xi^3(1+\log(1/\xi))^3\), uniformly in the full box.
No order-\(\xi^4\) assertion is substituted for that proved order.

There is an entirely explicit interval on which the relative estimate
is nonvacuous:
\[
0<\xi\le10^{-16}\quad\Longrightarrow\quad\epsilon_\xi<1/32.
                                                               \tag{14.6}
\]
To verify every constant, \(\mathcal P\) has positive coefficients
and degree three. For \(z\ge3\), every \(e^{-z}z^k\),
\(0\le k\le3\), is nonincreasing, by differentiation.
Hence \(e^{-z}\mathcal P(z)\) is nonincreasing there.
The elementary bounds \(e<3<10<e^3\), proved by the exponential
series, give \(16<16\log10<48\). At \(z_0=16\log10\),
\[
e^{-z_0}\mathcal P(z_0)
\le10^{-16}\mathcal P(48)
=\frac{356710369517}{20000000000000}<\frac1{32}.
\]
The exact integer evaluation is
\(\mathcal P(48)=178355184758500\).
Monotonicity proves (14.6), and the same exponential-series bounds
show \(\epsilon_\xi\to0\) as \(\xi\downarrow0\).
The smaller interval is used for the explicit positive lower
denominators below; (14.5) holds on all of (11.16).

For every nonzero nonnegative weight vector, summing the facewise
inequalities \((\sum w_e)^2\ge\sum w_e^2\) gives
\(\|\mathsf Iw\|_2^2\ge2\|w\|_2^2\).
Equations (14.5)--(14.6) imply
\[
\|v_w\|^2=w^{\mathsf T}Cw\ge\frac{3\xi^2}{32}\|w\|_2^2>0,
\qquad
\left|\frac{\mathfrak q_A[v_w]}{\|v_w\|^2}-3\kappa\right|
\le\kappa(3744000\xi+32\epsilon_\xi).                        \tag{14.7}
\]
For the second inequality subtract \(3\kappa\) times (14.5) from
(7.2): the numerator error is at most
\(\kappa\xi^2(351000\xi+3\epsilon_\xi)\|w\|_2^2\).
Divide by the positive lower bound just proved.
The conclusion is uniform over all boxes and all such weights, not
merely over a prescribed finite support.

For the unchanged native weights of (1.4), (14.5) reads
\[
\left|\|v_{w^{\rm nat}}\|^2-\frac{\xi^2}{4}\mathcal A_L\right|
\le\xi^2\epsilon_\xi S_{2,L}
\le2\xi^2\epsilon_\xi\mathcal A_L.                            \tag{14.8}
\]
Thus its relative denominator error is at most \(8\epsilon_\xi\),
with no \(L^3\) loss. On (14.6),
\[
\frac{3\xi^2}{16}\mathcal A_L
\le\|v_{w^{\rm nat}}\|^2
\le\frac{5\xi^2}{16}\mathcal A_L,                             \tag{14.9}
\]
and the exact physical native electric-state quotient satisfies (14.7).
No original \(n_2^2\) weight or original scale has been changed.
The physical substitution remains
\(\xi=1/(4g_{\rm YM}^4)\), \(\kappa=2g_{\rm YM}^2/a\);
the explicit interval (14.6) is \(g_{\rm YM}^4\ge2500000000000000\).
This conservative numerical interval is not claimed optimal.

For signed weights (14.5) is still valid, but the nonnegative-weight
lower bound is not asserted. On the full leading kernel it gives
\[
0\le\|v_w\|^2\le\xi^2\epsilon_\xi\|w\|_2^2
\qquad(\mathsf Iw=0).                                       \tag{14.10}
\]
The fourth-order forms already proved in the parent remain intact.
Equations (7.3) and (12.14) remain additional upper bounds, and the
smallest of these proved bounds may be used. A uniform fourth-order
kernel remainder and the minimum over all signed electric weights
have not been obtained by this argument.
Section 15 below obtains a uniform bound on that minimum by proving the
gauge-equivariance of the full cluster similarity and using the exact
physical free threshold. It does not identify the fourth-order kernel
quotient by dividing (14.10).
Section 16 instead constructs the exact two-face correction function,
bounds its full-vacuum residual, and proves that kernel quotient with
an explicit uniform remainder in (16.24).
Nor does (14.7) remove the fixed-regulator restriction on the
small-angle remainder in (1.4), construct a spatial continuum theory,
or determine the Millennium mass gap.

# 15. The gauge-restricted threshold and the full signed electric minimum

The physical constraint improves the full-space estimate (12.8) by a
factor of four, without changing the interaction or the interval (11.16).
We prove the gauge maps, the free threshold, and the restricted resolvent
before using the improvement for the actual interacting states.

The literature source for the finite-graph gauge Hilbert space and its
vertex-invariant representation is John C. Baez, *Spin Network States in
Gauge Theory*, arXiv:gr-qc/9411007v1, the section *Gauge Theory on a
Graph*, Lemmas 1, 2, and the lemma labelled lem2.5 in the original TeX
([primary source](https://arxiv.org/abs/gr-qc/9411007v1);
*Advances in Mathematics* 117 (1996), 253--272,
DOI 10.1006/aima.1996.0012). The retained source is
\nolinkurl{literature/Baez-spin-network-states.tex}, lines 174--321.
The source constructs the invariant Hilbert space from edge
representations and vertex intertwiners. The leaf argument below proves
the particular free spectral bound directly, including the original
open boundary and every endpoint gauge transformation.

## 15.1. Exact gauge projection, source convention, and support sectors

Retain the entire vertex set and define
\[
\mathcal G_L=SU(2)^{\mathsf V_L},\qquad
(\alpha_gU)_e=g_{s(e)}U_eg_{t(e)}^{-1},\qquad
(\mathsf T_g f)(U)=f(\alpha_{g^{-1}}U).                       \tag{15.1}
\]
There is no restriction of \(g_v\) to the identity at boundary vertices
and no external charged representation at a vertex. These are precisely
the gauge transformations of Section 1. Group multiplication gives
\(\alpha_g\alpha_h=\alpha_{gh}\), hence
\(\mathsf T_g\mathsf T_h=\mathsf T_{gh}\).
Left and right Haar invariance on each link prove
\(\|\mathsf T_g f\|=\|f\|\) and
\(\mathsf T_g^*=\mathsf T_{g^{-1}}\).
Translations of continuous functions are continuous in \(g\), and
density extends this to strong continuity on \(\mathcal H_L\).
Thus the strong Haar integral
\[
\mathsf P_{\mathcal G}=\int_{\mathcal G_L}\mathsf T_g\,dg,
\qquad
\mathcal H_{\mathrm{phys}}
 =\{f:\mathsf T_gf=f\text{ for every }g\}
 =\operatorname{Ran}\mathsf P_{\mathcal G}                    \tag{15.2}
\]
exists and is bounded. Haar invariance gives
\(\mathsf T_h\mathsf P_{\mathcal G}=\mathsf P_{\mathcal G}\);
inversion invariance gives
\(\mathsf P_{\mathcal G}^*=\mathsf P_{\mathcal G}\).
Integrating the first identity proves
\(\mathsf P_{\mathcal G}^2=\mathsf P_{\mathcal G}\).
Conversely the integral fixes every invariant vector, proving both
range identities in (15.2).

Baez uses the coordinate action
\(A_e\mapsto g_{t(e)}A_eg_{s(e)}^{-1}\).
The exact dictionary, on the same directed graph, is
\[
\jmath:SU(2)^{\mathsf E_L}\longrightarrow SU(2)^{\mathsf E_L},
\qquad
A_e=\jmath(U)_e=U_e^{-1},\qquad \jmath^{-1}=\jmath.             \tag{15.3}
\]
Indeed \((g_sU_eg_t^{-1})^{-1}=g_tU_e^{-1}g_s^{-1}\).
The pullback \(\mathsf Jf=f\circ\jmath\), from the source's Haar
Hilbert space to ours, is therefore a unitary intertwiner with
inverse the same pullback. Haar measure is invariant under inversion.
Inversion is an isometry for the bi-invariant metric with the
\(T_a\) frame of (1.2), so it preserves the Sobolev domains and
intertwines every \(E_e\). This proves the gauge-space dictionary;
it does not silently reverse a Wilson traversal in (1.1).

Each \(\mathsf T_g\) is a product of link isometries, so it preserves
\(H^1,H^2\) and commutes with \(E_e\) on its operator domain.
In (1.1) the endpoint factors cancel at the four consecutive vertices,
leaving conjugation by \(g_n\) inside the trace. Thus every \(W_p\),
and consequently \(H,H_0,V_p\), is gauge invariant on its stated
domain. The gauge projection also preserves these domains, by
integrating in the corresponding graph norm.

Let \(P_e\) be Haar averaging in the one link \(e\), followed by the
constant lift. Endpoint Haar invariance gives
\(P_e\mathsf T_g=\mathsf T_gP_e\). In Section 11 notation,
the embedded sector projection is exactly
\[
\mathsf Q_I=
 \prod_{e\in I}(I-P_e)\prod_{f\notin I}P_f,
\qquad
\mathsf Q_If=(\Pi_If)\otimes1_{I^c}.                         \tag{15.4}
\]
Products commute, so \(\mathsf Q_I\) commutes with the gauge
representation and with \(\mathsf P_{\mathcal G}\).
The finite sum of all \(\mathsf Q_I\) is the identity, by expanding
\(\prod_e[(I-P_e)+P_e]\).
Restricting the unitary (11.2) consequently gives the exact
orthogonal decomposition
\[
\mathcal H_{\mathrm{phys}}
 =\bigoplus_{I\subset\mathsf E_L}
     \bigl(\mathcal H'_I\otimes1_{I^c}\bigr)^{\mathcal G_L}.
                                                               \tag{15.5}
\]
The inverse map remains the collection of Haar projections (15.4).
The action on the \(I\) factor is the restriction of the product
link representation, not a gauge group with its boundary removed.

## 15.2. Leaf annihilation and the exact free physical threshold

For a nonempty set \(I\) of links, consider the undirected graph
with these edges and their endpoints. Suppose a vertex \(v\)
has exactly one incident edge \(e\) in \(I\). For
\[
f\in\bigl(\mathcal H'_I\otimes1_{I^c}\bigr)^{\mathcal G_L},
\]
vary only \(g_v\). On the \(I\) factors this translates only the
variable \(U_e\), on the left or the right according to its
original orientation. On the exterior factors it acts on constants.
Since \(f\) is invariant, integration over this single \(SU(2)\)
gauge variable gives
\[
f=\int_{SU(2)}\mathsf T_{g_v}f\,dg_v=P_ef=0.                 \tag{15.6}
\]
The second equality is exactly left or right Haar averaging; the
last equality follows from the \(I-P_e\) factor in (15.4).
For arbitrary, possibly entangled \(L^2\) vectors the identity
follows first on elementary tensors, then by density and the
boundedness of the two averages. Thus no pointwise representative
or unstated smoothness is used in the leaf argument.

It follows that every nonempty support of a nonzero invariant sector
has degree at least two at every one of its incident vertices.
Such a finite graph contains a cycle: choose a simple path of
maximal length; at its last vertex there is a neighbor other than
the preceding vertex. Maximality places that neighbor earlier in
the path, and the resulting segment closes a simple cycle.
The original cubic graph has no loops or multiple edges.
The coloring \(n\mapsto(-1)^{n_1+n_2+n_3}\) changes sign along
every edge, so every cycle has even length. Its length is therefore
at least four. In particular,
\[
\bigl(\mathcal H'_I\otimes1_{I^c}\bigr)^{\mathcal G_L}
 \ne\{0\},\quad I\ne\varnothing
\quad\Longrightarrow\quad |I|\ge4.                          \tag{15.7}
\]
This proof includes vertices on faces, edges, and corners of the
open box. Omitting a boundary gauge transformation would invalidate
the corresponding step (15.6); no such omission has been made.

On a nonempty support (11.3) gives
\(H_I\ge(3\kappa/4)|I|\), on its full domain and hence on its
invariant subspace. Combining (15.5)--(15.7) and summing the
orthogonal nonempty sectors yields the form inequality
\[
H_0\big|_{\mathcal H_{\mathrm{phys}}\cap\Omega^\perp}
 \ge 3\kappa I.                                             \tag{15.8}
\]
The constant is attained. For any elementary face \(p\), its
unchanged \(W_p\) is gauge invariant and is a fundamental
matrix coefficient in each of its four distinct link variables,
including the two inverse traversals. Bi-invariance of the
Casimir gives
\[
E_eW_p=\tfrac34W_p\quad(e\in\partial p),\qquad
E_eW_p=0\quad(e\notin\partial p).
\]
Integration in one participating link, with all others held fixed,
gives \(\int W_p\,dU=0\) and \(\int |W_p|^2dU=1\).
For the latter, the product inside the trace is Haar distributed
under that integral, also for an inverse occurrence, and the
fundamental matrix-coefficient identity
\(\int U_{ij}\overline{U_{k\ell}}\,dU
 =\delta_{ik}\delta_{j\ell}/2\) gives the unit norm of its trace.
Consequently
\[
H_0W_p=3\kappa W_p,\qquad
W_p\in\mathcal H_{\mathrm{phys}}\cap\Omega^\perp,\qquad
\|W_p\|=1.                                                   \tag{15.9}
\]
This proves the exact free physical threshold \(3\kappa\), rather
than merely a lower estimate. No free vector is substituted for
the interacting vacuum in the argument that follows.

## 15.3. Gauge-equivariance of the interacting cluster similarity

The fixed-point construction of Section 11 may be performed within
the invariant sector collections. To prove that statement, assume
each \(z_I\otimes1_{I^c}\) is gauge invariant. The gauge operator
factorizes as \(\mathsf T_{g,I}\otimes\mathsf T_{g,I^c}\).
Both \(z_I\) and \(1_I\) are fixed by the first factor. Hence
the rank-one creation operator (11.4) satisfies
\[
\mathsf T_g\widehat z_I\mathsf T_g^{-1}
 =|\mathsf T_{g,I}z_I\rangle
   \langle\mathsf T_{g,I}1_I|\otimes I_{I^c}
 =\widehat z_I.                                             \tag{15.10}
\]
The projections \(\Pi_I\) intertwine the full representation with
its sector action by (15.4). The operator \(H_I^{-1}\) commutes
with this action by the reducing property and functional calculus.
Since \(V_p\) and \(\Omega\) are invariant, (11.10) therefore sends
invariant collections to invariant collections.

Iteration starts at zero. Every iterate is invariant, and the
limit in the energy norm (11.7) is invariant because fixed
subspaces of bounded representations are closed. Thus the actual
fixed point has the claimed invariance. Its creation sum \(C(z)\)
and the two finite polynomial exponentials commute with
\(\mathsf T_g\) and \(\mathsf P_{\mathcal G}\).
The domain preservation proved in (11.9) also holds upon restriction.
In particular the exact relation remains
\[
\psi=\alpha e^{C(z)}\Omega,\qquad
\alpha=\langle\Omega,\psi\rangle>0,
\]
with the scalar and unit physical vacuum specified in (12.7).

Write \(\widetilde H=H_0+\mathcal K\) as in (12.1).
All three operators preserve the physical subspace; the bounded
invertible similarity and its inverse do as well. The restriction
of the sector norm (12.2) is still equivalent to the Hilbert norm,
with its same explicitly volume-dependent upper comparison.
The relative estimate is unchanged:
\[
\|\mathcal K f\|_{\oplus,1}
 \le c_\xi\|H_0 f\|_{\oplus,1},\qquad
c_\xi=\frac{512}{3}\xi\le\frac1{288},
\quad
f\in\operatorname{Dom}(H_0)\cap\mathcal H_{\mathrm{phys}}.
                                                               \tag{15.11}
\]
We do not replace the per-link bound used to prove this estimate
by a larger value or alter its numerical contraction.

On every nonempty invariant sector, the spectral parameter
\(\lambda\) of \(H_I\) satisfies \(\lambda\ge3\kappa\)
by (15.7). Therefore, for \(0<t<3\kappa(1-c_\xi)\),
\[
\|\mathcal K(H_0-t)^{-1}\|_{\oplus,1;\mathrm{phys}}
 \le c_\xi\sup_{\lambda\ge3\kappa}
               \frac{\lambda}{\lambda-t}
 =\frac{3\kappa c_\xi}{3\kappa-t}<1.                         \tag{15.12}
\]
The constant sector contributes zero because
\(\mathcal K\Omega=0\), exactly as in Section 12.
The Neumann series therefore gives a bounded inverse for
\(\widetilde H-t\) on the physical subspace. Its image is in the
restricted \(H_0\) domain: factor the inverse as
\((H_0-t)^{-1}[I+\mathcal K(H_0-t)^{-1}]^{-1}\).
Norm equivalence and the invariant similarities transfer that
inverse to \(H-\mathcal E-t\) on the original physical Hilbert
space. No form positivity is claimed for the nonunitary similarity
itself. Applying the spectral theorem to the original self-adjoint
restriction, with its simple ground eigenvalue, proves
\[
(H-\mathcal E)\big|_{\mathcal H_{\mathrm{phys}}\cap\psi^\perp}
 \ge 3\kappa\left(1-\frac{512}{3}\xi\right)I
 \ge\frac{287\kappa}{96}I,
\qquad 0<\xi\le\frac1{49152}.                                \tag{15.13}
\]
In original parameters the last constant is
\(287g_{\rm YM}^2/(48a)\) and the range is
\(g_{\rm YM}^4\ge12288\).
The full, not necessarily invariant Hilbert-space bound remains
(12.8), with constant \(287\kappa/384\). The fourfold improvement
is asserted exactly on the physical restriction just proved.

## 15.4. Covariance order, signed states, and an attained uniform minimum

Every \(E_e\) commutes with the gauge representation, so each
centered vector \(v_e\) is in
\(\mathcal H_{\mathrm{phys}}\cap\psi^\perp\).
There is no sign restriction on the coefficients in a real linear
combination. Applying (15.13) to every \(v_w\), including a zero
vector, gives the matrix inequality
\[
\mathcal N\ \ge\
3\kappa(1-c_\xi)C\ \ge\ 0
\quad\hbox{on }\mathbb R^{\mathsf E_L}.                       \tag{15.14}
\]
Combining it with the upper side of (7.2) yields
\[
0\le w^{\mathsf T}Cw
 \le\frac{\xi^2\|\mathsf Iw\|_2^2/16
               +117000\xi^3\|w\|_2^2}{1-512\xi/3}.           \tag{15.15}
\]
Here \(351000/3=117000\); the leading coefficient is \(1/16\).
The exact facewise estimate \(\|\mathsf Iw\|_2^2\le16\|w\|_2^2\)
from Section 12 gives
\[
0\le C\le
\frac{\xi^2+117000\xi^3}{1-512\xi/3}
 I_{\mathbb R^{\mathsf E_L}}.                                \tag{15.16}
\]
On \(\ker\mathsf I\) the numerator of (15.15) is exactly
\(117000\xi^3\|w\|_2^2\). This is an upper bound, not a
fourth-order identification or a discarded null direction.
For the unchanged native weights,
\[
\|v_{w^{\rm nat}}\|^2
 \le\frac{\xi^2\mathcal A_L/4+117000\xi^3 S_{2,L}}
              {1-512\xi/3}
 \le\frac{\xi^2\mathcal A_L}{4}
       \frac{1+936000\xi}{1-512\xi/3}.                       \tag{15.17}
\]
The last step uses \(S_{2,L}\le2\mathcal A_L\), without changing
the coefficients or coordinates in the original state.

To define the signed minimum without dividing by an unproved
denominator, let \(\mathcal H_{\mathrm{phys},\mathbb R}\) denote
the real-valued invariant functions and define
\[
\mathsf V_\xi:\mathbb R^{\mathsf E_L}
 \longrightarrow\mathcal H_{\mathrm{phys},\mathbb R}\cap\psi^\perp,
\qquad
\mathsf V_\xi w=v_w,\qquad
\mathscr W_\xi=\operatorname{Ran}\mathsf V_\xi.               \tag{15.18}
\]
Its Gram identity is
\(\langle\mathsf V_\xi w,\mathsf V_\xi z\rangle=w^{\mathsf T}Cz\).
Thus
\(\ker\mathsf V_\xi=\ker C\): \(Cw=0\) implies zero norm of
\(\mathsf V_\xi w\); conversely a zero vector has zero inner
product with every \(\mathsf V_\xi z\).
The induced map
\[
\overline{\mathsf V}_\xi:
\bigl(\mathbb R^{\mathsf E_L}/\ker C,\,
       \langle[w],[z]\rangle_C=w^{\mathsf T}Cz\bigr)
 \longrightarrow\mathscr W_\xi                              \tag{15.19}
\]
is an isometric linear bijection. The bilinear form is well-defined
because \(C\) annihilates its kernel, and it is positive on every
nonzero equivalence class by the Gram identity.
The inverse sends a vector \(v_w\) to its class \([w]\);
two preimages differ by \(\ker C\), which proves independence of
choice. The same identity for the energy form shows that
\(\mathcal N\) annihilates \(\ker C\) and descends to the quotient.
This records the exact information loss. No equality
\(\ker C=\ker\mathsf I\), or \(\ker C=\{0\}\), is assumed.

On \(0<\xi\le1/680000\), (7.5)--(7.6) give a nonzero
\(v_e\) for every link, so \(\mathscr W_\xi\ne\{0\}\).
It is finite dimensional and consists of smooth vectors.
The energy form is a continuous quadratic form on this finite
dimensional space. Its restriction to the unit sphere attains a
minimum by compactness. Through (15.19) this number is exactly
\[
\mathfrak m_L(\xi)
 =\min_{\substack{w\in\mathbb R^{\mathsf E_L}\\
                  w^{\mathsf T}Cw>0}}
       \frac{w^{\mathsf T}\mathcal N w}{w^{\mathsf T}Cw}.
                                                               \tag{15.20}
\]
Write \(\Delta_{\mathrm{phys},L}(\xi)\) for the first positive
spectral value of \(H-\mathcal E\) on
\(\mathcal H_{\mathrm{phys}}\).
Its existence follows from compact resolvent, the simple ground
eigenvalue, and the nonzero physical excited subspace; this is the
same excitation operator as in (15.13).
The spectral variational principle, (15.14), and the actual
single-link trial bound (7.6) prove the complete chain
\[
\begin{split}
3\kappa-512\kappa\xi
 &=3\kappa(1-c_\xi)\\
 &\le\Delta_{\mathrm{phys},L}(\xi)
 \le\mathfrak m_L(\xi)
 \le3\kappa+2472000\kappa\xi ,
\qquad 0<\xi\le\frac1{680000}.
\end{split}                                                \tag{15.21}
\]
Every \(L\ge2\) is covered by these same constants and coupling
interval. In particular the estimate permits weights that depend
on \(L,\xi\), have arbitrary signs, or lie in \(\ker\mathsf I\),
whenever they represent a nonzero actual state. Such a state is
included in the minimization, not excluded by a leading-coefficient
test. The quotient construction retains all zero actual states as
the explicitly identified kernel, where an energy quotient has no
defined value.

Equation (15.21) proves both uniform statements
\(\Delta_{\mathrm{phys},L}(\xi)=3\kappa+O(\kappa\xi)\) and
\(\mathfrak m_L(\xi)=3\kappa+O(\kappa\xi)\), with the displayed
two-sided constants as their meaning. It does not assert that
every signed state's quotient is near \(3\kappa\).
In particular it does not replace the parent's fixed-box
fourth-order kernel quotient or prove its remainder uniform.
The separate calculation (16.17)--(16.24) supplies that uniform
remainder on the entire original incidence kernel.
The earlier two-sided nonnegative/native estimate (14.7) also
remains valid with its original range.
In physical parameters the range of (15.21) is
\(g_{\rm YM}^4\ge170000\) and its central scale is
\(3\kappa=6g_{\rm YM}^2/a\).
No lattice-spacing limit or coupling continuation is taken.

## 15.5. The physical conditional-complement operator

Retain \(J_S,Q_S^\rho,\mathscr K_S^\rho,U_\psi,q_\rho\) and their
domains from Section 10. Let the gauge group act on
\(\mathscr H_\rho\) by the same pullback (15.1). It is unitary
because \(\rho=\psi^2\) is invariant. The retained-variable space
has the induced endpoint action on its retained links.
Under a simultaneous transformation of \((s,r)\), invariance of
\(\rho(s,r)\) and Haar measure in \(s\) proves invariance of the
marginal \(\rho_{S^c}(r)\). Changing variables in the conditional
integral then gives
\[
J_S^*\mathsf T_g=\mathsf T_{g,S^c}J_S^*,\qquad
\mathsf T_gJ_S=J_S\mathsf T_{g,S^c}.                          \tag{15.22}
\]
It follows that \(Q_S^\rho\) and the gauge projection commute.
They preserve the form domain as proved in Section 10 and by
the isometric gauge action. Averaging smooth approximants over
the compact gauge group and then applying \(Q_S^\rho\) proves
form density of the smooth invariant conditional-mean-zero
vectors in
\[
\mathscr K_{S,\mathrm{phys}}^\rho
 =\mathscr K_S^\rho\cap\mathscr H_\rho^{\mathcal G_L}.
\]
The closed form restricted to
\(H^1\cap\mathscr K_{S,\mathrm{phys}}^\rho\) therefore defines a
self-adjoint operator \(C_{S,\mathrm{phys}}^\rho\) by exactly
the variational domain rule given for \(C_S^\rho\) in Section 10.
Equations (15.22) and invariance of \(q_\rho\) also show that this
is the reducing physical restriction of \(C_S^\rho\).

The exact unitary \(U_\psi G=\psi G\) intertwines the gauge
representations. For a conditional-mean-zero \(G\), Fubini gives
\(\int G\rho\,dU=0\); consequently \(U_\psi G\) is physical and
perpendicular to \(\psi\) when \(G\) is invariant.
Apply (15.13) under this unitary and the form identity (10.10):
\[
C_{S,\mathrm{phys}}^\rho
 \ge3\kappa(1-512\xi/3)I\ge\frac{287\kappa}{96}I,
\qquad
\|(C_{S,\mathrm{phys}}^\rho)^{-1}\|
 \le\frac1{3\kappa(1-512\xi/3)}
 \le\frac{96}{287\kappa}.                                    \tag{15.23}
\]
This holds for every nonempty eliminated set \(S\), independently
of its size and the exterior volume, on (11.16). It concerns the
full form with derivatives in all link directions, not a
differential operator containing only the eliminated derivatives.
For noninvariant conditional-mean-zero vectors the previously
proved constants (12.15)--(12.16), not (15.23), remain the stated
bounds. The mathematical distinction is implemented by the
proved reducing projection and unitary, not by declaring the
two constructions unrelated.

# 16. Uniform fourth-order forms on the entire signed incidence kernel

Retain the full Hamiltonian (1.2), its actual positive unit vacuum
\(\psi\), \(A=H-\mathcal E\), the gauge constraint (15.1), and every
original real edge weight. Throughout this section
\(0<\xi\le1/49152\), unless an explicitly smaller interval is displayed.
Write \(\mathscr Z_L=\ker\mathsf I\). We prove volume-uniform remainders
for the first surviving covariance and energy forms on all of
\(\mathscr Z_L\), not merely on one alternating weight.

The exact two-face coefficients are the existing calculation in the
parent source
\nolinkurl{wilson_variation/ELECTRIC_COVARIANCE_UNSIGNED_INCIDENCE_20260908.md},
Sections 4--5, equations (4.1)--(5.8). The source's electric operator
denoted \(H_0\) there is \(\sum_eE_e\); our \(H_0\) in (11.1) is
\(\kappa\sum_eE_e\). Accordingly define here
\(\mathfrak h_0=\sum_eE_e\), so \(H_0=\kappa\mathfrak h_0\), on
the same domain. Every occurrence of a physical energy below retains
\(\kappa=2g_{\rm YM}^2/a\). No change of Hamiltonian or vacuum is made.
We first record the two-face functions and their exact derivative
dictionary needed for the new remainder calculation.

## 16.1. The retained two-face modes and a local correction function

Let \(\mathscr P_2\) be the unordered pairs of distinct elementary
faces sharing a link. Their unique shared link is \(e(p,q)\);
their other six links form the set \(O(p,q)\). Write
\[
R_{pq}=\operatorname{tr}(A_{pq}B_{pq}),\qquad
D_{pq}=W_pW_q-\tfrac12R_{pq},\qquad
G_{pq}=\nabla_{e(p,q)}W_p\cdot\nabla_{e(p,q)}W_q .
\]
Here the original face words, cyclically based at the shared link,
are \(U_eA_{pq}\) and \(U_e^{-1}B_{pq}\), reversing a full face
traversal when necessary. The trace is unchanged under that full
reversal in \(SU(2)\). The words \(A_{pq},B_{pq}\) contain the six
distinct outer links with the original inherited inverse occurrences.
No individual inverse occurrence is dropped.

The Pauli contraction with \(T_a=-i\sigma_a/2\) is
\[
\sum_a\operatorname{tr}(T_aC)\operatorname{tr}(T_aD)
 =-\tfrac12\operatorname{tr}(CD)
   +\tfrac14\operatorname{tr}C\operatorname{tr}D .
\]
Inserting the minus sign from differentiation of the inverse shared
link proves the first identity below. The product rule for \(E_e\)
then proves the shared-link label \(2\) of \(D_{pq}\):
\[
\begin{split}
G_{pq}&=\tfrac38R_{pq}-\tfrac14D_{pq},\\
\mathfrak h_0R_{pq}&=\tfrac92R_{pq},\qquad
\mathfrak h_0D_{pq}=\tfrac{13}{2}D_{pq},\\
\|R_{pq}\|_0^2&=1,\qquad
\|D_{pq}\|_0^2=\tfrac34,\qquad
\langle R_{pq},D_{pq}\rangle_0=0 .
\end{split}                                                  \tag{16.1}
\]
The subscript \(0\) denotes the original full product Haar measure,
used to compute coefficients, not substituted for the physical density.
Indeed each outer link has Casimir \(3/4\) on both functions;
on the shared link \(R_{pq}\) has Casimir zero. The identity
\(E_e(W_pW_q)=2D_{pq}\) follows from the displayed Pauli
contraction, and gives the remaining Casimir label.

For completeness, the norms in (16.1) can be checked by conditioning
on the shared link. The two disjoint outer words are independent
Haar matrices. Specifically take \(P=U_eA_{pq}\) and
\(Q=B_{pq}U_e^{-1}\); then \(\operatorname{tr}(PQ)=R_{pq}\)
and \(\operatorname{tr}P\operatorname{tr}Q=W_pW_q\).
For these independent holonomies
\(P=p_0I+i p_a\sigma_a,\ Q=q_0I+i q_a\sigma_a\), put
\(x=p_0q_0,\ y=\sum_{a=1}^3p_aq_a\). Their uniform unit-sphere
second moments give
\(\mathbb E x^2=1/16,\ \mathbb E y^2=3/16,\ \mathbb E xy=0\).
Now \(R=2(x-y)\) and \(D=3x+y\); multiplying these expressions
proves all three Haar products in (16.1).
Their individual Haar means are zero, by integration in an outer
fundamental link.

The functions \(R_{pq},D_{pq}\), for all unordered pairs, are
mutually orthogonal except for their own squared norms.
Here is the geometric check retained from the parent. A coplanar
pair has a \(2\)-by-\(1\) rectangular outer boundary, which determines
its two unit faces. A perpendicular pair has a unit-cube bounding box;
the two vertices absent from its outer six-cycle form the edge
opposite the shared edge. They determine that shared edge and the
two faces. The two cases have respectively two and three nonzero
coordinate spans. Thus different pairs have different outer supports.
Two \(R\)'s then have a \(3/4\)-versus-zero link label somewhere.
An \(R\) and a \(D\) differ at the latter's label-\(2\) link.
Two \(D\)'s differ either at that label-\(2\) link or at an outer
link. Self-adjointness of the differing link Casimir proves the
claimed orthogonality in every case.

For a physical link \(e\) and pair \(\{p,q\}\), define the exact
real coefficient
\[
\begin{split}
c_{e;pq}=-\mathbf1_{\{e=e(p,q)\}}
              +\tfrac16\mathbf1_{\{e\in O(p,q)\}},&\\
F_e=\sum_{\{p,q\}\in\mathscr P_2}c_{e;pq}G_{pq},\qquad&\\
\mathcal B_e=\sum_{\{p,q\}\in\mathscr P_2}c_{e;pq}
          \left(\tfrac1{12}R_{pq}-\tfrac1{26}D_{pq}\right).&
\end{split}
                                                               \tag{16.2}
\]
Equation (16.1) proves \(\mathfrak h_0\mathcal B_e=F_e\)
and \(\int\mathcal B_e\,dU=0\).
These functions are bounded, real, smooth and gauge invariant.
They are not truncated Hamiltonians.

Every contributing pair has \(e\) in at least one of its faces.
There are at most four such faces and at most twelve adjacent
faces for each, giving at most \(48\) pairs. Their link union
lies in the shared-face graph ball of radius two about \(e\).
Each radius-one ball has at most \(13\) links, so a radius-two
ball is contained in a union of \(13\) such balls and has at
most \(169\) links.
The pointwise bounds are
\[
\|\mathcal B_e\|_\infty\le24,\qquad
\sum_f\|\nabla_f\mathcal B_e\|_\infty\le168.                  \tag{16.3}
\]
To verify the constants, \(|R|\le2,\ |D|\le5\).
On an outer link \(|\nabla R|\le1\) and
\(|\nabla D|\le2+1/2=5/2\), using (6.2) and the product rule.
On the shared link \(\nabla R=0,\ |\nabla D|\le4\).
The absolute value of a shared-coefficient summand in (16.2)
is at most \(2/12+5/26<1/2\). Its derivative at any one
of its seven links is at most
\(\max\{1/12+(5/2)/26,4/26\}<1/2\).
An outer-coefficient summand is a further factor \(1/6\) smaller.
Summing at most \(48\) summands and seven derivative locations
proves (16.3).

## 16.2. A full-vacuum third-order state residual

Set \(h_e=W_e^\star/4\), which is a function, and put
\(d_e=E_e\psi-\xi h_e\psi\). Section 4 gives
\(\|d_e\|\le4200\xi^2\).
We need its differentiated counterpart, not a derivative of a norm
estimate. Introduce \(f_e=\psi-(\xi/3)W_e^\star\psi\).
The exact product rule gives
\[
E_ef_e=d_e-\tfrac{\xi}{3}W_e^\star E_e\psi
                         +\tfrac{2\xi}{3}D_e\psi .
\]
Here \(D_e\) is the differential contraction of Section 6,
not the two-face function \(D_{pq}\).
Equations (3.1), (10.5) and (6.2) give
\(\|E_e\psi\|\le8\xi,\ \|\nabla_e\psi\|\le8\xi,\
\|D_e\psi\|\le32\xi\).
Thus
\(\|E_ef_e\|\le(4200+128/3)\xi^2=(12728/3)\xi^2\).
The exact one-link spectral inequality
\(\|\nabla_ef\|\le(2/\sqrt3)\|E_ef\|\) holds also when
\(f\) has a constant component. Apply it to \(f_e\) and retain
the product-rule remainder:
\[
\begin{split}
\left\|\nabla_e\psi-\tfrac{\xi}{3}
                    (\nabla_eW_e^\star)\psi\right\|
&\le\frac{2}{\sqrt3}\frac{12728}{3}\xi^2
                              +\frac{64}{3}\xi^2\\
&<5000\xi^2 .
\end{split}                                                  \tag{16.4}
\]
For the last numerical inequality use \(2/\sqrt3<7/6\);
the resulting coefficient is \(44740/9<5000\).
All differentiations are on the actual smooth vacuum.

From (6.1) and the full ground-state product rule,
\[
Ad_e=\kappa\xi\left[
 -2D_e\psi+\tfrac12
   \sum_{p\ni e}\sum_{f\in\partial p}
          \nabla_fW_p\cdot\nabla_f\psi\right].
                                                               \tag{16.5}
\]
Insert (16.4) for each differentiated vacuum. The error from
the first term has norm at most \(2\cdot4\cdot5000\kappa\xi^3\).
The error from the second has norm at most
\((1/2)\cdot4\cdot4\cdot5000\kappa\xi^3\).
The full leading function is exactly \(F_e\) of (16.2).
To check every cancellation, a repeated face contributes
\(-2/3\) from the first sum and \(4/6\) from the second, hence zero.
An unordered distinct pair with shared link \(e\) contributes
\(-4/3+2/6=-1\); a pair with \(e\) on its outer boundary
contributes \(1/6\). These are precisely \(c_{e;pq}\).
Consequently
\[
\|Ad_e-\kappa\xi^2F_e\psi\|\le80000\kappa\xi^3.               \tag{16.6}
\]

Define the original local differential observable and its centered
residual state by
\[
\mathscr D_e=E_e-\xi h_e-\xi^2\mathcal B_e,\qquad
s_e=Q_\psi\mathscr D_e\psi,\qquad
Q_\psi=I-|\psi\rangle\langle\psi|.                            \tag{16.7}
\]
It is a bounded real multiplication perturbation of \(E_e\),
with the same one-link operator domain tensored with the exterior
space. It is self-adjoint on that domain; every product below is
first evaluated on smooth \(\psi\). The vector is gauge invariant,
real, smooth and perpendicular to the same \(\psi\).
Since
\[
A(\mathcal B_e\psi)
 =\kappa F_e\psi
       -2\kappa\sum_f\nabla_f\mathcal B_e\cdot\nabla_f\psi ,
\]
the last term has norm at most
\(2\kappa\cdot168\cdot8\xi=2688\kappa\xi\).
Equations (16.6)--(16.7), including the exact centering killed by
\(A\), imply
\[
\|As_e\|\le82688\kappa\xi^3<83000\kappa\xi^3,\qquad
\|s_e\|\le28000\xi^3.                                       \tag{16.8}
\]
The second assertion is the proved physical inverse bound
\(96/(287\kappa)\) from (15.13), applied to \(s_e\):
\(96\cdot83000/287<28000\). It is not obtained from an
assumed locality of the full vacuum.

## 16.3. Exact finite-range residual energy and its extensive consequence

The support of \(\mathscr D_e\) is inside the radius-two link
ball about \(e\). The commutator \([H,\mathscr D_f]\) has support
inside the radius-two ball about \(f\) as well. Indeed
\([H,E_f]\) uses only the faces at \(f\), while the commutator
of \(H\) with either multiplication function in (16.7) contains
only that function's derivatives on its own link support.
All multiplication potentials commute with those functions.
No distant coefficient is generated by these exact commutators.

Let \(\mathcal S_{ef}=\langle s_e,As_f\rangle\). Expanding the
double commutator on the smooth vacuum gives
\[
\mathcal S_{ef}
 =\tfrac12\langle\psi,[\mathscr D_e,[H,\mathscr D_f]]\psi\rangle,
\qquad
\mathcal S_{ef}=0\quad\text{when }d(e,f)>4.                  \tag{16.9}
\]
For the first identity no commutation of
\(\mathscr D_e,\mathscr D_f\) is assumed. The expansion equals
\(\langle\mathscr D_e\psi,A\mathscr D_f\psi\rangle+
 \langle\mathscr D_f\psi,A\mathscr D_e\psi\rangle\);
the two terms are equal because all functions and differential
operators are real and \(A\) is self-adjoint. Centering changes
neither term. For the second identity the two indicated supports
are disjoint, so their differential operators commute on the
smooth domain.

The radius-four link ball has at most \(17^3=4913\) vertices
by the unchanged coordinate map of Section 14. Equation (16.8)
gives
\(|\mathcal S_{ef}|\le28000\cdot83000\kappa\xi^6\).
The symmetric row-sum estimate used in (6.6) now gives, for every
real weight \(w\), with \(s_w=\sum_e w_es_e\),
\[
0\le\mathfrak q_A[s_w]\le10^{14}\kappa\xi^6\|w\|_2^2,
\qquad
\|s_w\|\le6\cdot10^6\xi^3\|w\|_2.                           \tag{16.10}
\]
The exact row coefficient is
\(4913\cdot28000\cdot83000=11417812000000<10^{14}\).
Applying (15.13) once more bounds the squared norm by
\((96/287)10^{14}\xi^6\|w\|_2^2\);
\((96/287)10^{14}<(6\cdot10^6)^2\).
This is the step which removes the number of nonzero weights
from the residual estimate. The physical \(s_w\) and its full
energy form remain unchanged.

## 16.4. Uniform covariance and energy estimates for the correction functions

Put
\[
u_e=Q_\psi\mathcal B_e\psi,\qquad
\mathcal C^{B}_{ef}=\langle u_e,u_f\rangle,\qquad
\mathcal C^{B,0}_{ef}=\langle\mathcal B_e,\mathcal B_f\rangle_0 .
\]
Each \(\mathcal B_e\) uses at most \(169\) links, and a product
uses at most \(338\). Equations (3.2)--(3.3), with
\(32\sqrt{169}/3<139\) and \(32\sqrt{338}/3<197\),
give
\[
|\langle\mathcal B_e\rangle_\psi|\le7000\xi,\qquad
|\mathcal C^B_{ef}-\mathcal C^{B,0}_{ef}|\le230000\xi .
                                                               \tag{16.11}
\]
In detail, the first coefficient is at most
\(48\cdot139(1+139/49152)<7000\).
For the second use the product bound \(24^2=576\), and retain
the product of the two means. The coefficient is at most
\[
2\cdot576\cdot197+
 \frac{2\cdot576\cdot197^2+7000^2}{49152}
 =\frac{175757179}{768}<230000.
\]
This controls every pair locally; it does not yet sum all pairs.

We also require the large-distance bound
\[
|\mathcal C^B_{ef}|\le10000e^{-d(e,f)/4}
\quad\text{when }d(e,f)\ge5.                                \tag{16.12}
\]
Here is the support-dependent version of the method in Section 13.
For bounded \(O_X,O_Y\) on disjoint link sets, the exact recurrence
(13.6) has the initial term
\(2\|O_X\|\|O_Y\|\mathbf1_{X\cap Y\ne\varnothing}\).
The first face in an iterated chain has at most \(4|X|\)
choices; each later face has at most \(16\) choices. Reaching
\(Y\) requires at least \(d(X,Y)\) faces. The same strong
evolution and factorial-remainder proof therefore gives
\[
\|[\alpha_t(O_X),O_Y]\|
 \le2|X|\|O_X\|\|O_Y\|
      e^{-d(X,Y)}(e^{192b|t|}-1).                            \tag{16.13}
\]
The extra factor is the explicitly counted \(|X|\), not the
volume of the full box or an assumed single-link estimate for
a multi-link observable. This is the crossing-set construction
of Nachtergaele--Sims, arXiv:1410.8174v1, Section 3, equations
fbd, iterandum and the complete Step 4; the original proof has
been read directly in the retained TeX.

For \(\mathcal B_e,\mathcal B_f\), take \(X,Y\) their actual
supports and set \(s=d(e,f)-4\ge1\), so \(d(X,Y)\ge s\).
Repeat the explicitly evaluated Gaussian filter (13.7), now with
the \(|X|\) in (16.13), and take
\(T=s/(\Delta_*+2v)\),
\(\Delta_*=287\kappa/384,\ v=192b\).
The spectral-integral proof is unchanged because its only
observable hypotheses are boundedness and self-adjointness.
This is the method of Nachtergaele--Sims,
arXiv:math-ph/0506030v3, Section 3.2; its spectral and Gaussian
integral proof is read and retained, not inferred from a title.
The numerical estimates (13.8) give \(vT<s/100\) and
\(\Delta_*T\ge287s/290\). Since \(|X|\le169\) and
\(\|u_e\|\|u_f\|\le576\), the two terms of the filter are at most
\[
\frac{576\cdot169}{100}s\,e^{-99s/100}
       +1728e^{-s/4}
 \le\left(\frac{576\cdot169}{74}+1728\right)e^{-s/4}.
\]
We used \(s e^{-74s/100}\le100/74\), proved by
\(\exp(x)\ge x\), and \(2/\pi<1\).
Finally \(e^{-s/4}=\exp(1)e^{-d(e,f)/4}<3e^{-d(e,f)/4}\);
the resulting coefficient \(337824/37<10000\) proves (16.12).

For \(d(e,f)>4\), the two correction functions have disjoint
supports and zero individual Haar means, so
\(\mathcal C^{B,0}_{ef}=0\) by Fubini. Use (16.11) up to
integer distance \(D\) and (16.12) outside it. With the
generating function \(G\) already explicitly evaluated in
(14.2), define
\[
\begin{split}
\mathcal P_B(z)&=230000(16z+5)^3+10000G(16z+9,4/5),\\
r_B(\xi)&=\xi\mathcal P_B(\log(1/\xi)).
\end{split}                                                  \tag{16.14}
\]
Take \(D=\lceil4\log(1/\xi)\rceil\), which is at least four
on the present interval. The same coordinate shell count gives
\[
\begin{split}
\sup_e\sum_f|\mathcal C^B_{ef}-\mathcal C^{B,0}_{ef}|
&\le230000\xi(4D+1)^3
       +10000\sum_{n>D}(4n+1)^3e^{-n/4}\\
&\le r_B(\xi).
\end{split}                                                  \tag{16.15}
\]
Indeed \(e^{-D/4}\le\xi\), \(4D+1\le16\log(1/\xi)+5\),
and \(4D+5\le16\log(1/\xi)+9\); (14.2) evaluates the full
tail. The symmetric row and column bound also bounds the
\(\ell^2\) operator norm, by the weighted Cauchy--Schwarz
proof following (14.4). Thus (16.15) applies to arbitrary
extensive real weights without an \(\ell^1\) loss.

For energy, retain the exact multiplication-state form
\[
\mathcal E^B_{ef}
 =\mathfrak q_A[u_e,u_f]
 =\kappa\int \rho\sum_h
       \nabla_h\mathcal B_e\cdot\nabla_h\mathcal B_f\,dU .
\]
Its Haar counterpart is
\(\mathcal E^{B,0}_{ef}
 =\kappa\langle\mathcal B_e,\mathfrak h_0\mathcal B_f\rangle_0\),
by integration by parts. Both matrices vanish when \(d(e,f)>4\).
The multiplier in the integral has sup norm at most \(168^2=28224\)
and support size at most \(338\). Formula (3.3) bounds the
coefficient of its expectation difference by
\[
2\cdot28224\cdot197(1+197/49152)
=\frac{1429097691}{128}<12000000.
\]
The same radius-four row count proves, for all real \(w\),
\[
|w^{\mathsf T}(\mathcal E^B-\mathcal E^{B,0})w|
\le6\cdot10^{10}\kappa\xi\|w\|_2^2 .                         \tag{16.16}
\]
The exact row coefficient \(4913\cdot12000000=58956000000\)
is smaller than the stated constant.

## 16.5. The full kernel identity and its uniform fourth-order remainder

For \(w\in\mathscr Z_L\), the two face sums vanish separately.
Thus the sum of its six outer weights at each adjacent pair is
\(-2w_{e(p,q)}\). Substituting in (16.2) gives the exact
function identity
\[
\mathcal B_w:=\sum_e w_e\mathcal B_e
 =\sum_{\{p,q\}\in\mathscr P_2}w_{e(p,q)}
         \left(-\tfrac19R_{pq}+\tfrac2{39}D_{pq}\right)
 =S_w .                                                     \tag{16.17}
\]
Indeed the summed \(c_{e;pq}\) is
\(-w_{e(p,q)}+(1/6)(-2w_{e(p,q)})=-4w_{e(p,q)}/3\).
This is precisely the parent's surviving two-face function;
the present calculation has not chosen a different weight
family or discarded one of its Casimir components.

Define
\[
\mathcal K_L(w,z)=\sum_e\binom{r_e}{2}w_ez_e,\qquad
d_0=\frac{196}{13689},\qquad e_0=\frac8{117}.
\]
Since \(2\le r_e\le4\),
\(\|w\|_2^2\le\mathcal K_L(w,w)\le6\|w\|_2^2\).
The orthogonality in (16.1) gives exactly
\[
\|\mathcal B_w\|_0^2=d_0\mathcal K_L(w,w),\qquad
\kappa\langle\mathcal B_w,\mathfrak h_0\mathcal B_w\rangle_0
=\kappa e_0\mathcal K_L(w,w).                                \tag{16.18}
\]
The retained component sums are
\(d_0=1/81+(3/4)(4/1521)\) and
\(e_0=(9/2)/81+(13/2)(3/4)(4/1521)\).
Each pair is counted once through its unique shared link.

The first-order term in (16.7) cancels exactly on
\(\mathscr Z_L\), because
\(\sum_e w_eh_e=(1/4)\sum_p(\mathsf Iw)_pW_p=0\).
Consequently the actual centered state satisfies
\[
v_w=\xi^2u_w+s_w,\qquad
u_w=Q_\psi\mathcal B_w\psi,\qquad
s_w=\sum_e w_es_e,\qquad w\in\mathscr Z_L.                   \tag{16.19}
\]
Both terms on the right are physical vectors of the full
interacting Hilbert space, on the domains used above.

Set the explicit positive errors
\[
\begin{split}
\varepsilon_C(\xi)
 &=r_B(\xi)+12\cdot10^6\xi\sqrt{6d_0+r_B(\xi)}
                              +36\cdot10^{12}\xi^2,\\
\varepsilon_N(\xi)
 &=6\cdot10^{10}\xi
   +2\cdot10^7\xi\sqrt{6e_0+6\cdot10^{10}\xi}
                              +10^{14}\xi^2.
\end{split}                                                  \tag{16.20}
\]
Then, simultaneously for every original box and every
real \(w\in\mathscr Z_L\),
\[
\begin{split}
\left|\|v_w\|^2-d_0\xi^4\mathcal K_L(w,w)\right|
 &\le\xi^4\varepsilon_C(\xi)\|w\|_2^2,\\
\left|\mathfrak q_A[v_w]
             -\kappa e_0\xi^4\mathcal K_L(w,w)\right|
 &\le\kappa\xi^4\varepsilon_N(\xi)\|w\|_2^2 .
\end{split}                                                  \tag{16.21}
\]
Here is the complete error calculation. Equations (16.15),(16.18)
give
\[
\left|\|u_w\|^2-d_0\mathcal K_L(w,w)\right|
\le r_B(\xi)\|w\|_2^2,\qquad
\|u_w\|\le\sqrt{6d_0+r_B(\xi)}\,\|w\|_2.
\]
Expand the squared norm of (16.19). Its cross term is at most
\(2\xi^2\|u_w\|\|s_w\|\), and its residual square is
\(\|s_w\|^2\). Substitution of (16.10) yields exactly the
first line of (16.20), with no hidden weight-dependent constant.

For energy, (16.16),(16.18) give
\[
\left|\mathfrak q_A[u_w]-\kappa e_0\mathcal K_L(w,w)\right|
 \le6\cdot10^{10}\kappa\xi\|w\|_2^2,\qquad
\mathfrak q_A[u_w]\le
 \kappa(6e_0+6\cdot10^{10}\xi)\|w\|_2^2.
\]
The nonnegative form satisfies Cauchy--Schwarz: apply ordinary
Cauchy--Schwarz to \(A^{1/2}u_w,A^{1/2}s_w\).
Thus the energy cross term in (16.19) is at most
\(2\xi^2\sqrt{\mathfrak q_A[u_w]\mathfrak q_A[s_w]}\).
Use (16.10), whose square-root coefficient is \(10^7\).
The residual energy contributes \(10^{14}\kappa\xi^6\|w\|_2^2\).
These are exactly the three terms in \(\varepsilon_N\), proving
the second line of (16.21).

Both errors tend to zero as \(\xi\downarrow0\).
Indeed \(\mathcal P_B\) is a fixed cubic with positive coefficients,
so \(\xi\mathcal P_B(\log(1/\xi))\to0\);
each remaining displayed term then tends to zero.
More explicitly, (16.21) gives a covariance remainder
\(O(\xi^5(1+\log(1/\xi))^3)\|w\|_2^2\) and an energy
remainder \(O(\kappa\xi^5)\|w\|_2^2\), with constants independent
of \(L,w\). These real-coupling estimates do not assert that the
fixed-box even Taylor expansion has a nonzero fifth-order term.
The parent's \(O_L(\xi^6)\) expansion remains true on its stated
fixed-box interval; its constant is not silently promoted to a
uniform one.

## 16.6. Nonzero kernel states and the uniform two-face energy quotient

The explicit interval
\[
0<\xi\le10^{-24}                                             \tag{16.22}
\]
has \(\varepsilon_C(\xi)<d_0/2\).
To check this without a numerical logarithm, put \(z=\log(1/\xi)\).
The positive-coefficient cubic \(\mathcal P_B\) has
\(e^{-z}\mathcal P_B(z)\) nonincreasing for \(z\ge3\);
differentiate each monomial \(e^{-z}z^k\), \(0\le k\le3\).
At the largest allowed \(\xi\), \(24<24\log10<72\), using
the exponential-series bounds \(e<10<e^3\).
The exact polynomial value is
\[
\mathcal P_B(72)=437811569040000 .
\]
It follows for all of (16.22) that
\[
r_B(\xi)\le
\frac{437811569040000}{10^{24}}<10^{-9},\qquad
6d_0+r_B(\xi)<1.
\]
The second and third terms of \(\varepsilon_C\) are therefore
bounded by \(12\cdot10^6/10^{24}\) and
\(36\cdot10^{12}/10^{48}\).
Their sum with the displayed rational bound is less than
\(10^{-9}<d_0/2\); every number in this comparison is rational.
This conservative interval is explicit, not asserted optimal.

For every nonzero real \(w\in\mathscr Z_L\), (16.21) now proves
\[
\|v_w\|^2\ge\xi^4(d_0-\varepsilon_C(\xi))\|w\|_2^2
 \ge\tfrac12d_0\xi^4\|w\|_2^2>0.                             \tag{16.23}
\]
The exact state map (15.18) is therefore injective on the
entire incidence kernel throughout the same volume-independent
interval. Its restriction is a bijection onto its image, and
(16.23) bounds its inverse, in the original edge norm and
physical state norm, by
\(\xi^{-2}\sqrt{2/d_0}\). Neither the weights nor the state
has been rescaled in that assertion.

Finally \(e_0/d_0=234/49\). Subtract
\((234/49)\kappa\) times the first line of (16.21) from the
second before dividing by the strictly positive bound (16.23).
The leading \(\mathcal K_L(w,w)\) terms cancel with their exact
coefficients. The result is
\[
\left|
 \frac{\mathfrak q_A[v_w]}{\|v_w\|^2}
          -\frac{234}{49}\kappa
\right|
\le
\kappa\,
\frac{\varepsilon_N(\xi)+(234/49)\varepsilon_C(\xi)}
     {d_0-\varepsilon_C(\xi)}
\quad
\left(0\ne w\in\mathscr Z_L,\ 0<\xi\le10^{-24}\right).
                                                               \tag{16.24}
\]
Its right-hand coefficient tends to zero independently of the
box and of every signed, volume-dependent or coupling-dependent
kernel weight. This proves the uniform first surviving
two-face quotient of the actual states, retaining both free
Casimir components only as coefficients of the full-vacuum
calculation.

The minimum over all signed actual states in (15.21) and the
kernel quotients in (16.24) describe the same state map on
different explicitly specified domains. Their central energies
are \(3\kappa\) and \((234/49)\kappa\); the difference
\((234/49-3)\kappa=(87/49)\kappa>0\) is explicit.
No implication of unrelatedness is drawn: (16.17)--(16.19) prove
the exact cancellation map and the surviving physical vectors.
The present injectivity assertion is on \(\mathscr Z_L\);
it is not a proof that \(\ker C=\{0\}\) on the entire edge space
for a uniform coupling interval.
Section 17 proves that stronger statement by controlling the mixed
one-face and two-face coefficient covariance; it does not infer it
from the kernel restriction.
The physical parameters remain
\(\xi=1/(4g_{\rm YM}^4)\), \(\kappa=2g_{\rm YM}^2/a\).
Interval (16.22) is \(g_{\rm YM}^4\ge250000000000000000000000\).
No spatial continuum construction, interchange of limits, or
Millennium conclusion is asserted by these finite-regulator
strong-coupling estimates.

# 17. Mixed face coordinates and uniform injectivity on the full edge space

We retain the same actual vacuum and all real edge weights, without
restricting to \(\ker\mathsf I\). The local residual construction of
Section 16 already applies to these weights. Its remaining leading
function contains both the one-face and two-face coordinates. We now
control their complete mixed covariance. Throughout
\(0<\xi\le1/49152\); the smaller interval used for a positive lower
bound will be stated separately.

## 17.1. Exact coefficient map, image and inverse

For each unordered adjacent pair \(\alpha=\{p,q\}\), put
\[
f_p=W_p,\qquad
f_\alpha=\tfrac1{12}R_{pq}-\tfrac1{26}D_{pq},\qquad
b_0=\tfrac1{144}+\tfrac3{4\cdot676}=\frac{49}{6084}.
\]
The index set is the disjoint union
\(\mathscr J_L=\mathsf P_L\sqcup\mathscr P_2\). These are real,
gauge-invariant smooth functions with zero Haar means, supported on
at most seven original links and of absolute value at most two.
The pair functions in fact have absolute value less than \(1/2\),
by the constants in (16.3).
For different faces the Wilson functions are orthogonal by integration
in a link appearing in only one face. Each has squared norm one.
Every one-face function is orthogonal to every \(R_{pq}\): their
four- and six-link fundamental supports differ. It is orthogonal
to every \(D_{pq}\), whose shared link has Casimir two rather than
zero or \(3/4\). Together with (16.1), these facts prove the entire
Haar Gram matrix, including its mixed blocks:
\[
\langle f_j,f_k\rangle_0=
\begin{cases}
1,&j=k\in\mathsf P_L,\\
b_0,&j=k\in\mathscr P_2,\\
0,&j\ne k.
\end{cases}                                                   \tag{17.1}
\]

For the original weight \(w\in\mathbb R^{\mathsf E_L}\), define
\[
\begin{split}
z_p&=(\mathsf Iw)_p,\\
c_\alpha&=\tfrac16(z_p+z_q)-\tfrac43w_{e(p,q)},\\
\mathsf T_\xi w&=a,\qquad
a_p=\tfrac{\xi}{4}z_p,\quad a_\alpha=\xi^2c_\alpha,\\
F_w&=\sum_{j\in\mathscr J_L}a_j f_j
     =\xi h_w+\xi^2\mathcal B_w .
\end{split}                                                   \tag{17.2}
\]
The formula for \(c_\alpha\) follows by summing the coefficients
in (16.2): the six outer weights sum to \(z_p+z_q-2w_e\).
Thus no term of \(\mathcal B_w\) is lost.
The exact state identity for all weights is
\[
v_w=Q_\psi F_w\psi+s_w .                                     \tag{17.3}
\]

Every link has at least two incident faces. Fix the lexicographically
first pair \(\alpha_e=\{p_e,q_e\}\) of them, using the original
integer face labels. On the whole coefficient space define
\[
\begin{split}
\mathsf L_\xi:\mathbb R^{\mathscr J_L}&\longrightarrow
                         \mathbb R^{\mathsf E_L},\\
(\mathsf L_\xi a)_e
 &=\frac{a_{p_e}+a_{q_e}}{2\xi}
                   -\frac{3a_{\alpha_e}}{4\xi^2}.
\end{split}                                                   \tag{17.4}
\]
Substitution of (17.2) gives
\((z_{p_e}+z_{q_e})/8-3c_{\alpha_e}/4=w_e\).
Consequently \(\mathsf L_\xi\mathsf T_\xi=I\) exactly,
\(\ker\mathsf T_\xi=\{0\}\), and
\(\mathsf T_\xi\mathsf L_\xi\) is an idempotent with image
\(\operatorname{Ran}\mathsf T_\xi\). A coefficient array \(a\)
lies in this image exactly when
\(a=\mathsf T_\xi\mathsf L_\xi a\). This is an explicit system
of linear equations, with inverse (17.4) on that image.
The powers of \(\xi\) belong to this recorded coefficient map;
the original physical state and its norm have not been changed.

Let \((\mathsf Jz)_\alpha=z_p+z_q\). Each face has at most twelve
adjacent faces, since its four links each meet at most three other
faces. Therefore
\[
\|\mathsf Jz\|_2^2
\le2\sum_{\{p,q\}\in\mathscr P_2}(z_p^2+z_q^2)
\le24\|z\|_2^2 .
\]
Using \(w_{e(p,q)}=(\mathsf Jz)_\alpha/8-3c_\alpha/4\)
at every pair, not only the selected pair, gives
\[
\|w\|_2^2\le\mathcal K_L(w,w)
\le\tfrac34\|z\|_2^2+\tfrac98\|c\|_2^2.                      \tag{17.5}
\]
Indeed \(|x+y|^2\le2|x|^2+2|y|^2\) gives the coefficients
\(24/32=3/4\) and \(18/16=9/8\).
Write \(d_0=196/13689\) as before. The exact Haar value is
\[
\begin{split}
\mathcal H_\xi(w):=\|F_w\|_0^2
 &=\tfrac{\xi^2}{16}\|\mathsf Iw\|_2^2
                         +b_0\xi^4\|c\|_2^2,\\
\mathcal H_\xi(w)&\ge\tfrac{d_0}{2}\xi^4\|w\|_2^2 .
\end{split}                                                   \tag{17.6}
\]
For the second inequality multiply (17.5) by
\((d_0/2)\xi^4\). The pair coefficients agree because
\(9d_0/16=b_0\), and the face coefficient is bounded by
\(\xi^2/16\), since \(\xi\le1\) and \(3d_0/8<1/16\).
No inverse singular value of \(\mathsf I\) was used.

## 17.2. The full actual-vacuum Gram matrix

Anchor each face \((n;i,j)\), \(i<j\), at link \((n,i)\);
anchor each pair at its unique shared link. At most two face
indices and at most six pair indices have the same anchor.
All supports lie in the radius-one link ball of their anchor.
Hence the number of indices whose anchors lie within distance
\(D\) of a fixed anchor is at most \(8(4D+1)^3\).

Put
\[
\mathsf G^\psi_{jk}
=\langle Q_\psi f_j\psi,Q_\psi f_k\psi\rangle,\qquad
\mathsf G^0_{jk}=\langle f_j,f_k\rangle_0 .
\]
Each support has at most seven links, and two supports together
have at most fourteen. In (3.2)--(3.3) use
\((32/3)\sqrt7<29\), \((32/3)\sqrt{14}<40\).
The means satisfy
\[
|\langle f_j\rangle_\psi|
\le116\xi(1+29\xi)<117\xi.
\]
The product has absolute value at most four. Keeping the
product of the means, the entrywise difference is bounded by
\[
|\mathsf G^\psi_{jk}-\mathsf G^0_{jk}|
\le\bigl[320+(12800+13689)/49152\bigr]\xi<400\xi.              \tag{17.7}
\]

For anchor distance \(d\ge3\), the supports are disjoint and
their distance is at least \(s=d-2\ge1\).
Apply the full-dynamics estimate (16.13) with \(|X|\le7\)
and \(\|f_j\|\|f_k\|\le4\), and the exact Gaussian integral
proof (13.7), retaining \(T=s/(\Delta_*+2v)\).
Here \(s_0\le4\). The two resulting terms are bounded by
\[
\frac{28}{100}s e^{-99s/100}+12e^{-s/4}
\le\left(\frac{28}{74}+12\right)e^{-s/4}.
\]
Since \(e^{1/2}<2\), this proves
\[
|\mathsf G^\psi_{jk}|\le32e^{-d/4}\qquad(d\ge3).             \tag{17.8}
\]
The constants follow from the same strong on-site evolution
and spectral integrals as in Section16.4, using the original
Nachtergaele--Sims source proofs cited there. No infinite-volume
Hamiltonian or tensorized correlated vacuum is assumed.

For \(d\ge3\), \(\mathsf G^0_{jk}=0\) also follows from disjoint
supports and zero Haar means. Define, with \(G\) from (14.2),
\[
\begin{split}
\mathcal P_{\mathrm{mix}}(z)
 &=8\left[400(16z+5)^3+32G(16z+9,4/5)\right],\\
\rho_{\mathrm{mix}}(\xi)
 &=\xi\mathcal P_{\mathrm{mix}}(\log(1/\xi)).
\end{split}                                                   \tag{17.9}
\]
Taking \(D=\lceil4\log(1/\xi)\rceil\ge2\), summing (17.7)
inside and (17.8) outside, with the anchor multiplicity eight,
gives
\[
\sup_j\sum_k|\mathsf G^\psi_{jk}-\mathsf G^0_{jk}|
\le\rho_{\mathrm{mix}}(\xi),\qquad
\|\mathsf G^\psi-\mathsf G^0\|_{\ell^2\to\ell^2}
\le\rho_{\mathrm{mix}}(\xi).                                \tag{17.10}
\]
The summation is exactly
\(8[400\xi(4D+1)^3+32\sum_{n>D}(4n+1)^3e^{-n/4}]\).
Equation (14.2) evaluates its complete tail and
\(e^{-D/4}\le\xi\) proves (17.10).
The symmetric row/column argument of (14.4) proves the
operator-norm statement. Thus the mixed blocks have been
bounded, not set to zero in the actual density.

For \(a=\mathsf T_\xi w\), put
\[
\mathcal A_\xi(w)=\|a\|_2^2
 =\tfrac{\xi^2}{16}\|z\|_2^2+\xi^4\|c\|_2^2 .
\]
Equations (17.1) and (17.10) imply
\[
\left|\|Q_\psi F_w\psi\|^2-\mathcal H_\xi(w)\right|
\le\rho_{\mathrm{mix}}(\xi)\mathcal A_\xi(w),\qquad
b_0\mathcal A_\xi(w)\le\mathcal H_\xi(w).                    \tag{17.11}
\]
In particular the following complete all-weight covariance
error keeps both coefficient arrays:
\[
\begin{split}
\left|\|v_w\|^2-\mathcal H_\xi(w)\right|
&\le \rho_{\mathrm{mix}}(\xi)\mathcal A_\xi(w)\\
&\quad+12\cdot10^6\xi^3\|w\|_2
 \sqrt{\mathcal H_\xi(w)+\rho_{\mathrm{mix}}(\xi)\mathcal A_\xi(w)}\\
&\quad+36\cdot10^{12}\xi^6\|w\|_2^2 .
\end{split}                                                   \tag{17.12}
\]
This is the squared norm expansion of (17.3), the exact
bound (17.11), and the original residual norm (16.10).
It applies to signed, volume-dependent and coupling-dependent
weights, including mixtures approaching \(\ker\mathsf I\).

## 17.3. A positive uniform interval for every raw weight

On \(0<\xi\le10^{-24}\), the positive-coefficient cubic in
(17.9) gives
\(\rho_{\mathrm{mix}}(\xi)\le10^{-24}\mathcal P_{\mathrm{mix}}(72)\),
by the monomial monotonicity and \(24<24\log10<72\) used in
Section16.6. Direct rational evaluation of (17.9) gives
\(\mathcal P_{\mathrm{mix}}(72)=7044756359040<10^{13}\), so
\[
\rho_{\mathrm{mix}}(\xi)<10^{-11}<b_0/4,\qquad
(24\cdot10^6\xi)^2<d_0/2 .                                 \tag{17.13}
\]
Both numerical comparisons are rational and hold on the
whole stated interval. Equations (17.11), (17.13) show
\(\|Q_\psi F_w\psi\|\ge(3/4)\sqrt{\mathcal H_\xi(w)}\),
since \(1-\rho_{\mathrm{mix}}/b_0>3/4>(3/4)^2\).
The second inequality in (17.13) and (16.10) give
\(\|s_w\|\le(1/4)\sqrt{d_0/2}\xi^2\|w\|_2\).
Use (17.6) in the reverse triangle inequality for (17.3).
For every real \(w\) the result is
\[
\boxed{\quad
\|v_w\|^2\ge\frac{d_0}{8}\xi^4\|w\|_2^2,\qquad
C(\xi)\ge\frac{d_0}{8}\xi^4 I_{\mathbb R^{\mathsf E_L}}
\quad(0<\xi\le10^{-24}).\quad}                               \tag{17.14}
\]
This is on the entire original edge space, uniformly in \(L\).
It strengthens, rather than substitutes for, the sharper
kernel lower bound (16.23).

The physical state map \(V_\xi:w\mapsto v_w\) of (15.18)
therefore has zero kernel on this interval and is bijective
onto its actual image, with inverse norm at most
\(\xi^{-2}\sqrt{8/d_0}\). An explicit inverse on that image is
\[
w=C(\xi)^{-1}
      \bigl(\langle v_e,v_w\rangle\bigr)_{e\in\mathsf E_L}.
                                                               \tag{17.15}
\]
Indeed the vector on the right before applying \(C^{-1}\)
is precisely \(Cw\). Inequality (17.14) proves existence of
this finite-matrix inverse, and the physical inverse-norm bound
follows directly by taking square roots in (17.14).
No identification of these vectors as individual eigenvectors
is made. The original signed minimum (15.21), kernel quotient
(16.24), and full mixed covariance (17.12) all refer to this
same injective state map on their stated intervals.
The original spacing \(a>0\), coupling \(g_{\rm YM}\) and every
Hamiltonian term remain unchanged. This calculation does not
take a spatial continuum limit or continue beyond the displayed
strong-coupling interval.

# 18. Complete mixed energy and the original electric-state Ritz spectrum

Write \(A=H-\mathcal E\), with exactly the Hamiltonian, domains and
actual vacuum of Section 1. The coefficients \(z,c,a=\mathsf T_\xi w\),
the function \(F_w\), and the positive quadratic form
\(\mathcal H_\xi(w)\) are those of Section 17. We first work on
\(0<\xi\le1/49152\), and then give an explicit smaller interval for
all quotients and ordered Ritz values. All weights remain the original
real link arrays; none is replaced by a unit vector or a different
choice of physical coefficients.

## 18.1. The complete coefficient energy matrix

For \(j,k\in\mathscr J_L\) define
\[
\mathsf K^\psi_{jk}
 =\kappa\int\psi^2\sum_e\nabla_e f_j\cdot\nabla_e f_k\,dU,
\qquad
\mathsf K^0_{jk}
 =\kappa\int\sum_e\nabla_e f_j\cdot\nabla_e f_k\,dU .       \tag{18.1}
\]
Equation (1.5), polarized over real smooth functions, proves that
\(\mathsf K^\psi\) is exactly the energy Gram matrix of
\(Q_\psi f_j\psi\). Centering contributes no derivative. Every
function and state here is smooth on the full compact link manifold,
so both the form and operator domains are available.

Haar integration by parts gives
\(\mathsf K^0_{jk}=\kappa\langle f_j,\mathfrak h_0f_k\rangle_0\).
Each \(W_p\) has free energy \(3\). For a pair, retaining the two
distinct eigenvalues in (16.1) gives
\[
\langle f_\alpha,\mathfrak h_0 f_\alpha\rangle_0
 =\frac{9/2}{144}+\frac{(13/2)(3/4)}{676}=\frac1{26}.
\]
The link-Casimir orthogonality proved in Sections16.1 and17.1
annuls every other Haar entry, including the face/pair entries.
Thus the entire coefficient matrix and its original-weight form are
\[
\begin{split}
\mathsf K^0_{jk}&=
\begin{cases}
3\kappa,&j=k\in\mathsf P_L,\\
\kappa/26,&j=k\in\mathscr P_2,\\
0,&j\ne k,
\end{cases}\\
\mathcal J_\xi(w)&:=\kappa^{-1}a^t\mathsf K^0a
 =\frac{3\xi^2}{16}\|z\|_2^2+\frac{\xi^4}{26}\|c\|_2^2,\\
3\mathcal H_\xi(w)&\le\mathcal J_\xi(w)
 \le q_*\mathcal H_\xi(w),\qquad q_*:=\frac{234}{49}.
\end{split}                                                   \tag{18.2}
\]
Indeed \((1/26)/b_0=234/49\), with the unchanged
\(b_0=49/6084\). These are Haar coefficient calculations, not a
replacement of the actual matrix \(\mathsf K^\psi\).

For a face, \(\sum_e\|\nabla_e f_p\|_\infty\le4\), by (6.2).
For a pair, the seven derivative bounds preceding (16.3) each
are less than \(1/2\); their sum is less than \(7/2<4\).
Consequently the real multiplier
\(M_{jk}=\sum_e\nabla_e f_j\cdot\nabla_e f_k\) has
\(\|M_{jk}\|_\infty\le16\). Its support has at most fourteen
links. Apply the actual local marginal estimate (3.3) with
\(q_S<40\xi\). It yields
\[
|\mathsf K^\psi_{jk}-\mathsf K^0_{jk}|
 \le1280\kappa\xi(1+40\xi)<1300\kappa\xi .                 \tag{18.3}
\]
If the anchors of \(j,k\) have link-graph distance greater than
two, their link supports are disjoint. Each summand in
\(M_{jk}\) then vanishes pointwise. Both energy entries, not
merely their difference, are zero. There are at most
\(8(4\cdot2+1)^3=8\cdot9^3\) indices at anchor distance at
most two from any one anchor. The exact row coefficient is
\(1300\cdot8\cdot9^3=7581600<8000000\). Put
\[
\chi_E(\xi)=8000000\xi.
\]
The symmetric row/column estimate therefore proves
\[
\begin{split}
\sup_j\sum_k|\mathsf K^\psi_{jk}-\mathsf K^0_{jk}|
 &\le\kappa\chi_E(\xi),\\
\|\mathsf K^\psi-\mathsf K^0\|_{\ell^2\to\ell^2}
 &\le\kappa\chi_E(\xi),\\
\left|\mathfrak q_A[Q_\psi F_w\psi]-\kappa\mathcal J_\xi(w)\right|
 &\le\kappa\chi_E(\xi)\mathcal A_\xi(w).
\end{split}                                                   \tag{18.4}
\]
All actual mixed entries are retained in the left sides of
(18.3)--(18.4); their smallness was calculated from the vacuum.

Now use the exact identity (17.3), not an identification with
its leading part. Positivity of \(A\) and Cauchy--Schwarz for
its form give the complete energy error
\[
\begin{split}
|w^t\mathcal Nw-\kappa\mathcal J_\xi(w)|
&\le\kappa\chi_E(\xi)\mathcal A_\xi(w)\\
&\quad+2\cdot10^7\kappa\xi^3\|w\|_2
 \sqrt{\mathcal J_\xi(w)+\chi_E(\xi)\mathcal A_\xi(w)}\\
&\quad+10^{14}\kappa\xi^6\|w\|_2^2.
\end{split}                                                   \tag{18.5}
\]
The cross term is bounded by
\(2\sqrt{\mathfrak q_A[Q_\psi F_w\psi]\mathfrak q_A[s_w]}\);
(18.4) bounds its first factor and (16.10) its second.
This proves (18.5) for every weight, including any dependence
of the weight on the box and coupling.

## 18.2. Uniform relative errors and every electric-state quotient

Keep \(d_0=196/13689\) and \(\rho_{\rm mix}\) from (17.9).
Define the following explicit functions of the original \(\xi\):
\[
\begin{split}
r(\xi)&=\rho_{\rm mix}(\xi)/b_0,\qquad
t_C(\xi)=6\cdot10^6\sqrt{2/d_0}\,\xi,\\
t_N(\xi)&=10^7\sqrt{2/d_0}\,\xi,\\
\beta_C(\xi)&=r(\xi)+2t_C(\xi)\sqrt{1+r(\xi)}+t_C(\xi)^2,\\
\beta_N(\xi)&=\frac{\chi_E(\xi)}{b_0}
 +2t_N(\xi)\sqrt{q_*+\frac{\chi_E(\xi)}{b_0}}+t_N(\xi)^2.
\end{split}                                                   \tag{18.6}
\]
By (17.6) and (17.11),
\(\|w\|_2\le\sqrt{2/d_0}\xi^{-2}\sqrt{\mathcal H_\xi(w)}\)
and \(\mathcal A_\xi(w)\le\mathcal H_\xi(w)/b_0\).
Substitution into every term of (17.12) and (18.5), followed by
the two inequalities in (18.2), proves
\[
\begin{split}
|w^tCw-\mathcal H_\xi(w)|
 &\le\beta_C(\xi)\mathcal H_\xi(w),\\
|w^t\mathcal Nw-\kappa\mathcal J_\xi(w)|
 &\le\kappa\beta_N(\xi)\mathcal H_\xi(w).
\end{split}                                                   \tag{18.7}
\]
For example the covariance cross term, divided by
\(\mathcal H_\xi(w)\), is at most
\(12\cdot10^6\sqrt{2/d_0}\xi\sqrt{1+r}\), exactly the
middle term of \(\beta_C\). The energy calculation has the
same retained two factors and yields its displayed \(\beta_N\).
All these functions tend to zero as \(\xi\downarrow0\):
\(\rho_{\rm mix}\) is \(\xi\) times a fixed cubic in
\(\log(1/\xi)\), and all other factors are displayed.

On the explicit nonempty interval \(0<\xi\le10^{-24}\), set
\(x_0=10^{-24}\) only for recording numerical bounds. Equation
(17.13), \(2/d_0=13689/98<144\), and rational comparisons give
\[
\begin{split}
\beta_C(\xi)&<B_C:={10^{-11}\over b_0}
 +4(72\cdot10^6x_0)+(72\cdot10^6x_0)^2<10^{-8},\\
\beta_N(\xi)&<B_N:={8000000x_0\over b_0}
 +6(120\cdot10^6x_0)+(120\cdot10^6x_0)^2<2\cdot10^{-15}.
\end{split}                                                   \tag{18.8}
\]
Here \(1+10^{-11}/b_0<4\) and
\(q_*+8000000x_0/b_0<9\) justify respectively the square-root
bounds two and three used above. The polynomial monotonicity
proved in Section17.3 makes these bounds valid on the whole
interval, not just at its upper endpoint. Define
\[
\delta(\xi)=\frac{\beta_N(\xi)+q_*\beta_C(\xi)}{1-\beta_C(\xi)}.
\]
Its denominator is positive and
\(\delta(\xi)<(B_N+q_*B_C)/(1-B_C)<10^{-7}\).
For every nonzero original weight, (17.14) permits division
by the actual norm. Subtract the two quotients with their
denominators retained:
\[
\begin{split}
{w^t\mathcal Nw\over w^tCw}
 -{\kappa\mathcal J_\xi(w)\over\mathcal H_\xi(w)}
&={w^t\mathcal Nw-\kappa\mathcal J_\xi(w)\over w^tCw}\\
&\quad-{\kappa\mathcal J_\xi(w)\over\mathcal H_\xi(w)}
 {w^tCw-\mathcal H_\xi(w)\over w^tCw}.
\end{split}
\]
Since \(w^tCw\ge(1-\beta_C)\mathcal H_\xi(w)\), this proves
\[
\boxed{\quad
\left|{w^t\mathcal Nw\over w^tCw}
       -{\kappa\mathcal J_\xi(w)\over\mathcal H_\xi(w)}\right|
 \le\kappa\delta(\xi),\quad
0<\xi\le10^{-24},\quad w\ne0.\quad}                         \tag{18.9}
\]
The bound is uniform in every original box and every such
weight. It controls all quotients, not only the minimum or
the incidence kernel. In particular they all lie between
\(\kappa(3-\delta(\xi))\) and \(\kappa(q_*+\delta(\xi))\).
The independent stronger physical lower bound
\(3\kappa(1-512\xi/3)\) from (15.13) still applies.

For a precise record of the interpolation, put
\[
\eta_\xi(w)={b_0\xi^4\|c\|_2^2\over\mathcal H_\xi(w)}.
\]
Then \(0\le\eta_\xi(w)\le1\), and the coefficient quotient
satisfies the exact identity
\[
\frac{\mathcal J_\xi(w)}{\mathcal H_\xi(w)}
 =3+\frac{87}{49}\eta_\xi(w).                                \tag{18.10}
\]
This records both contributions with their original powers
of coupling. It is not a change of state or its norm.

## 18.3. Exact compression, inverse and retained leakage

Let \(\mathcal H_{\rm phys,\mathbb R}\) be the real-valued
part of the gauge-invariant Hilbert space. The real operator
\(A\) preserves it. Set
\(\mathscr S_\xi=\operatorname{Ran}V_\xi\subset
 \mathcal H_{\rm phys,\mathbb R}\cap\psi^\perp\), where
\(V_\xi w=v_w\). On the interval above, (17.14) proves
\(\dim\mathscr S_\xi=N\). Every vector of this space is
smooth. The adjoint and the orthogonal projection are
\[
\begin{split}
V_\xi^*f&=(\langle v_e,f\rangle)_e,\qquad V_\xi^*V_\xi=C,\\
P_{\mathscr S_\xi}&=V_\xi C^{-1}V_\xi^*.
\end{split}                                                   \tag{18.11}
\]
The last operator is self-adjoint because \(C\) is positive
and symmetric. Its square is itself by \(V_\xi^*V_\xi=C\).
Its range is contained in \(\mathscr S_\xi\), and it fixes
\(V_\xi w\) for every \(w\); thus it is the stated projection.
The inverse of \(V_\xi\) on its image is \(C^{-1}V_\xi^*\),
which is the exact formula (17.15).

Define the self-adjoint finite-dimensional compression
\(R_\xi=P_{\mathscr S_\xi}A|_{\mathscr S_\xi}\). For
\(u,v\in\mathscr S_\xi\),
\(\langle u,R_\xi v\rangle=\langle u,Av\rangle
=\langle Au,v\rangle\). Its coordinate intertwiner and its
full uncompressed action are exactly
\[
\begin{split}
R_\xi V_\xi&=V_\xi C^{-1}\mathcal N,\\
AV_\xi&=V_\xi C^{-1}\mathcal N+\mathcal L_\xi,\qquad
\mathcal L_\xi:=(I-P_{\mathscr S_\xi})AV_\xi,\\
V_\xi^*\mathcal L_\xi&=0.
\end{split}                                                   \tag{18.12}
\]
These follow by inserting (18.11) and
\(V_\xi^*AV_\xi=\mathcal N\). The domain of
\(\mathcal L_\xi\) is the entire finite edge space; its
codomain is \(\mathscr S_\xi^\perp\cap
\mathcal H_{\rm phys,\mathbb R}\cap\psi^\perp\).
Thus \(C^{-1}\mathcal N\) is self-adjoint in the exact
inner product \(\langle w,z\rangle_C=w^tCz\). This records
its metric rather than replacing it by the Euclidean one.
The map \(V_\xi\) is an isometry from this metric space
onto \(\mathscr S_\xi\). Its Rayleigh quotient is exactly
the first quotient in (18.9). No vanishing of
\(\mathcal L_\xi\), or invariance of the state image under
\(A\), is used or asserted.

## 18.4. Ordered Ritz values and the exact top coefficient eigenspace

Let \(B_0\) be the diagonal coefficient matrix with entries
one on faces and \(b_0\) on pairs, and let \(B_1\) have
entries three on faces and \(1/26\) on pairs. On the original
edge space define
\[
\mathsf H_\xi=\mathsf T_\xi^tB_0\mathsf T_\xi,\qquad
\mathsf J_\xi=\mathsf T_\xi^tB_1\mathsf T_\xi,
\qquad K^{\rm coeff}_\xi=\mathsf H_\xi^{-1}\mathsf J_\xi.
                                                               \tag{18.13}
\]
Their quadratic forms are respectively \(\mathcal H_\xi\)
and \(\mathcal J_\xi\), and (17.6) proves the inverse exists.
The operator \(K^{\rm coeff}_\xi\) is self-adjoint in the
positive metric \(\mathsf H_\xi\). Let its ordered eigenvalues
be \(\mu_1\le\cdots\le\mu_N\), retaining their dependence
on \(L,\xi\), and let \(\lambda_1\le\cdots\le\lambda_N\)
be those of \(R_\xi\), with physical energy units retained.

Here is the full variational comparison argument. For any
self-adjoint operator \(B\) in a finite-dimensional positive
inner product \(g\), take a \(g\)-orthonormal eigenbasis with
ordered eigenvalues \(\nu_i\). A \(j\)-dimensional subspace
intersects the \(g\)-orthogonal complement of the first
\(j-1\) eigenvectors in a nonzero vector: the projection
onto their span has rank at most \(j-1\). Such a vector has
Rayleigh quotient at least \(\nu_j\), by its eigenbasis
expansion. The span of the first \(j\) eigenvectors has
maximum quotient exactly \(\nu_j\). Hence
\[
\nu_j=\min_{\substack{W\text{ linear}\\\dim W=j}}
       \ \max_{0\ne w\in W}\frac{g(w,Bw)}{g(w,w)}.
                                                               \tag{18.14}
\]
The eigenbasis used to prove this identity does not change
the original physical vectors or either retained Gram matrix.
Both problems in (18.13) and (18.12) use precisely the same
collection of linear subspaces of the raw edge space. Apply
(18.9) to every nonzero vector of every one of those subspaces,
then take the maximum and minimum in (18.14). This proves
\[
\boxed{\quad
|\lambda_j/\kappa-\mu_j|\le\delta(\xi)
\quad(1\le j\le N),\qquad 3\le\mu_j\le\frac{234}{49}.
\quad}                                                       \tag{18.15}
\]
No volume-dependent matrix perturbation constant enters.

The top eigenspace of the coefficient problem is computable
exactly, without solving a large characteristic polynomial:
\[
q_*\mathsf H_\xi-\mathsf J_\xi
 =\frac{87}{49}\frac{\xi^2}{16}\mathsf I^t\mathsf I,
\qquad
\ker(K^{\rm coeff}_\xi-q_*I)=\ker\mathsf I .                 \tag{18.16}
\]
The first identity follows by retaining both diagonal blocks
in (18.13); the pair block vanishes because \(q_*b_0=1/26\).
Its right side is positive, with zero quadratic form exactly
when \(\mathsf Iw=0\). Invertibility of \(\mathsf H_\xi\)
then proves the stated equality of kernels.

The exact original-box incidence calculation in the parent,
*Electric covariance and unsigned incidence*, Section3,
equations(3.2)--(3.9), gives
\(\dim\ker\mathsf I=3m(m+1)=N-M\), \(m=2L\).
For explicitness, its coordinate proof writes
\(w_i(n)=(-1)^{n_1+n_2+n_3}a_i(n)\) and turns the kernel
equations into \(D_ja_i+D_ia_j=0\). Commuting differences in
three distinct directions gives \(D_kD_ja_i=0\). The complete
inverse parameters are the longitudinal boundary values
\(f_i(n_i)\) and anchored potentials
\(\varphi_{ij}(x,y)=\sum_{r=-L}^{x-1}u_{ij}(r,y)\), where
\(u_{ij}(x,y)=a_i(x\mathbf e_i+y\mathbf e_j-L\mathbf e_k)-f_i(x)\).
They obey \(\varphi_{ij}(-L,y)=\varphi_{ij}(x,-L)=0\), and
reconstruct
\[
a_i(n)=f_i(n_i)+\sum_{j>i}D_i\varphi_{ij}(n_i,n_j)
                    -\sum_{j<i}D_i\varphi_{ji}(n_j,n_i).
\]
The vanishing transverse mixed difference proves the additive
decomposition giving these parameters; summing
\(D_ju_{ij}+D_iu_{ji}=0\) proves both reconstructed cross
derivatives. The boundary values and finite sums fix the inverse
uniquely. There are \(3m\) longitudinal and \(3m^2\) anchored
potential entries, on the original edge and vertex domains.
Thus (18.16), including multiplicities, gives
\[
\begin{split}
\mu_{M+1}=\cdots=\mu_N&=\frac{234}{49},\qquad
\mu_j<\frac{234}{49}\quad(1\le j\le M),\\
\left|\lambda_j-\frac{234}{49}\kappa\right|
 &\le\kappa\delta(\xi)\quad(M+1\le j\le N).
\end{split}                                                   \tag{18.17}
\]
No uniform separation of \(\mu_M\) from \(q_*\) is asserted.
The last \(N-M\) Ritz values need not be exactly equal; the
comparison preserves the actual mixed energy and covariance.

## 18.5. Consequence for the true physical excitation eigenvalues

The gauge-invariant restriction of \(A\) has compact resolvent
because its gauge projection commutes with the full resolvent;
the restriction is a compression of a compact operator. Remove
its simple vacuum. The remaining physical space is infinite
dimensional: characters of every integer and half-integer spin
of a fixed face holonomy are gauge invariant, and are linearly
independent by integration in one face link. Removing one
dimension does not change that fact. Let
\(\epsilon_1\le\epsilon_2\le\cdots\) be the true excitation
eigenvalues there, counted with multiplicity.

The eigenbasis proof of (18.14) applies also to this positive
compact-resolvent operator: the first \(j\) eigenvectors give
the upper variational inequality, and expansion of the
nonzero intersection with their first \(j-1\) orthogonal
complement gives the lower one. This uses the form domain
for the nonnegative convergent spectral sum. Restricting the
admissible \(j\)-dimensional spaces to
\(\mathscr S_\xi\subset\operatorname{Dom}A\) therefore gives
\[
\begin{split}
3\kappa(1-512\xi/3)&\le\epsilon_j\le\lambda_j
 \le\kappa\bigl(\mu_j+\delta(\xi)\bigr)\quad(1\le j\le N),\\
\#\{j:\epsilon_j\le\kappa(q_*+\delta(\xi))\}&\ge N.
\end{split}                                                   \tag{18.18}
\]
The lower bound is the independent physical gap proof (15.13).
The upper inequalities and count are for the original interacting
operator, not the free coefficient operator. They do not transfer
the exact coefficient multiplicity in (18.17) into a physical
eigenvalue multiplicity. Equation (18.12) gives the exact map
and retained leakage underlying that distinction. All energies
are measured from the actual \(\mathcal E\); no level below
that spectral minimum has been introduced.

For the original nonnegative native weights in (1.4), the
sharper targeted bounds of Section14 remain in force. The
present result additionally controls every mixed signed weight
and the full ordered electric-state compression. It leaves
\(a>0\), \(\kappa=2g_{\rm YM}^2/a\),
\(\xi=1/(4g_{\rm YM}^4)\), and the geometric input (1.3)
unchanged. No spatial continuum limit or Millennium conclusion
is inferred from this finite-regulator strong-coupling result.

## 18.6. Precise literature dependency and an attainment counterexample

The canonical corpus routes the variational method to Mathieu
Lewin, *Spectral Theory and Quantum Mechanics*, Universitext,
Springer2024, DOI[10.1007/978-3-031-66878-4](https://doi.org/10.1007/978-3-031-66878-4),
Section5.6.1, printed pages201--204. Equations(5.42) and(5.44)
are the min--max value and restriction inequality used here;
(18.14) and(18.18) provide their proofs in the exact present
spaces. Two details in that edition must not be imported as
extra mathematical claims.

First, the sentence on page202 asserting that the minimizing
subspaces are exactly eigenvector-generated low-energy spaces,
and the concluding necessity argument on page204, fail for
the following explicit example. On \(\mathbb R^3\) with its
Euclidean inner product take
\[
B=\operatorname{diag}(0,1,2),\qquad
W=\operatorname{span}(e_2,e_1+e_3).
\]
For all real \(s,t\),
\[
\langle se_2+t(e_1+e_3),B[se_2+t(e_1+e_3)]\rangle
 =s^2+2t^2=\|se_2+t(e_1+e_3)\|^2.                           \tag{18.19}
\]
Every nonzero vector of \(W\) has quotient one, the second
eigenvalue of \(B\). The dimension-intersection proof of
(18.14) proves this is the minimizing value. Yet \(W\) is
not contained in \(\operatorname{span}(e_1,e_2)\), and
\(W\cap\operatorname{span}(e_3)=\{0\}\). Failure of
containment does not imply the nonzero intersection used in
the source's necessity argument. The min--max value itself
is unaffected; only that characterization of all attaining
spaces is refuted.

Second, the matrix following (5.44) represents the stated
ordinary eigenvalues with an orthonormal basis. For a general
basis \(v_i\), the exact coordinate problem is
\(\mathcal Nw=\lambda Cw\), with both Gram matrices retained,
as proved in (18.11)--(18.12). Already on \(\mathbb R\), the
identity operator and basis vector \(v_1=2\) give
\(\mathcal N=(4)\), \(C=(4)\), and eigenvalue one, not four.
These independent finite-dimensional checks explain exactly
which source assertions are used and which are corrected.
They assert nothing about unread editions or other parts of
the book. No protected bulk text is reproduced in this note.
