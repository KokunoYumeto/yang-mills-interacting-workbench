# Retained cusp and the actual quantum magnetic state

The complete calculation is in [spatial_continuum.md](spatial_continuum.md), with standalone [TeX](spatial_continuum.tex) and a [readable PDF](spatial_continuum.pdf). It proves exact cusp/refinement maps, spectral escape with both volume-dependent and uniform coupling bounds, a positive raw high-energy loop fraction at every fixed positive coupling, and the resulting spectral atom at infinity. The weak-coupling continuation proves actual-vacuum energy and electric-moment bounds, vanishing of the original magnetic-state norm at a fixed physical electric coefficient, and an explicit pure-gauge configuration limit on a specified decreasing-coupling trajectory. The relative continuation adds explicit all-positive-coupling covariance and native-mass lower bounds and an exact corrected cusp on which two decreasing-coupling native probabilities approach their actual electric covariance probabilities in total variation. The graph continuation proves the actual weighted electric-state limit at each fixed box, its complete raw pair spectral measure, and a specified sequence of full positive-coupling Hamiltonians whose gaps close while the native magnetic probability escapes every bounded physical energy interval. A bounded physical low-mode observable has an exact Gamma/Laguerre spectral measure with positive raw mass; on its separately selected macroscopic diagonal that mass converges to a zero-energy atom, incompatible with a unique vacuum when the original centering is retained. Every map, coefficient and raw amplitude is retained in the full 116-page proof. The refreshed retained volume-uniform companion source also proves exact all-weight covariance injectivity and a signed finite-box Rayleigh control in its explicit strong-coupling interval. The new fluid bridge proves invariant curvature concentration, a finite magnetic spacetime bound, and a necessarily singular conserved gauge current, with a complete shrinking-loop holonomy calculation on the cited source's displayed core data. The external Navier--Stokes existence proof remains independently unverified here. Corrected material-tensor source proofs and their three exact spectral sectors are retained. Section22 proves a separate radial Gamma measure with positive raw mass in every low-energy interval, and an exact positive electric double commutator whose rescaled carrier action, complete polynomial insertion kernels and first energy moment converge. Its centered action on the vacuum has a nonzero zero-energy atom, giving the precise obstruction when that observable action is retained. Section23 gives an exact common-sequence correspondence between compact local-energy first-band states and the sum of three original radial vacuum-image directions, with coefficient H_h/50. It extends to all seven vacuum-plus-first-band operator coordinates, retaining the original mode map, raw overlap factors and nonzero terms leaving the band. Sections24–25 prove the full local directional electric density and the original weighted all-mode trace, with exact finite-energy probability coefficient a⁵Ω⁵/(600π²I_lat). A strengthened actual dyadic sequence and cusp carry this coefficient to the native magnetic state, retaining every raw amplitude. Section26 proves direct finite-energy escape for the unchanged original cusp state on a common selected weak-coupling sequence. It proves explicit raw upper/lower bounds, spectral separation and vector orthogonality from the covariance and strengthened-cusp states, and actual failure of the relative angular Taylor approximation on that sequence. The original prescribed paths and interacting four-dimensional continuum and mass-gap counterexample remain unproved.

`CURRENT_HANDOFF.md` records the current result, exact parameter dictionary and unresolved continuation. `sources/` retains the source mathematics and primary literature TeX. The main manuscript contains the full proofs of the new assertions; its copied temporal-transfer source supplies the previously established finite-spatial-regulator temporal theorem.

Run the exact diagnostics with Python and SymPy:

```text
python check_spatial_continuum.py
python check_weak_continuation.py
python check_relative_continuation.py
python check_gamma_continuation.py
python check_phase_square_continuation.py
python check_band_radial_overlap.py
python check_directional_electric_spectrum.py
python check_original_weighted_trace.py
python check_native_localization.py
python check_scaled_angle_native_limit.py
```

Run the local document build with Pandoc and pdfLaTeX installed:

```text
python build.py
```

The TeX is also directly compilable with pdfLaTeX. `CHECK_RESULTS.json`, `WEAK_CONTINUATION_CHECKS.json`, `RELATIVE_CONTINUATION_CHECKS.json`, `GAMMA_CONTINUATION_CHECKS.json` and `PHASE_SQUARE_CONTINUATION_CHECKS.json` record 834 passed exact finite diagnostics and their limited scope; general operator and limit proofs are in the manuscript. BAND_RADIAL_OVERLAP_CHECKS.json separately records 39 passed grouped exact checks covering 495 scalar residuals. The `private/` directory contains instruction provenance and workflow records and is excluded from the repository and public delivery.

The additional DIRECTIONAL_ELECTRIC_CHECKS.json records25 exact identities.
ORIGINAL_WEIGHTED_TRACE_CHECKS.json records26 exact identities and8 numerical
finite-matrix diagnostics. These bring the seven main exact reports to885.
The complete proof, all raw coefficients, coordinate maps and scope are in
Sections24–25; these finite diagnostics do not certify a continuum limit.


NATIVE_LOCALIZATION_CHECKS.json records81 additional exact finite diagnostics, giving966 across the eight main reports. The new complete analytic proof is Section26,449–486, also retained in sources/native_original_angle_weak_localization.md. These diagnostics use only public source files; the independent audits remain private.

Sections26.7–26.9 add the sharper actual-vacuum fourth electric moment,
polynomial covariance lower bound, and fixed-box scaled-angle Gaussian native
limit. SCALED_ANGLE_NATIVE_LIMIT_CHECKS.json records9/9 exact structural
checks. These fixed-box results retain regulator dependence and do not certify
an infinite-volume interacting continuum.
