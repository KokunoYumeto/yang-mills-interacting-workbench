# Current exact Yang-Mills and cusp calculations for AI review

8 September 2026. Complete proof texts follow, not compressed summaries.

The native magnetic coefficient vector now has a complete proved open-box
spectral measure: its mass is A_L=4L^7/5+6L^6/5+2L^5/3+L^3/30+L^2/20,
and its probability in Q_L tends to (2/3)delta24+(1/3)delta12.
The exact first-band coefficient map q -> 7/15-q/21 gives atoms
-71/105 and -11/105. The companion transports the actual interacting
magnetic state by its true band isometry, retaining the full out-of-band
mass at order theta^4 xi^4 and both adjacent spin channels. These are
ordered coefficient limits, with no assumed volume-uniform quantum remainder.

For links e,f sharing no elementary face, the connected electric covariance
has fourth coefficient (127/219024)a_ef, with a_ef the exact count of
adjacent-face channels. Its entire spectral test functional is
a_ef[-59h(3)/275184-h'(3)/336+h(9/2)/1296+3h(13/2)/132496].
The h' term is essential: it cancels the other first moments exactly,
as required by the identically zero energy-matrix entry. The complete
proof gives the original physical-time correlation and the full domains.
This is neither a positive atomic replacement for the exact spectral
measure nor a fixed-coupling continuum claim.

Three further complete manuscripts give quantitative all-coupling or
volume-independent estimates, full extensive path-product blocking with
all its memory, and the original cusp/spatial refinement and actual
spectral measure. Their statements retain their precise proved regimes.
Local electric covariance entries have a uniform remainder42500xi³,
while the weighted energy numerator has remainder351000kappa xi³||w||₂².
The corresponding extensive state norm still has an l1² error, not a
proved summable covariance remainder. The exact coarse kinetic factor is
kappa times the chain length; all conditional drifts/covariances and the
energy-dependent Schur memory remain. Large bare Wilson-loop channels have
a strictly positive all-coupling fraction of high-energy weight with
explicit volume-independent constants, not a claimed lower support bound.
On the original fixed-g cusp diagonal the raw magnetic-state norm tends
to zero with a proved O_g(j^-2) bound; this does not determine its spectral
probability. A separate fully controlled positive-coupling sequence has
spectral escape to infinite physical energy and a discontinuous unscaled
time-correlation limit, not a continuum counterexample.

The new center-disorder note gives the exact theta=pi endpoint of the same
native link-translation family, its Wilson commutation signs, and full
vacuum spectral moments2b<S_twist>/(1-c²) and4b²<S_twist²>/(1-c²).
The integer line flux maps under the adjoint by the explicit doubled-angle
rotation; neither the factor2 nor the actual zero center obstruction of
the original SU2 lift is discarded. A closed cochain fixes the finite-box
vacuum and produces zero centered state; a nonempty coboundary produces
the nonzero state with the exact overlap-dependent moments above.

The newest result is the actual first physical excitation band, not only
a chosen trial quotient. The physical free eigenspace at energy3 is exactly
the full face-trace span; its next free energy is9/2. Its actual second-order
excitation matrix is F_L=7I/15-(D_face+A_face)/21, retaining vacuum mixing,
the actual vacuum-energy shift, and both shared-link channels9/2 and13/2.
The finite physical gap is kappa[3+xi²(7/15-q_L/21)+R_L(xi)], where
q_L is the maximum eigenvalue of the unchanged open signless face graph.
The explicit remainder bound is |R_L| <= (7/3)(64M/3)^4 xi^4 for
|xi| <= 3/(128M). The exact spectral projection/isometry and first-order
dressing are written out. This is an actual eigenvalue result at finite
volume, not an assumption that the original magnetic state is an eigenstate.
The complete open-boundary and bulk-symbol calculation gives
0 < 24-q_L <= 6pi²/(2L-1)², and thus the lowest second coefficient tends
to -71/105. This is a coefficient limit; the explicitly volume-dependent
remainder is not promoted to a fixed-coupling continuum gap statement.
Primary historical strong-coupling literature is cited; novelty of this
coefficient is not claimed. The two new complete proofs and the independent
derivation follow in this packet with their exact checkers.

Newest calculations: the full real unsigned edge-to-face incidence kernel
is now parametrized exactly, of dimension3m(m+1) for m=2L. The true-vacuum
electric covariance is C=xi² I^T I/16+O_L(xi⁴). Every nonzero weight in
the leading kernel has a surviving second-order state on adjacent-face
spin channels9/2 and13/2. Its leading quotient is234kappa/49. Minimizing
over ALL real electric weights, including xi-dependent weights on a fixed
box, gives3kappa+O_L(kappa xi²). No volume-uniform bound is inferred.

The matching local magnetic energy provides another exact state map:
Df=kappa sum_e fe Ee+sum_p fp b(2-Wp), fp=(1/4)sum_face fe. Its current
is i[H,Df]=i kappa sum_incident(fp-fe)[Ee,Vp], retaining all terms.
Its one-face state cancels; the surviving coefficient is
sum_adj delta_pq(P0/9-P1/39), delta=fp+fq-2f_shared.
Norm/energy coefficients are49/13689 and2/117 times sum delta².
Midpoint coordinate weights give sum delta²=16L³ with boundaries counted,
and quotient234kappa/49 at that fixed-box order. For any affine slope t,
the entire actual-vacuum spectral measure is exactly |t|² times that for
one coordinate, by the explicit finite-box symmetry maps at every b>0.
Changing slope direction or size within this family does not change
its positive-energy support. The large-volume interacting measure is
not replaced by these finite Taylor coefficients.

The original magnetic connection has an exact map into
the interacting finite-box quantum Hilbert space, with gauge projection
and vacuum subtraction both performed. Original D=L_T q_T+6m_T² and both
connection frame changes are retained. The native field is
h1(n)=exp(-theta n2 Hc), theta=2pi a²/D, Hc=i sigma3; the reference
connection transforms together with the magnetic connection.
On invariant states, its projected translation is exactly the product K
of central SU(2) edge class convolutions. On spin j_e it multiplies by
sin((2j_e+1)theta n2)/[(2j_e+1)sin(theta n2)], defined by the character
sum at every apparent zero denominator. No representation is discarded.

For the actual finite-box vacuum psi at EVERY positive coupling, set
Gamma=sum_{direction1 links}n2²(-Delta_e^T), v=(Gamma-<Gamma>)psi.
The centered state satisfies chi_theta=-(2/3)theta² v+O_H1(theta⁴),
||chi_theta||²=(4/9)theta⁴||v||²+O(theta⁶), and its excitation energy
is (4/9)theta⁴ q_(H-E)(v)+O(theta⁶). The variance ||v||² is proved
strictly positive; the fixed-regulator small-angle quotient is q(v)/||v||²,
not an energy that tends to zero merely with the angle. An exact discrete
electric-channel expansion retains all vacuum coefficients and the full
plaquette coupling matrix in that ratio.

The companion evaluates the finite-box vertex Haar integrals, the actual
vacuum's leading coupling coefficients and the original cusp diagonal.
For a face in plane12, alpha=cos(theta n2)cos(theta(n2+1)); for plane13,
alpha=cos²(theta n2); for plane23, alpha=1. Thus even background-flat
13 faces contribute to the translated quantum state. The complete norm
coefficient D_L(theta) and its explicit remainder are printed in the proof.
The state is exactly zero only at theta in 2pi Z (for b>0). The proved
fixed-box coupling expansion and joint geometric coefficient limit are
not substituted for a controlled fixed-coupling continuum spectral limit.

The original magnetic bundle and printed compact links are related by the
explicit vertex-frame map h(n)=exp(-2πH n₁n₂/N²), including both wraps.
Full nonlinear field/action transport through the original cusp covers is
proved with the original metric, Lie inner product and coupling retained.

For the full SU(2) Wilson action on an actual four-dimensional physical
patch, an extensive set of links is integrated exactly. At the original
magnetic background, the ratio of its integrated to original action cost
tends to I₂(12b)/I₁(12b), where b=1/(2gYM²), without a Gaussian replacement.
The finite Hamiltonian calculation gives actual vacuum-weighted Wilson-loop
variations and their exact relation to spectral first moments. With spatial
spacing a and time spacing epsilon kept independent, the exact temporal
character multiplier is I_(2j+1)(2b_t)/I_1(2b_t), b_t=a/(2gYM² epsilon).
The fully proved time limit, including integration of the temporal links,
gives H=-(2gYM²/a) sum_e Delta_e^T
       +(1/(2gYM²a)) sum_p (2-Re tr U_p)
on gauge-invariant functions. The probability-Haar scalar multiplying the
raw transfer is retained explicitly, together with its common energy shift.
No magnetic plaquette is discarded. The original Lie metric is c=-tr/2,
so Delta^c=4 Delta^T; the coefficient in that metric is gYM²/(2a).

The adjacent-plaquette calculation and its full-box extension evaluate a
nonzero quantum elimination coupling on an actual gauge-invariant retained
Wilson loop. In every fixed open three-dimensional box [-L,L]³, L≥2,
with all its links and plaquettes retained in H and original coefficients
kappa and b, ||B f||²=b²/12+O_L(b³/kappa). The explicit resolvent-corrected
full-system trial vector lowers the retained-only excitation quotient by
(1951/81675)b²/kappa+O_L(b³/kappa²), at fixed kappa and small positive b/kappa.
The two contributing eliminated Casimir channels are 9kappa/2 and 13kappa/2.
This coefficient is computed from the derivative of the actual analytic
vacuum; independent Haar links are used only at its exact b=0 endpoint.
The full positive-b state is not replaced by that endpoint.

For the two-plaquette system the absolute excitation quotients are also
evaluated: R_ret=3kappa+(5/9)b²/kappa+O(b³/kappa²), and
R_corrected=3kappa+(43424/81675)b²/kappa+O(b³/kappa²).
Thus both lie above their zero-b value to this order, despite the strict
improvement at the same positive b. They are trial quotients, not exact
excited eigenvalues. The complete proof also retains the vacuum energy
E=4b-(2/3)b²/kappa+O(b³/kappa²) and gives the unsubtracted-H quotients.
The full-box spectral-projection disk is |b/kappa|<3/(16M), with
M=3(2L)²(2L+1); its shrinking radius and box-dependent remainder have not
been replaced by a volume-uniform or continuum statement.

The goal remains a counterexample to the genuine interacting four-dimensional
quantum mass-gap assertion. No such counterexample is claimed in these
files. The computed marginal-density values are not already vacuum energies.
The next research step is to calculate their full surviving-link correlations
and transfer to physical spectral weight, retaining all generated interactions.
The completed fixed-spatial-regulator time limit must not be silently
substituted for a simultaneous spatial-continuum and infinite-volume limit.
Do not assume the same one-plaquette action survives repeated integration.

The final analytic note independently tests the actual announced Euler
construction under positive viscosity and constructs explicit correction
maps; it does not identify that theorem as a Navier-Stokes counterexample.

Primary references are given within the proof texts. The classical single-link
integral and standard compact-group representation identities are not claimed
as new discoveries. Their exact use in this retained cusp calculation is shown.

## Complete source: retained_cusp_nonlinear_bridge.md

```markdown
# Retained cusp coordinates and nonlinear gauge-field integration

Research calculation, 8 September 2026. This document proves the maps below;
it does not claim a quantum mass-gap counterexample. All couplings are retained.

## 1. Exact original metric and nonlinear action

Use precisely the period data in the compact-link manuscript, with
\(L=\operatorname{Im}\tau\), \(m=\operatorname{Im}\mu\),
\(q=-\operatorname{Im}\beta\), and \(D=Lq+6m^2>0\). Define
\[
A=\begin{pmatrix}6\operatorname{Re}\mu&\operatorname{Re}\tau\\
\operatorname{Re}\beta&\operatorname{Re}\mu\end{pmatrix},\qquad
B=\begin{pmatrix}6m&L\\-q&m\end{pmatrix}.
\]
The original physical coordinate order is \((x_1,x_2,x_3,x_4)\).
Let \(R(x_1,x_2,x_3,x_4)=(x_1,x_3,x_2,x_4)\); \(R\) is orthogonal,
\(\det R=-1\), and it is only a recorded permutation, not a replacement
of any period. For the original cover matrix \(P_M=P\operatorname{diag}(1,1,M,M)\),
\[
 Q:=RP_M=\begin{pmatrix}A&MI_2\\B&0\end{pmatrix},\qquad
 Q^{-1}=\begin{pmatrix}0&B^{-1}\\M^{-1}I_2&-M^{-1}AB^{-1}\end{pmatrix},
\quad B^{-1}=D^{-1}\begin{pmatrix}m&-L\\q&6m\end{pmatrix}.
\]
Multiplying the two displayed block matrices gives the identity on both
sides, which proves the inverse including all signs. Consequently, writing
\(K=B^{-1}B^{-\mathsf T}\),
\[
G^{-1}=(P_M^{\mathsf T}P_M)^{-1}
=\begin{pmatrix}
K&-M^{-1}KA^{\mathsf T}\\
-M^{-1}AK&M^{-2}(I_2+AKA^{\mathsf T})
\end{pmatrix},
\]
where
\[
K=D^{-2}\begin{pmatrix}
m^2+L^2&mq-6mL\\mq-6mL&q^2+36m^2
\end{pmatrix},\qquad \det K=D^{-2}.
\]
Indeed \(G^{-1}=Q^{-1}Q^{-\mathsf T}\). The determinant is
\(\det P_M=-M^2D\), and physical volume is \(\mathcal D=M^2D\).
The sign of the original orientation and the positive volume density are
recorded separately.

For each ordered pair \(I=(i,j)\), \(1\leq i<j\leq4\), define the full
six-by-six two-form metric
\[
\mathcal K_{(i,j),(k,l)}=(G^{-1})_{ik}(G^{-1})_{jl}
                         -(G^{-1})_{il}(G^{-1})_{jk}.
\]
Every entry, including entries with \((i,j)\ne(k,l)\), is retained. This
is the Gram matrix of the six covectors \(dy^i\wedge dy^j\); it is positive
definite because the exterior-square map of the invertible matrix
\(P_M^{-\mathsf T}\) is invertible. In particular
\(\mathcal K_{12,12}=D^{-2}\), without imposing \(A=0\) or \(m=0\).

Take gauge group \(SU(n)\), \(n\geq2\), with the original invariant
inner product \(c(X,Y)=-\tfrac12\operatorname{tr}(XY)\) on anti-Hermitian
trace-free matrices. For a connection \(\mathscr A=\sum_\alpha
\mathscr A_\alpha dx^\alpha\), the coordinate map
\(\phi_M(y)=[P_My]\) gives
\[
 \widetilde{\mathscr A}_i(y)=\sum_\alpha(P_M)_{\alpha i}
                       \mathscr A_\alpha(P_My),\qquad
 \widetilde F_{ij}=\partial_i\widetilde{\mathscr A}_j
  -\partial_j\widetilde{\mathscr A}_i
  +[\widetilde{\mathscr A}_i,\widetilde{\mathscr A}_j]
 =\sum_{\alpha,\beta}(P_M)_{\alpha i}(P_M)_{\beta j}
                       F_{\alpha\beta}(P_My).
\]
The derivative identity is the chain rule; the commutator identity follows
by bilinearity of the matrix commutator. No bracket has been omitted.
Changing variables in the original action gives exactly
\[
 S(\mathscr A)=\frac1{2g_{\rm YM}^2}\int |F_{\mathscr A}|^2dx
 =\frac{M^2D}{2g_{\rm YM}^2}\int_{[0,1)^4}
   \sum_{I,J}\mathcal K_{I,J}\,c(\widetilde F_I,\widetilde F_J)\,d^4y.
\]
For the previously displayed flux \(\widetilde F_{12}=2\pi H\),
\(H=\operatorname{diag}(i,-i)\), \(c(H,H)=1\), all other curvature
components zero, this is \(2\pi^2M^2/(g_{\rm YM}^2D)\).
For general connections it is the full mixed quadratic form in their
nonlinear curvatures, not six independent scalar plaquette weights.

Gauge maps obey the original convention
\(\mathscr A^h=h^{-1}\mathscr A h+h^{-1}dh\). Pullback commutes with
this expression, with \(\widetilde h=h\circ\phi_M\). Along every path,
the parallel-transport ODE with coefficient \(-\mathscr A(\dot\gamma)\)
is carried to the identical ODE under \(\phi_M\). Thus both ordered
holonomies and their traces are preserved, including nonlinear dependence
on the connection. This supplies the gauge and observable maps alongside
the metric and action maps.

## 2. Exact local transport of full nonlinear fields through the cusp limit

Retain \(B_T=TJ+C_T\), where
\(J=\left(\begin{smallmatrix}0&1\\-1&0\end{smallmatrix}\right)\),
\(\sup_T\|C_T\|_{\rm op}\leq C\). Each covered period, in the recorded
permuted physical order, is
\[
 \lambda(n,z)=(A_Tn+Mz,B_Tn),\qquad n,z\in\mathbb Z^2.
\]
Its original-order value is \(R^{\mathsf T}\lambda(n,z)\); since \(R\)
is orthogonal, the following norms have exactly their original values.
If \(n\ne0\), its length is at least \((T-C)|n|\geq T-C\).
If \(n=0\) and the period is nonzero, its length is \(M|z|\geq M\).
Thus \(\operatorname{sys}(\widetilde F_{T,M})\geq\min(T-C,M)\).

Let \(\mathscr A\in C_c^\infty(\mathbb R^4;
T^*\mathbb R^4\otimes\mathfrak{su}(n))\) have support in \(B_R(0)\).
For \(\operatorname{sys}>8R\), the quotient map restricts to an
isometric embedding of \(B_{2R}\): for \(x,y\in B_{2R}\) and a
nonzero period \(\lambda\),
\[
 |x-y+\lambda|\geq|\lambda|-|x-y|>8R-4R\geq|x-y|.
\]
Transport \(\mathscr A\) by this embedding and extend it by zero outside
the image of \(B_{2R}\). It is smooth since \(\mathscr A\) is identically
zero on a neighborhood of the boundary. Denote the resulting connection
on the trivial bundle by \(\iota_{T,M}\mathscr A\). Then
\[
 F_{\iota\mathscr A}=\iota(d\mathscr A+\mathscr A\wedge\mathscr A),
 \qquad S(\iota\mathscr A)=S(\mathscr A).
\]
Both identities follow on the embedded ball from the chain rule and the
unchanged Euclidean metric; on the complement both sides vanish. The
Yang--Mills differential expression \(d_{\mathscr A}^*F_{\mathscr A}\)
is transported identically for the same reason. These statements concern
arbitrary compactly supported connections, not only a flat background or
its Hessian. They do not assert the existence of a nonzero compactly
supported solution of the Yang--Mills equation.

A smooth gauge transformation equal to the identity outside \(B_R\)
extends by the identity in precisely the same manner, and
\(\iota(\mathscr A^h)=(\iota\mathscr A)^{\iota h}\). Wilson traces along
paths in \(B_{2R}\) agree by uniqueness of the transport ODE. Given a
finite collection of such fields, variations and paths, one common \(R\)
makes all these identities simultaneous. Thus the covered cusp supplies
exact local transports of the full interacting classical field data on
every fixed bounded domain. The probability distribution on those data
is a separate calculation, performed at a finite regulator below.

## 3. Every finite link field has a smooth-connection realization

Fix the embedded finite cubical graph on one covered torus. Give each
geometric edge one orientation and use inverse parallel transport as the
link convention. For arbitrary \(U_e\in SU(n)\), choose
\(X_e\in\mathfrak{su}(n)\) with \(\exp X_e=U_e\). Such a choice exists:
unitarily diagonalize \(U_e\), choose real eigenangles whose sum is an
integer multiple of \(2\pi\), and change one angle by that multiple so
their sum is zero. Conjugating the diagonal imaginary angles back gives
the required trace-free anti-Hermitian logarithm.

Select a closed subinterval in the interior of each edge. These finitely
many subintervals admit disjoint tubular neighborhoods, each disjoint from
all other edges. In tube coordinates \((s,z)\), choose smooth functions
\(b_e(s)\), \(\rho_e(z)\), supported away from the tube boundary, with
\(\int b_e(s)ds=1\) and \(\rho_e(0)=1\). Set
\[
 \mathscr A=\sum_e X_e b_e(s)\rho_e(z)\,ds,
\]
extending each summand by zero. This is a global smooth connection on the
trivial bundle. Along edge \(e\) its coefficient commutes with itself at
different times, so ordinary parallel transport is \(\exp(-X_e)\), and
inverse parallel transport is exactly \(U_e\). All other summands vanish
on that edge. The continuum-to-link map is therefore surjective for this
finite graph.

This proof does not assert a globally continuous choice of logarithms or
an action-preserving right inverse. It gives an exact realization of every
link configuration, including the previously printed flux. For the latter,
the displayed logarithms lie in the same Cartan line, so the constructed
connection is globally Abelian and its total real curvature period on a
closed two-torus is zero by Stokes' theorem. The nonzero principal
plaquette logarithms still agree with the printed links: exponentiation
does not determine the integral curvature outside the finite graph.
The next explicit vertex-frame calculation relates the original
constant-curvature bundle connection to these printed links as well;
it does not identify the two smooth connections or their actions.

On the original magnetic line-sum bundle, retain the lifted connection
\(d+2\pi u_1Hdu_2\) and transition
\(G_k(u)=\exp(-2\pi k_1u_2H)\). Choose vertex representatives
\(u_j=n_j/N\) in the half-open fundamental cube (and \(u_3=Mn_3/N\),
\(u_4=Mn_4/N\) on the cover). In those vertex frames, inverse transport is
\[
 W_1(n)=\begin{cases}I&n_1<N-1,\\
 e^{-2\pi Hn_2/N}&n_1=N-1,\end{cases}\quad
 W_2(n)=e^{2\pi Hn_1/N^2},\qquad W_3=W_4=I.
\]
For a non-wrapping first-direction edge the connection integral is zero.
For a wrapping first-direction edge it is also zero in the lift, but the
endpoint frame is changed by \(G_{(1,0,0,0)}\). Ordinary transport in the
chosen endpoint frame therefore has the additional factor
\(G_{(1,0,0,0)}^{-1}=e^{2\pi Hn_2/N}\), giving the stated inverse
transport. The second-direction integral is \(2\pi H n_1/N^2\);
its wrap transition is the identity because that transition has \(k_1=0\).
The remaining two directions have both zero integral and identity transition.

Set \(h(n)=e^{-2\pi Hn_1n_2/N^2}\) at these finitely many vertices,
with vertex indices always represented in \(\{0,\ldots,N-1\}\).
The gauge formula \(U_j(n)=h(n)^{-1}W_j(n)h(n+e_j)\) gives
\[
 U_1(n)=e^{-2\pi Hn_2/N^2},\qquad
 U_2(n)=\begin{cases}I&n_2<N-1,\\
 e^{2\pi Hn_1/N}&n_2=N-1,\end{cases}\qquad U_3=U_4=I.
\]
For the four nontrivial cases, the exponents after division by \(2\pi H\)
are respectively
\[
 \frac{n_1n_2-(n_1+1)n_2}{N^2}=-\frac{n_2}{N^2},\quad
 \frac{(N-1)n_2}{N^2}-\frac{n_2}{N}=-\frac{n_2}{N^2},
\]
\[
 \frac{n_1n_2+n_1-n_1(n_2+1)}{N^2}=0,\quad
 \frac{n_1(N-1)+n_1}{N^2}=\frac{n_1}{N}.
\]
The other vertex factors cancel. These are exactly the printed compact
flux links. Thus the original smooth magnetic connection does realize
that finite link field in explicitly related vertex frames. The auxiliary
smooth connection constructed by edge tubes also realizes it, and can have
a different action: finite holonomies do not determine a smooth connection.

## 4. One exact nonlinear integration step, with all neighboring staples

Take a finite four-dimensional orthogonal cubical regulator inside one of
the locally isometric domains, and the full \(SU(2)\) Wilson action
\[
 S_W(U)=\sum_p b_p(2-\operatorname{Re}\operatorname{tr}U_p),\qquad b_p>0.
\]
Each unordered geometric plaquette is included once. For constant mesh
spacing \(a\) and the Lie metric and continuum action of section 1,
\(b_p=1/(2g_{\rm YM}^2)\) has the classical continuum coefficient:
\(2-\operatorname{Re}\operatorname{tr}\exp(a^2F)=a^4c(F,F)+O(a^8)\)
for the displayed constant-curvature exponential. No assertion about a
quantum continuum limit follows from this classical coefficient matching.
The following exact integration works for arbitrary positive \(b_p\).

Keep all links except an interior link \(U_e\) fixed. There are six
incident plaquettes. Cyclic permutation inside the trace, and taking an
inverse when the plaquette uses \(U_e^{-1}\), write each contribution as
\(\operatorname{Re}\operatorname{tr}(U_e V_{ep})\), with
\(V_{ep}\in SU(2)\) the ordered product of its other three links. Define
\[
 H_e=\sum_{p\ni e}b_pV_{ep},\qquad
 r_e^2=\tfrac12\operatorname{tr}(H_eH_e^*)
 =\sum_{p\ni e}b_p^2+
   \sum_{p<q,\ p,q\ni e}b_pb_q\operatorname{Re}\operatorname{tr}(V_{ep}V_{eq}^*).
\]
All six coefficients and all fifteen pairwise traces remain present.
Every \(SU(2)\) matrix has the form \(a_0I+i\sum a_j\sigma_j\) with
real \(a_\alpha\) and \(\sum a_\alpha^2=1\). Consequently the real
linear combination \(H_e\) satisfies \(H_eH_e^*=r_e^2I\),
\(\det H_e=r_e^2\). When \(r_e>0\), the identity
\(H_e=r_eV_e\) defines \(V_e\in SU(2)\), with \(r_e\) retained as an
independent exact coefficient, not replaced by one. If \(r_e=0\),
\(H_e=0\) and the conditional link distribution is Haar.

Use Haar probability measure solely as the convention for finite integrals;
this does not change a physical period, field amplitude or coupling. Under
\(W=U_eV_e\), write \(w_0=\tfrac12\operatorname{tr}W\). The marginal
Haar density of \(w_0\in[-1,1]\) is
\(\tfrac2\pi(1-w_0^2)^{1/2}dw_0\), obtained by slicing the unit
three-sphere in four real quaternion coordinates. Therefore
\[
 Z(r):=\int_{SU(2)}e^{\operatorname{Re}\operatorname{tr}(UH)}dU
 =\frac2\pi\int_{-1}^1e^{2rs}\sqrt{1-s^2}\,ds
 =\sum_{k=0}^\infty\frac{r^{2k}}{k!(k+1)!}
 =\frac{I_1(2r)}r,\qquad Z(0)=1.
\]
To prove the series, integrate the exponential term by term (uniform
absolute convergence on the compact interval). Odd powers vanish, and
\(\int_{-1}^1s^{2k}\sqrt{1-s^2}ds
=\pi(2k)!/[2\,4^k k!(k+1)!]\), by the beta integral, or induction by
integration by parts from the area of a semicircle. This also defines the
Bessel expression without importing a special-function convention.

Writing \(B_e=\sum_{p\ni e}b_p\), integration of this link replaces
its incident action by exactly
\[
 2B_e-\log Z(r_e).
\]
The additive constant \(2B_e\) is retained. Other plaquette terms remain
unchanged. The series has nonnegative terms and converges for every finite
\(r\), so \(Z(r)>0\) and this logarithm is well-defined. This is an
explicit nonlinear map from six interacting plaquettes to an effective
interaction among their boundary links, not a Gaussian integration.

Differentiating the uniformly convergent series gives
\(Z'(r)=2I_2(2r)/r\) and \(Z''+3Z'/r=4Z\). Let
\(\eta(r)=I_2(2r)/I_1(2r)\). Then the exact conditional mean is
\[
 \mathbb E[U_e\mid U_{f\ne e}]=\eta(r_e)V_e^*,
\]
because transverse quaternion coordinates have zero mean, while
\(\mathbb E[w_0]=Z'/(2Z)=\eta\). Their second moments are
\[
 \mathbb E[w_0^2]=1-\frac{3\eta}{2r},\qquad
 \mathbb E[w_jw_k]=\delta_{jk}\frac{\eta}{2r}\quad(1\leq j,k\leq3),
 \quad \mathbb E[w_0w_j]=0.
\]
At \(r=0\) these have continuous values \(1/4\), since the displayed
series gives \(\eta(r)=r/2+O(r^3)\). The longitudinal variance is
\(1-3\eta/(2r)-\eta^2\); it has not been replaced by a harmonic width.
The gauge law \(U_e\mapsto g_s^{-1}U_eg_t\) sends
\(H_e\mapsto g_t^{-1}H_eg_s\); hence \(r_e\) is gauge invariant and
the conditional mean has exactly the same gauge law as \(U_e\).

## 5. Exact integration at the retained small-curvature background

Use an orthogonal physical cubical patch with common spacing \(a>0\),
not the generally skew period-coordinate mesh. On that patch take the
retained Abelian magnetic curvature in its physical magnetic two-plane,
\(F_{12}=\mathfrak bH\), \(\mathfrak b=2\pi/D_T\), with the other
components zero. In this paragraph indices 1 and 2 label an explicitly
chosen orthonormal frame of that two-plane, not the first two original
period-coordinate indices. The remaining two orthonormal directions are
in its orthogonal complement. This is the smooth magnetic background's
local curvature, pulled to a covered torus; its amplitude is unchanged by
the covering. A local potential is \(\mathscr A=\mathfrak b x_1Hdx_2\).
The inverse-transport convention gives every positively oriented magnetic
plaquette the holonomy \(\exp(\vartheta H)\), where
\(\vartheta=\mathfrak b a^2=2\pi a^2/D_T\), and gives the other
plaquettes the identity. This follows either by integrating this potential
on the four edges, whose coefficients commute, or by Stokes' theorem in
the fixed Cartan line.

Let all six incident plaquettes of an interior link in the magnetic plane
have the same retained Wilson coefficient \(b=1/(2g_{\rm YM}^2)>0\).
Write \(U_e^{(0)}\) for that background link. The two magnetic staples
occur with opposite orientations relative to the link; the other four
plaquettes are flat. Thus the exact sum, before integrating \(U_e\), is
\[
 H_e=b(U_e^{(0)})^{-1}
       (4I+e^{\vartheta H}+e^{-\vartheta H})
     =b(4+2\cos\vartheta)(U_e^{(0)})^{-1}.
\]
All factors commute here because this specific background is Abelian;
the integrated link \(U_e\) still ranges over the entire non-Abelian
group \(SU(2)\), not its diagonal subgroup. Since
\(4+2\cos\vartheta\geq2\),
\(r_\vartheta=b(4+2\cos\vartheta)>0\). The exact change of the integrated
six-plaquette incident contribution, relative to its flat-background
value, is
\[
 \Delta S_{\rm eff}(\vartheta)
 =\log Z(6b)-\log Z\bigl(b(4+2\cos\vartheta)\bigr)
 =\int_{b(4+2\cos\vartheta)}^{6b}2\eta(s)\,ds.
\]
For the full action one must also retain
\(S_{\rm nonincident}(U^{(\vartheta)})-
S_{\rm nonincident}(U^{(0)})\); the displayed quantity is the local
incident contribution, not an identification of the entire lattice cost.
No expansion in \(g_{\rm YM}\), no quadratic replacement of the
plaquette interaction, and no limit of \(b\) was used.

For every \(s>0\), \(0<\eta(s)<1\). The upper inequality follows from
\(w_0<1\) almost surely under a positive Haar density. To prove strict
positivity, pair \(w_0\) with \(-w_0\) in its symmetric Haar marginal:
the first moment numerator becomes an integral over \((0,1)\) of
\(w_0(e^{2sw_0}-e^{-2sw_0})\sqrt{1-w_0^2}\), which is positive.
Consequently, whenever \(\cos\vartheta<1\),
\[
 0<\Delta S_{\rm eff}(\vartheta)
       <4b(1-\cos\vartheta).
\]
The right side is exactly the original action of the two affected magnetic
plaquettes relative to two flat plaquettes. The inequality is therefore a
computed reduction of this local cost by integration of one full compact
link. It is not an assertion about the mass gap.

The exact integral also yields its leading retained-scale coefficient:
\[
 \Delta S_{\rm eff}(\vartheta)
   =2b\,\eta(6b)\,\vartheta^2+O_b(\vartheta^4)
   =\frac{8\pi^2 b\,\eta(6b)a^4}{D_T^2}
       +O_b(a^8D_T^{-4}).
\]
This expansion is a consequence of the exact expression, which remains
the definition and retains every higher term. Specifically
\(6b-r_\vartheta=2b(1-\cos\vartheta)
=b\vartheta^2+O_b(\vartheta^4)\), and the smooth function
\(2\eta(s)\) can be integrated over that actual interval. The first
moment of the integrated link is exactly
\(\eta(r_\vartheta)U_e^{(0)}\); its two-point moments remain the
full expressions in section 4. This computes one genuine interacting
fluctuation step at the cusp background, with its geometric curvature
scale and gauge coupling both present.

### 5.1 An extensive exact integration on a four-dimensional cusp patch

The same calculation can be applied simultaneously to a growing number of
links without discarding the interactions. Take the physical box with
vertices \(a\{0,\ldots,N\}^4\), \(N\geq2\) even, and all its internal
nearest-neighbor links and plaquettes. Let \(\mathcal E_*\) be the
first-direction links based at vertices satisfying
\[
 0\leq n_1\leq N-1,\qquad 1\leq n_2,n_3,n_4\leq N-1,
 \qquad n_2+n_3+n_4\equiv1\pmod2.
\]
Each such link has all six incident plaquettes. No plaquette contains two
selected links: its two first-direction edges have transverse coordinates
differing by one in exactly one direction, and hence opposite parity.
Plaquettes not involving direction 1 contain no selected link at all.
Therefore, for any configuration of the remaining links,
\[
 \int e^{-S_W(U)}\prod_{e\in\mathcal E_*}dU_e
 =e^{-S_{\rm rest}(U)}
   \prod_{e\in\mathcal E_*}e^{-12b}Z(r_e(U)).
\]
This is an identity between finite-dimensional functions, with all
interactions in the functions \(r_e(U)\) retained. Its proof is the
decomposition of the action into its disjoint incident plaquette sets,
followed by Fubini's theorem for a positive continuous integrand on a
compact product. It integrates over all of \(SU(2)\) independently on
each selected link. The surviving links interact through the products of
staples; they have not been assigned independent distributions.

The number of selected links and the total number of magnetic plaquettes
are, respectively,
\[
 m_N=\frac N2\big((N-1)^3+1\big),\qquad
 p_N=N^2(N+1)^2.
\]
For the first count there are \(N/2\) odd and \(N/2-1\) even integers
in \(\{1,\ldots,N-1\}\). If \(E\) and \(O\) count even and odd sums
of three such integers, then \(E+O=(N-1)^3\) and
\(E-O=((N/2-1)-N/2)^3=-1\). Thus \(O=((N-1)^3+1)/2\);
the first coordinate supplies the factor \(N\). For the second count,
the first two plaquette coordinates each have \(N\) choices and the
other two each have \(N+1\) choices. Exactly \(2m_N\) magnetic
plaquettes belong to selected-link stars, with no overlaps.

Evaluate the resulting exact marginal density at the remaining links of
the constant-curvature background, and compare with the remaining links
of the flat background. The full effective-action difference on this box
is now
\[
 \Delta S_{*,N}(\vartheta)
 =(p_N-2m_N)\,2b(1-\cos\vartheta)
   +m_N\left[\log Z(6b)-\log Z\big(b(4+2\cos\vartheta)\big)\right].
\]
This includes the nonincident term explicitly. The original box action
difference was \(S_{0,N}=2bp_N(1-\cos\vartheta)\). Hence
\[
 0<\Delta S_{*,N}<S_{0,N}\qquad(\cos\vartheta<1),
\]
and for any sequence \(N\to\infty\), \(\vartheta\to0\) with
\(\vartheta\ne0\),
\[
 \frac{\Delta S_{*,N}}{S_{0,N}}\longrightarrow\eta(6b).
\]
Indeed \(2m_N/p_N\to1\), and the ratio of the integrated star cost to
its original two-plaquette cost tends to \(\eta(6b)\) by the exact
integral in section 5. The ratio tends to a strictly positive number
below one at every fixed retained \(b>0\). This is one exact integration
layer; it is not iterated by assuming the same action form at the next
layer.

Here is a sequence with all geometric and cutoff constants specified.
Take the original covered cusp at \(T_j=j^2\), \(M_j=j\), the physical
mesh spacing \(a_j=1/(100j)\), and \(N_j=2j^2\). Its box side is
\(a_jN_j=j/50\). Centering this box at the origin puts it in a ball of
radius \(j/50\), since a four-dimensional cube of side \(\ell\) has
half-diagonal \(\ell\). For sufficiently large \(j\), the earlier
systole bound gives \(\operatorname{sys}\geq j>8j/50\), so the whole
box and a collar embed isometrically in the actual covered cusp. The
mesh tends to zero and its physical box grows without bound. Retaining
the original \(D_{T_j}=j^4(1+O(j^{-2}))\) gives
\[
 \vartheta_j=\frac{2\pi}{10^4 j^2D_{T_j}},\qquad
 j^4S_{0,N_j}(\vartheta_j)
     \longrightarrow\frac{64\pi^2b}{10^8},\qquad
 j^4\Delta S_{*,N_j}(\vartheta_j)
     \longrightarrow\frac{64\pi^2b}{10^8}\eta(6b).
\]
For these constants, \(p_{N_j}/j^8\to16\),
\(j^{12}\vartheta_j^2\to4\pi^2/10^8\), and
\(2(1-\cos\vartheta_j)/\vartheta_j^2\to1\), proving both limits.
Thus the already known small classical curvature cost remains small
after an extensive exact integration of nonlinear compact links on a
four-dimensional physical exhaustion, with its leading coefficient
calculated. This determines a ratio of finite marginal-density values;
it does not yet determine a vacuum excitation energy or a temporal
correlation decay rate.

### 5.2 Retained anisotropic time step

The temporal coordinate must also be specified when relating this action
to a Hamiltonian. Let directions 1, 2 and 3 be spatial, with mesh \(a\),
and direction 4 Euclidean temporal, with mesh \(\epsilon\). For the
original action and Lie metric, coefficient matching gives
\[
 b_s=\frac{\epsilon}{2g_{\rm YM}^2a},\qquad
 b_t=\frac{a}{2g_{\rm YM}^2\epsilon}.
\]
Indeed a spatial plaquette has curvature area \(a^2\) and a temporal
plaquette area \(a\epsilon\), whereas the physical cell volume is
\(a^3\epsilon\). Multiplying each squared area by its displayed
coefficient gives \(a^3\epsilon/(2g_{\rm YM}^2)\). The isotropic
choice \(\epsilon=a\) recovers \(b_s=b_t=b\), including every factor.

For a selected spatial link in the magnetic plane, there are two magnetic
spatial staples, two other spatial staples and two temporal staples.
Its exact flat and magnetic staple radii are consequently
\[
 r_0=4b_s+2b_t,\qquad
 r_\vartheta=2b_s(1+\cos\vartheta)+2b_t,
 \qquad r_0-r_\vartheta=2b_s(1-\cos\vartheta).
\]
The exact integrated star cost is still
\[
 \Delta S^{a,\epsilon}_{\rm star}
 =\log Z(r_0)-\log Z(r_\vartheta)
 =\int_{r_\vartheta}^{r_0}2\eta(s)ds.
\]
Thus the same nonlinear integration has an explicit time-step dictionary,
not an identification of \(a\) and \(\epsilon\) made after the fact.

For clarity, the first large-\(r\) coefficient used here can be proved
from the exact Haar integral. Set \(w_0=1-z/r\). Apart from factors
that cancel in expectations, the density of \(z\in[0,2r]\) is
\[
 e^{-2z}z^{1/2}\left(1-\frac z{2r}\right)^{1/2}dz.
\]
On \(0\leq z\leq r\), the last factor equals \(1+O(z/r)\), with an
absolute bound supplied by the mean value theorem on \([0,1/2]\).
The tail \(z\geq r\) is bounded by the exponentially integrable
\(e^{-2z}z^{1/2}\), and the same argument works after multiplication
by \(z\). Hence the mean of \(z\) is
\[
 \frac{\int_0^\infty e^{-2z}z^{3/2}dz}
      {\int_0^\infty e^{-2z}z^{1/2}dz}+O(r^{-1})
 =\frac34+O(r^{-1}),
\]
where integration by parts gives the ratio \(3/4\). Since
\(w_0=1-z/r\), this proves
\(\eta(r)=1-3/(4r)+O(r^{-2})\), with no Gaussian substitution for
the finite integral.

Keeping \(a>0\) and \(g_{\rm YM}>0\) fixed and taking
\(\epsilon\downarrow0\), the exact star formula gives
\[
 \frac{\Delta S^{a,\epsilon}_{\rm star}}
      {4b_s(1-\cos\vartheta)}
 =1-\frac{3}{4r_0}+O_{a,g_{\rm YM}}(\epsilon^2)
 =1-\frac{3g_{\rm YM}^2\epsilon}{4a}
       +O_{a,g_{\rm YM}}(\epsilon^2)
\]
when \(\cos\vartheta<1\). This follows by averaging \(\eta\) over
the actual interval, whose width is at most \(4b_s=O(\epsilon)\),
while \(r_0\) is of order \(\epsilon^{-1}\). Equivalently,
\[
 4b_s(1-\cos\vartheta)-\Delta S^{a,\epsilon}_{\rm star}
 =\frac{3\epsilon^2}{2a^2}(1-\cos\vartheta)
      +O_{a,g_{\rm YM}}(\epsilon^3).
\]
The error estimate is uniform for real \(\vartheta\), using
\(0\leq1-\cos\vartheta\leq2\). At \(\cos\vartheta=1\) the exact
difference vanishes, while the ratio is interpreted by its continuous
value. The strict finite-step reduction proved above is preserved;
its size in a continuous-time limit is now explicitly calculated.
At fixed spatial regulator and fixed temporal extent, there are at most
a constant times \(\epsilon^{-1}\) selected links, so their total
one-layer reduction is \(O_{a,g_{\rm YM}}(\epsilon)\). No uniform
claim in \(a\downarrow0\) follows from this fixed-\(a\) estimate.
In the isotropic joint sequence of section 5.1 the exact coefficient
remains \(\eta(6b)\). Both limiting procedures and their retained
coefficients are therefore visible.

## 6. What this calculation transports, and the next actual calculation

The cusp sequence now has a fully explicit nonlinear classical action and
observable transport on any fixed bounded physical domain. The finite
compact-link regulator has an exact integration of a link retaining every
neighboring plaquette, with the induced interaction displayed above.
Neither operation changes \(SU(2)\) to a commutative field theory.

Successive integration produces further interactions; the displayed
six-staple formula is not asserted to stay in the original one-plaquette
form after previous eliminations. For a region \(\Lambda\), the exact
marginal is obtained by integrating its complement in
\(e^{-S_W}\prod_e dU_e\), leaving the positive boundary-dependent
factor \(Z_{\Lambda^c}(U_{\partial\Lambda})\). Discarding that factor
would discard an interaction. Its effect on gauge-invariant covariance
and spectral weight is the quantity to calculate, alongside the exact
Hamiltonian ground-state identities in the companion calculation.
No vanishing interacting infinite-volume quantum gap is proved here.

## Literature and provenance

The period matrix, covering map, action convention and original flux are
the formulas with these source labels in the canonical compact-link draft:

- `cusp-link-period-matrix`;
- `cusp-link-cover-matrix`;
- `cusp-link-magnetic-ym-normalization`;
- `cusp-link-flux-theorem`.

The block inverses, full curvature transport,
local nonlinear extension and finite-graph realization are proved above.

The single-link integral is established lattice-gauge mathematics, not
claimed here as a newly discovered integration method. Its role here is to
compute the interaction retained in this cusp-to-regulator route.

- K. G. Wilson, *Confinement of quarks*, Physical Review D **10** (1974),
  2445-2459, <https://doi.org/10.1103/PhysRevD.10.2445>.
- J. Kogut and L. Susskind, *Hamiltonian formulation of Wilson's lattice
  gauge theories*, Physical Review D **11** (1975), 395-408,
  <https://doi.org/10.1103/PhysRevD.11.395>.
- M. Creutz, *Monte Carlo study of quantized SU(2) gauge theory*, Physical
  Review D **21** (1980), 2308-2315,
  <https://doi.org/10.1103/PhysRevD.21.2308>. Author's primary inventory:
  <https://www.latticeguy.net/mypubs/pubs.html>, item 37.
- D. Tong, *Lectures on Gauge Theory*, chapter 4, especially Wilson loops,
  the Wilson action and Haar integration, <https://www.damtp.cam.ac.uk/user/tong/gaugetheory.html>.
  The locally retained text was inspected rather than relying only on recall.
- A. Jaffe and E. Witten, *Quantum Yang-Mills Theory*,
  <https://www.claymath.org/wp-content/uploads/2022/06/yangmills.pdf>,
  specifies the quantum existence and mass-gap target; no part of that
  target is replaced by the finite calculations above.

```

## Complete source: wilson_variation/wilson_finite_lattice.tex

```latex
\documentclass[11pt]{article}
\usepackage[margin=1in]{geometry}
\usepackage{amsmath,amssymb,amsthm,mathtools}
\usepackage[hidelinks]{hyperref}
\newtheorem{theorem}{Theorem}
\newtheorem{lemma}[theorem]{Lemma}
\newtheorem{proposition}[theorem]{Proposition}
\newtheorem{corollary}[theorem]{Corollary}
\theoremstyle{definition}
\newtheorem{definition}[theorem]{Definition}
\newcommand{\tr}{\operatorname{tr}}
\newcommand{\SU}{\operatorname{SU}}
\newcommand{\Rea}{\operatorname{Re}}
\newcommand{\Ima}{\operatorname{Im}}
\newcommand{\Var}{\operatorname{Var}}
\newcommand{\Cov}{\operatorname{Cov}}
\newcommand{\dd}{\,\mathrm d}
\title{Exact vacuum-weighted Wilson-loop variation on a finite interacting lattice}
\author{}
\date{8 September 2026}
\begin{document}
\maketitle

\section{Objects, orientations, and both Lie metrics}

Fix an integer $n\geq2$, a finite oriented graph with vertex set $\mathsf V$
and one chosen orientation for every physical edge in a nonempty edge set
$\mathsf E$, and a finite list $\mathsf P$ of oriented closed plaquette words.
Write $N=|\mathsf E|$. Reverse traversal of $e$ uses $U_e^{-1}$, not a new
independent link. The configuration manifold and its probability Haar measure
are
\[
 \mathcal Q=\SU(n)^{\mathsf E},\qquad
 d\lambda(U)=\prod_{e\in\mathsf E}dU_e,\qquad \lambda(\mathcal Q)=1.
\]
For a word $C=((e_1,\varepsilon_1),\ldots,(e_\ell,\varepsilon_\ell))$
with $\varepsilon_j\in\{1,-1\}$, define, in the written order,
\[
 H_C(U)=U_{e_1}^{\varepsilon_1}\cdots U_{e_\ell}^{\varepsilon_\ell},
 \qquad W_C(U)=\tr H_C(U).
\]
A simple edge loop here means a nonempty closed word using each physical edge
at most once. Vertices may be repeated; all statements below needing simplicity
need precisely the absence of repeated physical edges. Ordinary simple
plaquettes and primitive winding loops on a sufficiently large periodic
hypercubic lattice satisfy this definition. If a small periodic lattice makes
one plaquette repeat an edge, use the repeated-occurrence formula below.

Choose an anti-Hermitian traceless basis $T_a$, $1\leq a\leq n^2-1$, with
\[
 -2\tr(T_aT_b)=\delta_{ab}.
\]
The derivatives requested in this calculation are exactly
\[
 X_{e,a}f(U)=\left.\frac d{dt}\right|_{t=0}
 f(\ldots,e^{tT_a}U_e,\ldots),\qquad
 \Delta_e^T=\sum_aX_{e,a}^2.
\]
In this convention $X_{e,a}$ is skew-adjoint in $L^2(\lambda)$. Indeed,
left invariance of Haar gives
\[
 \int f(e^{tT_a}U_e)g(U_e)dU_e
 =\int f(U_e)g(e^{-tT_a}U_e)dU_e;
\]
differentiation proves the assertion,
with the complex conjugate placed on the first argument when appropriate.

There are two retained Lie metrics, related by an explicit dictionary:
\begin{align}
 g_T(A,B)&=-2\tr(AB),&
 c(A,B)&=-\tfrac12\tr(AB)=\tfrac14g_T(A,B),\label{eq:metrics}\\
 c(T_a,T_b)&=\tfrac14\delta_{ab},&
 S_a&=2T_a,& c(S_a,S_b)&=\delta_{ab},\nonumber\\
 X^c_{e,a}&=2X_{e,a},&
 \Delta_e^c&=4\Delta_e^T.\label{eq:metric-laplace}
\end{align}
Thus a Casimir eigenvalue measured with $c$ is four times its $g_T$ value.
The Hamiltonian in this paper is the specified operator
\begin{equation}\label{eq:H}
 H=-\sum_{e\in\mathsf E}\kappa_e\Delta_e^T+V,
 \quad
 V(U)=\sum_{p\in\mathsf P}b_p\bigl(n-\Rea W_p(U)\bigr),
 \quad \kappa_e>0,\ b_p>0.
\end{equation}
In the original cusp metric it is identically
$H=-\sum_e(\kappa_e/4)\Delta_e^c+V$.
Keeping the coefficient $\kappa_e$ in front of $\Delta_e^c$ would instead
multiply the kinetic operator by four and would define a different
Hamiltonian. No such replacement is made here. The inequalities
$|\tr U|\leq n$ for $U\in\SU(n)$ and
\begin{equation}\label{eq:Vbounds}
 0\leq V\leq M,\qquad
 M=2nB,\qquad B=\sum_{p\in\mathsf P}b_p,
\end{equation}
retain every plaquette term. The trace bound follows by summing the $n$
unit-modulus eigenvalues. The constant $2nB$ is a valid bound; no assertion
that all plaquettes attain their separate maxima simultaneously is needed.

The probability Haar convention also has an exact volume dictionary.
On the compact configuration manifold, whose real dimension is
$d=N(n^2-1)$, \eqref{eq:metrics} gives
$d\operatorname{vol}_c=2^{-d}d\operatorname{vol}_{g_T}$.
If $\mathcal V_c=\operatorname{vol}_c(\mathcal Q)$ and
$\mathcal V_T=\operatorname{vol}_{g_T}(\mathcal Q)$, then
\[
 d\lambda=\mathcal V_c^{-1}d\operatorname{vol}_c
         =\mathcal V_T^{-1}d\operatorname{vol}_{g_T},\qquad
 \mathcal V_c=2^{-d}\mathcal V_T.
\]
The map $f\mapsto\sqrt{\mathcal V_c}\,f$ is unitary from
$L^2(d\operatorname{vol}_c)$ to $L^2(d\lambda)$ and intertwines the same
differential Hamiltonian. A ground state normalized in the former
space is therefore taken to $\psi_0=\sqrt{\mathcal V_c}\,\psi_c$, so
$\psi_0^2d\lambda=\psi_c^2d\operatorname{vol}_c$ exactly. These are
volume identities on the compact group product only; they do not
identify a noncompact cusp measure with Haar measure.

Gauge transformations are
$(g\cdot U)_e=g_{s(e)}U_eg_{t(e)}^{-1}$ for
$g\in\SU(n)^{\mathsf V}$. Along a closed word all adjacent factors cancel,
so $H_C$ changes by conjugation at its base vertex and $W_C$ is invariant.
Haar measure, each $\Delta_e^T$, and $V$ are gauge invariant. The physically
restricted finite Hilbert space is therefore the closed invariant subspace
$\mathcal H_{\rm inv}\subset L^2(\mathcal Q,\lambda)$, and $H$ preserves it.

\section{Fierz identities with the stated normalization}

\begin{lemma}\label{lem:Fierz}
For arbitrary complex $n\times n$ matrices $A,B$,
\begin{align}
 \sum_a(T_a)_{ij}(T_a)_{kl}
 &=-\frac12\left(\delta_{il}\delta_{jk}
                  -\frac1n\delta_{ij}\delta_{kl}\right),\label{eq:Fierz}\\
 \sum_a\tr(T_aA)\tr(T_aB)
 &=-\frac12\left(\tr(AB)-\frac1n\tr A\tr B\right),\label{eq:bilinear}\\
 \sum_a\tr(T_aA)\overline{\tr(T_aB)}
 &=\frac12\left(\tr(AB^\dagger)
       -\frac1n\tr A\,\overline{\tr B}\right),\label{eq:sesquilinear}\\
 \sum_aT_a^2&=-C_FI_n,\qquad C_F=\frac{n^2-1}{2n}.\label{eq:fundcasimir}
\end{align}
In particular, for $A\in\SU(n)$,
\begin{equation}\label{eq:singlecontraction}
 \sum_a|\tr(T_aA)|^2=\frac{n^2-|\tr A|^2}{2n}.
\end{equation}
\end{lemma}
\begin{proof}
The matrices $Q_0=I_n/\sqrt n$ and $Q_a=i\sqrt2T_a$ form an orthonormal
basis of the real vector space of Hermitian matrices for the scalar product
$\tr(QR)$. Their complex linear span is all complex matrices. Expanding an
arbitrary matrix $D$ gives
$D=\sum_{\alpha=0}^{n^2-1}Q_\alpha\tr(Q_\alpha D)$.
Taking the coefficient of $D_{lk}$ in entry $ij$ proves
$\sum_\alpha(Q_\alpha)_{ij}(Q_\alpha)_{kl}=\delta_{il}\delta_{jk}$.
Subtract the $Q_0$ term and use $(i\sqrt2)^2=-2$ to obtain
\eqref{eq:Fierz}. Contract it with $A_{ji}B_{lk}$ to get
\eqref{eq:bilinear}. Anti-Hermiticity gives
$\overline{\tr(T_aB)}=-\tr(T_aB^\dagger)$; this proves
\eqref{eq:sesquilinear}. Put $k=j$ in \eqref{eq:Fierz} and sum $j$ to
obtain \eqref{eq:fundcasimir}. Finally $AA^\dagger=I_n$ gives
\eqref{eq:singlecontraction}.
\end{proof}

\section{Every edge orientation and the exact overlap morphism}

Fix one occurrence of physical edge $e$ in $C$ and write the ordered word
as $P U_e^{\varepsilon}Q$, where $P$ and $Q$ are the products before and
after that occurrence. Cyclic trace invariance gives the following
matrices based at the original source $s(e)$:
\begin{equation}\label{eq:based}
 A_{C,e,r}=
 \begin{cases}
 U_eQP,&\varepsilon=+1,\\
 QPU_e^{-1},&\varepsilon=-1.
 \end{cases}
\end{equation}
The occurrence index $r$ is suppressed when there is only one occurrence.
Each $A_{C,e,r}$ lies in $\SU(n)$, has trace $W_C$, and transforms by
conjugation with $g_{s(e)}$ under a gauge transformation. These statements
follow either by multiplying the factors or by following the cyclically
based closed path at $s(e)$.

The derivative of an inverse is
$X_{e,a}U_e^{-1}=-U_e^{-1}T_a$, since
$(e^{tT_a}U_e)^{-1}=U_e^{-1}e^{-tT_a}$. Consequently
\begin{align}
 X_{e,a}\tr(PU_eQ)&=\tr(PT_aU_eQ)=\tr(T_aU_eQP),\nonumber\\
 X_{e,a}\tr(PU_e^{-1}Q)&=-\tr(PU_e^{-1}T_aQ)
 =-\tr(T_aQPU_e^{-1}).\label{eq:orientations}
\end{align}
For an arbitrary closed word the product rule now gives
\begin{equation}\label{eq:repeatedderivative}
 X_{e,a}W_C=\sum_{r:e_r=e}\varepsilon_r\tr(T_aA_{C,e,r}).
\end{equation}
All factors in \eqref{eq:based} are evaluated at the original configuration;
there is no independent-link approximation in this formula.

For two words define the edgewise sesquilinear and bilinear contractions
by
\[
 \Gamma_e(F,G)=\sum_a(X_{e,a}F)\overline{X_{e,a}G},\qquad
 \Gamma_e^{\rm bil}(F,G)=\sum_a(X_{e,a}F)(X_{e,a}G).
\]
Lemma \ref{lem:Fierz} proves, occurrence by occurrence,
\begin{align}
\Gamma_e(W_C,W_D)
 &=\frac12\sum_{r:e_r=e}\sum_{s:d_s=e}\varepsilon_r\eta_s
 \left[\tr(A_{C,e,r}A_{D,e,s}^{\dagger})
       -\frac1nW_C\overline{W_D}\right],\label{eq:overlap-general}\\
\Gamma_e^{\rm bil}(W_C,W_D)
 &=-\frac12\sum_{r:e_r=e}\sum_{s:d_s=e}\varepsilon_r\eta_s
 \left[\tr(A_{C,e,r}A_{D,e,s})-\frac1nW_CW_D\right].
 \label{eq:overlap-bil-general}
\end{align}
These identities construct the exact relation between the two loop
variations: $A_{C,e,r}A_{D,e,s}^{-1}$ is the concatenation of the first
based loop and the inverse of the second, and its trace is gauge invariant.
The nonconjugated contraction concatenates the two based loops directly.
An edge not occurring in both words contributes zero.

For simple edge loops, a common edge contributes exactly
\begin{align}
\Gamma_e(W_C,W_D)
 &=\frac{\varepsilon_{Ce}\varepsilon_{De}}2
   \left[\tr(A_{Ce}A_{De}^{\dagger})
                    -\frac1nW_C\overline{W_D}\right],\label{eq:overlap-simple}\\
\Gamma_e^{\rm bil}(W_C,W_D)
 &=-\frac{\varepsilon_{Ce}\varepsilon_{De}}2
   \left[\tr(A_{Ce}A_{De})-\frac1nW_CW_D\right].\nonumber
\end{align}
In particular, for every used edge of a simple loop,
\begin{equation}\label{eq:simpleenergy}
 \Gamma_e(W_C,W_C)=\frac{n^2-|W_C|^2}{2n},\qquad
 \sum_aX_{e,a}^2W_C=-C_FW_C.
\end{equation}
The second equality follows directly from \eqref{eq:orientations} and
\eqref{eq:fundcasimir}; in negative orientation the two derivative signs
cancel. Both equalities are zero on unused edges. Define
$K_C=\sum_{e\in C}\kappa_e$. Then the full pointwise energy is
\begin{equation}\label{eq:simplefullenergy}
 \Gamma_\kappa(W_C,W_C):=\sum_e\kappa_e\Gamma_e(W_C,W_C)
       =\frac{K_C}{2n}(n^2-|W_C|^2).
\end{equation}

For later real plaquette observables the exact companion identity is
\begin{equation}\label{eq:realenergy}
 \Gamma_\kappa(\Rea W_C,\Rea W_C)
 =\frac{K_C}{4}\left[n-\Rea\tr(H_C^2)
                           -\frac2n(\Ima W_C)^2\right].
\end{equation}
To prove it, use $(\Rea z)^2=(|z|^2+\Rea z^2)/2$ in the derivative
sum, apply both contractions in Lemma \ref{lem:Fierz}, and observe
$\tr(A_{Ce}^2)=\tr(H_C^2)$ because cyclic rotations of invertible factors
are conjugate matrices. Thus the right side is nonnegative despite its
written difference of terms. The same energy holds for $n-\Rea W_C$.
Measured using $X^c=2X$, every $\Gamma_e$ in this section is multiplied
by four; pairing it with kinetic coefficient $\kappa_e/4$ recovers
exactly \eqref{eq:simplefullenergy} and \eqref{eq:realenergy}.

\section{Existence, exact ground-state transform, and orthogonality}

The domain of the nonnegative quadratic form of $H$ is the first Sobolev
space on $\mathcal Q$, with the equivalent norm given by the finitely many
fields $X_{e,a}$. Its form is
\[
 q_H(u,v)=\sum_{e,a}\kappa_e\int\overline{X_{e,a}u}X_{e,a}v\,d\lambda
                   +\int V\overline uv\,d\lambda.
\]
We use the self-adjoint operator associated to this closed form.

\begin{lemma}\label{lem:ground}
$H$ has a unique normalized strictly positive ground eigenfunction
$\psi_0\in C^\infty(\mathcal Q)$, with $H\psi_0=E_0\psi_0$ and
$\int\psi_0^2d\lambda=1$. It is gauge invariant. In particular the bottom
eigenvalue of the gauge-invariant restriction is the same $E_0$.
\end{lemma}
\begin{proof}
The free positive operator $H_0=-\sum_e\kappa_e\Delta_e^T$ has a complete
matrix-coefficient eigenbasis by the compact-group Peter--Weyl theorem
\cite{PeterWeyl}; its finite-multiplicity eigenvalues tend to infinity.
The latter fact also follows from the explicit weights and bounds proved
in Section \ref{sec:heat}. Its resolvent is compact. Bounded real
multiplication by $V$ preserves self-adjointness and compact resolvent:
for sufficiently negative $z$, the identity
$(H-z)^{-1}=(H_0-z)^{-1}[I+V(H_0-z)^{-1}]^{-1}$ proves compactness by a
convergent Neumann series. Hence the bottom of the spectrum is an
eigenvalue. The inequality $|X|u||\leq|Xu|$ almost everywhere (obtain it
first for $\sqrt{|u|^2+\epsilon^2}$ and then let $\epsilon\downarrow0$)
shows that the modulus of a minimizing eigenfunction is also minimizing.
Choose a nonnegative normalized one. The elliptic equation
$H_0\psi_0=(E_0-V)\psi_0$ and local elliptic regularity, iterated with
smooth $V$, give $\psi_0\in C^\infty$.

For completeness, positivity needs no assumption about an unknown vacuum.
The parabolic comparison inequality proved in Section \ref{sec:heat} is
$e^{-tH}f\geq e^{-Mt}e^{-tH_0}f$ for $f\geq0$.
At the explicit time $t_*$ in that section the kernel of $e^{-t_*H_0}$
is at least $2^{-N}$. Thus
$\psi_0(U)\geq e^{(E_0-M)t_*}2^{-N}\int\psi_0d\lambda>0$.
The next theorem, whose calculation uses only this already established
positivity and the eigenvalue equation, proves uniqueness: if $u$ is
another ground eigenfunction, put $f=u/\psi_0$ in its identity. The
result is $\int\psi_0^2\sum_{e,a}\kappa_e|X_{e,a}f|^2d\lambda=0$.
The fields span each tangent space and $\mathcal Q$ is connected, so
$f$ is constant. Gauge transformations preserve $H$, positivity and
normalization, and consequently fix $\psi_0$ by this uniqueness.
\end{proof}

Set
\begin{equation}\label{eq:vacuummeasure}
 d\mu=\rho\,d\lambda,\qquad \rho=\psi_0^2,
 \qquad \mu(F)=\int F\,d\mu.
\end{equation}
This measure is determined by the interacting Hamiltonian
\eqref{eq:H}; no other measure is substituted for it below.
Multiplication $\mathcal U f=\psi_0 f$ is a unitary map from
$L^2(\mu)$ onto $L^2(\lambda)$, since
$\|\mathcal U f\|_\lambda^2=\int|f|^2d\mu$, and division by the positive
$\psi_0$ is its inverse. It also maps the respective gauge-invariant
subspaces onto one another.

\begin{theorem}\label{thm:ground-transform}
For all smooth complex $f,g$,
\begin{align}
 Lg:=\mathcal U^{-1}(H-E_0)\mathcal Ug
 &=-\sum_{e,a}\kappa_e
       \bigl[X_{e,a}^2g+2(X_{e,a}\log\psi_0)X_{e,a}g\bigr]
       \label{eq:groundop}\\
 &=-\rho^{-1}\sum_{e,a}\kappa_e X_{e,a}(\rho X_{e,a}g),\nonumber\\
 \langle\psi_0f,(H-E_0)\psi_0g\rangle_\lambda
 &=\sum_{e,a}\kappa_e\int\overline{X_{e,a}f}X_{e,a}g\,d\mu.
 \label{eq:groundform}
\end{align}
The identities extend to the corresponding closed form domains. For any
nonconstant smooth $F$, the vector
$u_F=\psi_0(F-\mu(F))$ is orthogonal to $\psi_0$, and
\begin{equation}\label{eq:Rayleigh-general}
 \frac{\langle u_F,(H-E_0)u_F\rangle}{\|u_F\|^2}
 =\frac{\mu(\Gamma_\kappa(F,F))}
        {\mu(|F|^2)-|\mu(F)|^2}.
\end{equation}
\end{theorem}
\begin{proof}
The product rule gives
$X^2(\psi_0g)=\psi_0X^2g+2(X\psi_0)Xg+gX^2\psi_0$ for each $X$.
Subtracting $g(H-E_0)\psi_0=0$ from $(H-E_0)(\psi_0g)$ proves
\eqref{eq:groundop}; its divergence form uses $X\rho=2\psi_0X\psi_0$.
Multiply by $\rho\overline f$ and integrate. The skew-adjointness of
$X$ with respect to $\lambda$, proved above, gives
$-\int\overline f X(\rho Xg)d\lambda
=\int\rho\overline{Xf}Xg d\lambda$. Summing proves
\eqref{eq:groundform}. On a compact manifold multiplication and division
by the smooth positive $\psi_0$ are bounded on the first Sobolev space,
so smooth approximation proves the form extension. Finally
$\langle\psi_0,u_F\rangle=\mu(F)-\mu(F)=0$,
$\|u_F\|^2=\mu(|F|^2)-|\mu(F)|^2$, and subtracting a constant leaves
all derivatives unchanged. The variance is strictly positive because
$F$ is nonconstant and $\rho>0$ everywhere. These observations prove
\eqref{eq:Rayleigh-general}.
\end{proof}

In particular, put $m_C=\mu(W_C)$ and $r_C=\mu(|W_C|^2)$. For a simple
edge loop the exact answer is
\begin{equation}\label{eq:Rayleigh-loop}
 Q_C=\frac{K_C}{2n}\,
       \frac{n^2-r_C}{r_C-|m_C|^2}.
\end{equation}
The potential disappears from the displayed Dirichlet integrand because
the exact ground-state equation was used. It remains in $\rho$, $m_C$,
and $r_C$, as well as in the drift term in \eqref{eq:groundop}. Thus
this identity does not set $V$ or any $b_p$ to zero.

\section{Center symmetry, exact selection rules, and character limits}

Assign a central element $z_e\in Z(\SU(n))$ to each physical edge, subject
to
\begin{equation}\label{eq:centercondition}
 \prod_{r\in p}z_{e_r}^{\varepsilon_r}=1
 \quad\hbox{for every retained plaquette }p.
\end{equation}
Define $\sigma_z(U)_e=z_eU_e$. This is a Haar-preserving diffeomorphism,
commutes with the edge derivatives, and preserves every plaquette
holonomy because the factors $z_e$ are central and obey
\eqref{eq:centercondition}. It therefore preserves $H$ and, by uniqueness
and positivity, $\psi_0$ and $\mu$. For every closed word,
\[
 W_C(\sigma_z U)=\zeta_C W_C(U),\qquad
 \zeta_C=\prod_{r\in C}z_{e_r}^{\varepsilon_r}.
\]
Integration proves the exact selection rules
\begin{equation}\label{eq:selection}
 \mu(W_C)=0\quad\hbox{if }\zeta_C\ne1,
 \qquad
 \mu(W_C\overline{W_D})=0\quad\hbox{if }\zeta_C\overline{\zeta_D}\ne1.
\end{equation}
For powers and products the same proof applies with their product charge.

On a periodic hypercubic lattice, multiply the links in one coordinate
direction crossing one fixed periodic cut by $z\in Z(\SU(n))$, and
leave the other links unchanged. Each oriented plaquette crosses that
cut with total signed count zero, which verifies
\eqref{eq:centercondition} directly. A loop with integer winding $q$
in that direction acquires $z^q$. A primitive single winding has a
nontrivial charge for a nonidentity suitable $z$, and therefore $m_C=0$.
A loop whose winding in every direction is divisible by $n$ does not
obtain a zero mean from this argument. Contractible plaquettes are
center neutral; their means must be retained.

For a charged simple loop the quotient becomes
\begin{equation}\label{eq:chargedquotient}
 Q_C=\frac{K_C}{2n}\left(\frac{n^2}{r_C}-1\right),
 \qquad 0<r_C<n^2.
\end{equation}
The strict inequalities follow from $\rho>0$ and the fact that the
holonomy map of a simple loop has image all of $\SU(n)$: fix the other
edges and vary any one used edge. Some images have trace zero and
others have trace $n$, and neighborhoods of both have positive Haar
measure. In particular center symmetry does not set $r_C$ equal to one.

\begin{lemma}\label{lem:Haar-loop}
For every simple edge loop,
\[
 \int W_Cd\lambda=0,\quad
 \int|W_C|^2d\lambda=1,\quad
 \int(n^2-|W_C|^2)d\lambda=n^2-1.
\]
\end{lemma}
\begin{proof}
Condition on every edge except one appearing once. Its loop holonomy
is $A U_e^{\pm1}B$ for fixed group matrices $A,B$, and is Haar distributed
by left and right invariance and invariance under inversion. It suffices
to integrate over one Haar matrix $U$. Its mean trace is zero since
$U\mapsto zU$ preserves Haar for a nonidentity central $z$.
For arbitrary $D$, the matrix $\int UDU^\dagger dU$ commutes with every
$\SU(n)$ matrix by invariance, and so is $(\tr D)I_n/n$.
To see the scalar conclusion without an additional representation
assumption, commuting with diagonal unitary matrices kills the
off-diagonal entries and commuting with determinant-one unitary changes
of coordinate axes makes all diagonal entries equal. Set $D=E_{jl}$
and compare entries to get
$\int U_{ij}\overline{U_{kl}}dU=\delta_{ik}\delta_{jl}/n$.
Taking $j=i$, $l=k$ and summing $i,k$ gives $\int|\tr U|^2dU=1$.
The last asserted integral follows by subtraction.
\end{proof}

There is also an exact character map that retains the second moment.
The conjugation action $A\mapsto UAU^{-1}$ on $\operatorname{End}(\mathbb C^n)$
has trace $\tr U\tr U^{-1}=|\tr U|^2$. The invariant decomposition into
scalar and traceless matrices has characters $1$ and $\chi_{\rm ad}$.
Consequently
\begin{equation}\label{eq:adjointmoment}
 |\tr U|^2=1+\chi_{\rm ad}(U),\quad
 r_C=1+\mu(\chi_{\rm ad}(H_C)),\quad
 -1\leq\chi_{\rm ad}(U)\leq n^2-1.
\end{equation}
This derivation proves the equality and both bounds directly; the adjoint
character is center neutral, so \eqref{eq:selection} imposes no zero
expectation on it.

\begin{proposition}\label{prop:symmetryinsufficient}
Center and gauge invariance, positivity of a smooth density, and the
pointwise character bounds alone imply no strictly positive uniform
lower bound on $r_C$ and no upper bound strictly smaller than $n^2$.
This assertion concerns those premises alone, not the narrower family
of ground states of \eqref{eq:H}.
\end{proposition}
\begin{proof}
Let $h(U)=|W_C(U)|^2$. Its range includes $0$ and $n^2$.
For an explicit trace-zero matrix take
$\zeta=e^{2\pi i/n}$ and
$A=\alpha\operatorname{diag}(1,\zeta,\ldots,\zeta^{n-1})$ with
$\alpha=e^{-\pi i(n-1)/n}$. The geometric sum is zero and
$\det A=\alpha^n\zeta^{n(n-1)/2}=1$. Choose one edge to realize $A$
as holonomy; identity holonomy realizes $n^2$.
For each $s>0$, the densities
\[
 \rho_s^- =\frac{e^{-sh}}{\int e^{-sh}d\lambda},\qquad
 \rho_s^+ =\frac{e^{sh}}{\int e^{sh}d\lambda}
\]
are smooth, strictly positive, gauge invariant, and invariant under
every center transformation of the stated type. For $\epsilon>0$, the
set $h<\epsilon/2$ is nonempty open and has Haar measure $a_\epsilon>0$.
Its contribution to the first denominator is at least
$a_\epsilon e^{-s\epsilon/2}$, whereas the numerator mass of $h\geq\epsilon$
is at most $e^{-s\epsilon}$. Thus this latter probability tends to zero
and $\int h\rho_s^-d\lambda\to0$ by boundedness. Apply the same argument
to $n^2-h$ for $\rho_s^+$ to obtain $\int h\rho_s^+d\lambda\to n^2$.
For a nontrivially charged loop, both measures also have zero loop mean
by the selection-rule proof. No claim is made that these constructed
densities arise from positive Wilson plaquette coefficients in
\eqref{eq:H}; their role is to prove exactly the asserted insufficiency
of symmetry and character bounds alone.
\end{proof}

\section{Explicit all-coupling finite-volume estimates}\label{sec:heat}

The full Hamiltonian supplies more information than those symmetry
premises. The following bounds use it and hold for arbitrary positive
values of all retained couplings. Define
\begin{equation}\label{eq:constants}
 \kappa_* =\min_{e\in\mathsf E}\kappa_e,
 \quad D=n^2-2,
 \quad t_* =\frac{2(D\log2+\log3)}{(n-1)\kappa_*},
 \quad a_* =3^{-2N}e^{-2Mt_*}=3^{-2N}e^{-4nBt_*}.
\end{equation}
These constants are dimensionally consistent: $t_*$ is inverse energy,
$M$ is energy, and $a_*$ is dimensionless. They are estimates, not a
claim of optimal constants.

\begin{lemma}\label{lem:heat}
The integral kernel of $P_t=e^{-tH_0}$ satisfies
\begin{equation}\label{eq:kernelbounds}
 2^{-N}\leq p_{t_*}(U,V)\leq(3/2)^N
 \qquad\hbox{for all }U,V\in\mathcal Q.
\end{equation}
\end{lemma}
\begin{proof}
We give the representation constants to fix the heat time and Lie
metric exactly. The irreducibles of $\SU(n)$ are indexed by
$m=(m_1,\ldots,m_{n-1})\in\mathbb Z_{\geq0}^{n-1}$, with
$\lambda_m=\sum_i m_i\omega_i$. In the usual Euclidean root space
$\{x\in\mathbb R^n:\sum x_i=0\}$ with roots $e_i-e_j$ of squared
length two, set
\[
 \omega_i=\sum_{j=1}^i e_j-\frac in\sum_{j=1}^n e_j,
 \quad \rho_{\rm rt}=\sum_{i=1}^{n-1}\omega_i.
\]
The dimension and the $g_T$-Casimir eigenvalue are
\begin{align}
 d_m&=\prod_{1\leq i<j\leq n}
       \frac{\sum_{q=i}^{j-1}m_q+j-i}{j-i},\label{eq:dim}\\
 C_m&=\frac12(\lambda_m,\lambda_m+2\rho_{\rm rt}).\label{eq:casimir}
\end{align}
These standard representation identities can be read in row coordinates
in \cite{PolychronakosSfetsos}. To spell out the dictionary and constants,
put $\ell_i=\sum_{q=i}^{n-1}m_q$, $\ell_n=0$, and $L=\sum_i\ell_i$.
The highest weight has coordinates $\ell_i-L/n$, and
$2\rho_{{\rm rt},i}=n+1-2i$. Thus \eqref{eq:casimir} says explicitly
\[
 C_m=\frac12\left[\sum_{i=1}^n\ell_i(\ell_i+n+1-2i)-\frac{L^2}{n}\right].
\]
The dimension formula follows from the character alternant
$\det(z_i^{\ell_j+n-j})/\det(z_i^{n-j})$ by letting all $z_i$ tend to
one: the first nonzero alternant terms are the two Vandermonde
determinants in $\ell_j+n-j$ and $n-j$, whose ratio is
\eqref{eq:dim}. The Casimir formula follows by applying the Cartan and
root decomposition of the quadratic Casimir to a highest weight
vector: the Cartan term gives $(\lambda_m,\lambda_m)$, and commuting
each positive-root raising operator past its lowering operator gives
$2(\lambda_m,\rho_{\rm rt})$; the factor $1/2$ is fixed by
\eqref{eq:fundcasimir}. Hence the metric normalization is the one used
in \eqref{eq:H}, rather than an unspecified heat-kernel convention.

Write $k=\sum_i m_i$. Direct scalar multiplication gives
$(\omega_i,\rho_{\rm rt})=i(n-i)/2$. Since
$(\lambda_m,\lambda_m)\geq0$ and $i(n-i)\geq n-1$,
\[
 C_m\geq\frac{n-1}{2}k,\qquad
 d_m\leq(k+1)^{n(n-1)/2}.
\]
The number of $m$ with this sum $k$ is
$\binom{k+n-2}{n-2}\leq(k+1)^{n-2}$: the first $n-2$ entries determine
the last, and each has at most $k+1$ choices. This also covers $n=2$.

Peter--Weyl orthogonality and the Casimir action give the single-edge
heat kernel
\[
 q_s(g)=\sum_m d_m e^{-sC_m}\chi_m(g).
\]
Indeed convolution by $d_m\chi_m$ projects onto the matrix coefficients
of the corresponding irreducible (with the inverse in the kernel
argument if needed), and the heat operator multiplies that subspace by
$e^{-sC_m}$. The series is absolutely uniformly convergent for every
$s>0$: a unitary representation has $|\chi_m(g)|\leq d_m$, and the
above bounds majorize the nonconstant terms by a polynomial in $k$
times $e^{-s(n-1)k/2}$. This also proves finite eigenvalue multiplicities
and divergence of the eigenvalues used in Lemma \ref{lem:ground}.
The constant representation contributes one. For edge $e$ and time $t$,
\begin{align*}
 |q_{\kappa_et}(g)-1|
 &\leq\sum_{k\geq1}(k+1)^D e^{-\kappa_et(n-1)k/2}\\
 &\leq\sum_{k\geq1}\left(2^D e^{-\kappa_et(n-1)/2}\right)^k.
\end{align*}
The second inequality uses $k+1\leq2^k$ for integer $k\geq1$, proved
by induction. At $t=t_*$ the ratio is at most $1/3$, so the sum is at
most $1/2$. Thus $1/2\leq q_{\kappa_et_*}\leq3/2$. The free generator
is the sum of commuting edge generators on the product space, so its
kernel is the product of these $N$ kernels. This proves
\eqref{eq:kernelbounds}.
\end{proof}

\begin{lemma}\label{lem:comparison}
For every continuous $f\geq0$ and $t\geq0$,
\begin{equation}\label{eq:semigroupcomparison}
 e^{-Mt}P_tf\leq e^{-tH}f\leq P_tf.
\end{equation}
Consequently the exact vacuum satisfies
\begin{equation}\label{eq:densitybounds}
 \frac{\max\psi_0}{\min\psi_0}\leq3^Ne^{Mt_*},\qquad
 \frac{\min\rho}{\max\rho}\geq a_*,\qquad
 a_*\leq\rho(U)\leq a_*^{-1}\quad(U\in\mathcal Q).
\end{equation}
\end{lemma}
\begin{proof}
Write $\mathcal A=\sum_e\kappa_e\Delta_e^T$, so
$P_t=e^{t\mathcal A}$. The parabolic maximum principle on this compact
manifold says that a solution of
$(\partial_t-\mathcal A+V)u\geq0$ with nonnegative initial data is
nonnegative when $V\geq0$. One direct proof replaces $u$ by
$e^{-ct}u+\epsilon$ with $c>0$, considers a first negative minimum,
and uses that $\partial_tu\leq0$, $\mathcal Au\geq0$ at that point;
the positive zero-order coefficient makes the differential inequality
impossible. Letting $\epsilon\downarrow0$ proves the result. Smooth
approximation covers continuous initial data.
Apply this principle first to $u=e^{-tH}f$ to get $u\geq0$.
The free solution $v=P_tf$ is also nonnegative by the same argument
with $V=0$. Now
$(\partial_t-\mathcal A+V)v=Vv\geq0$, so $v-u\geq0$.
For $w=e^{-Mt}v$ the corresponding expression is
$(V-M)w\leq0$, so $u-w\geq0$. This proves
\eqref{eq:semigroupcomparison} with no approximation of $V$.

Apply it to $f=\psi_0$ and use
$e^{-tH}\psi_0=e^{-tE_0}\psi_0$. At time $t_*$, letting
$I_0=\int\psi_0d\lambda>0$, Lemma \ref{lem:heat} gives
\[
 e^{(E_0-M)t_*}2^{-N}I_0
 \leq\psi_0(U)\leq e^{E_0t_*}(3/2)^NI_0.
\]
Take the ratio of upper to lower bounds and square to obtain the first
two assertions in \eqref{eq:densitybounds}. Since $\int\rho d\lambda=1$,
$\min\rho\leq1\leq\max\rho$. The ratio bound then gives
$\min\rho\geq a_*\max\rho\geq a_*$ and
$\max\rho\leq\min\rho/a_*\leq a_*^{-1}$, as required.
\end{proof}

\begin{theorem}\label{thm:finite-bounds}
For every simple edge loop,
\begin{equation}\label{eq:momentbounds}
 a_*\leq r_C\leq n^2-a_*(n^2-1),\qquad
 a_*(n^2-1)\leq n^2-r_C\leq n^2-a_*.
\end{equation}
For every such loop carrying a nontrivial center charge,
\begin{equation}\label{eq:quotientbounds}
 \frac{K_C}{2n}\frac{a_*(n^2-1)}{n^2-a_*(n^2-1)}
 \leq Q_C\leq
 \frac{K_C}{2n}\frac{n^2-a_*}{a_*}.
\end{equation}
The full finite-lattice spectral gap, and also its gauge-invariant
restriction above the unique vacuum, obey the genuine lower bound
\begin{equation}\label{eq:gapbound}
 \operatorname{gap}(H)\geq a_*\kappa_*\frac{n^2-1}{2n}>0.
\end{equation}
\end{theorem}
\begin{proof}
The density inequality $\rho\geq a_*$ and Lemma \ref{lem:Haar-loop}
give $r_C\geq a_*$ and
$n^2-r_C\geq a_*(n^2-1)$ by integrating the two nonnegative functions.
These prove all of \eqref{eq:momentbounds}. For a charged loop the
function $r\mapsto(n^2-r)/r$ is strictly decreasing for $r>0$;
substitute the two endpoints into \eqref{eq:chargedquotient} to get
\eqref{eq:quotientbounds}.

For \eqref{eq:gapbound}, first the exact free-product gap is
$g_0=\kappa_*C_F$. To verify the least nonzero single-edge Casimir,
compute
$(\omega_i,\omega_j)=\min(i,j)-ij/n>0$ for $1\leq i,j\leq n-1$.
If $m_i\geq1$, all coefficients in
$C(\lambda_m)-C(\omega_i)$ are nonnegative in the expansion in
fundamental weights. Hence
\[
 C_m\geq C(\omega_i)
 =\frac{i(n-i)(n+1)}{2n}\geq\frac{n^2-1}{2n}.
\]
Equality occurs for a fundamental or antifundamental representation.
On the product space each nonconstant matrix coefficient has at least
one such nonzero edge term; taking a fundamental coefficient on an
edge with $\kappa_e=\kappa_*$ realizes $g_0$. Peter--Weyl expansion
therefore proves the free Poincare inequality
$\mathcal E_\lambda(f,f)\geq g_0\Var_\lambda(f)$.
For any complex $f$, the variational identity
$\Var_\mu(f)=\min_{c\in\mathbb C}\int|f-c|^2d\mu$ gives
\[
 \Var_\mu(f)\leq(\max\rho)\Var_\lambda(f),\qquad
 \mathcal E_\mu(f,f)\geq(\min\rho)\mathcal E_\lambda(f,f).
\]
Consequently
$\mathcal E_\mu(f,f)\geq[(\min\rho)/(\max\rho)]g_0\Var_\mu(f)
\geq a_*g_0\Var_\mu(f)$.
The exact unitary ground-state transform identifies this weighted
Poincare infimum with the spectral gap of $H$. Restricting the infimum
to gauge-invariant functions can only increase it, and the ground
state belongs to that subspace by Lemma \ref{lem:ground}.
\end{proof}

The quotient bounds and the spectral bound have different logical
roles: the upper bound on any one orthogonal trial quotient is an upper
bound on the spectral gap, while a lower bound on that one quotient
alone is not. Equation \eqref{eq:gapbound} is valid because its proof
covers every form-domain vector. All constants in
\eqref{eq:constants} retain volume and coupling dependence. For example,
$a_*$ decreases exponentially in $N$ even with $B$ fixed, and also
decreases with $Bt_*$. Thus none of these inequalities asserts a
strictly positive lower bound after removing a cutoff or taking
infinite volume, and none proves that the limiting gap vanishes.

For a normalization check only, if $V$ is identically zero then
$\psi_0=1$, $r_C=1$, and $m_C=0$ for a simple loop, yielding
$Q_C=K_CC_F$. This is an exact special case of the formula, not a
replacement for the positive-coupling vacuum. The stated interacting
results above apply with all $b_p>0$.

\section{Disjoint parallel plaquettes, covariance Fourier sums, and spectral weight}

Let $p_j$, $j=0,\ldots,m-1$, be simple plaquettes whose physical-edge
supports are pairwise disjoint. Define
\[
 W_j=W_{p_j},\quad f_j=W_j-\mu(W_j),\quad
 c_j(k)=e^{ikj},\quad F_k=\sum_{j=0}^{m-1}c_j(k)f_j.
\]
The mean subtraction is necessary for center-neutral plaquettes. It
gives $\mu(F_k)=0$ for every real $k$ without any translation assumption.
For each edge at most one $f_j$ has a nonzero derivative, so pointwise
\begin{equation}\label{eq:disjointnumerator}
 \Gamma_\kappa(F_k,F_k)
 =\sum_j|c_j(k)|^2\Gamma_\kappa(W_j,W_j)
 =\sum_j\frac{K_j}{2n}(n^2-|W_j|^2),
 \quad K_j=\sum_{e\in p_j}\kappa_e.
\end{equation}
In particular its exact vacuum expectation is independent of $k$:
\begin{equation}\label{eq:Ek}
 E_k:=\mu(\Gamma_\kappa(F_k,F_k))
      =\sum_j\frac{K_j}{2n}(n^2-r_j),\qquad r_j=\mu(|W_j|^2).
\end{equation}
Edge disjointness says nothing about statistical independence in
$\mu$. The full variance is
\begin{equation}\label{eq:Dk}
 D_k:=\mu(|F_k|^2)
 =\sum_{j,l=0}^{m-1}e^{ik(j-l)}C_{jl},\qquad
 C_{jl}=\mu\bigl[(W_j-\mu W_j)\overline{(W_l-\mu W_l)}\bigr].
\end{equation}
All plaquette interactions, including plaquettes meeting more than one
of these supports or connecting them indirectly, remain in $C_{jl}$.
The covariance matrix is Hermitian positive semidefinite because its
quadratic form is the displayed squared $L^2(\mu)$ norm.
In fact $D_k>0$: if $F_k$ were constant, varying an edge unique to $p_j$
would force $W_j$ to be constant, which it is not. Positivity of $\rho$
then gives strictly positive variance. The exact quotient is
\begin{equation}\label{eq:disjointquotient}
 Q_k=\frac{E_k}{D_k}.
\end{equation}

Suppose now the specified finite lattice and its full lists of couplings
are invariant under a translation $\tau$ of order $m$ taking $p_j$ to
$p_{j+1}$ cyclically with their chosen orientations. Such a translation
preserves $H$ and Haar measure and therefore $\psi_0$ and $\mu$ by the
same uniqueness argument as for gauge transformations. There are then
constants $K_j=K$, $r_j=r$ and a cyclic covariance
\[
 C(d)=\mu(f_{l+d}\overline{f_l}),\qquad d\in\mathbb Z/m\mathbb Z,
\]
independent of $l$. For the allowed cyclic wave numbers
$k=2\pi q/m$, $q\in\{0,\ldots,m-1\}$, set
$\widehat C(k)=\sum_{d=0}^{m-1}e^{ikd}C(d)$. Regrouping the full
double sum in \eqref{eq:Dk}, with $j=l+d$, proves
\begin{equation}\label{eq:Fourierquotient}
 D_k=m\widehat C(k),\qquad
 E_k=m\frac{K}{2n}(n^2-r),\qquad
 Q_k=\frac{K(n^2-r)}{2n\widehat C(k)}.
\end{equation}
Here $\widehat C(k)$ is real and strictly positive because it equals
$D_k/m$; $C(-d)=\overline{C(d)}$ also proves reality directly.
There is no algebraic $k^2$ factor in this numerator. Obtaining a
small quotient in this family requires the actual interacting ratio
on the right of \eqref{eq:Fourierquotient} to become small. An assertion
that all covariances vanish, or that the denominator has prescribed
small-$k$ behavior, is not contained in edge disjointness.

For real plaquette energy observables $A_j=n-\Rea W_j$, replace $f_j$
by $A_j-\mu A_j$ and use the same coefficients. All support and covariance
arguments remain exact, but the local numerator is
\begin{equation}\label{eq:real-localnumerator}
 e_j^{\rm real}
 =\frac{K_j}{4}\left[n-\mu\bigl(\Rea\tr(H_{p_j}^2)\bigr)
                       -\frac2n\mu\bigl((\Ima W_j)^2\bigr)\right]
\end{equation}
by \eqref{eq:realenergy}. Thus under the same cyclic invariance
$Q_k=e^{\rm real}/\widehat C_A(k)$ with $\widehat C_A$ the full covariance
transform of $A_j$. Replacing this local numerator by the complex
Wilson numerator would lose terms unless equality is proved in the
particular group and observable.

Finally let $\mathsf P_{H-E_0}(\cdot)$ be the spectral projection measure
of the nonnegative self-adjoint operator $H-E_0$ on the invariant
Hilbert space. The normalized state and its scalar spectral probability
measure are
\begin{equation}\label{eq:spectralmeasure}
 v_k=\frac{\psi_0F_k}{\sqrt{D_k}},\qquad
 \nu_k(A)=\langle v_k,\mathsf P_{H-E_0}(A)v_k\rangle.
\end{equation}
The orthogonality $\langle\psi_0,v_k\rangle=0$ and uniqueness of the
vacuum imply $\nu_k(\{0\})=0$. The spectral theorem and the ground-state
identity prove the exact interacting first moment
\begin{equation}\label{eq:firstmoment}
 \int_{[0,\infty)}\omega\,d\nu_k(\omega)=Q_k=\frac{E_k}{D_k}.
\end{equation}
For every $\epsilon>0$, integrating
$\epsilon\mathbf 1_{[\epsilon,\infty)}(\omega)\leq\omega$ gives
\[
 \nu_k([\epsilon,\infty))\leq Q_k/\epsilon.
\]
This is the exact connection between the computed variation and
low-energy spectral weight. It makes no unproved assertion about
$\widehat C(k)$, a continuum Hamiltonian, an infinite-volume vacuum,
or convergence of the measures $\nu_k$.

\section{Verification and scope}

The companion script \texttt{check\_wilson\_exact.py} uses exact SymPy
arithmetic. On 8 September 2026 it completed with 1,012 exact scalar
assertions, together with exact matrix-entry assertions. It verifies
the basis, Fierz and Casimir constants for $\SU(2)$, $\SU(3)$, $\SU(4)$;
the factor-four metric dictionary; explicit noncommuting $\SU(3)$
positive and negative edge variations and their cross contractions;
real trace energy; a repeated physical edge with opposite signs;
and the one-coordinate product-rule identity underlying
\eqref{eq:groundform}. The proofs above are for all $n\geq2$ and are
not inferred from those finite checks. The script does not compute
$\psi_0$, the interacting covariance matrix, or a continuum spectrum.

All main identities here concern the exact finite interacting
Hamiltonian \eqref{eq:H}. They give explicit trial vectors and their
exact relation to its spectral measure, as well as a positive but
nonuniform finite-volume spectral bound. These proved relations can
be carried into a separate continuum or geometric construction only
through a proved state-space and operator map with controlled limits;
no such map is claimed to be established by the present finite-lattice
calculation.

\begin{thebibliography}{9}
\bibitem{PeterWeyl}
F. Peter and H. Weyl,
\emph{Die Vollst\"andigkeit der primitiven Darstellungen einer
geschlossenen kontinuierlichen Gruppe},
Mathematische Annalen \textbf{97} (1927), 737--755.
\href{https://doi.org/10.1007/BF01447892}{doi:10.1007/BF01447892}.
This is the foundational compact-group completeness theorem used to
identify the complete free spectral resolution.

\bibitem{PolychronakosSfetsos}
A. P. Polychronakos and K. Sfetsos,
\emph{Composing arbitrarily many $SU(N)$ fundamentals},
Nuclear Physics B \textbf{994} (2023), 116314,
\href{https://arxiv.org/abs/2305.19345}{arXiv:2305.19345}.
The row/weight dictionary and dimension/Casimir expressions are given
in Sections 2 and 4, including equation (4.30). Our symbol $n$ is that
paper's $N$; the derivations and all bounds used here retain the
specified anti-Hermitian basis convention.
\end{thebibliography}
\end{document}

```

## Complete source: wilson_variation/temporal_transfer.tex

```latex
\documentclass[11pt]{article}
\usepackage[margin=1in]{geometry}
\usepackage{amsmath,amssymb,amsthm,mathtools}
\usepackage{mathrsfs}
\usepackage[hidelinks]{hyperref}
\newtheorem{theorem}{Theorem}
\newtheorem{lemma}[theorem]{Lemma}
\newtheorem{proposition}[theorem]{Proposition}
\newcommand{\SU}{\operatorname{SU}}
\newcommand{\tr}{\operatorname{tr}}
\newcommand{\Rea}{\operatorname{Re}}
\newcommand{\dd}{\,\mathrm d}
\title{Exact SU(2) Wilson transfer operator and the finite-spatial-lattice time limit}
\author{}
\date{8 September 2026}
\begin{document}
\maketitle

\section{Retained action, coefficients, and conventions}

Fix $a>0$ and $g_{\rm YM}>0$. The spatial regulator is a fixed finite
oriented cubical graph with vertices $\mathsf V$, physical spatial edges
$\mathsf E$, and the full set $\mathsf P_s$ of its geometric spatial
plaquettes, each included once, with $|\mathsf E|\geq1$.
Open spatial boundary conditions or a
fixed periodic spatial lattice are both allowed. Reverse traversal uses
$U_e^{-1}$, not a second independent link. Write $N=|\mathsf E|$ and
\[
 \mathcal Q=\SU(2)^{\mathsf E},\qquad
 \mathcal H=L^2(\mathcal Q,\lambda),\qquad
 d\lambda=\prod_{e\in\mathsf E}dU_e,
\]
with probability Haar on each link. The spatial graph, $a$, and
$g_{\rm YM}$ stay fixed in every limit in this paper.

The original invariant Lie metric and continuum action are
\begin{equation}\label{eq:original-action}
 c(X,Y)=-\frac12\tr(XY),\qquad
 S(\mathscr A)=\frac1{2g_{\rm YM}^2}
 \int\sum_{\mu<\nu}c(F_{\mu\nu},F_{\mu\nu})\,d^4x.
\end{equation}
For time spacing $\epsilon>0$, retain exactly
\begin{equation}\label{eq:anisotropic}
 b_t(\epsilon)=\frac{a}{2g_{\rm YM}^2\epsilon},\qquad
 b_s(\epsilon)=\frac{\epsilon}{2g_{\rm YM}^2a}.
\end{equation}
For the frozen-curvature holonomy $e^{\delta F}$,
$2-\Rea\tr e^{\delta F}=\delta^2c(F,F)+O_F(\delta^4)$ on
$\mathfrak{su}(2)$, by the exponential series, tracelessness and the
paired eigenvalues of $F$. The exact coefficient checks are
\[
 \frac{b_t(a\epsilon)^2}{a^3\epsilon}
 =\frac1{2g_{\rm YM}^2},\qquad
 \frac{b_sa^4}{a^3\epsilon}=\frac1{2g_{\rm YM}^2}.
\]
These equalities record the prescribed classical action convention.
The transfer calculation below uses the full compact plaquette action,
not a curvature truncation, and proves no spatial continuum limit.

Choose $T_1,T_2,T_3\in\mathfrak{su}(2)$ with
$-2\tr(T_aT_b)=\delta_{ab}$, for example $T_a=i\sigma_a/2$ with the
Pauli matrices. Define
\[
 X_{e,a}f(U)=\left.\frac d{dt}\right|_{0}
 f(\ldots,e^{tT_a}U_e,\ldots),\qquad
 \Delta_e^T=\sum_{a=1}^3X_{e,a}^2.
\]
In the original metric, $c(T_a,T_b)=\delta_{ab}/4$, so the
$c$-orthonormal basis is $S_a=2T_a$, and
\begin{equation}\label{eq:metricdictionary}
 X^c_{e,a}=2X_{e,a},\qquad \Delta_e^c=4\Delta_e^T.
\end{equation}
The probability Haar convention changes no operator coefficient. If
$d\operatorname{vol}_c=\mathcal V_c d\lambda$ on this compact product,
$f\mapsto\sqrt{\mathcal V_c}f$ is the exact unitary change from
$L^2(d\operatorname{vol}_c)$ to $L^2(d\lambda)$ and intertwines the same
differential operators.

The original inverse-transport gauge law and the convention used in the
companion Hamiltonian derivation are related at the configuration level by
\begin{equation}\label{eq:gaugedictionary}
 (\beta_hU)_e=h_{s(e)}^{-1}U_eh_{t(e)},\qquad
 (\alpha_gU)_e=g_{s(e)}U_eg_{t(e)}^{-1},\qquad
 \alpha_gU=\beta_hU\ \text{when }g_v=h_v^{-1}\text{ for every }v.
\end{equation}
Inversion preserves Haar, so their vertex gauge averages are the same
operator. No link variable is inverted by this dictionary; only the
parameter describing the same vertex change is replaced by its inverse.

\section{The exact single-link character multiplier}

For $b>0$, let
\begin{equation}\label{eq:kernel}
 Z(b)=\int_{\SU(2)}e^{b\Rea\tr U}dU,\qquad
 k_b(U)=\frac{e^{b\Rea\tr U}}{Z(b)},\qquad
 (\mathcal K_b f)(U')=\int k_b(U'U^{-1})f(U)dU.
\end{equation}
Every $U\in\SU(2)$ has eigenvalues $e^{i\theta},e^{-i\theta}$ with
$0\leq\theta\leq\pi$. Probability Haar integration of a class function is
\[
 \int f(U)dU=\frac2\pi\int_0^\pi f(\theta)\sin^2\theta\,d\theta.
\]
For example, write $U=w_0I+i\sum_{a=1}^3w_a\sigma_a$ on the unit
three-sphere. Slicing at $w_0=\cos\theta$ gives density
$(2/\pi)\sqrt{1-w_0^2}dw_0$, which is the displayed formula.

Define the integer-order modified Bessel functions by their entire series
\begin{equation}\label{eq:Besselseries}
 I_d(2b)=\sum_{r=0}^{\infty}\frac{b^{2r+d}}{r!(r+d)!},
 \qquad d\in\mathbb Z_{\geq0}.
\end{equation}
They also satisfy
\begin{equation}\label{eq:Besselintegral}
 I_d(2b)=\frac1\pi\int_0^\pi e^{2b\cos\theta}\cos(d\theta)\,d\theta.
\end{equation}
To prove this, multiply the uniformly absolutely convergent series for
$e^{bz}$ and $e^{b/z}$ on $|z|=1$. The coefficient of $z^d$ is
\eqref{eq:Besselseries}, and Fourier orthogonality gives
\eqref{eq:Besselintegral}. For $d\geq1$, integration of the derivative
of $e^{2b\cos\theta}\sin(d\theta)$ over $[0,\pi]$ gives
\begin{equation}\label{eq:recurrence}
 I_{d-1}(2b)-I_{d+1}(2b)=\frac db I_d(2b).
\end{equation}
The endpoint term is zero, and
$2\sin\theta\sin(d\theta)=\cos((d-1)\theta)-\cos((d+1)\theta)$
fixes every coefficient in this recurrence.

The spin-$j$ irreducible representation has $j\in\frac12\mathbb Z_{\geq0}$,
dimension $d=2j+1$, and character
\[
 \chi_j(\theta)=\sum_{r=0}^{d-1}e^{i(d-1-2r)\theta}
 =\frac{\sin(d\theta)}{\sin\theta}.
\]
The finite sum is the character of the $(d-1)$st symmetric power of the
defining representation; its equality with the sine quotient is the
finite geometric-series identity, including endpoint values by
continuity. These are all irreducibles of $\SU(2)$, and their matrix
coefficients are complete by Peter--Weyl \cite{PeterWeyl}.

\begin{theorem}\label{thm:multiplier}
The exact normalization and the exact spin-$j$ multiplier of
\eqref{eq:kernel} are
\begin{equation}\label{eq:multiplier}
 Z(b)=\frac{I_1(2b)}b,\qquad
 \mathcal K_bD^j_{rs}=m_j(b)D^j_{rs},\qquad
 m_j(b)=\frac{I_{2j+1}(2b)}{I_1(2b)}.
\end{equation}
For every $j$ and $b>0$, $0<m_j(b)\leq1$, and $m_0(b)=1$.
The operator $\mathcal K_b$ is a positive self-adjoint contraction,
is injective, and is trace class.
\end{theorem}
\begin{proof}
The exact unnormalized character integral is
\begin{align*}
 \int e^{b\Rea\tr U}\chi_j(U)dU
 &=\frac2\pi\int_0^\pi e^{2b\cos\theta}
                      \sin\theta\sin(d\theta)d\theta\\
 &=I_{d-1}(2b)-I_{d+1}(2b)=\frac dbI_d(2b).
\end{align*}
Set $d=1$ to obtain $Z(b)$. Since $k_b$ is central, the matrix
$\int k_b(W)D^j(W^{-1})dW$ commutes with the representation and hence
is scalar. Its trace divided by $d$ is
$(dZ(b))^{-1}\int e^{b\Rea\tr W}\chi_j(W)dW=I_d/I_1$.
The substitution $U=W^{-1}U'$ in \eqref{eq:kernel} proves the asserted
matrix-coefficient eigenvalue. In particular the dimension factor in
the character integral is exactly canceled by division by $d$; no
dimension factor remains in the multiplier.

All terms in \eqref{eq:Besselseries} are positive for $b>0$, which
proves $m_j>0$. The integral expression for the normalized multiplier
and $|\chi_j(U)|\leq d$ prove $|m_j|\leq1$. The matrix coefficients
form an orthogonal complete basis, so these real positive eigenvalues
prove positivity, self-adjointness, contraction, and injectivity.
For fixed $b$, \eqref{eq:Besselseries} gives
$I_d(2b)\leq b^de^{b^2}/d!$, since $(r+d)!\geq d!$.
Thus
\[
 \tr\mathcal K_b=\sum_{d=1}^{\infty}d^2\frac{I_d(2b)}{I_1(2b)}<\infty,
\]
where the multiplicity is exactly $d^2$. The factorial majorant proves
the convergence and hence trace-classness.
\end{proof}

\section{Controlled small-time derivative of the full compact kernel}

\begin{lemma}\label{lem:asymptotic}
For each fixed spin $j$,
\begin{equation}\label{eq:large-b}
 m_j(b)=1-\frac{j(j+1)}b+O_j(b^{-2})\qquad(b\longrightarrow\infty).
\end{equation}
The estimate is proved from the exact compact integral and does not
replace that integral by a different finite-$b$ kernel.
\end{lemma}
\begin{proof}
Set $y=1-\cos\theta\in[0,2]$. Under the probability density $k_b dU$,
the density of $y$ is proportional to
$e^{-2by}y^{1/2}(2-y)^{1/2}dy$. Write
\[
 J_q(b)=\int_0^2e^{-2by}y^{q+1/2}(2-y)^{1/2}dy,
 \qquad q=0,1,2.
\]
On $[0,1]$, Taylor's theorem with a bounded second derivative gives
$\sqrt{2-y}=\sqrt2(1-y/4)+R(y)$, with $|R(y)|\leq C y^2$.
The part on $[1,2]$ is bounded by a constant times $e^{-2b}$.
The tails when extending the two leading integrals to $[0,\infty)$
have the same exponentially small order times a polynomial in $b$.
Finally, the error integral over $[0,1]$ is bounded by
$C\int_0^\infty e^{-2by}y^{q+5/2}dy$.
Using the exact substitution $z=2by$ in these gamma integrals gives
\begin{equation}\label{eq:J-expansion}
 J_q(b)=\frac{\sqrt2\,\Gamma(q+3/2)}{(2b)^{q+3/2}}
 \left[1-\frac{q+3/2}{8b}+O_q(b^{-2})\right].
\end{equation}
Every error assertion follows from the displayed remainder bound and
the exponentially small tail; none extends a finite-$b$ probability
measure by declaration. Since $J_0>0$, division gives
\[
 \mathbb E_b[y]=\frac{J_1}{J_0}=\frac3{4b}+O(b^{-2}),\qquad
 \mathbb E_b[y^2]=\frac{J_2}{J_0}=\frac{15}{16b^2}+O(b^{-3}).
\]
The character $\chi_j$ is the polynomial $U_{d-1}(\cos\theta)$, where
$U_0(x)=1$, $U_1(x)=2x$, and
$U_{r+1}(x)=2xU_r(x)-U_{r-1}(x)$. Induction at $x=1$ gives
\[
 U_{d-1}(1)=d,\qquad U'_{d-1}(1)=\frac{d(d^2-1)}3.
\]
For the derivative formula, differentiate the recurrence; the induction
step is
$U'_{r+1}(1)=2(r+1)+2U'_r(1)-U'_{r-1}(1)$, which the displayed
cubic expression satisfies with its initial values. Polynomial Taylor
expansion on the whole compact interval $y\in[0,2]$ therefore yields
\[
 \frac{\chi_j(\theta)}d
 =1-\frac{d^2-1}{3}y+R_j(y),\qquad |R_j(y)|\leq C_jy^2.
\]
Its exact $\mathbb E_b$ average is $m_j(b)$. Substitute the two moment
estimates and use $(d^2-1)/4=j(j+1)$ to prove \eqref{eq:large-b}.
\end{proof}

Substitution of the retained $b_t$ gives the exact infinitesimal
coefficient
\begin{equation}\label{eq:epsilonmultiplier}
 m_j(b_t(\epsilon))
 =1-\epsilon\frac{2g_{\rm YM}^2}{a}j(j+1)+O_j(\epsilon^2).
\end{equation}
For the chosen basis, $-\Delta^T$ has eigenvalue $j(j+1)$ on spin $j$.
Indeed take the displayed Pauli basis and put $J_a=-i\,dD^j(T_a)$.
Its anti-Hermitian generators satisfy $[T_a,T_b]=-\varepsilon_{abc}T_c$,
so the Hermitian generators satisfy $[J_a,J_b]=i\varepsilon_{abc}J_c$.
Let $J_\pm=J_1\pm iJ_2$. Directly from these commutators,
$[J_3,J_\pm]=\pm J_\pm$ and
$\sum_aJ_a^2=J_-J_++J_3^2+J_3$. On the highest vector
$e_1^{\otimes 2j}$ of the symmetric power, $J_3$ has eigenvalue $j$
and $J_+$ is zero, so the sum of squares has value $j(j+1)$.
Expanding its commutator with each $J_a$ shows it commutes with all
three; irreducibility therefore extends this value to the whole
representation. An orthogonal change to any other specified
orthonormal $T$ basis leaves the sum of squares unchanged.
For $j=1/2$, it is explicitly
$-\sum_aT_a^2=3I/4$, fixing the absolute scale. Thus
\eqref{eq:epsilonmultiplier} has precisely the $\Delta^T$ convention,
and \eqref{eq:metricdictionary} supplies the other metric.

On the full finite edge product define
\begin{equation}\label{eq:freeproduct}
 (K_\epsilon f)(U')=
 \int_{\mathcal Q}\prod_{e\in\mathsf E}
 k_{b_t(\epsilon)}(U'_eU_e^{-1})f(U)d\lambda(U),
 \qquad
 H_0=-\frac{2g_{\rm YM}^2}{a}\sum_e\Delta_e^T.
\end{equation}
A product matrix coefficient with spins $\boldsymbol j=(j_e)$ has
$K_\epsilon$ eigenvalue $\prod_em_{j_e}(b_t(\epsilon))$ and
$H_0$ eigenvalue $(2g_{\rm YM}^2/a)\sum_ej_e(j_e+1)$.
For every finite linear combination $f$ of such coefficients,
\begin{equation}\label{eq:corederivative}
 \lim_{\epsilon\downarrow0}\frac{K_\epsilon f-f}{\epsilon}=-H_0f.
\end{equation}
This follows by the finite product expansion of
\eqref{eq:epsilonmultiplier}, not by an assertion uniform over arbitrary
spins. Contraction and density then imply $K_\epsilon f\to f$ for every
$f\in\mathcal H$: approximate $f$ by a fixed finite combination and
bound the two approximation errors by its distance from $f$.

\section{Exact magnetic factor and temporal-link Gauss integration}

For the ordered spatial plaquette holonomy $U_p$, set
\begin{equation}\label{eq:magnetic}
 V(U)=\frac1{2g_{\rm YM}^2a}
        \sum_{p\in\mathsf P_s}(2-\Rea\tr U_p),\qquad
 M_\epsilon f(U)=e^{-\epsilon V(U)/2}f(U).
\end{equation}
Every magnetic plaquette is present in this sum. It is a bounded
nonnegative real smooth multiplication operator, with
$0\leq V\leq2|\mathsf P_s|/(g_{\rm YM}^2a)$.
In particular $\epsilon V=b_s\sum_p(2-\Rea\tr U_p)$ exactly.

Define the vertex gauge average
\begin{equation}\label{eq:Gauss}
 (P_Gf)(U)=\int_{\SU(2)^{\mathsf V}}f(\alpha_gU)\prod_vdg_v.
\end{equation}
Every pullback in the integrand is unitary. Haar inversion proves
$P_G^*=P_G$, Haar invariance in two successive integrals proves
$P_G^2=P_G$, and another left translation of the integration variable
shows that the range consists exactly of the invariant functions.
Thus $P_G$ is the orthogonal projection onto
$\mathcal H_{\rm inv}$. Equation \eqref{eq:gaugedictionary} proves that
it is also the original-$h$ Gauss average. Gauge invariance of spatial
Wilson traces proves $M_\epsilon P_G=P_GM_\epsilon$.
The identity
\[
 (\alpha_gU')_e(\alpha_gU)_e^{-1}
 =g_{s(e)}U'_eU_e^{-1}g_{s(e)}^{-1}
\]
and centrality of $k_b$ prove that $K_\epsilon$ commutes with $P_G$.

To compute the temporal integral, write $U$ and $U'$ for two adjacent
spatial slices and $q_v$ for the temporal link at vertex $v$ from the
first slice to the second. In the original inverse-transport convention,
the oriented temporal plaquette associated to edge $e:s\to t$ is
\begin{equation}\label{eq:temporalplaquette}
 P_e(U',q,U)=U_eq_t(U'_e)^{-1}q_s^{-1}.
\end{equation}
Its inverse is $q_sU'_eq_t^{-1}U_e^{-1}$, and $\Rea\tr A^{-1}=
\Rea\tr A$ for a unitary matrix. Hence
\begin{equation}\label{eq:temporal-conjugacy}
 \Rea\tr P_e=\Rea\tr[(\alpha_qU')_eU_e^{-1}].
\end{equation}
This equality includes every temporal vertex variable; it makes no
global temporal gauge-fixing assumption. Under independent original
vertex changes $h^{(0)}$ and $h^{(1)}$ on the two slices,
\[
 U_e\mapsto(h_s^{(0)})^{-1}U_eh_t^{(0)},\quad
 U'_e\mapsto(h_s^{(1)})^{-1}U'_eh_t^{(1)},\quad
 q_v\mapsto(h_v^{(0)})^{-1}q_vh_v^{(1)}.
\]
Multiplication in \eqref{eq:temporalplaquette} cancels the intermediate
factors and gives $P_e\mapsto(h_s^{(0)})^{-1}P_eh_s^{(0)}$.
This verifies directly its original gauge law.

Define the raw two-slice Wilson kernel, with symmetric magnetic endpoint
weights, by
\begin{equation}\label{eq:rawkernel}
 \mathcal T_\epsilon^{\rm raw}(U',U)
 =e^{-\epsilon V(U')/2}e^{-\epsilon V(U)/2}
 \int\exp\!\left[-b_t\sum_e(2-\Rea\tr P_e(U',q,U))\right]\prod_vdq_v.
\end{equation}
The integral is over the whole non-Abelian group at every temporal
vertex. With
\begin{equation}\label{eq:scalar}
 c_\epsilon=[e^{-2b_t}Z(b_t)]^N,\qquad
 F_\epsilon=M_\epsilon K_\epsilon M_\epsilon,
\end{equation}
equations \eqref{eq:kernel} and \eqref{eq:temporal-conjugacy} give the
exact operator identity
\begin{equation}\label{eq:fulltransfer}
 \mathcal T_\epsilon^{\rm raw}
 =c_\epsilon M_\epsilon P_GK_\epsilon M_\epsilon
 =c_\epsilon F_\epsilon P_G
 =c_\epsilon P_GF_\epsilon.
\end{equation}
In particular the normalized transfer is $F_\epsilon$ on
$\mathcal H_{\rm inv}$ and $F_\epsilon P_G$ on $\mathcal H$.
The operator $F_\epsilon$ is positive, self-adjoint, injective and a
contraction because $K_\epsilon$ has those properties and
$M_\epsilon$ is positive, bounded, and invertible. Injectivity follows
from
$\langle f,F_\epsilon f\rangle=
\langle M_\epsilon f,K_\epsilon M_\epsilon f\rangle$ and the strictly
positive eigenvalues of $K_\epsilon$. All these statements remain
valid after restriction to the invariant subspace.

For several adjacent slices, the two half magnetic factors at each
interior slice multiply to $e^{-\epsilon V}$. On an open time interval
the two boundary slices carry half weights; on a periodic time lattice
all slices have their full weight. Fubini's theorem therefore identifies
the exact product of \eqref{eq:rawkernel} with the full anisotropic
Wilson integral, retaining all temporal and spatial plaquettes. In the
periodic case with $m$ time steps the exact partition identity is
\begin{equation}\label{eq:partition}
 Z_{\rm Wilson}^{(m)}
 =c_\epsilon^m\tr_{\mathcal H}(F_\epsilon^mP_G)
 =c_\epsilon^m\tr_{\mathcal H_{\rm inv}}(F_\epsilon^m).
\end{equation}
The traces are well defined: the proof of Theorem \ref{thm:multiplier}
gives a trace-class single-link operator, a finite tensor product is
trace class, and multiplication by bounded operators and $P_G$ preserves
that property. The integral and trace equality can also be checked by
successively integrating its positive continuous compact kernels.
Equation \eqref{eq:partition} is an exact finite-$\epsilon$ identity;
the strong convergence below alone is not used to assert trace-norm
convergence of these partition functions.

The Wilson constant and the normalization are explicitly retained as the
common energy shift
\begin{equation}\label{eq:shift}
 E_{\rm scalar}(\epsilon)
 =-\frac1\epsilon\log c_\epsilon
 =\frac N\epsilon\bigl[2b_t-\log Z(b_t)\bigr].
\end{equation}
In particular $0<c_\epsilon<1$, because
$e^{-2b}Z(b)=\int e^{-b(2-\Rea\tr U)}dU$ is a strictly positive average
of a function at most one and strictly below one on a set of positive
Haar measure. From the proved $J_0$ expansion,
\[
 e^{-2b}Z(b)=\frac1{2\sqrt\pi\,b^{3/2}}
             \left[1-\frac3{16b}+O(b^{-2})\right].
\]
Thus the shift is not finite as $\epsilon\downarrow0$; it is a known
scalar that affects all energies equally. The exact relation
\eqref{eq:fulltransfer}, rather than an unrecorded removal of constants,
specifies which operator has the finite time limit.

\section{The actual core and the strong time-continuum limit}

Let $\mathscr D$ be the finite linear span of product matrix coefficients
of all edge representations, and let $\mathscr D_{\rm inv}=P_G\mathscr D$.
Peter--Weyl completeness makes $\mathscr D$ dense in $\mathcal H$ and
$\mathscr D_{\rm inv}$ dense in $\mathcal H_{\rm inv}$. The gauge action
mixes only matrix coefficients with the same finite list of edge spins,
so $P_G\mathscr D\subset\mathscr D$. The diagonal positive operator $H_0$
in \eqref{eq:freeproduct} is self-adjoint on
\[
 D(H_0)=\left\{f:\sum_{\boldsymbol j,\boldsymbol r,\boldsymbol s}
 \left(\frac{2g_{\rm YM}^2}{a}\sum_ej_e(j_e+1)\right)^2
 |f_{\boldsymbol j,\boldsymbol r,\boldsymbol s}|^2<\infty\right\},
\]
where coefficients use an orthonormal matrix-coefficient basis.
Finite spectral truncation proves that $\mathscr D$ is an operator core:
both $f$ and $H_0f$ are approximated by the same finite sums. The
projection $P_G$ commutes with $H_0$, so applying it to these graph-norm
approximations proves the invariant core assertion as well.

Since $V$ in \eqref{eq:magnetic} is bounded and real, the operator
\begin{equation}\label{eq:resultH}
 H=H_0+V
 =-\frac{2g_{\rm YM}^2}{a}\sum_e\Delta_e^T
 +\frac1{2g_{\rm YM}^2a}\sum_{p\in\mathsf P_s}(2-\Rea\tr U_p)
\end{equation}
is self-adjoint and nonnegative on $D(H_0)$. Bounded perturbation does
not change the core, since the graph norms of $H_0$ and $H_0+V$ are
equivalent by the two inequalities
$\|Hf\|\leq\|H_0f\|+\|V\|\|f\|$ and its converse. All gauge
invariance statements persist. The original-metric expression is exactly
\begin{equation}\label{eq:resultHc}
 H=-\frac{g_{\rm YM}^2}{2a}\sum_e\Delta_e^c
 +\frac1{2g_{\rm YM}^2a}\sum_{p\in\mathsf P_s}(2-\Rea\tr U_p).
\end{equation}
No conventional redefinition of $g_{\rm YM}$ was used to obtain either
expression.

For $f\in\mathscr D$, use the exact algebraic decomposition
\[
 (F_\epsilon-I)f=(M_\epsilon-I)f
    +M_\epsilon(K_\epsilon-I)f
    +M_\epsilon K_\epsilon(M_\epsilon-I)f.
\]
Boundedness of $V$ gives
$(M_\epsilon-I)/\epsilon\to-V/2$ in operator norm. Equation
\eqref{eq:corederivative}, the strong convergence $K_\epsilon\to I$,
and the contraction bounds therefore prove
\begin{equation}\label{eq:Fderivative}
 \frac{F_\epsilon f-f}{\epsilon}\longrightarrow-Hf
 \quad\text{for every }f\in\mathscr D,
\end{equation}
and in particular for every $f\in\mathscr D_{\rm inv}$. The magnetic
operator need not commute with the kinetic operator for this argument.

\begin{theorem}\label{thm:stronglimit}
For every fixed $t>0$ and every $f\in\mathcal H$,
\begin{equation}\label{eq:stronglimit}
 F_{t/m}^{\,m}f\longrightarrow e^{-tH}f
 \qquad(m\longrightarrow\infty).
\end{equation}
Consequently the exact normalized Wilson transfer obeys
\begin{equation}\label{eq:projectedlimit}
 \left(c_{t/m}^{-1}\mathcal T_{t/m}^{\rm raw}\right)^mf
 =F_{t/m}^{\,m}P_Gf\longrightarrow e^{-tH}P_Gf.
\end{equation}
On $\mathcal H_{\rm inv}$ the limit is the strongly continuous
semigroup $e^{-tH}$, with generator \eqref{eq:resultH} or equivalently
\eqref{eq:resultHc}. At $t=0$ its identity is $I$ on that subspace;
on the unrestricted space the projected family has value $P_G$.
\end{theorem}
\begin{proof}
We give the positive-contraction specialization of the product-formula
argument directly; the general framework is Chernoff's theorem
\cite{Chernoff}. Put
$A_\epsilon=(I-F_\epsilon)/\epsilon$. It is bounded, self-adjoint and
nonnegative, and \eqref{eq:Fderivative} gives
$A_\epsilon f\to Hf$ on the operator core $\mathscr D$.
For any $\lambda_0>0$ and $f\in\mathscr D$,
\begin{equation}\label{eq:resolventidentity}
 (\lambda_0+A_\epsilon)^{-1}(\lambda_0+H)f-f
 =(\lambda_0+A_\epsilon)^{-1}(H-A_\epsilon)f\longrightarrow0.
\end{equation}
The resolvents have norms at most $1/\lambda_0$. Moreover
$(\lambda_0+H)\mathscr D$ is dense: for arbitrary $u$, apply a
graph-norm approximation from $\mathscr D$ to
$f=(\lambda_0+H)^{-1}u$. Thus the uniform bound extends
\eqref{eq:resolventidentity} to all vectors and proves
$(\lambda_0+A_\epsilon)^{-1}\to(\lambda_0+H)^{-1}$ strongly.

For completeness this implies $e^{-tA_\epsilon}\to e^{-tH}$ strongly
for each fixed $t>0$ without any estimate of an unknown spectrum.
Set $R_\epsilon=(\lambda_0+A_\epsilon)^{-1}$ and
$R=(\lambda_0+H)^{-1}$. On $[0,1/\lambda_0]$ define the continuous
function
\[
 h_t(y)=\begin{cases}\exp[-t(y^{-1}-\lambda_0)],&y>0,\\0,&y=0.
 \end{cases}
\]
Uniform polynomial approximation on this interval and strong convergence
of every polynomial in the uniformly bounded $R_\epsilon$ prove
$h_t(R_\epsilon)\to h_t(R)$ strongly. The spectral calculus identifies
these two operators with the desired semigroups.

It remains to compare powers with this exponential. For integer $m\geq1$
and $0\leq x\leq1$,
\begin{equation}\label{eq:scalarpower}
 0\leq e^{-mx}-(1-x)^m\leq\frac1m.
\end{equation}
For $x\leq1/2$, the integral identity
$-\log(1-x)-x=\int_0^x u/(1-u)du\leq x^2$ gives
\[
 e^{-mx}-(1-x)^m
 \leq mx^2e^{-mx}\leq\frac4{e^2m}<\frac1m.
\]
For $x\geq1/2$ the difference is at most $e^{-m/2}\leq2/(em)<1/m$;
the last inequality follows by maximizing $s e^{-s/2}$ for $s>0$.
The endpoint $x=1$ also satisfies the bound. Spectral calculus with
$x=I-F_\epsilon=\epsilon A_\epsilon$ now yields
\[
 \|F_\epsilon^m-e^{-m\epsilon A_\epsilon}\|\leq1/m.
\]
Take $\epsilon=t/m$ and combine with the established strong convergence
of $e^{-tA_{t/m}}$. This proves \eqref{eq:stronglimit}.
Finally \eqref{eq:fulltransfer}, $P_G^2=P_G$, and commutation with
$F_\epsilon$ prove \eqref{eq:projectedlimit}. The same reasoning
applies directly on the verified invariant core.
\end{proof}

\section{Effective Hamiltonians and the exact finite-vacuum bridge}

On $\mathcal H_{\rm inv}$, positivity and injectivity allow the
self-adjoint functional-calculus definition
\begin{equation}\label{eq:effectiveH}
 H_\epsilon=-\epsilon^{-1}\log(F_\epsilon|_{\mathcal H_{\rm inv}}),
 \qquad
 H_\epsilon^{\rm raw}=E_{\rm scalar}(\epsilon)I+H_\epsilon.
\end{equation}
Zero is not an eigenvalue of $F_\epsilon$, so the logarithm is densely
defined even though zero is a spectral accumulation point. The operator
$H_\epsilon$ is nonnegative. Equation \eqref{eq:effectiveH} is the exact
scalar-energy dictionary, and the raw and normalized effective operators
have identical energy differences and eigenvectors at each $\epsilon$.

They satisfy $H_\epsilon\to H|_{\mathcal H_{\rm inv}}$ in the strong
resolvent sense. Here is a direct consequence of the proof already given,
which also covers arbitrary $\epsilon\downarrow0$ rather than only
$t/m$. Fix $t>0$ and set $m_\epsilon=\lfloor t/\epsilon\rfloor$ and
$t_\epsilon=m_\epsilon\epsilon$. The power comparison gives
$\|F_\epsilon^{m_\epsilon}-e^{-t_\epsilon A_\epsilon}\|
\leq1/m_\epsilon$. For $t_\epsilon\geq t/2$, the scalar mean-value
bound yields
\[
 \sup_{x\geq0}|e^{-t_\epsilon x}-e^{-tx}|
 \leq|t-t_\epsilon|\sup_{x\geq0}xe^{-(t/2)x}
 \leq\frac{2\epsilon}{et}\longrightarrow0.
\]
Thus $F_\epsilon^{m_\epsilon}\to e^{-tH}$ strongly. If
$t/\epsilon=m_\epsilon+\delta$ with $0\leq\delta<1$, then for
$0\leq z\leq1$,
\[
 0\leq z^{m_\epsilon}-z^{m_\epsilon+\delta}
 \leq z^{m_\epsilon}(1-z)
 \leq\frac1{m_\epsilon+1}.
\]
The middle inequality uses $z^\delta\geq z$, and the last follows by
maximizing $z^m(1-z)$. Applying spectral calculus gives
$e^{-tH_\epsilon}=F_\epsilon^{t/\epsilon}\to e^{-tH}$ strongly.
For any $\lambda_0>0$ the resolvent identity
\[
 (\lambda_0+H_\epsilon)^{-1}f
 =\int_0^\infty e^{-\lambda_0t}e^{-tH_\epsilon}f\,dt
\]
and the uniform contraction bound permit dominated convergence in norm,
proving the asserted strong resolvent convergence.

The resulting Hamiltonian is precisely the finite interacting one in
the companion derivation, with the explicit substitution
\begin{equation}\label{eq:companiondictionary}
 n=2,\qquad \kappa_e=\frac{2g_{\rm YM}^2}{a},\qquad
 b_p^{\rm Hamiltonian}=\frac1{2g_{\rm YM}^2a}
                       =\frac{b_s(\epsilon)}\epsilon.
\end{equation}
All magnetic interactions survive this limit. This yields a concrete
state-space and operator map from the finite anisotropic Wilson integral
to the vacuum-weighted finite-lattice identities; it does not identify
the interacting vacuum with Haar measure.

For example, let $\psi_0>0$ be the normalized exact ground state of
\eqref{eq:resultH}, $E_0$ its eigenvalue, and $d\mu=\psi_0^2d\lambda$.
The finite compact elliptic Hamiltonian has this unique ground state
by the positivity and compact-resolvent argument in the companion
paper. For any nonzero smooth gauge-invariant $F$ with $\mu(F)=0$, put
$u=\psi_0F$ and $D=\|u\|^2>0$. The exact ground-state product rule gives
\begin{equation}\label{eq:vacuumform}
 \langle u,(H-E_0)u\rangle
 =\frac{2g_{\rm YM}^2}{a}\sum_{e,a}\int|X_{e,a}F|^2d\mu.
\end{equation}
To see the cancellation, expand
$X^2(\psi_0F)=\psi_0X^2F+2(X\psi_0)XF+F X^2\psi_0$,
subtract $F(H-E_0)\psi_0=0$, and integrate each Haar-skew derivative
by parts. The remaining integral is exactly \eqref{eq:vacuumform}.
Thus no component of $V$ was omitted in passing to that form.

The strong transfer limit proves the concrete correlation identity
\begin{equation}\label{eq:correlation}
 \lim_{m\to\infty}
 \frac{\langle u,F_{t/m}^{\,m}u\rangle}
      {\langle\psi_0,F_{t/m}^{\,m}\psi_0\rangle}
 =\langle u,e^{-t(H-E_0)}u\rangle
 =D\int_{[0,\infty)}e^{-t\omega}d\nu_F(\omega),
\end{equation}
where $\nu_F(A)=D^{-1}\langle u,\mathbf1_A(H-E_0)u\rangle$.
The denominator converges to $e^{-tE_0}>0$. The raw scalar
$c_{t/m}^m$ cancels exactly if both numerator and denominator are
written using the raw transfer. The state $\psi_0$ in
\eqref{eq:correlation} is the actual limiting finite-lattice vacuum,
not a constant trial state. The spectral theorem and
\eqref{eq:vacuumform} give its first moment
\[
 \int\omega\,d\nu_F(\omega)
 =\frac{(2g_{\rm YM}^2/a)\sum_{e,a}\mu(|X_{e,a}F|^2)}{\mu(|F|^2)}.
\]
These are fixed-spatial-regulator statements. Strong time convergence
alone does not supply a spatial continuum vacuum, a limiting spectral
gap, or a gapless interacting four-dimensional quantum theory.

\section{Exact checks and provenance}

The companion script \texttt{check\_temporal\_coefficients.py} completed
237 exact scalar assertions plus exact matrix-entry checks. It verifies
the two anisotropic action coefficients, Bessel recurrence coefficients
through bounded formal orders, the character derivatives for dimensions
1 through 9, the resulting spin coefficients, the SU(2) metric and
Casimir constants, a noncommuting temporal-plaquette example and its
original gauge law, the $g=h^{-1}$ dictionary, and the magnetic endpoint
weights. The all-spin and operator convergence proofs are the analytic
arguments above; they are not inferred from finitely many checked spins.
No numerical integration, spatial continuum calculation, or approximate
vacuum was used.

\begin{thebibliography}{9}
\bibitem{PeterWeyl}
F. Peter and H. Weyl, \emph{Die Vollst\"andigkeit der primitiven
Darstellungen einer geschlossenen kontinuierlichen Gruppe},
Mathematische Annalen \textbf{97} (1927), 737--755,
\href{https://doi.org/10.1007/BF01447892}{doi:10.1007/BF01447892}.

\bibitem{Chernoff}
P. R. Chernoff, \emph{Note on product formulas for operator semigroups},
Journal of Functional Analysis \textbf{2} (1968), 238--242,
\href{https://doi.org/10.1016/0022-1236(68)90020-7}
{doi:10.1016/0022-1236(68)90020-7}.
The positive self-adjoint contraction specialization needed here is
proved directly in Theorem \ref{thm:stronglimit}.
\end{thebibliography}
\end{document}

```

## Complete source: wilson_variation/spatial_vacuum_elimination.tex

```latex
\documentclass[11pt]{article}
\usepackage[margin=1in]{geometry}
\usepackage{amsmath,amssymb,amsthm,mathtools,mathrsfs}
\usepackage[hidelinks]{hyperref}
\newtheorem{theorem}{Theorem}
\newtheorem{lemma}[theorem]{Lemma}
\newtheorem{proposition}[theorem]{Proposition}
\newtheorem{corollary}[theorem]{Corollary}
\newcommand{\SU}{\operatorname{SU}}
\newcommand{\tr}{\operatorname{tr}}
\newcommand{\Rea}{\operatorname{Re}}
\newcommand{\Var}{\operatorname{Var}}
\newcommand{\dd}{\,\mathrm d}
\title{Exact spatial elimination in the true lattice vacuum:\\marginals, temporal memory, and excitation estimates}
\author{}
\date{8 September 2026}
\begin{document}
\maketitle

\section{The finite interacting Hamiltonian and its actual vacuum}

Let $n\geq2$. Fix a finite lattice with physical oriented links
$\mathsf E$, all its retained oriented plaquette words $\mathsf P$, and
positive coefficients $\kappa_e,b_p$. Reverse traversal uses $U_e^{-1}$.
Take precisely
\begin{equation}\label{eq:H}
 H=-\sum_{e\in\mathsf E}\kappa_e\sum_{a=1}^{n^2-1}X_{e,a}^2
       +\sum_{p\in\mathsf P}b_p(n-\Rea\tr U_p),\qquad
 X_{e,a}f=\left.\frac d{dt}\right|_0f(\ldots,e^{tT_a}U_e,\ldots),
\end{equation}
where $T_a$ is anti-Hermitian, traceless, and
$-2\tr(T_aT_b)=\delta_{ab}$. Its Hilbert space is the probability-Haar
space $L^2(\mathcal Q,\lambda)$ on $\mathcal Q=\SU(n)^{\mathsf E}$.
Every potential term in \eqref{eq:H} is retained. The original metric
$c(X,Y)=-\tfrac12\tr(XY)$ has orthonormal basis $2T_a$ and
$\Delta_e^c=4\sum_aX_{e,a}^2$. Hence the same kinetic operator is
$-\sum_e(\kappa_e/4)\Delta_e^c$.

Let $\psi_0$ be the actual positive normalized ground state,
$H\psi_0=E_0\psi_0$ and $\int\psi_0^2d\lambda=1$. Existence,
smoothness, strict positivity, uniqueness, and gauge invariance hold
for this finite compact elliptic Schr\"odinger operator; they are proved
for \eqref{eq:H} in \texttt{wilson\_finite\_lattice.tex}. Set
\[
 \rho=\psi_0^2,\quad d\mu=\rho d\lambda,\quad
 \mathbb H=L^2(\mathcal Q,\mu),\quad \mathcal Uu=\psi_0u.
\]
The map $\mathcal U:\mathbb H\to L^2(\lambda)$ is unitary, and the
exact ground-state transform is
\begin{align}
 L&=\mathcal U^{-1}(H-E_0)\mathcal U
   =-\rho^{-1}\sum_{e,a}\kappa_eX_{e,a}(\rho X_{e,a}),\label{eq:L}\\
 q(u,v)&=\langle L^{1/2}u,L^{1/2}v\rangle_\mu
   =\sum_{e,a}\kappa_e\int\overline{X_{e,a}u}X_{e,a}v\,d\mu.
   \label{eq:fullform}
\end{align}
Indeed the product rule in $H(\psi_0u)-uH\psi_0$ gives the displayed
divergence operator, and Haar integration by parts gives the form.
These steps use the eigenvalue equation for the full potential.

All inner products below are conjugate-linear in the first argument.
The form domain $\mathcal V$ of $q$ is $H^1(\mathcal Q)$: the fields
span the tangent spaces and the positive smooth $\rho$ is bounded
above and below on the compact product. Its form norm is
$\|u\|_\mathcal V^2=q(u,u)+\|u\|_\mu^2$. Smooth functions are a form
core, and the smooth weighted elliptic operator has domain $H^2$ and
smooth operator core. The compact Sobolev embedding gives compact
resolvent. If $q(u,u)=0$, every derivative is zero and connectedness
gives a constant function. Consequently the kernel is exactly
$\mathbb C1$ and the first nonzero eigenvalue $\delta$ is positive.
These are finite-regulator assertions; $\delta$ is not assumed to have
a positive bound uniform in a spatial continuum limit.

\section{The true marginal, conditional projection, and retained form}

Split the physical links into two disjoint nonempty sets
$\mathsf E=\mathsf S\sqcup\mathsf R$. There is no independence
assumption and no restriction on shared plaquettes in the operator
calculation. Write
\[
 \mathcal Q=\mathcal Q_S\times\mathcal Q_R,\quad U=(s,r),\quad
 d\lambda=d\lambda_Sd\lambda_R,
\]
and define
\begin{equation}\label{eq:marginal}
 \rho_R(r)=\int_{\mathcal Q_S}\rho(s,r)d\lambda_S(s),\qquad
 d\mu_R=\rho_Rd\lambda_R,\qquad
 p(s\mid r)=\frac{\rho(s,r)}{\rho_R(r)}.
\end{equation}
Differentiation under a compact integral proves that $\rho_R$ is smooth.
Its positivity follows from $\rho>0$, and
$\int\rho_Rd\lambda_R=1$ by Fubini. The density $p$ is also smooth
and positive and integrates to one for each $r$.

Let $\mathbb K=L^2(\mathcal Q_R,\mu_R)$ and define
\begin{equation}\label{eq:conditional}
 (Jf)(s,r)=f(r),\qquad
 (J^*u)(r)=\int p(s\mid r)u(s,r)d\lambda_S(s),\qquad
 P=JJ^*,\quad Q=I-P.
\end{equation}
Fubini proves $\|Jf\|_\mu=\|f\|_{\mu_R}$ and
$\langle Jf,u\rangle_\mu=\langle f,J^*u\rangle_{\mu_R}$.
Jensen's inequality proves $\|J^*u\|\leq\|u\|$. Therefore $P$ is
the orthogonal projection onto functions of the retained links, and
\[
 \mathbb H=J\mathbb K\oplus\mathbb H_Q,\qquad
 \mathbb H_Q=\ker J^*=Q\mathbb H.
\]
In particular every $h\in\mathbb H_Q$ is orthogonal to $1=J1$.

For a retained index $i=(e,a)$ with $e\in\mathsf R$, write $X_i=X_{e,a}$
and $\kappa_i=\kappa_e$. These fields act on $r$ and leave $s$ fixed.
Define the real conditional score
\begin{equation}\label{eq:score}
 \ell_i=X_i\log\rho,\qquad
 \bar\ell_i=X_i\log\rho_R,\qquad
 \sigma_i=\ell_i-J\bar\ell_i=X_i\log p(s\mid r).
\end{equation}
Compactness makes every $\sigma_i$ and its derivatives bounded.
Differentiation of \eqref{eq:marginal} gives
$J^*\ell_i=\bar\ell_i$, so $J^*\sigma_i=0$.

\begin{lemma}\label{lem:projection-domain}
Conditional expectation satisfies the exact derivative identity
\begin{equation}\label{eq:conditional-derivative}
 X_iJ^*u=J^*(X_i u)+J^*(\sigma_i u)
\end{equation}
for smooth $u$. It extends boundedly from $\mathcal V$ to
$\mathcal V_R:=H^1(\mathcal Q_R)$, with
\begin{equation}\label{eq:projection-bound}
 a(J^*u,J^*u)\leq2q(u,u)+2\eta\|u\|_\mu^2,
 \quad
 \eta=\sum_{i\in R}\kappa_i\|\sigma_i\|_\infty^2,
\end{equation}
where
\begin{equation}\label{eq:reducedform}
 a(f,g)=\sum_{i\in R}\kappa_i\int\overline{X_if}X_ig\,d\mu_R.
\end{equation}
Both $P$ and $Q$ preserve the full form domain and are bounded for its
norm. The lift $J$ identifies $\mathcal V_R$ with
$\mathcal V\cap J\mathbb K$.
\end{lemma}
\begin{proof}
Differentiate $J^*u=\int p u\,d\lambda_S$ and use $X_ip=p\sigma_i$.
Conditional Cauchy--Schwarz and Fubini give
$\|J^*X_iu\|_{\mu_R}\leq\|X_iu\|_\mu$ and
$\|J^*(\sigma_i u)\|_{\mu_R}\leq\|\sigma_i\|_\infty\|u\|_\mu$.
Squaring their sum with $(x+y)^2\leq2x^2+2y^2$ and summing all
retained $\kappa_i$ proves \eqref{eq:projection-bound}.
Smooth approximation extends the derivative identity in the weak
Sobolev sense and the norm bound to $\mathcal V$. Since
$q(Jf,Jf)=a(f,f)$ and $J$ is an isometry in $L^2$, this proves the
claims about $P$ and $Q$. Conversely the weak retained derivatives of
$Jf$ are the lifts of those of $f$, so $Jf\in\mathcal V$ implies
$f\in\mathcal V_R$. Repeated differentiation of the compact conditional
integral also shows $J^*:H^k(\mathcal Q)\to H^k(\mathcal Q_R)$ is
bounded for each nonnegative integer $k$; in particular these maps
preserve smooth functions.
\end{proof}

The form $a$ is closed on $\mathcal V_R$ and has the self-adjoint
weighted elliptic generator
\begin{equation}\label{eq:A}
 A=-\rho_R^{-1}\sum_{i\in R}\kappa_iX_i(\rho_RX_i),
 \qquad D(A)=H^2(\mathcal Q_R).
\end{equation}
For a nonconstant smooth retained observable $F$, let
$f=F-\mu_R(F)$ and $u_F=\psi_0Jf$. Then
\begin{equation}\label{eq:Rayleigh}
 \langle\psi_0,u_F\rangle_\lambda=0,\qquad
 \frac{\langle u_F,(H-E_0)u_F\rangle_\lambda}{\|u_F\|_\lambda^2}
 =\frac{\displaystyle\sum_{i\in R}\kappa_i\mu_R(|X_iF|^2)}
        {\displaystyle\mu_R(|F|^2)-|\mu_R(F)|^2}.
\end{equation}
The numerator follows from \eqref{eq:fullform}, since the eliminated-link
derivatives of $Jf$ vanish; the denominator and orthogonality follow
from Fubini. Positivity of $\rho_R$ makes the denominator strictly
positive. Eliminated kinetic coefficients and all magnetic coefficients
still affect $\psi_0$, $\rho_R$, and the conditional density.

For the original gauge law $U_e\mapsto h_{s(e)}^{-1}U_eh_{t(e)}$,
the same vertex transformation acts separately on $s$ and $r$.
Gauge invariance of $\rho$ and Haar substitution in $s$ prove
$\rho_R(h\cdot r)=\rho_R(r)$ and covariance of $p(s\mid r)$.
Thus $J,J^*,P,Q$ intertwine these gauge actions. The equally valid law
$g_{s(e)}U_eg_{t(e)}^{-1}$ uses $g_v=h_v^{-1}$ and gives exactly the
same subspaces. Every formula therefore restricts to gauge-invariant
observables and vectors. For such a nonconstant $F$, \eqref{eq:Rayleigh}
is an upper bound on the physical finite-lattice gap. The infimum of
these quotients over retained invariant functions is at least the
infimum over all full invariant functions; a lower bound on one
retained quotient alone is not a full spectral lower bound.

\section{The exact coupling to eliminated functions and its domains}

For $f\in C^\infty(\mathcal Q_R)$, expand \eqref{eq:L} and compare
with \eqref{eq:A}. The retained second-derivative terms cancel, and
all eliminated derivatives of $Jf$ are zero. Hence
\begin{equation}\label{eq:B}
 LJf=JAf+Bf,\qquad
 Bf=-\sum_{i\in R}\kappa_i\sigma_i J(X_if),\qquad J^*Bf=0.
\end{equation}
This is the exact first-order map from retained variation to the
eliminated subspace. It extends boundedly
$B:\mathcal V_R\to\mathbb H_Q$, because
\begin{equation}\label{eq:Bbound}
 \|Bf\|_\mu^2\leq\eta\,a(f,f).
\end{equation}
Pointwise Cauchy--Schwarz with the factors $\sqrt{\kappa_i}\sigma_i$
and $\sqrt{\kappa_i}X_if$, followed by integration, proves this bound.
The exact squared norm retains the full conditional covariance:
\begin{equation}\label{eq:Fisher}
 \|Bf\|_\mu^2
 =\int\sum_{i,j\in R}\kappa_i\kappa_j
       I_{ij}(r)\overline{X_if(r)}X_jf(r)\,d\mu_R(r),
 \quad I_{ij}=J^*(\sigma_i\sigma_j).
\end{equation}
The matrix $I(r)$ is positive semidefinite by the exact identity
\[
 \sum_{i,j}\overline z_i I_{ij}(r)z_j
 =J^*\left(\left|\sum_i z_i\sigma_i\right|^2\right)(r)\geq0.
\]
Because $J^*\ell_i=\bar\ell_i$, it is exactly the conditional covariance
of $X_i\log\rho$ and $X_j\log\rho$ under $p(s\mid r)$.

Define $\mathcal V_Q=\mathcal V\cap\mathbb H_Q$ and restrict the
full form:
\begin{equation}\label{eq:Cform}
 c_Q(h,k)=q(h,k),\qquad h,k\in\mathcal V_Q.
\end{equation}
This is a closed densely defined nonnegative form on $\mathbb H_Q$.
Closedness follows since $\mathbb H_Q$ is $L^2$ closed. Density and a
form core follow by applying the bounded $Q$ of Lemma
\ref{lem:projection-domain} to smooth approximations; thus
$Q C^\infty(\mathcal Q)$ is a form core. Let $C$ be its associated
self-adjoint operator. There is no unsupported assertion here that
the formal differential compression $QLQ$ has an automatically chosen
operator domain. The form determines the domain uniquely by
\[
 D(C)=\{h\in\mathcal V_Q:\text{there exists }v\in\mathbb H_Q
       \text{ with }c_Q(k,h)=\langle k,v\rangle
       \text{ for every }k\in\mathcal V_Q\},\quad Ch=v.
\]
For smooth $h\in\mathbb H_Q$ this definition gives $Ch=QLh$ by
integration by parts. Since every $h\in\mathbb H_Q$ is orthogonal to
$1$, the full Poincare inequality gives
\begin{equation}\label{eq:Cgap}
 c_Q(h,h)\geq\delta\|h\|_\mu^2,
 \qquad C\geq\delta I>0.
\end{equation}
In particular $C^{-1}$ exists as a bounded operator. It and all
$(C+z)^{-1}$, $z\geq0$, map into $D(C)\subset\mathcal V_Q$.

For $f,g\in\mathcal V_R$ and $h,k\in\mathcal V_Q$, the exact block
form is
\begin{equation}\label{eq:blockform}
 q(Jf+h,Jg+k)=a(f,g)+\langle Bf,k\rangle
                         +\langle h,Bg\rangle+c_Q(h,k).
\end{equation}
For smooth functions this follows from \eqref{eq:B}; the bounded map
$B:\mathcal V_R\to\mathbb H_Q$ and the form-domain decomposition in
Lemma \ref{lem:projection-domain} extend it to the displayed domains.

The adjoint coupling has an explicit expression as well. For smooth
$h\in\mathbb H_Q$, Haar integration by parts in $r$ gives
\begin{equation}\label{eq:Bstar}
 B^*h=\rho_R^{-1}\sum_{i\in R}\kappa_i
                   X_i\bigl(\rho_R J^*(\sigma_i h)\bigr).
\end{equation}
Indeed $\langle Bf,h\rangle=-\sum_i\kappa_i
\int\rho_R\overline{X_if}J^*(\sigma_ih)d\lambda_R$, which becomes
$\langle f,B^*h\rangle$ with the sign in \eqref{eq:Bstar}.
Using \eqref{eq:conditional-derivative} with $u=\sigma_i h$ expands it
as the finite sum
\[
 B^*h=\sum_{i\in R}\kappa_i
 \left[J^*(\sigma_iX_ih)+J^*((X_i\sigma_i)h)
       +J^*(\sigma_i^2h)+\bar\ell_iJ^*(\sigma_i h)\right].
\]
Every coefficient is bounded, so this formula extends to a bounded map
$B^*:\mathcal V_Q\to\mathbb K$. On $\mathbb H_Q$ without this
regularity, the symbol $B^*$ is instead the bounded dual map into
$\mathcal V_R^*$ specified by $\langle f,B^*h\rangle=\langle Bf,h\rangle$.
These two definitions agree on their common domain.

Replacing $X_i$ by $X_i^c=2X_i$, $\sigma_i$ by $2\sigma_i$, and every
kinetic coefficient by $\kappa_i/4$ leaves \eqref{eq:A}, \eqref{eq:B},
and \eqref{eq:blockform} unchanged. This records the full original
metric dictionary for the eliminated coupling as well as for $H$.

\section{Exact compressed resolvents as closed Schur forms}

For $z>0$, put $R_z=(C+z)^{-1}$ and define on $\mathcal V_R$
\begin{equation}\label{eq:Schurform}
 s_z(f,g)=a(f,g)+z\langle f,g\rangle-\langle Bf,R_zBg\rangle.
\end{equation}
The last term is well defined by \eqref{eq:Bbound}. All occurrences of
$B^*R_zB$ below mean this form on the stated domain, not a product of
unbounded operators with unspecified domains.

\begin{theorem}\label{thm:Schur}
The form $s_z$ is closed, positive, and coercive on $\mathcal V_R$.
Its self-adjoint operator $S_z$ obeys $S_z\geq zI$ and
\begin{equation}\label{eq:Schurresolvent}
 J^*(L+z)^{-1}J=S_z^{-1}
   =\left[A+z-B^*(C+z)^{-1}B\right]^{-1}.
\end{equation}
The eliminated component of $(L+z)^{-1}Jg$ is exactly
$-R_zB S_z^{-1}g$. Moreover, in operator order,
\begin{equation}\label{eq:resolventorder}
 J^*(L+z)^{-1}J\ \geq\ (A+z)^{-1}.
\end{equation}
\end{theorem}
\begin{proof}
The block form and completion of the square give, for every
$f\in\mathcal V_R$, $h\in\mathcal V_Q$,
\begin{equation}\label{eq:square}
 q(Jf+h,Jf+h)+z(\|f\|^2+\|h\|^2)
 =s_z(f,f)+\|(C+z)^{1/2}(h+R_zBf)\|^2.
\end{equation}
Thus $s_z(f,f)$ is the infimum over $h$, uniquely attained at
$h=-R_zBf$, and nonnegativity of $q$ gives $s_z(f,f)\geq z\|f\|^2$.
For an explicit form-norm lower bound, apply
\eqref{eq:projection-bound} to $v=Jf+h$, for which $J^*v=f$:
\[
 a(f,f)+\|f\|^2
 \leq2q(v,v)+(2\eta+1)\|v\|^2
 \leq K_z\bigl(q(v,v)+z\|v\|^2\bigr),
 \quad K_z=\max\{2,(2\eta+1)/z\}.
\]
Take the minimizing $h$ to obtain
$s_z(f,f)\geq K_z^{-1}(a(f,f)+\|f\|^2)$.
Conversely $s_z(f,f)\leq a(f,f)+z\|f\|^2$ by choosing $h=0$.
These two bounds make its norm equivalent to the complete
$\mathcal V_R$ norm and prove closedness and coercivity. The
associated operator therefore exists and is at least $zI$.

For $g\in\mathbb K$, let $v=(L+z)^{-1}Jg$ and decompose it as
$v=Jf+h$ using the bounded form projection. The weak resolvent
equation tested against $k\in\mathcal V_Q$ gives
$c_Q(k,h)+z\langle k,h\rangle=-\langle k,Bf\rangle$.
The definition of $C$ proves $h=-R_zBf$. Testing against $Jf'$ for
$f'\in\mathcal V_R$ then gives
$s_z(f',f)=\langle f',g\rangle$, so $f=S_z^{-1}g$.
This proves both the compressed inverse and the reconstruction formula
with their domains resolved.

Finally, $s_z(f,f)\leq a(f,f)+z\|f\|^2$. For a positive coercive
closed form $t$ with associated operator $T$, completing the square in
its form space gives
$\langle g,T^{-1}g\rangle=\sup_f[2\Rea\langle g,f\rangle-t(f,f)]$.
Applying this formula to the two forms proves
\eqref{eq:resolventorder}. It is an order statement for the resolvents;
no ordering of their time exponentials is inferred from it.
\end{proof}

This is a weighted, infinite-rank Schur complement. The projection and
effective-resolvent method itself is established in Feshbach's work and
in the modern Feshbach--Schur formulation \cite{Feshbach,DSS}. The proof
above supplies the conditional-score coupling, form domains, and
coercivity needed for this particular infinite-dimensional projection.

\section{Full temporal correlations and exact memory}

Define the compressed correlation operator on the retained Hilbert space
by
\begin{equation}\label{eq:Kt}
 K(t)=J^*e^{-tL}J,\qquad t\geq0.
\end{equation}
It is a positive self-adjoint contraction with $K(0)=I$ and $K(t)1=1$.
These statements follow respectively from positivity in the spectral
sense, contraction, the isometry $J$, and $L1=0$. Its matrix elements
are the actual full quantum vacuum correlations, since
\begin{equation}\label{eq:quantumcorrelation}
 \langle f,K(t)g\rangle_{\mu_R}
 =\langle\psi_0Jf,e^{-t(H-E_0)}\psi_0Jg\rangle_\lambda.
\end{equation}
The spectral theorem also gives its norm-convergent Laplace integral
\begin{equation}\label{eq:Laplace}
 \int_0^\infty e^{-zt}K(t)\,dt
 =J^*(L+z)^{-1}J=S_z^{-1},\qquad z>0.
\end{equation}
The integral is convergent in operator norm because $\|K(t)\|\leq1$.

\begin{theorem}\label{thm:memory}
For smooth initial $f_0\in C^\infty(\mathcal Q_R)$, set
$f(t)=K(t)f_0$. It satisfies the exact equation in $\mathbb K$
\begin{equation}\label{eq:memory}
 f'(t)=-Af(t)+\int_0^t B^*e^{-(t-s)C}Bf(s)\,ds,
 \qquad f(0)=f_0.
\end{equation}
The integral is a well-defined Bochner integral; its positive sign is
fixed by eliminating the other component of the full equation.
For every smooth $f$,
\begin{equation}\label{eq:secondmoment}
 \langle f,K(t)f\rangle
 =\|f\|^2-t\,a(f,f)
       +\frac{t^2}{2}\bigl(\|Af\|^2+\|Bf\|^2\bigr)+o(t^2).
\end{equation}
The equality $K(t)=e^{-tA}$ for all $t\geq0$ holds if and only if
$B=0$ on $\mathcal V_R$.
\end{theorem}
\begin{proof}
Let $v(t)=e^{-tL}Jf_0$ and $h(t)=Qv(t)$. Smooth initial data belong to
all powers of the compact elliptic operator $L$, so spectral calculus
and elliptic regularity make $v(t)$ smooth in space and continuously
differentiable in every required Sobolev norm for $t\geq0$. Lemma
\ref{lem:projection-domain} implies the same spatial regularity for
$f(t)=J^*v(t)$ and $h(t)$. The full equation $v'=-Lv$ and
\eqref{eq:blockform} therefore give
\[
 f'=-Af-B^*h,\qquad h'=-Bf-Ch,\qquad h(0)=0.
\]
For the second equation, differentiating
$e^{-(t-s)C}h(s)$ and integrating in $s$ gives
\begin{equation}\label{eq:eliminatedevolution}
 h(t)=-\int_0^te^{-(t-s)C}Bf(s)\,ds.
\end{equation}
This differentiation is justified since the smooth $h(s)$ lies in
$D(C)$ with $Ch(s)=QLh(s)$ continuously in $\mathbb H_Q$.

The map $B^*:\mathcal V_Q\to\mathbb K$ was proved bounded above.
Spectral calculus for $C\geq0$ gives
\[
 \|e^{-\tau C}\|_{\mathbb H_Q\to\mathcal V_Q}
 \leq1+(2e\tau)^{-1/2},\qquad\tau>0,
\]
because $\sup_{x\geq0}\sqrt{x}e^{-\tau x}=(2e\tau)^{-1/2}$.
Consequently the integrand in \eqref{eq:eliminatedevolution} is
integrable in the form norm near $s=t$, as $Bf(s)$ is continuous in
$\mathbb H_Q$. Applying the bounded $B^*$ to that form-norm integral
and substituting into the first equation proves \eqref{eq:memory}
as a strong $\mathbb K$ identity. This also specifies rigorously the
memory-kernel domain: $B^*e^{-\tau C}B$ maps $\mathcal V_R$ to
$\mathbb K$ for $\tau>0$, with an integrable $O(1+\tau^{-1/2})$
bound on bounded time intervals. This is an exact projection-memory
construction of the type introduced by Mori \cite{Mori}, with the
Euclidean generator and signs derived here.

For \eqref{eq:secondmoment}, apply the scalar spectral theorem to the
smooth vector $Jf$, which lies in $D(L^2)$. The zeroth, first and
second moments are $\|f\|^2$, $a(f,f)$, and
\[
 \|LJf\|_\mu^2=\|JAf+Bf\|_\mu^2=\|Af\|_{\mu_R}^2+\|Bf\|_\mu^2.
\]
The second-order Taylor remainder is $o(t^2)$ by dominated convergence
against its finite second spectral moment. This proves the expansion.
The corresponding expansion for $e^{-tA}$ has second coefficient
$\|Af\|^2/2$. Equality of all the correlation operators therefore
forces $Bf=0$ for every smooth $f$, and density and \eqref{eq:Bbound}
extend this to $\mathcal V_R$. Conversely, if $B=0$, the exact closed
form \eqref{eq:blockform} is the orthogonal direct sum of $a$ and $c_Q$.
Its self-adjoint operator and semigroup are direct sums as well, giving
$K(t)=e^{-tA}$.
\end{proof}

In particular the explicit second-derivative diagnostic is
\[
 \left.\frac{d^2}{dt^2}\right|_{t=0}
 \left[\langle Jf,e^{-tL}Jf\rangle_\mu
              -\langle f,e^{-tA}f\rangle_{\mu_R}\right]=\|Bf\|_\mu^2.
\]

For the unrestricted retained function space this condition has a
concrete statistical characterization:
\begin{equation}\label{eq:factorization}
 B=0\text{ on }\mathcal V_R
 \quad\Longleftrightarrow\quad
 \rho(s,r)=\rho_S(s)\rho_R(r)
 \text{ for positive probability densities }\rho_S,\rho_R.
\end{equation}
The reverse implication follows immediately from $\sigma_i=0$.
For the forward implication, \eqref{eq:B} vanishes for every smooth
test function $f$. The resulting functions are smooth, so vanishing
in $L^2$ means vanishing pointwise. At any fixed $r$, a smooth function
with arbitrary prescribed differential at $r$ is obtained from local
coordinates and a smooth cutoff. The independent tangent basis $X_i$
and positive $\kappa_i$ then force each $\sigma_i(s,r)=0$. Thus every
$r$ derivative of $p(s\mid r)$ is zero, and connectedness of
$\mathcal Q_R$ makes it independent of $r$. Normalization gives the
factorization. If one restricts tests to gauge-invariant functions,
the exact criterion is $B=0$ on that invariant form space; the stronger
factorization is not asserted from that smaller test space.

\section{Constructed excitation vectors using the eliminated resolvent}

The marginal quotient can be improved by an explicit full-state vector.
Let $0\ne f\in\mathcal V_R$ satisfy $\mu_R(f)=0$. For every $z\geq0$
define
\begin{equation}\label{eq:correctedstate}
 w_z=(C+z)^{-1}Bf,\qquad
 u_z=\psi_0(Jf-w_z).
\end{equation}
Equation \eqref{eq:Cgap} guarantees existence even at $z=0$, and
$w_z\in\mathcal V_Q$. Orthogonality gives
$\langle\psi_0,u_z\rangle_\lambda=0$ and
$\|u_z\|_\lambda^2=\|f\|_{\mu_R}^2+\|w_z\|_\mu^2>0$.
All gauge actions commute with the forms and their resolvents; hence
if $f$ is invariant, $u_z$ is invariant as well.
For a full original-Hilbert-space form-domain vector $u$, write
\[
 \mathfrak h_0[u]=\|(H-E_0)^{1/2}u\|_\lambda^2
                =q(u/\psi_0,u/\psi_0).
\]
This is the energy used below. It equals
$\langle u,(H-E_0)u\rangle$ when $u\in D(H)$, but no such stronger
domain membership is assumed for the constructed form-domain vector.

\begin{theorem}\label{thm:improvedtrial}
The actual full-Hamiltonian Rayleigh quotient of \eqref{eq:correctedstate}
is
\begin{equation}\label{eq:improvedquotient}
 \frac{\mathfrak h_0[u_z]}{\|u_z\|^2}
 =\frac{a(f,f)-\langle Bf,w_z\rangle-z\|w_z\|^2}
        {\|f\|^2+\|w_z\|^2}
 \leq\frac{a(f,f)}{\|f\|^2}.
\end{equation}
The inequality is strict whenever $Bf\ne0$. The numerator is
nonnegative. For $z=0$, $-w_0$ uniquely minimizes the full Dirichlet
energy among all $Jf+h$, $h\in\mathcal V_Q$, with the retained
conditional mean $f$ fixed.
\end{theorem}
\begin{proof}
The equation $(C+z)w_z=Bf$ gives
$c_Q(w_z,w_z)=\langle Bf,w_z\rangle-z\|w_z\|^2$.
Insert $h=-w_z$ in \eqref{eq:blockform}. The two cross terms subtract
$2\langle Bf,w_z\rangle$, yielding exactly the numerator in
\eqref{eq:improvedquotient}. It is nonnegative because it is the full
closed form $q(Jf-w_z,Jf-w_z)$. The scalar
$\langle Bf,w_z\rangle=\langle Bf,(C+z)^{-1}Bf\rangle$ is
nonnegative and strictly positive when $Bf\ne0$. The numerator is
therefore at most $a(f,f)$ and the denominator at least $\|f\|^2$;
when $Bf\ne0$ the numerator is strictly smaller. The base energy is
positive for a nonzero centered $f$, because $\rho_R>0$ on a connected
space. This proves the claimed strict inequality. Completion of the
square in \eqref{eq:square} with $z=0$ remains valid because $C>0$,
and proves the minimization statement.
\end{proof}

For a centered retained $f$, define the actual excitation spectral
probability measure
\[
 \nu_f(E)=\|f\|^{-2}
 \langle\psi_0Jf,\mathbf1_E(H-E_0)\psi_0Jf\rangle.
\]
Its first moment is $a(f,f)/\|f\|^2$, its second moment for smooth
$f$ is $(\|Af\|^2+\|Bf\|^2)/\|f\|^2$, and its Laplace transform
is $\langle f,K(t)f\rangle/\|f\|^2$. The corrected states have their
own actual spectral measures with first moment
\eqref{eq:improvedquotient}. In particular each invariant corrected
state gives a genuine upper bound on the full physical spectral gap;
none of these energies is assigned from an independently chosen
single-slice density.

\section{Exact nonlinear Wilson integration leading to this marginal}

We now construct the connection to the completed compact-link
integration. Specialize to $\SU(2)$ and the fixed spatial regulator
with the original action metric, spatial mesh $a>0$, and coupling
$g_{\rm YM}>0$. Retain
\begin{equation}\label{eq:physicalcoefficients}
 \kappa_e=\frac{2g_{\rm YM}^2}{a},\qquad
 b_p^{\rm Hamiltonian}=\frac1{2g_{\rm YM}^2a},\qquad
 b_t(\epsilon)=\frac{a}{2g_{\rm YM}^2\epsilon},\qquad
 b_s(\epsilon)=\frac{\epsilon}{2g_{\rm YM}^2a}.
\end{equation}
The companion \texttt{temporal\_transfer.tex} defines the positive
normalized transfer operator
\[
 F_\epsilon=e^{-\epsilon V/2}K_\epsilon e^{-\epsilon V/2}.
\]
The exact temporal link kernel has
spin-$j$ multiplier $I_{2j+1}(2b_t)/I_1(2b_t)$, temporal vertex
integration gives the Gauss projector $P_G$, and the raw transfer is
\begin{equation}\label{eq:rawrelation}
 T_\epsilon^{\rm raw}=c_\epsilon F_\epsilon P_G,
 \qquad c_\epsilon=[e^{-2b_t}Z(b_t)]^{|\mathsf E|},\qquad
 Z(b)=I_1(2b)/b.
\end{equation}
That companion proves, on the actual dense invariant core and then
strongly on the full Hilbert space,
$F_{T/m}^{\,m}\to e^{-TH}$ for fixed $T>0$. This is a time limit at
fixed spatial graph, with every coefficient in
\eqref{eq:physicalcoefficients} retained.

For $T>0$ and integer $m\geq1$, put $\epsilon=T/m$ and
\begin{equation}\label{eq:slabdensities}
 \phi_{T,m}=F_{T/m}^{\,m}1,\qquad
 \rho_{T,m}(U)=\frac{\phi_{T,m}(U)^2}{\|\phi_{T,m}\|_\lambda^2},\qquad
 \rho_{R;T,m}(r)=\int\rho_{T,m}(s,r)d\lambda_S(s).
\end{equation}
All these functions are positive, and $1$ is gauge invariant, so the
Gauss projector is retained automatically. Kernel composition and
Fubini identify \eqref{eq:slabdensities} with the central-slice density
of a two-sided finite Euclidean Wilson slab with slices
$-m,-m+1,\ldots,m$, fixed central slice $U$, and constant outer
boundary states. Each temporal plaquette has weight $b_t$, every
interior spatial plaquette has weight $b_s$, and spatial plaquettes
on the two outer boundary slices have half weight. The central
magnetic factor is full, because the two half factors multiply.
The two raw factors $c_\epsilon^m$ multiply to $c_\epsilon^{2m}$ in
both numerator and normalization and cancel exactly. This proves a
specific Euclidean-integral representation, including both temporal
sides and their boundary weights.

Assume now that $\mathsf S$ is the selected spatial-link set with no
two selected edges belonging to one spatial plaquette, and that each
plaquette uses any one physical edge at most once. Apply the selection
only at the central time slice. A temporal plaquette has only one
spatial edge at that slice, so no spacetime plaquette contains two
selected central links either. Let $Y$ denote every remaining slab
variable except the retained central links $r$.
For each selected central edge $e$, cyclically rotate and, when
necessary, invert a plaquette inside its real trace to write all its
incident contributions as $\Rea\tr(U_eV_{ep})$. Define
\begin{align}
 H_e(Y,r)&=\sum_{p\ni(e,0)}b_pV_{ep},&
 B_e&=\sum_{p\ni(e,0)}b_p,\nonumber\\
 r_e^2(Y,r)&=\tfrac12\tr(H_eH_e^\dagger)
 =\sum_{p\ni(e,0)}b_p^2
   +\sum_{p<q\ni(e,0)}b_pb_q\Rea\tr(V_{ep}V_{eq}^\dagger).
   \label{eq:allstaples}
\end{align}
The weights in this sum are the actual anisotropic weights of their
plaquettes. For a spatial interior edge there are four spatial staples
of weight $b_s$ and two temporal staples of weight $b_t$, so
$B_e=4b_s+2b_t$. At a spatial boundary the displayed incident sum,
rather than this interior count, is used.

The exact single-link integral is
\begin{equation}\label{eq:Zintegration}
 \int_{\SU(2)}e^{-2B_e+\Rea\tr(U_eH_e)}dU_e
   =e^{-2B_e}Z(r_e),\qquad
 Z(r)=\sum_{k=0}^\infty\frac{r^{2k}}{k!(k+1)!},\quad Z(0)=1.
\end{equation}
To prove it, write every $\SU(2)$ matrix as a unit real quaternion.
The real linear combination $H_e$ then obeys
$H_eH_e^\dagger=r_e^2I$ and $\det H_e=r_e^2$.
For $r_e>0$, $H_e/r_e\in\SU(2)$ and Haar translation reduces the
integral to
$(2/\pi)\int_{-1}^1e^{2r_ex}\sqrt{1-x^2}dx$.
Termwise integration of its uniformly convergent exponential series,
using
$\int_{-1}^1x^{2k}\sqrt{1-x^2}dx
=\pi(2k)!/[2\cdot4^kk!(k+1)!]$, gives
\eqref{eq:Zintegration}. The even moment formula follows by integration
by parts from the semicircle area at $k=0$. At $r_e=0$ the quaternion
is zero and the integral is exactly one before its constant factor.

No incident plaquette is shared by selected links. Thus the exact
central retained density in \eqref{eq:slabdensities} is
\begin{equation}\label{eq:integratedslab}
 \rho_{R;T,m}(r)=
 \frac{\displaystyle\int
    e^{-S_{\rm rest}(Y,r)}
    \prod_{e\in\mathsf S}e^{-2B_e}Z(r_e(Y,r))\,dY}
      {\displaystyle\int_{\mathcal Q_R}\int
    e^{-S_{\rm rest}(Y,r')}
    \prod_{e\in\mathsf S}e^{-2B_e}Z(r_e(Y,r'))\,dY\,d\lambda_R(r')}.
\end{equation}
Here $S_{\rm rest}$ is precisely the slab action with those incident
plaquettes removed; it includes every other plaquette and the stated
outer boundary weights. The integrals over $Y$ include all temporal
vertex links. Formula \eqref{eq:integratedslab} follows by applying
\eqref{eq:Zintegration} to the finite positive integrand and Fubini.
All cross-staple traces, the two temporal staples, and all induced
interactions remain in it. For a general split $\mathsf S$, the
unfactorized exact integral over selected links in
\eqref{eq:slabdensities} remains valid; only the product expression
\eqref{eq:integratedslab} uses the no-shared-plaquette property.

\begin{theorem}\label{thm:slablimit}
The exact true-vacuum marginal is the sequential $L^1$ limit
\begin{equation}\label{eq:sequentiallimit}
 \rho_R=\lim_{T\to\infty}\lim_{m\to\infty}\rho_{R;T,m},
 \qquad\epsilon=T/m,
\end{equation}
with the spatial graph and $a,g_{\rm YM}$ fixed. In particular the
nonlinear integration \eqref{eq:integratedslab}, performed with all
its interactions, has this precise relation to the true vacuum.
\end{theorem}
\begin{proof}
Strong transfer convergence gives
$\phi_{T,m}\to\phi_T:=e^{-TH}1$ in $L^2(\lambda)$ for each fixed
$T>0$. This nonzero positive vector has a nonzero norm. Normalization
is continuous at a nonzero vector, and
$\|v^2-w^2\|_1\leq(\|v\|_2+\|w\|_2)\|v-w\|_2$ for real
functions. Consequently
\[
 \rho_{T,m}\longrightarrow
 \rho_T:=\frac{(e^{-TH}1)^2}{\|e^{-TH}1\|^2}
 \quad\text{in }L^1(\lambda).
\]
Marginalization is an $L^1$ contraction by Fubini and the triangle
inequality, so the retained marginals converge in $L^1(\lambda_R)$.

Set $c_0=\langle\psi_0,1\rangle_\lambda>0$. Spectral decomposition,
the unique ground state, and the finite gap $\delta$ give
\[
 e^{TE_0}e^{-TH}1=c_0\psi_0+r_T,\qquad
 r_T\perp\psi_0,\qquad
 \|r_T\|\leq e^{-T\delta}\sqrt{1-c_0^2}.
\]
The norm of this vector is $\sqrt{c_0^2+\|r_T\|^2}$. Subtracting
$\psi_0$ after normalizing and using the triangle inequality gives
\[
 \left\|\frac{e^{-TH}1}{\|e^{-TH}1\|}-\psi_0\right\|_2
 \leq\frac{2\|r_T\|}{c_0}.
\]
Thus the same square-density inequality and marginal contraction yield
\begin{equation}\label{eq:vacuumerror}
 \|\rho_{R;T}-\rho_R\|_1
 \leq\|\rho_T-\rho\|_1
 \leq\frac{4\sqrt{1-c_0^2}}{c_0}e^{-T\delta}.
\end{equation}
This proves \eqref{eq:sequentiallimit}. It does not exchange the two
limits or infer a spatial continuum limit from them.
\end{proof}

The resulting excitation estimate can be obtained continuously from
these exact marginal integrations. Fix a nonconstant smooth invariant
$F(r)$ and put
\[
 \gamma_R(F)=\sum_{i\in R}\kappa_i|X_iF|^2,
 \qquad Q_R(F)=\frac{\mu_R(\gamma_R(F))}{\Var_{\mu_R}(F)}.
\]
For a probability density $\widetilde\rho_R$ let $\widetilde Q_R(F)$
be the same ratio with that density. Set
$\eta_1=\|\widetilde\rho_R-\rho_R\|_1$,
$M_F=\|F\|_\infty$, $G_F=\|\gamma_R(F)\|_\infty$, and
$v_F=\Var_{\mu_R}(F)>0$. Direct integration gives
\[
 |\widetilde\mu_R(\gamma_R)-\mu_R(\gamma_R)|\leq G_F\eta_1,
 \quad
 |\Var_{\widetilde\mu_R}(F)-v_F|\leq3M_F^2\eta_1.
\]
The second inequality uses the second-moment error at most
$M_F^2\eta_1$ and
$\bigl|\lvert\widetilde\mu_R(F)\rvert^2-\lvert\mu_R(F)\rvert^2\bigr|
\leq2M_F^2\eta_1$ for the mean term. If
$\eta_1\leq v_F/(6M_F^2)$, the new variance is at least $v_F/2$;
subtracting the two fractions then proves the explicit estimate
\begin{equation}\label{eq:quotienterror}
 |\widetilde Q_R(F)-Q_R(F)|
 \leq\frac{2G_F}{v_F}\eta_1
      +\frac{6G_FM_F^2}{v_F^2}\eta_1.
\end{equation}
In particular the sequential limits of the quotients constructed from
\eqref{eq:integratedslab} equal the genuine full-vacuum Rayleigh
quotient \eqref{eq:Rayleigh}, and hence its actual spectral first
moment. The controlled finite integrals, the true marginal, and the
quantum excitation estimate are related by the displayed maps and
limits. The single-time density proportional to
$\exp[-\sum_pb_p(2-\Rea\tr U_p)]$ is nowhere substituted for
$\psi_0^2$.

\section{Verification and literature provenance}

The calculation uses the full finite interacting Hamiltonian, not a
Gaussian or Abelian replacement. The map $B$, its conditional
covariance, the closed Schur form, the memory integral, and the
corrected full trial states all retain the actual $\rho=\psi_0^2$.
The scalar Schur/memory signs and corrected Rayleigh algebra are also
checked in \texttt{check\_spatial\_elimination.py}; that finite exact
algebra check does not replace the proved form-domain argument.
It passed 12 exact scalar/block assertions, together with exact
matrix-entry checks. An additional explicit rational-matrix quotient
checks the strict decrease; it is an algebra diagnostic and is not
presented as a lattice vacuum or a continuum approximation.

The general projection and Schur ideas are established methods, not
claimed as new results here. The locally retained source of
Dusson--Sigal--Stamm was inspected at Theorem 1.2 and the subsequent
effective-interaction equations; the retained projection here has
infinite rank, so its bounded finite-rank formulas are not invoked
without the form proof above. The earlier complete finite-vacuum and
time-transfer sources in this directory provide the retained kinetic,
potential, metric, and temporal-normalization dictionaries used here.
No infinite-volume or spatial-continuum spectral conclusion is made.

\begin{thebibliography}{9}
\bibitem{Feshbach}
H. Feshbach, \emph{Unified Theory of Nuclear Reactions},
Reviews of Modern Physics \textbf{36} (1964), 1076--1078,
\href{https://doi.org/10.1103/RevModPhys.36.1076}
{doi:10.1103/RevModPhys.36.1076}.

\bibitem{DSS}
G. Dusson, I. M. Sigal, and B. Stamm,
\emph{The Feshbach--Schur map and perturbation theory},
\href{https://arxiv.org/abs/2105.02058}{arXiv:2105.02058v1} (2021),
Theorem 1.2 and equations (1.10)--(1.16).

\bibitem{Mori}
H. Mori, \emph{Transport, Collective Motion, and Brownian Motion},
Progress of Theoretical Physics \textbf{33} (1965), 423--455,
\href{https://doi.org/10.1143/PTP.33.423}{doi:10.1143/PTP.33.423}.
\end{thebibliography}
\end{document}

```

## Complete source: euler_transfer/EXACT_VISCOUS_TRANSFER.md

```markdown
# Exact positive-viscosity transfer of the announced Euler construction

Date: 2026-09-08. This is a calculation for the velocity field constructed in *Blowup for the Euler Equations with Smooth Forcing*, the manuscript linked from the 2026-09-07 announcement. The downloaded source is identified in SOURCE_RECEIPTS.md. Its full 112-page proof and its Lean development have not been independently reverified here. The statements about that construction below are the stated results and formulas of the identified manuscript. Every new transfer identity and obstruction asserted here is proved below. No Navier-Stokes or Yang-Mills counterexample is asserted.

## 1. The actual objects, geometry, and equations

The source's Theorem 1.1 fixes any radius \(r_0>0\) and height \(z_0\), and produces \(T_*>0\), \(0<R<r_0/2\), smooth axisymmetric initial data with nonzero swirl and zero meridional velocity, and an axisymmetric force \(f_E\in C^\infty(\mathbb R^3\times[0,T_*])\). Its velocity and pressure solve
\[
 \partial_tu+(u\cdot\nabla)u+\nabla p_E=f_E,
 \qquad \operatorname{div}u=0
 \tag{1}
\]
on \(\mathbb R^3\times[0,T_*)\). In physical cylindrical coordinates \((r,\varphi,z)\), the construction has fixed support within
\[
 \mathcal T_R=\{(r,\varphi,z):(z-z_0)^2+(r-r_0)^2<R^2\}.
\]
Although the theorem initially states the support of circulation and azimuthal vorticity, Section 13.2 explicitly proves the support of the velocity itself in this torus. Thus the state has support in \(B_L(z_0e_z)\), where the exact convenient radius is \(L=r_0+R\). This follows by the triangle inequality from the distance to the circle of radius \(r_0\). No changing spatial domain is used below.

The source's physical volume coordinate, orientation, and elliptic coefficients are
\[
 y=(z,r^2/2),\quad J(a_1,a_2)=(-a_2,a_1),\quad
 A(y)=\begin{pmatrix}(2y_2)^{-1}&0\\0&1\end{pmatrix},
 \quad L_E=\partial_{y_2}^2+(2y_2)^{-1}\partial_{y_1}^2,
 \quad W=(2y_2)^{-2}.
\]
Here \(L_E\) is the source operator denoted \(L\); the subscript only avoids collision with the enclosing-ball radius. With \(v=J\nabla_y\Psi\),
\[
 u^z=-\Psi_{y_2},\qquad u^r=\Psi_{y_1}/r,\qquad
 u^\varphi=\Gamma/r,\qquad \xi=\omega^\varphi/r=L_E\Psi,
 \quad D_v=\partial_t+v\cdot\nabla_y.
\]
The exact Euler residuals and source compact recovery are
\[
 F_E^\Gamma=D_v\Gamma,\qquad
 E_E^\xi=D_v\xi-W\partial_{y_1}(\Gamma^2),
\]
\[
 f_E^\varphi=F_E^\Gamma/r,\qquad
 (f_E^z,f_E^r/r)=\mathcal R_y E_E^\xi,
 \quad\operatorname{curl}_y\mathcal R_yE_E^\xi=E_E^\xi.
 \tag{2}
\]
Here \(\operatorname{curl}_y(h_1,h_2)=\partial_{y_1}h_2-\partial_{y_2}h_1\). All radial denominators are bounded because the support stays in \(r_0-R\le r\le r_0+R\).

The source proves that \(\Gamma,u^r,u^z\) remain uniformly bounded, while \(\|\nabla\Gamma(t)\|_\infty\), \(\|\omega(t)\|_\infty\), and \(\int_0^{T_*}\|\omega(t)\|_\infty\,dt\) diverge. The full physical velocity is bounded because \(|u^\varphi|\le (r_0-R)^{-1}|\Gamma|\).

## 2. Exact viscous map, with arbitrary pressure and fixed positive viscosity

Fix any constant physical kinematic viscosity \(\nu_{\mathrm{vis}}>0\). The subscript distinguishes it from the source's unrelated cone margin also named \(\nu\). For the same velocity and pressure, define
\[
 f_{\mathrm{vis}}=f_E-\nu_{\mathrm{vis}}\Delta_xu.
 \tag{3}
\]
Subtraction of \(\nu_{\mathrm{vis}}\Delta_xu\) from both sides of (1) proves exactly
\[
 \partial_tu+(u\cdot\nabla)u+\nabla p_E
   =\nu_{\mathrm{vis}}\Delta_xu+f_{\mathrm{vis}}.
\]
Thus (3) gives a genuine morphism between forced equations on every compact preterminal interval, preserving the initial datum, velocity, divergence, viscosity value, and physical coordinates. It does not by itself preserve the closed-time smooth-force class.

Every other pressure \(p_E+q\) for this same velocity requires the force
\[
 \widetilde f_{\mathrm{vis}}=f_E-\nu_{\mathrm{vis}}\Delta_xu+\nabla q.
 \tag{4}
\]
This follows by subtracting the two momentum equations componentwise, so (4) is exhaustive for fixed \(u\). Curl eliminates the pressure exactly:
\[
 \operatorname{curl}(\widetilde f_{\mathrm{vis}}-f_E)
       =-\nu_{\mathrm{vis}}\Delta_x\omega.
 \tag{5}
\]

For completeness, on \(L^2(\mathbb R^3;\mathbb R^3)\) the solenoidal projection has Fourier multiplier
\[
 \widehat{\mathbb Ph}(k)=\left(I-\frac{kk^T}{|k|^2}\right)\widehat h(k)
 \quad(k\ne0).
\]
The value at \(k=0\) is immaterial to \(L^2\). Since \(k\cdot\widehat u=0\), multiplication by \(-|k|^2\) proves \(\mathbb P\Delta u=\Delta u\). Since the multiplier annihilates \(k\), it annihilates gradients whenever the projected expressions are defined. Consequently
\[
 \mathbb Pf_{\mathrm{vis}}=\mathbb Pf_E-\nu_{\mathrm{vis}}\Delta u.
 \tag{6}
\]
Pressure absorption cannot remove this solenoidal viscous term. Equation (5) remains meaningful locally even without an \(L^2\) hypothesis on \(\nabla q\).

The energy identity independently checks the sign in (3). Compact support permits integration by parts:
\[
 \int u\cdot f_{\mathrm{vis}}\,dx
   =\int u\cdot f_E\,dx+\nu_{\mathrm{vis}}\int|\nabla u|^2\,dx.
\]
Hence the positive-viscosity energy identity reads
\(\frac12\partial_t\|u\|_2^2+\nu_{\mathrm{vis}}\|\nabla u\|_2^2
=\langle u,f_{\mathrm{vis}}\rangle\), exactly as required.

## 3. Exact viscous reduced operators in the source's coordinates

For an axisymmetric scalar, the Cartesian scalar Laplacian is
\(\Delta_0=\partial_z^2+\partial_r^2+r^{-1}\partial_r\).
The vector Laplacian of the azimuthal component is \((\Delta_0-r^{-2})u^\varphi\). Directly differentiating \(u^\varphi=\Gamma/r\) gives
\[
 r(\Delta_0-r^{-2})(\Gamma/r)
   =\partial_z^2\Gamma+\partial_r^2\Gamma-r^{-1}\partial_r\Gamma
   =:D_\Gamma\Gamma.
\]
Likewise
\[
 r^{-1}(\Delta_0-r^{-2})(r\xi)
   =\partial_z^2\xi+\partial_r^2\xi+3r^{-1}\partial_r\xi
   =:D_\xi\xi.
\]
The factors follow from
\(\partial_r^2(\Gamma/r)=\Gamma_{rr}/r-2\Gamma_r/r^2+2\Gamma/r^3\)
and \(\partial_r^2(r\xi)=r\xi_{rr}+2\xi_r\).
Using \(\partial_r=r\partial_{y_2}\) then gives the exact operators
\[
 D_\Gamma=\partial_{y_1}^2+2y_2\partial_{y_2}^2,
 \qquad
 D_\xi=\partial_{y_1}^2+2y_2\partial_{y_2}^2+4\partial_{y_2}.
 \tag{7}
\]
Therefore the correct source residuals for positive viscosity are
\[
 F_{\mathrm{vis}}^\Gamma=F_E^\Gamma-\nu_{\mathrm{vis}}D_\Gamma\Gamma,
 \qquad
 E_{\mathrm{vis}}^\xi=E_E^\xi-\nu_{\mathrm{vis}}D_\xi\xi.
 \tag{8}
\]
The second follows equivalently by taking curl of (3). In fact
\(r^{-1}(\partial_z(\Delta u)^r-\partial_r(\Delta u)^z)
=r^{-1}(\Delta\omega)^\varphi=D_\xi\xi\).

The compatibility of the compact source inverse survives:
\[
 D_\xi\xi=\partial_{y_1}(\partial_{y_1}\xi)
    +\partial_{y_2}(2y_2\partial_{y_2}\xi+2\xi),
 \qquad \int_{\mathbb R^2}D_\xi\xi\,dy=0.
\]
Thus applying the same \(\mathcal R_y\) to (8) gives a legitimate compact force. Its azimuthal component equals that of (3), and its meridional curl agrees with (3); their difference has zero full curl and zero azimuthal component. The difference is smooth through the axis because both forces vanish nearby. On simply connected \(\mathbb R^3\) it is an exact gradient. One explicit potential for a smooth curl-free difference \(h\) is
\(q(x,t)=\int_0^1h(sx,t)\cdot x\,ds\): differentiating and using \(\partial_i h_j=\partial_j h_i\) gives \(\partial_iq=h_i\). This proves the precise equivalence between compact recovery and the direct force map, including pressure.

## 4. Terminal obstruction for this actual field, independent of pressure

Let \(G(x)=(4\pi|x|)^{-1}\), so \(-\Delta G=\delta_0\). For a smooth compactly supported vector field \(h\),
\[
 h=-G*\Delta h.
 \tag{9}
\]
One proof is integration by parts in the distribution identity \(-\Delta G=\delta_0\), component by component. Compact support removes all boundary terms; the locally integrable kernel makes the convolution well defined.

The integral of \(G(x-y)\) over a ball of radius \(L\) centered at \(c\), with \(\rho=|x-c|\), is exactly
\[
 \int_{B_L(c)}G(x-y)\,dy=
 \begin{cases}(3L^2-\rho^2)/6,&0\le\rho\le L,\\
 L^3/(3\rho),&\rho\ge L.
 \end{cases}
 \tag{10}
\]
To verify (10), use spherical shells about \(c\). The angular integral at shell radius \(a\) is
\(\int_{S^2}|x-c-a\theta|^{-1}\,d\theta=4\pi/\max(\rho,a)\).
For \(\rho,a>0\), this follows by integrating
\(2\pi\int_{-1}^1(\rho^2+a^2-2\rho a s)^{-1/2}\,ds\);
zero radii follow by continuity. Integration of \(a^2/\max(\rho,a)\) from zero to \(L\) yields (10).
Its maximum is \(L^2/2\). Taking Euclidean vector norms in (9) therefore gives
\[
 \|h\|_\infty\le\frac{L^2}{2}\|\Delta h\|_\infty
 \quad\text{when }\operatorname{supp}h\subset B_L(c).
 \tag{11}
\]
Apply this at each preterminal time to the source vorticity. Its derivatives have the same support. Equations (5) and (11) imply
\[
 \|\operatorname{curl}\widetilde f_{\mathrm{vis}}(t)\|_{L^\infty(B_L)}
 \ge \frac{2\nu_{\mathrm{vis}}}{L^2}\|\omega(t)\|_\infty
       -\|\operatorname{curl}f_E(t)\|_{L^\infty(B_L)}
 \longrightarrow+\infty.
 \tag{12}
\]
The last term is bounded on the fixed compact cylinder because the actual Euler force is smooth through \(T_*\). Hence no single-valued smooth pressure correction can make the same actual velocity solve positive-viscosity Navier-Stokes with force smooth through \(T_*\). Equation (12) even rules out a uniform \(C^1\) force bound there.

The actual axisymmetric construction gives the stronger failure of the force's \(C^0\) norm. Define its swirl field
\(U_{\mathrm{sw}}=(\Gamma/r)e_\varphi\). It is a smooth Cartesian field supported in the same ball, because it vanishes near the axis. Its curl consists precisely of
\[
 \omega^r=-r^{-1}\partial_z\Gamma=-r^{-1}\partial_{y_1}\Gamma,
 \qquad \omega^z=r^{-1}\partial_r\Gamma=\partial_{y_2}\Gamma.
 \tag{13}
\]
These are exactly the components whose divergence is proved in source (14.5), so
\(\|\operatorname{curl}U_{\mathrm{sw}}(t)\|_\infty\to\infty\).
Differentiating (9), and using \(|a\times b|\le|a||b|\), gives
\[
 \|\operatorname{curl}h\|_\infty
       \le L\|\Delta h\|_\infty.
 \tag{14}
\]
Here \(\int_{B_L(c)}|\nabla G(x-y)|\,dy\le L\). To prove the constant, use the layer-cake representation of the decreasing radial kernel \((4\pi|z|^2)^{-1}\). At every radius, the intersection of \(B_L(c)\) with a ball centered at \(x\) has volume at most the smaller of the two ball volumes. The concentric case attains that upper bound at every layer. The centered integral is \(\int_0^Ldr=L\).

For arbitrary single-valued \(q\), its angular derivative has zero angular average:
\[
 \frac1{2\pi}\int_0^{2\pi}e_\varphi\cdot\nabla q(r,\varphi,z,t)\,d\varphi
 =\frac1{2\pi r}[q(r,2\pi,z,t)-q(r,0,z,t)]=0.
\]
The azimuthal component of \(\Delta u\) is exactly that of \(\Delta U_{\mathrm{sw}}\), which is axisymmetric. Taking the angular average of (4), then a supremum over the fixed torus, yields
\[
 \|\widetilde f_{\mathrm{vis}}(t)\|_{L^\infty(B_L)}
 \ge \nu_{\mathrm{vis}}\|\Delta U_{\mathrm{sw}}(t)\|_\infty
       -\|f_E^\varphi(t)\|_\infty
 \ge\frac{\nu_{\mathrm{vis}}}{L}\|\operatorname{curl}U_{\mathrm{sw}}(t)\|_\infty
       -\|f_E^\varphi(t)\|_\infty
 \longrightarrow+\infty.
 \tag{15}
\]
No axisymmetry of the new pressure or new force was assumed in this angular-average argument. This is a result about the proposed transport of the particular field. It is not a nonexistence result for different Navier-Stokes profiles or a dismissal of the cascade mechanism.

## 5. The actual scale schedule and the exact diffusion seen by its phase

Source (12.1)-(12.4), visually checked on pages 95-96, chooses
\[
 \beta=1/8,\quad\bar\beta=h=7/8,\quad a=4,\quad p=8,\quad q=10,
 \quad r=40,\quad d=16,\quad e=8,
\]
\[
 c_Q\ge2^{18},\quad q_0\ge2^{20},\quad Q_i=q_0+i,
 \quad u=q/c_Q,\quad v=q/(q_0+1),\quad h_*=h-dv.
\]
The letter \(r=40\) in this list is the source's exponent, not the physical radial coordinate. The strict requirements are
\[
 dv<1/16,\quad8u+100v<1/16,\quad9/c_Q+51/(q_0+1)<1.
\]
With the source scalar \(y=\log N_1\), a fixed positive initial frequency \(N_0\), and fixed \(s_0,C_\ell\),
\[
 N_1=e^y,\quad N_i=N_{i-1}^{Q_i}\ (i\ge2),\qquad
 \Pi_1=N_0^8y^{40},\quad\Pi_i=N_{i-1}^8(\log N_i)^{40}\ (i\ge2),
\]
\[
 \ell_1=s_0/(C_\ell N_0y^2),\quad\ell_i=N_{i-1}^{-4}\ (i\ge2),
 \quad\delta_i=\Pi_i^{16}N_i^{-7/8}.
\]
Here \(\delta_i\) is a correction parameter, not an insertion duration. The depth and seed are
\[
 k_i=\max\{k\in\mathbb N_0:k\le Q_i/c_Q,\ \mathcal K_{\rm ho}(k)\le\log N_i\},
 \quad J_i=2k_i+8,
\]
\[
 T_i^{\rm seed}=-N_i^{-k_i-8},\qquad
 \Lambda_i=(k_i+8-7/8)\log N_i.
 \tag{16}
\]
The source-defined function \(\mathcal K_{\rm ho}\) is fixed before \(y\), and \(k_i\to\infty\). No numerical value for the source's threshold or that function was independently computed here.

The clocks obey \(c_\sigma N_i^{1/8}\le\sigma_i^2\le C_\sigma N_i^{1/8}\), with \(\sigma_0=\sqrt{A_0}\). For \(i\ge2\),
\[
 s_i=\Lambda_i\sigma_{i-2}/\sigma_{i-1},\qquad
 \Gamma_i^{\rm gr}=\sigma_{i-1}\sin s_i,
\]
\[
 c_T\Lambda_i/\Gamma_i^{\rm gr}\le|I_i^{\rm gr}|
 \le|W_i|\le C'_T\Lambda_i/\Gamma_i^{\rm gr}
 \le C''_T/\sigma_{i-2}.
 \tag{17}
\]
Since \(\sin s\le s\), also \(|I_i^{\rm gr}|\ge c_T/\sigma_{i-2}\). The insertion times increase to finite \(T_*\). At the growth hit \(t_i^a\), the exact central amplitude condition is
\(-T_i(0,t_i^a)=N_i^{-7/8}\); hence its principal circulation gradient has magnitude
\(N_i^{1/8}|\zeta_i(0,t_i^a)|\). The complete force increments satisfy, with the same chosen sequence,
\[
 \|f_i\|_{C^k_{x,t}([0,T_*))}\le C_kN_i^{-1/2}\quad(k\le k_i),
 \qquad
 \sup_{t<T_*}(\|\gamma_i\|_\infty+\|J\nabla\psi_i\|_\infty)
 \le CN_i^{-1/2}.
 \tag{18}
\]
Source (14.4)-(14.5) gives a fixed \(c_*>0\) and fixed off-axis geometric factor with meridional vorticity at least \(c_*N_n^{1/8}\) for every \(t\ge\tau_{n+1}\). Inserting that lower bound in (15) gives a force lower bound of the same \(N_n^{1/8}\) order, after multiplying by the retained \(\nu_{\mathrm{vis}}/L\), for the transported field. This bound concerns the complete field and cannot be invalidated by cancellation among its correction levels.

For the phase calculation, keep the source's actual material flow \(X_m(a,t)\), inverse \(A_m(y,t)\), matrix \(H_m=(D_aX_m)^{-1}\), covector \(\zeta_m=H_m^Tp_m\), and phase \(s=N_mp_m\cdot A_m\), with \(|p_m|=1\). The principal circulation and streamfunction are
\[
 \gamma_{m,0}=(w_mT_mF(s)g_m(a))^\flat,\quad
 \psi_{m,0}=(w_mB_mP(s)g_m(a))^\flat,
 \quad\Omega_m=N_m^2\kappa_mB_m,
\]
\[
 \kappa_m=\zeta_m^TA(X_m)\zeta_m,\quad
 \widehat\Omega_m=\sigma_{m-1}\Omega_m/N_m,
 \quad\partial_t\binom{T_m}{\widehat\Omega_m}
 =\mathcal B_m\binom{T_m}{\widehat\Omega_m},
\]
\[
 \mathcal B_m=\begin{pmatrix}0&-d_m/(\sigma_{m-1}\kappa_m)\\
 \sigma_{m-1}c_m\zeta_{m,1}&0\end{pmatrix},\quad
 d_m=(J\zeta_m)\cdot(\nabla\Gamma_{<m})\circ X_m,\quad
 c_m=2(W\Gamma_{<m})\circ X_m.
 \tag{19}
\]
The source profile \(F\) is smooth, odd, \(2\pi\)-periodic, and exactly \(s\) near zero; \(P'=F\). It must not be replaced by a sinusoid or by a single Fourier mode.

Here is the exact chain rule including every lower derivative of the material map. Set \(B_{\rm ph}=\operatorname{diag}(1,2y_2)\), \(\phi=p_m\cdot A_m\), and use \(H_{kj}=\partial_{y_j}(A_m)_k\). For every smooth profile \(Q(s,a,t)\),
\[
\begin{split}
 D_\Gamma Q^\flat={}&\big[N_m^2\chi_m Q_{ss}
  +N_m(D_\Gamma\phi)Q_s
  +2N_m\sum_{j,k}(B_{\rm ph})_{jj}\zeta_{m,j}H_{kj}Q_{sa_k}\\
 &+\sum_{j,k,l}(B_{\rm ph})_{jj}H_{kj}H_{lj}Q_{a_ka_l}
  +\sum_k(D_\Gamma(A_m)_k)Q_{a_k}\big]^\flat,
\end{split}
 \tag{20}
\]
where \(\chi_m=\zeta_{m,1}^2+2y_2\zeta_{m,2}^2=2y_2\kappa_m\). All coefficients are evaluated at \(y=X_m(a,t)\). To prove (20), first apply
\(\partial_{y_j}Q^\flat=(N_m\zeta_{m,j}Q_s+\sum_kH_{kj}Q_{a_k})^\flat\), then differentiate once more and sum the diagonal coefficients of (7). The terms differentiating \(\zeta\) give \(D_\Gamma\phi\); those differentiating \(H\) give \(D_\Gamma(A_m)_k\). Thus no frozen-flow approximation was made. The exact expression for \(D_\xi Q^\flat\) adds
\(4[N_m\zeta_{m,2}Q_s+\sum_kH_{k2}Q_{a_k}]^\flat\).

In particular the circulation's highest phase residual from viscosity is
\(-\nu_{\mathrm{vis}}N_m^2\chi_mw_mT_mg_mF''\).
Although \(F''=0\) on the central linear interval, it is not identically zero: a periodic function with zero second derivative everywhere would be affine and periodic, hence constant, contradicting \(F'(0)=1\). The high derivative term therefore survives away from that interval. At the hit its coefficient has size proportional to \(\nu_{\mathrm{vis}}N_m^{9/8}\). This last statement is about a coefficient of the exact profile expression, not an unproved lower bound after summing all fields; (15) supplies the latter.

The physical radius and magnification do not eliminate viscosity. The source's physical radius change is \(x=z_0e_z+r_0\widehat x\), \(u=r_0\widehat u\), with time unchanged. Since \(\Delta_xu=r_0^{-1}\Delta_{\widehat x}\widehat u\), the coefficient in the unit-radius momentum equation is \(\nu_{\mathrm{vis}}/r_0^2\). The source next uses \(y=y_*+\varepsilon_{\rm geom}x'\), with \(y_*=(0,1/2)\) at unit radius. Equations (7) become
\[
 D_\Gamma=\varepsilon_{\rm geom}^{-2}
   (\partial_{x'_1}^2+c_{\rm geom}\partial_{x'_2}^2),\qquad
 D_\xi=\varepsilon_{\rm geom}^{-2}
   (\partial_{x'_1}^2+c_{\rm geom}\partial_{x'_2}^2
                   +4\varepsilon_{\rm geom}\partial_{x'_2}),
\]
where \(c_{\rm geom}=1+2\varepsilon_{\rm geom}x'_2\). Thus the schedule's magnified phase sees the fixed positive coefficient
\(\nu_{\rm eff}=\nu_{\mathrm{vis}}/(r_0^2\varepsilon_{\rm geom}^2)\),
and principal symbol \(\chi'_m=\zeta_{m,1}^2+c_{\rm geom}\zeta_{m,2}^2\). All factors are retained; reducing the fixed geometric scale increases this coefficient.

## 6. Explicit repairs and what they do to the amplification

The exact highest-phase repair of (19) is a heat equation in the full periodic phase, not a scalar adjustment of \(T_m\). With the same supplied material coefficients, define the two-component phase profile \(\mathcal U\) by
\[
 \partial_t\mathcal U=\mathcal B_m(a,t)\mathcal U
       +\nu_{\rm eff}N_m^2\chi'_m(a,t)\partial_s^2\mathcal U.
 \tag{21}
\]
Its solution for smooth periodic initial phase data is explicitly
\[
 \mathcal U(s,a,t)=\mathcal P_m(a;t,\tau_m)
  \sum_{j\in\mathbb Z}e^{ijs-j^2D_m(a,t)}\mathcal U_j(a,\tau_m),
 \quad D_m=\nu_{\rm eff}N_m^2\int_{\tau_m}^t\chi'_m(a,\theta)\,d\theta.
 \tag{22}
\]
Indeed, \(\partial_t\mathcal P_m=\mathcal B_m\mathcal P_m\), the matrix does not depend on \(s\), and differentiating each exponential supplies the second term in (21). Smooth periodic data have rapidly decaying Fourier coefficients, which justify termwise differentiation on each compact preterminal interval. For the actual source principal datum these coefficients equal a fixed vector times the Fourier coefficients of the actual \(F\). Oddness gives zero mean. Every nonzero phase mode is damped.

Equations (21)-(22) solve the highest-phase part exactly. They do not purport to solve the full Navier-Stokes correction hierarchy: its exact additional label derivatives, curvature terms, and nonlinear interactions are present in (20) and (8). In particular changing the principal flow alters that hierarchy and cannot inherit its Euler estimates without a new calculation.

There is already a quantitative result on the unchanged Euler history. The source's central covector and ellipticity bounds give a fixed \(\chi'_->0\). On the actual \(m\)-th growth interval, (17) proves for \(m\ge3\)
\[
 D_m(0,t_m^a)\ge\nu_{\rm eff}\chi'_-c_T N_m^2/\sigma_{m-2}
 \ge\frac{\nu_{\rm eff}\chi'_-c_T}{\sqrt{C_\sigma}}
       N_m^{\,2-1/(16Q_mQ_{m-1})}.
 \tag{23}
\]
The identity used is
\(N_{m-2}=N_m^{1/(Q_mQ_{m-1})}\), followed by
\(\sigma_{m-2}\le\sqrt{C_\sigma}N_{m-2}^{1/16}\).
The source gain is \(\Lambda_m=(k_m+57/8)\log N_m\), where
\(k_m\le Q_m/c_Q\). Since \(Q_m\le\log N_{m-1}\le\log N_m\),
\(\Lambda_m\le((\log N_m)/c_Q+57/8)\log N_m\).
On the other hand the exponent in (23) exceeds one, so \(D_m/\Lambda_m\to\infty\), by the elementary fact that \(e^x/x^2\to\infty\). Consequently even the smallest nonzero Fourier frequency in (22) acquires damping that exceeds the actual logarithmic gain by an unbounded factor. The unchanged seed and time schedule cannot retain its Euler phase amplification under this explicit repair. Increasing the seed to cancel that damping would multiply a nonzero Fourier coefficient by \(e^{j^2D_m}\), overwhelming the polynomially small seed (16); it is not a small perturbation of the stated data. This proves what happens to this concrete repair, without claiming that no redesigned cascade can work.

A second exact map changes the full velocity and retains the positive viscosity and the initial datum. Let \(S_t=e^{\nu_{\mathrm{vis}}t\Delta}\) and set
\[
 U=S_tu,\qquad P=S_tp_E,\qquad
 F=S_tf_E+(U\cdot\nabla)U-S_t((u\cdot\nabla)u).
 \tag{24}
\]
At \(t=0\), \(U=u_0\). Differentiation of the heat convolution and (1) gives
\(\partial_tU=\nu_{\mathrm{vis}}\Delta U+S_t\partial_tu\).
Spatial differentiation commutes with convolution. Substitution proves exactly
\[
 \partial_tU+(U\cdot\nabla)U+\nabla P
       =\nu_{\mathrm{vis}}\Delta U+F,\quad\operatorname{div}U=0
\]
at all preterminal times. All convolutions are legitimate there; a spatial constant can be subtracted from the source pressure outside its compact force region if desired.

This correction removes the sought velocity singularity. The heat kernel
\(K_t(x)=(4\pi\nu_{\mathrm{vis}}t)^{-3/2}e^{-|x|^2/(4\nu_{\mathrm{vis}}t)}\)
satisfies
\(\int|\nabla K_t|\,dx=2/\sqrt{\pi\nu_{\mathrm{vis}}t}\).
To check the constant, \(|\nabla K_t|=|x|K_t/(2\nu_{\mathrm{vis}}t)\); direct radial integration gives
\(\int|x|K_t\,dx=4\sqrt{\nu_{\mathrm{vis}}t/\pi}\).
Hence
\[
 \|\operatorname{curl}U(t)\|_\infty
 \le\frac{2}{\sqrt{\pi\nu_{\mathrm{vis}}t}}\|u(t)\|_\infty.
 \tag{25}
\]
The source's uniform velocity bound makes this uniformly finite for \(t\ge T_*/2\). The output force in (24) is established as smooth preterminally; all of its terminal time derivatives have not been proved bounded here. Neither (24) nor (22) is claimed as an admissible singular Navier-Stokes example. They are explicit corrections with their proved effects.

The completed calculation therefore locates the exact transferred forcing, the exact pressure freedom, the radial diffusion operators, the unchanged cascade's diffusion exponent, and two concrete correction maps. The direct transfer of the actual announced field loses even bounded forcing at terminal time; the repaired principal evolution suppresses its stated amplification; the full heat map suppresses its vorticity singularity. Constructing a different positive-viscosity singular profile with smooth terminal force remains unachieved by these calculations.

```

## Complete source: check_retained_cusp_bridge.py

```python
"""Exact algebra checks; analytic arguments are in the companion proof text."""
from pathlib import Path
import json
from fractions import Fraction
from itertools import product
import sympy as s

checks = []

def zero(name, value):
    entries = list(value) if isinstance(value, s.MatrixBase) else [value]
    assert all(s.cancel(v) == 0 for v in entries), name
    checks.append(name)

L, m, q, M = s.symbols('L m q M', nonzero=True, real=True)
aa, ab, ac, ad = s.symbols('aa ab ac ad', real=True)
A = s.Matrix([[aa, ab], [ac, ad]])
B = s.Matrix([[6*m, L], [-q, m]])
D = L*q + 6*m*m
Bi = s.Matrix([[m, -L], [q, 6*m]])/D
zero('retained B inverse', B*Bi-s.eye(2))
Q = A.row_join(M*s.eye(2)).col_join(B.row_join(s.zeros(2)))
Qi = s.zeros(2).row_join(Bi).col_join((s.eye(2)/M).row_join(-A*Bi/M))
zero('retained period right inverse', Q*Qi-s.eye(4))
zero('retained period left inverse', Qi*Q-s.eye(4))
zero('permuted orientation determinant', Q.det()-M**2*D)
K = Bi*Bi.T
Ke = s.Matrix([[m*m+L*L, m*q-6*m*L], [m*q-6*m*L, q*q+36*m*m]])/D**2
zero('all entries of upper metric block', K-Ke)
zero('retained two-form minor', K.det()-D**-2)
Gi = K.row_join(-K*A.T/M).col_join((-A*K/M).row_join((s.eye(2)+A*K*A.T)/M**2))
zero('full mixed metric entries', Gi-Qi*Qi.T)
zero('full inverse metric identity', (Q.T*Q)*Gi-s.eye(4))

# Quaternion staple formula with arbitrary real, non-unit coefficients.
h0, h1, h2, h3 = s.symbols('h0 h1 h2 h3', real=True)
sigma = [s.Matrix([[0,1],[1,0]]), s.Matrix([[0,-s.I],[s.I,0]]), s.diag(1,-1)]
H = h0*s.eye(2)+s.I*(h1*sigma[0]+h2*sigma[1]+h3*sigma[2])
r2 = h0*h0+h1*h1+h2*h2+h3*h3
zero('full quaternion staple norm', H*H.conjugate().T-r2*s.eye(2))
zero('full quaternion staple determinant', H.det()-r2)

# Verify the exact beta-integral coefficient recurrence at many orders.
for k in range(16):
    beta_val = s.gamma(s.Rational(1,2)+k)*s.gamma(s.Rational(3,2))/s.gamma(k+2)
    target = s.pi*s.factorial(2*k)/(2*4**k*s.factorial(k)*s.factorial(k+1))
    zero(f'Haar moment coefficient {k}', s.expand_func(beta_val)-target)

r = s.symbols('r')
Z = sum(r**(2*k)/(s.factorial(k)*s.factorial(k+1)) for k in range(18))
ode = s.diff(Z,r,2)+3*s.diff(Z,r)/r-4*Z
zero('Bessel radial ODE through degree 32', s.series(ode,r,0,33).removeO())
eta = s.series(s.diff(Z,r)/(2*Z),r,0,9).removeO()
zero('exact mean small-r coefficients', eta-(r/2-r**3/12+r**5/48-r**7/180))
zero('Haar second moment at zero', s.limit(eta/(2*r),r,0)-s.Rational(1,4))
zero('second-moment sum retains unit quaternion constraint', (1-3*eta/(2*r))+3*eta/(2*r)-1)

for N in range(2,14):
    for n1 in range(N):
        for n2 in range(N):
            h = -Fraction(n1*n2,N*N)
            h1 = -Fraction(((n1+1)%N)*n2,N*N)
            h2 = -Fraction(n1*((n2+1)%N),N*N)
            w1 = -Fraction(n2,N) if n1 == N-1 else Fraction(0)
            w2 = Fraction(n1,N*N)
            assert -h+w1+h1 == -Fraction(n2,N*N)
            assert -h+w2+h2 == (Fraction(n1,N) if n2 == N-1 else Fraction(0))
    checks.append(f'magnetic vertex gauge, every vertex and wrap, N={N}')

theta,b = s.symbols('theta b', real=True)
expH = s.diag(s.exp(s.I*theta),s.exp(-s.I*theta))
zero('retained six-staple background coefficient',
     s.expand_complex(b*(4*s.eye(2)+expH+expH.conjugate().T)-b*(4+2*s.cos(theta))*s.eye(2)))
zero('local full-star cost difference', 2*b*(2-2*s.cos(theta))-4*b*(1-s.cos(theta)))
zero('exact local r interval width', 6*b-b*(4+2*s.cos(theta))-2*b*(1-s.cos(theta)))

for N in (2,4,6,8):
    selected = {(n1,n2,n3,n4) for n1 in range(N)
                for n2,n3,n4 in product(range(1,N),repeat=3)
                if (n2+n3+n4)%2 == 1}
    assert len(selected) == N*((N-1)**3+1)//2
    degrees = {e:0 for e in selected}
    magnetic_count = magnetic_selected = 0
    for n in product(range(N+1),repeat=4):
        for i in range(4):
            for j in range(i+1,4):
                if n[i] == N or n[j] == N:
                    continue
                touches = []
                if i == 0:
                    upper = tuple(n[k]+int(k==j) for k in range(4))
                    touches = [e for e in (n,upper) if e in selected]
                assert len(touches) <= 1
                for e in touches:
                    degrees[e] += 1
                if (i,j) == (0,1):
                    magnetic_count += 1
                    magnetic_selected += len(touches)
    assert all(v==6 for v in degrees.values())
    assert magnetic_count == N*N*(N+1)**2
    assert magnetic_selected == 2*len(selected)
    checks.append(f'full 4D patch incidence and extensive integration counts, N={N}')

j = s.symbols('j', positive=True)
Nj = 2*j*j
mj = Nj*((Nj-1)**3+1)/2
pj = Nj**2*(Nj+1)**2
zero('bulk selected-star coverage limit', s.limit(2*mj/pj,j,s.oo)-1)
thetaj = 2*s.pi/(10000*j**6)
zero('retained leading extensive-action coefficient',
     s.limit(j**4*b*pj*thetaj**2,j,s.oo)-64*s.pi*s.pi*b/10**8)

receipt = {'status':'PASS','checks':checks,'check_count':len(checks),
           'scope':'Exact finite algebra and series coefficients only; not a quantum continuum calculation.'}
out = Path(__file__).with_name('RETAINED_CUSP_BRIDGE_CHECKS.json')
out.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':'PASS','check_count':len(checks),'receipt':str(out)}))

```

## Complete source: wilson_variation/check_wilson_exact.py

```python
"""Small exact algebra checks for wilson_finite_lattice.tex.

This verifies finite matrix identities and one product-rule identity. It does
not compute a Yang--Mills vacuum, any continuum limit, or any spectral gap.
Run: python check_wilson_exact.py
"""

import sympy as s


def su_basis(n):
    out = []
    for i in range(n):
        for j in range(i + 1, n):
            a, b = s.zeros(n), s.zeros(n)
            a[i, j], a[j, i] = s.Rational(1, 2), -s.Rational(1, 2)
            b[i, j] = b[j, i] = s.I / 2
            out.extend((a, b))
    for k in range(1, n):
        d = [1] * k + [-k] + [0] * (n - k - 1)
        out.append(s.I * s.diag(*d) / s.sqrt(2 * k * (k + 1)))
    return out


def zero(x):
    assert s.simplify(x) == 0, x


def matrix_zero(a):
    for x in a:
        zero(x)


checks = 0
for n in (2, 3, 4):
    basis = su_basis(n)
    assert len(basis) == n * n - 1
    for a, ta in enumerate(basis):
        matrix_zero(ta.H + ta)
        zero(s.trace(ta))
        for b, tb in enumerate(basis):
            zero(-2 * s.trace(ta * tb) - int(a == b))
            zero(-s.trace((2 * ta) * (2 * tb)) / 2 - int(a == b))
            checks += 2
    for i in range(n):
        for j in range(n):
            for k in range(n):
                for l in range(n):
                    lhs = sum(ta[i, j] * ta[k, l] for ta in basis)
                    rhs = -(s.Integer(i == l) * int(j == k)
                            - s.Rational(1, n) * int(i == j) * int(k == l)) / 2
                    zero(lhs - rhs)
                    checks += 1
    casimir = sum((ta * ta for ta in basis), s.zeros(n))
    matrix_zero(casimir + s.Rational(n * n - 1, 2 * n) * s.eye(n))
    checks += n * n

n = 3
basis = su_basis(n)
u = s.Matrix([[s.Rational(3, 5), s.Rational(4, 5), 0],
              [-s.Rational(4, 5), s.Rational(3, 5), 0], [0, 0, 1]])
r = s.Matrix([[1, 0, 0], [0, s.Rational(5, 13), 12 * s.I / 13],
              [0, 12 * s.I / 13, s.Rational(5, 13)]])
v = s.diag(s.I, -s.I, 1)
for m in (u, r, v):
    matrix_zero(m.H * m - s.eye(n))
    zero(m.det() - 1)

ap, am = u * r, v * u.H
wp, wm = s.trace(ap), s.trace(am)
dp = [s.trace(ta * u * r) for ta in basis]
dm = [-s.trace(u.H * ta * v) for ta in basis]
for ta, d in zip(basis, dm):
    zero(d + s.trace(ta * am))
    checks += 1
for a, w, ds in ((ap, wp, dp), (am, wm, dm)):
    zero(sum(d * s.conjugate(d) for d in ds)
         - (n * n - w * s.conjugate(w)) / (2 * n))
    zero(sum(d * d for d in ds)
         + (s.trace(a * a) - w * w / n) / 2)
    zero(sum(s.re(d) ** 2 for d in ds)
         - (n - s.re(s.trace(a * a)) - 2 * s.im(w) ** 2 / n) / 4)
    checks += 3

zero(sum(x * s.conjugate(y) for x, y in zip(dp, dm))
     + (s.trace(ap * am.H) - wp * s.conjugate(wm) / n) / 2)
zero(sum(x * y for x, y in zip(dp, dm))
     - (s.trace(ap * am) - wp * wm / n) / 2)
checks += 2

# A word with two occurrences of the same physical edge, with opposite signs.
a1, a2 = u * r * u.H * v, v * u * r * u.H
ds = [s.trace(ta * u * r * u.H * v - u * r * u.H * ta * v)
      for ta in basis]
for ta, d in zip(basis, ds):
    zero(d - s.trace(ta * a1) + s.trace(ta * a2))
    # Setting v=I makes the trace of u*r*u^-1 independent of u.
    zero(s.trace(ta * u * r * u.H - u * r * u.H * ta))
    checks += 2
rhs = 0
for eps, a in ((1, a1), (-1, a2)):
    for eta, b in ((1, a1), (-1, a2)):
        rhs += eps * eta * (s.trace(a * b.H)
                            - s.trace(a) * s.conjugate(s.trace(b)) / n) / 2
zero(sum(d * s.conjugate(d) for d in ds) - rhs)
checks += 1

# Exact local ground-state product rule in one coordinate, arbitrary functions.
x = s.symbols('x', real=True)
kappa = s.symbols('kappa', positive=True)
psi, f, g = (s.Function(z)(x) for z in ('psi', 'f', 'g'))
potential_minus_ground = kappa * s.diff(psi, x, 2) / psi
shifted_h = -kappa * s.diff(psi * g, x, 2) + potential_minus_ground * psi * g
identity = (psi * f * shifted_h
            - kappa * psi**2 * s.diff(f, x) * s.diff(g, x)
            + kappa * s.diff(psi**2 * f * s.diff(g, x), x))
zero(identity)
checks += 1

print(f'PASS: {checks} exact scalar assertions, plus exact matrix entries.')
print('Checked SU(2), SU(3), SU(4) Fierz normalization and Casimir; metric factor 4;')
print('oriented SU(3) loop contractions, repeated-edge terms, real trace, product rule.')
print('No interacting vacuum or continuum spectrum was computed.')

```

## Complete source: wilson_variation/check_temporal_coefficients.py

```python
"""Exact finite algebra checks for temporal_transfer.tex; no numerical limit."""
import sympy as s


def zero(value):
    assert s.simplify(value) == 0, value


def matrix_zero(value):
    for entry in value:
        zero(entry)


checks = 0
a, eps, g2, b, x = s.symbols('a eps g2 b x', positive=True)
bt = a / (2 * g2 * eps)
bs = eps / (2 * g2 * a)
zero(bt * (a * eps)**2 / (a**3 * eps) - 1 / (2 * g2))
zero(bs * a**4 / (a**3 * eps) - 1 / (2 * g2))
zero(bs / eps - 1 / (2 * g2 * a))
zero((2 * g2 / a) / 4 - g2 / (2 * a))
checks += 4


def bessel_polynomial(d, cutoff):
    return sum(b**(2 * r + d) / (s.factorial(r) * s.factorial(r + d))
               for r in range(cutoff + 1))


for d in range(1, 10):
    # Exact formal coefficients, no use of floating point or Bessel asymptotics.
    recurrence = (bessel_polynomial(d - 1, 10)
                  - bessel_polynomial(d + 1, 10)
                  - s.Integer(d) * bessel_polynomial(d, 10) / b)
    for power in range(d - 1, d + 18):
        zero(s.expand(recurrence).coeff(b, power))
        checks += 1
    character = s.chebyshevu(d - 1, x)
    zero(character.subs(x, 1) - d)
    zero(s.diff(character, x).subs(x, 1) / d - s.Rational(d*d - 1, 3))
    casimir = s.Rational(d*d - 1, 4)
    first_coefficient = s.Rational(d*d - 1, 3) * s.Rational(3, 4)
    zero(first_coefficient - casimir)
    zero((casimir / bt) / eps - 2 * g2 * casimir / a)
    checks += 4

# The two exact leading moment ratios arising from the gamma integrals.
zero(s.gamma(s.Rational(5, 2)) / (2 * s.gamma(s.Rational(3, 2)))
     - s.Rational(3, 4))
zero(s.gamma(s.Rational(7, 2)) / (4 * s.gamma(s.Rational(3, 2)))
     - s.Rational(15, 16))
checks += 2

# Metric convention and its unaltered kinetic coefficient.
sigma = [s.Matrix([[0, 1], [1, 0]]),
         s.Matrix([[0, -s.I], [s.I, 0]]),
         s.diag(1, -1)]
basis = [s.I * q / 2 for q in sigma]
for i, ta in enumerate(basis):
    for j, tb in enumerate(basis):
        zero(-2 * s.trace(ta * tb) - int(i == j))
        zero(-s.trace((2 * ta) * (2 * tb)) / 2 - int(i == j))
        checks += 2
matrix_zero(sum((ta * ta for ta in basis), s.zeros(2))
            + s.Rational(3, 4) * s.eye(2))


def q0(c, d):
    return s.Matrix([[c, d], [-d, c]])


def q1(c, d):
    return s.Matrix([[c, s.I * d], [s.I * d, c]])


u = q0(s.Rational(3, 5), s.Rational(4, 5))
up = q1(s.Rational(5, 13), s.Rational(12, 13))
vs = s.diag(s.I, -s.I)
vt = q0(s.Rational(8, 17), s.Rational(15, 17))
h0s, h0t, h1s, h1t = up, vt, u, vs
for value in (u, up, vs, vt):
    matrix_zero(value.H * value - s.eye(2))
    zero(value.det() - 1)
    checks += 1

plaquette = u * vt * up.H * vs.H
transformed_future = vs * up * vt.H
matrix_zero(plaquette.H - transformed_future * u.H)
zero(s.re(s.trace(plaquette))
     - s.re(s.trace(transformed_future * u.H)))
checks += 1

# Original inverse-transport gauge law h_source^-1 U h_target at both times.
u_h = h0s.H * u * h0t
up_h = h1s.H * up * h1t
vs_h = h0s.H * vs * h1s
vt_h = h0t.H * vt * h1t
p_h = u_h * vt_h * up_h.H * vs_h.H
matrix_zero(p_h - h0s.H * plaquette * h0s)
# Dictionary alpha_g=beta_h with g=h^-1.
gs, gt = h0s.H, h0t.H
matrix_zero(gs * u * gt.H - u_h)

# Symmetric endpoint magnetic weights produce one complete interior slice.
v0, v1, v2 = s.symbols('v0 v1 v2', real=True)
zero(eps * (v0 + v1) / 2 + eps * (v1 + v2) / 2
     - eps * (v0 / 2 + v1 + v2 / 2))
checks += 1

print(f'PASS: {checks} exact scalar assertions, plus exact matrix-entry checks.')
print('Checked anisotropic action coefficients, spin multiplier coefficients,')
print('SU(2) metrics/Casimir, temporal plaquette ordering, gauge dictionary,')
print('and symmetric magnetic endpoint weights. No numerical vacuum was used.')

```

## Complete source: wilson_variation/check_spatial_elimination.py

```python
"""Exact sign/coefficient checks; the unbounded-domain proofs are in the TeX.

The finite matrices below are an algebra diagnostic, not a numerical model
of the interacting Yang--Mills vacuum or a continuum approximation.
"""
import sympy as s


def zero(value):
    assert s.simplify(value) == 0, value


def matrix_zero(value):
    for entry in value:
        zero(entry)


checks = 0
x, y = s.symbols('x y', real=True)
kappa, z = s.symbols('kappa z', positive=True)
rho = s.Function('rho')(y, x)
marginal = s.Function('rho_R')(x)
f = s.Function('f')(x)
full_lift = -kappa * (s.diff(f, x, 2) + s.diff(rho, x) * s.diff(f, x) / rho)
reduced = -kappa * (s.diff(f, x, 2)
                    + s.diff(marginal, x) * s.diff(f, x) / marginal)
score = s.diff(rho, x) / rho - s.diff(marginal, x) / marginal
zero(full_lift - reduced + kappa * score * s.diff(f, x))
checks += 1

# The first retained basis vector is an exact zero-energy constant.
lmat = s.Matrix([[0, 0, 0], [0, 5, 2], [0, 2, 3]])
jmat = s.Matrix([[1, 0], [0, 1], [0, 0]])
amat = s.diag(0, 5)
bmat = s.Matrix([[0, 2]])
cmat = s.Matrix([[3]])
rmat = (cmat + z * s.eye(1)).inv()
schur = amat + z * s.eye(2) - bmat.T * rmat * bmat
matrix_zero(jmat.T * (lmat + z * s.eye(3)).inv() * jmat - schur.inv())
matrix_zero(jmat.T * lmat * jmat - amat)
matrix_zero(jmat.T * lmat**2 * jmat - amat**2 - bmat.T * bmat)
checks += 3

fvec = s.Matrix([0, 1])
wvec = rmat * bmat * fvec
uvec = jmat * fvec - s.Matrix([0, 0, wvec[0]])
base_energy = (fvec.T * amat * fvec)[0]
correction = (fvec.T * bmat.T * wvec)[0]
wnorm = (wvec.T * wvec)[0]
num = base_energy - correction - z * wnorm
den = (fvec.T * fvec)[0] + wnorm
zero((uvec.T * lmat * uvec)[0] - num)
zero((uvec.T * uvec)[0] - den)
zero((num / den).subs(z, 0) - s.Rational(33, 13))
zero((num / den - 5) - (-4 * (8 + 2 * z) / ((z + 3)**2 + 4)))
checks += 4

f1, f2, h = s.symbols('f1 f2 h', real=True)
fv = s.Matrix([f1, f2])
hv = s.Matrix([h])
v = jmat * fv + s.Matrix([0, 0, h])
square = ((fv.T * schur * fv)[0]
          + ((hv + rmat * bmat * fv).T
             * (cmat + z * s.eye(1)) * (hv + rmat * bmat * fv))[0])
zero((v.T * (lmat + z * s.eye(3)) * v)[0] - square)
checks += 1

# Formal short-time coefficient from the memory equation has the plus sign.
t = s.symbols('t', nonnegative=True)
kseries = s.eye(2) - t * amat + t**2 * (amat**2 + bmat.T * bmat) / 2
matrix_zero(kseries.diff(t).subs(t, 0) + amat)
matrix_zero(kseries.diff(t, 2).subs(t, 0) - amat**2 - bmat.T * bmat)
checks += 2

# Exact metric dictionary in the B term: X_c=2X, sigma_c=2sigma, kappa_c=kappa/4.
sigma, xf = s.symbols('sigma xf', real=True)
zero(-(kappa / 4) * (2 * sigma) * (2 * xf) + kappa * sigma * xf)
checks += 1

print(f'PASS: {checks} exact scalar/block assertions, plus exact matrix entries.')
print('Checked conditional-score cancellation, Schur inverse and reconstruction,')
print('square completion, corrected Rayleigh numerator/denominator, second moment,')
print('memory sign, and original metric factor. No vacuum approximation was used.')

```

## Complete source: adjacent_plaquette_quantum_correction.md

```markdown
# A nonzero quantum elimination correction on two adjacent Wilson plaquettes

8 September 2026. This is an explicit finite interacting calculation, not
a four-dimensional continuum mass-gap result. It evaluates a vacuum-dependent
elimination correction on a genuine gauge-invariant retained observable.

## 1. Original coefficients, graph and operator

Take two adjacent square plaquettes, P and Q, with a single common edge e,
six other distinct edges, and open boundary. This finite cell complex has
seven physical links; no link outside this specified complex is presumed
to have been integrated without its interaction. Choose orientations so
their ordered holonomies, after cyclic changes of their base vertices, are
\[
 P=U_e A,\qquad Q=U_e^{-1}B,
\]
where A and B are the ordered products of the respective three outer links.
Set \(W_P=\operatorname{tr}P\), \(W_Q=\operatorname{tr}Q\). These are real
for SU(2). Each Haar measure has total mass one; the total configuration
space is \(\mathcal Q=SU(2)^7\), with product measure \(d\lambda\).
Use the anti-Hermitian basis \(T_a=i\sigma_a/2\),
\(-2\operatorname{tr}T_aT_b=\delta_{ab}\), and the actual Hamiltonian
\[
 H= -\kappa\sum_{f=1}^7\Delta_f^T
       +b(4-W_P-W_Q),\qquad \kappa>0,\quad b>0.
\]
Every plaquette of this complex is retained. Its relation to the original
action convention \(c=-\operatorname{tr}/2\) is
\[
 \Delta^c=4\Delta^T,\qquad
 \kappa=\frac{2g_{\rm YM}^2}{a},\quad
 b=\frac1{2g_{\rm YM}^2a},\quad
 \xi:=\frac b\kappa=\frac1{4g_{\rm YM}^4}.
\]
Thus the small parameter below is a specified strong-coupling parameter,
not a removal of the interaction at the positive values under study.

The compact elliptic operator H has a unique strictly positive smooth
ground state. One proof is the strictly positive heat kernel for the
product Laplacian and its Feynman--Kac formula with the bounded real
potential. Compactness gives a lowest eigenfunction; replacing it by its
absolute value does not increase its form, and positivity improvement
makes the lowest eigenspace one-dimensional. Gauge transformations commute
with H and preserve positivity, so this ground state is gauge invariant.
Write its unit-L2 representative as \(\psi_\xi\), its eigenvalue as
\(E_\xi\), and \(d\mu_\xi=\rho_\xi d\lambda=\psi_\xi^2d\lambda\).
The unit-L2 convention fixes the state only: all scalar factors below are
retained explicitly.

## 2. Controlled first derivative of the actual vacuum

Let \(H_0=-\sum_f\Delta_f^T\). The exact operator identity is
\[
 H=\kappa[H_0-\xi(W_P+W_Q)]+4bI.
\]
The scalar \(4bI\) is not discarded from H; it changes its ground energy
by exactly 4b and leaves its ground vector and excitation differences
unchanged. The constant function is the simple zero eigenvector of H0,
and the next eigenvalue on the full link Hilbert space is 3/4, from the
spin-1/2 Casimir on one link. On the complex circle \(|z|=3/8\), the
resolvent of H0 has norm at most 8/3. Since \(|W_P+W_Q|\leq4\), its
resolvent Neumann series converges uniformly when \(|\xi|<3/32\).
The Riesz integral therefore gives an analytic rank-one eigenprojection
near zero. For real sufficiently small xi this is the ground projection;
the remainder of the spectrum stays separated by bounded perturbation.

Choose its analytic eigenvector \(\phi_\xi\) with
\(\int\phi_\xi d\lambda=1\). This fixes a representative, not the
physical state norm. Put
\[
 Z_\xi=\int\phi_\xi^2d\lambda,\qquad
 \psi_\xi=\phi_\xi/Z_\xi^{1/2},\qquad
 \rho_\xi=\phi_\xi^2/Z_\xi.
\]
Haar integration of a link appearing once gives \(\int W_P=\int W_Q=0\).
Each plaquette uses four links, each with Casimir 3/4, so
\(H_0W_P=3W_P\) and \(H_0W_Q=3W_Q\). Differentiating the eigen-equation
at xi=0, including its scalar eigenvalue, now gives
\[
 \phi_\xi=1+\frac\xi3(W_P+W_Q)+O(\xi^2),\qquad
 \log\rho_\xi=\frac{2\xi}3(W_P+W_Q)+O(\xi^2).
\]
The remainders hold in every fixed Ck norm. To justify this regularity,
start with the L2 analytic Riesz vector. The eigen-equation expresses H0
applied to that vector as multiplication by a fixed smooth function times
the vector, plus its scalar eigenvalue times the vector. The elliptic
estimate for the product Laplacian gains two Sobolev derivatives at each
iteration. Multiplication by the fixed Wilson polynomial is bounded in
each such Sobolev norm. Iterating also on the differentiated equations
gives analytic dependence in each fixed Sobolev norm; Sobolev embedding
then gives the stated fixed Ck bounds. Strict positivity near 1 permits
the ordinary logarithm with these same local analytic bounds.

The normalization factor is
\(Z_\xi=1+2\xi^2/9+O(\xi^3)\): the linear coefficient has zero mean,
its squared norm is 2/9, and every higher coefficient of phi has zero
mean by the chosen representative. This records rather than hides the
first state-normalization correction.

## 3. Eliminated link and the true conditional score

Let S consist of one outer edge of P which is not in Q, and let R contain
the other six edges. Use lower-case s and r for their configuration
variables. Define the actual marginal and lift
\[
 \rho_{R,\xi}(r)=\int\rho_\xi(s,r)d\lambda_S(s),\qquad Jf(s,r)=f(r).
\]
J is an isometry from \(L^2(\rho_{R,\xi}d\lambda_R)\) into
\(L^2(\mu_\xi)\). Its adjoint is the literal conditional integral
\[
 (J_\xi^*u)(r)=\rho_{R,\xi}(r)^{-1}
             \int u(s,r)\rho_\xi(s,r)d\lambda_S(s).
\]
Put \(P_\xi=JJ_\xi^*\) and \(Q_\xi=I-P_\xi\). These symbols denote
orthogonal Hilbert-space projections, not the two plaquette holonomies.
In particular the formula specifies every dependence of the projection
on the true vacuum.

The ground-state transformed nonnegative operator is
\[
 L_\xi=\psi_\xi^{-1}(H-E_\xi)\psi_\xi
       =-\kappa\sum_{f,a}\rho_\xi^{-1}X_{f,a}(\rho_\xi X_{f,a}).
\]
For a smooth retained function f, direct differentiation and conditional
integration give
\[
 L_\xi Jf=JA_\xi f+B_\xi f,
\]
\[
 A_\xi f=-\kappa\sum_{f'\in R,a}
       \rho_{R,\xi}^{-1}X_{f',a}(\rho_{R,\xi}X_{f',a}f),
\]
\[
 B_\xi f=-\kappa\sum_{f'\in R,a}
 (X_{f',a}\log\rho_\xi-X_{f',a}\log\rho_{R,\xi})X_{f',a}f.
\]
The last function has zero conditional mean, since differentiating the
marginal integral gives
\(J_\xi^*(X\log\rho_\xi)=X\log\rho_{R,\xi}\). Thus it is the actual
component in the eliminated subspace. No independent-link vacuum is used.

Choose the gauge-invariant retained observable
\(f_\xi=W_Q-\mu_\xi(W_Q)\). Haar integration over S annihilates WP
and all its derivatives on R, while leaving WQ unchanged. Therefore
\[
 B_\xi f_\xi=-\frac{2b}{3}\,G+O(b^2/\kappa),\qquad
 G:=\sum_{a=1}^3(X_{e,a}W_P)(X_{e,a}W_Q).
\]
Only the common edge contributes: all other derivatives of the two
plaquettes have disjoint supports. The remainder is in any fixed Sobolev
norm on this finite compact configuration space, at fixed kappa.

## 4. Exact color contraction and two eliminated eigencomponents

Set \(Q'=BU_e^{-1}\). Then trace Q'=trace Q and
\[
 X_{e,a}W_P=\operatorname{tr}(T_aP),\qquad
 X_{e,a}W_Q=-\operatorname{tr}(T_aQ').
\]
The SU(2) Fierz identity in this exact basis is
\[
 \sum_a\operatorname{tr}(T_aC)\operatorname{tr}(T_aD)
 =-\tfrac12[\operatorname{tr}(CD)-\tfrac12\operatorname{tr}C\operatorname{tr}D].
\]
It follows by substituting the three Pauli matrices, or equivalently their
entry identity \(\sum_a(T_a)_{ij}(T_a)_{kl}
=-\tfrac12(\delta_{il}\delta_{jk}-\tfrac12\delta_{ij}\delta_{kl})\).
Let
\[
 R_0=\operatorname{tr}(AB),\quad D_0=W_PW_Q,\quad
 D_1=D_0-\tfrac12R_0.
\]
R0 is the outer six-edge Wilson loop and is independent of the shared edge.
The contraction, with its opposite shared-edge orientation retained, is
\[
 G=\tfrac12R_0-\tfrac14D_0
   =\tfrac38R_0-\tfrac14D_1.
\]
To check all Haar inner products explicitly, for fixed Ue the products
P and Q' are independent Haar SU(2) matrices because A and B are products
of disjoint independent Haar edges. Write
\(P=p_0I+i\sum p_a\sigma_a\), \(Q'=q_0I+i\sum q_a\sigma_a\).
Each p or q is uniform on the unit three-sphere, so
\(\mathbb E p_\alpha p_\beta=\delta_{\alpha\beta}/4\), and the same
holds for q. Direct substitution gives
\[
 G=-\sum_{a=1}^3p_aq_a,\quad
 R_0=2(p_0q_0-\sum_ap_aq_a),\quad
 D_1=3p_0q_0+\sum_ap_aq_a.
\]
Consequently
\[
 \|R_0\|_\lambda^2=1,\qquad \|D_1\|_\lambda^2=\tfrac34,
 \quad\langle R_0,D_1\rangle_\lambda=0,
 \quad\|G\|_\lambda^2=\tfrac3{16}.
\]
Each of the six outer-link Laplacians acts on R0 and D1 by -3/4.
For the common edge, the product rule gives
\[
 \Delta_e^T D_0=-\tfrac32D_0+2G=R_0-2D_0=-2D_1,
 \qquad \Delta_e^T R_0=0.
\]
Therefore
\[
 \kappa H_0R_0=\tfrac{9\kappa}{2}R_0,\qquad
 \kappa H_0D_1=\tfrac{13\kappa}{2}D_1.
\]
Both have zero conditional mean over S, so these are also their
eigenvalues in the eliminated subspace at xi=0. In particular
\[
 B_\xi f_\xi=-\frac b4R_0+\frac b6D_1+O(b^2/\kappa),\qquad
 \|B_\xi f_\xi\|_{\mu_\xi}^2
      =\frac{b^2}{12}+O(b^3/\kappa).
\]
This proves that the eliminated quantum coupling on an actual retained
Wilson observable is nonzero for all sufficiently small positive b/kappa.
It is not a nonzero coupling assumed for an unspecified observable.

## 5. A full-system trial state with a strictly lower excitation energy

Let Cxi be the nonnegative self-adjoint operator associated to the closed
form of Lxi restricted to \(\ker J_\xi^*\). The form domain is the
intersection of that closed subspace with H1. The smooth positive density
and its derivatives are bounded above and below on the compact product.
The explicit conditional integral above is a bounded map on H1; therefore
the domain is closed in the form norm and dense in the eliminated
subspace, by applying Qxi to smooth approximations. This constructs Cxi
without assuming a domain for a formal operator product.

For z>0, define
\[
 w_{\xi,z}=(C_\xi+z)^{-1}B_\xi f_\xi,\qquad
 u_{\xi,z}=\psi_\xi(Jf_\xi-w_{\xi,z}).
\]
All conditional projections, operators and vectors here commute with the
vertex gauge action; hence u is a physical gauge-invariant state. Its
inner product with the vacuum is zero, since f is centered and w has
zero conditional mean. Put
\[
 d_\xi=\|f_\xi\|_{\rho_{R,\xi}}^2,\quad
 a_\xi=\kappa\sum_{f'\in R,a}\mu_\xi(|X_{f',a}f_\xi|^2),
 \quad I_{\xi,z}=\langle B_\xi f_\xi,w_{\xi,z}\rangle,
 \quad J_{\xi,z}=\|w_{\xi,z}\|^2.
\]
I is real and nonnegative. Testing the resolvent equation by w gives
\(\mathfrak c_\xi(w,w)=I_{\xi,z}-zJ_{\xi,z}\). The cross form between
Jf and w is exactly \(\langle B_\xi f,w\rangle\). Expanding the full
form and norm, with their cross terms, gives the exact two Rayleigh values
\[
 \mathcal R_{\rm retained}=\frac{a_\xi}{d_\xi},\qquad
 \mathcal R_{\rm full}(z)=
 \frac{a_\xi-I_{\xi,z}-zJ_{\xi,z}}{d_\xi+J_{\xi,z}},
\]
and the exact decrease
\[
 \mathcal R_{\rm retained}-\mathcal R_{\rm full}(z)
 =\frac{I_{\xi,z}+(z+\mathcal R_{\rm retained})J_{\xi,z}}
        {d_\xi+J_{\xi,z}}>0
\]
whenever Bxi fxi is nonzero. This is a constructed improved vector in the
original seven-link interacting Hilbert space, not an assignment of an
effective classical potential to a quantum energy.

For completeness the expansions of this resolvent as xi tends to zero
are controlled on the fixed compact complex. The densities and their
first derivatives differ from their xi=0 values by O(xi), uniformly.
The conditional integral formula implies
\(P_\xi-P_0=O(\xi)\) both on L2 and on H1. All Pxi have exactly the
same range, the functions of the retained links. Thus
\(P_\xi P_0=P_0\), \(P_0P_\xi=P_\xi\), and consequently
\(Q_0Q_\xi=Q_0\), \(Q_\xi Q_0=Q_\xi\).
On \(\ker P_0\), the map \(T_\xi=Q_\xi|_{\ker P_0}\)
therefore has the exact inverse \(Q_0|_{\ker P_\xi}\).
Both preserve H1 by the conditional integral bounds. This is an exact
identification of the moving form domains, not an assumption that the
conditional projections are independent of xi. After this
identification, the forms Cxi+z are uniformly coercive in H1 and differ
from the xi=0 form by O(xi) in H1 form norm. Subtracting their weak
resolvent equations and using coercivity proves an O(xi) difference of
solution maps from the dual of H1 to H1. Applying this to the already
proved \(B_\xi f_\xi=b(-R_0/4+D_1/6)+O(b\xi)\) justifies, without
an unproved interchange of spectra or projections,
\[
 w_{\xi,z}=-\frac{b}{4(9\kappa/2+z)}R_0
             +\frac{b}{6(13\kappa/2+z)}D_1+O(\xi^2)
\]
at fixed positive kappa and z. The error is in H1 and includes the
variation of the conditional projection and state density.

In particular, with the retained choice z=kappa,
\[
 I_{\xi,\kappa}=\frac{b^2}{\kappa}
           \left(\frac1{88}+\frac1{360}\right)+O(b^3/\kappa^2)
           =\frac{7b^2}{495\kappa}+O(b^3/\kappa^2),
\]
\[
 J_{\xi,\kappa}=\frac{b^2}{\kappa^2}
           \left(\frac1{484}+\frac1{2700}\right)+O(b^3/\kappa^3)
           =\frac{199b^2}{81675\kappa^2}+O(b^3/\kappa^3).
\]
Haar integration gives \(d_0=1\) and \(a_0=3\kappa\); their changes
are O(xi) with the respective retained scales. Substitution in the exact
decrease formula therefore proves the explicit positive coefficient
\[
 \boxed{\mathcal R_{\rm retained}-\mathcal R_{\rm full}(\kappa)
     =\frac{1951}{81675}\frac{b^2}{\kappa}
          +O(b^3/\kappa^2).}
\]
In the original coupling and spatial spacing this coefficient is
\(1951/[653400\,g_{\rm YM}^6a]\), with remainder of order
\(1/(g_{\rm YM}^{10}a)\) in the stated strong-coupling regime.

### 5.1 Absolute excitation energies, not only their difference

The absolute trial-state energies can also be computed to this order. Let
\(F=W_P+W_Q\), and write the mean-one vacuum representative as
\(\phi_\xi=1+\xi F/3+\xi^2\phi_2+O(\xi^3)\). Its eigen-equation and
mean constraint give
\[
 H_0\phi_2=(F^2-2)/3,\qquad \int\phi_2d\lambda=0.
\]
The subtracted 2 is the exact \(\int F^2d\lambda\), not a removed
plaquette. The identity \(W_Q^2=1+\chi_{\rm ad}(Q)\) follows by
\(2\cos\theta\) squared, with
\(\chi_{\rm ad}=1+2\cos2\theta\). The adjoint Casimir is 2 on each
of Q's four links, so \(H_0\chi_{\rm ad}(Q)=8\chi_{\rm ad}(Q)\).
The independent Haar holonomies P and Q satisfy
\[
 \int W_Q^2=1,\qquad\int W_Q^4=2,\qquad
 \int F^2W_Q^2=3,\qquad\int F^2\chi_{\rm ad}(Q)=1.
\]
For the fourth moment, \(W_Q=2q_0\) and the S3 marginal used above gives
\(\int q_0^4=1/8\), either by its beta integral or the corresponding
even moment recurrence. Cross terms vanish by Haar symmetry of P and Q.
Self-adjointness of H0 now yields
\[
 \int\phi_2 W_Q^2d\lambda
 =\int\phi_2\chi_{\rm ad}(Q)d\lambda=\frac1{24}.
\]
Using the full state-density expansion, including Zxi,
\[
 \rho_\xi=1+\frac{2\xi}3F
     +\xi^2\left(\frac{F^2}{9}+2\phi_2-\frac29\right)+O(\xi^3),
\]
therefore gives
\[
 r_\xi:=\mu_\xi(W_Q^2)=1+\frac7{36}\xi^2+O(\xi^3),\qquad
 \mu_\xi(W_Q)=\frac23\xi+O(\xi^2),
\]
\[
 d_\xi=r_\xi-\mu_\xi(W_Q)^2=1-\frac14\xi^2+O(\xi^3).
\]
For a single edge of the SU(2) loop,
\(\sum_a|X_{e,a}W_Q|^2=(4-W_Q^2)/4\), by the displayed Pauli
coordinates. Summing its four edges gives exactly
\(a_\xi=\kappa(4-r_\xi)\). Hence the absolute excitation Rayleigh
values relative to the same actual vacuum are
\[
 \boxed{\mathcal R_{\rm retained}
    =3\kappa+\frac59\frac{b^2}{\kappa}+O(b^3/\kappa^2),}
\]
\[
 \boxed{\mathcal R_{\rm full}(\kappa)
    =3\kappa+\frac{43424}{81675}\frac{b^2}{\kappa}
         +O(b^3/\kappa^2).}
\]
The latter coefficient is precisely
\(5/9-1951/81675=43424/81675\). The elimination correction decreases
the variational energy at the same positive coupling, but both trial
energies increase from their common zero-b value to this order. Neither
the decrease nor the positive second-order coefficients determine the
full spectrum or a limiting four-dimensional gap.

For completeness the energy origin is explicit as well. Taking the Haar
mean of the second-order eigen-equation gives
\(e(\xi)=-2\xi^2/3+O(\xi^3)\). The actual, unsubtracted Hamiltonian
therefore has vacuum energy
\[
 E_\xi=4b-\frac{2b^2}{3\kappa}+O(b^3/\kappa^2).
\]
Adding this same scalar to each excitation quotient gives the two trial
quotients for H itself:
\[
 3\kappa+4b-\frac19\frac{b^2}{\kappa}+O(b^3/\kappa^2),\qquad
 3\kappa+4b-\frac{11026}{81675}\frac{b^2}{\kappa}
       +O(b^3/\kappa^2),
\]
respectively. The mass-gap question concerns energies above the vacuum,
so the preceding excitation quotients, not this common scalar shift,
are the quantities used in the variational comparison.

## 6. Meaning and sources

The correction is already present in a nonlinear gauge-invariant quantum
calculation: it comes from covariance between a retained loop and the
eliminated link through their common plaquette edge. Its two explicit
Casimir channels, 9kappa/2 and 13kappa/2, supply the coefficient above.
The improved state still has an excitation Rayleigh value near 3kappa in
this regime. No small-energy continuum state or four-dimensional quantum
mass-gap disproof is inferred from this finite-complex result.

The exact general marginal, resolvent and trial-state identities are
proved in the companion source `spatial_vacuum_elimination.tex`; the
calculation above evaluates its nonzero coupling rather than assuming it.
The original coefficient dictionary is proved from the temporal Wilson
integral in `temporal_transfer.tex`. The compact-ground-state and Fierz
identities are expanded in `wilson_finite_lattice.tex`.

The general elimination method is established literature, not claimed as
a new discovery: G. Dusson, I. M. Sigal and B. Stamm,
*The Feshbach–Schur map and perturbation theory*, pp. 65–88 (2021),
<https://doi.org/10.4171/ECR/18-1/5>,
<https://arxiv.org/abs/2105.02058>.
The lattice Hamiltonian context is J. Kogut and L. Susskind,
*Hamiltonian formulation of Wilson's lattice gauge theories*,
Physical Review D 11 (1975), 395–408,
<https://doi.org/10.1103/PhysRevD.11.395>.

```

## Complete source: check_adjacent_plaquette.py

```python
"""Exact finite algebra for the adjacent-plaquette quantum correction.

The analytic ground-state and form-resolvent arguments are in the proof;
this script checks the original color, Haar and rational coefficients.
"""
from pathlib import Path
from hashlib import sha256
import json
import sympy as s

checks = []

def eq(name, value):
    assert s.expand(value) == 0, (name, value)
    checks.append(name)

p = s.symbols('p0:4', real=True)
q = s.symbols('q0:4', real=True)
sigma = [s.Matrix([[0, 1], [1, 0]]),
         s.Matrix([[0, -s.I], [s.I, 0]]), s.diag(1, -1)]
basis = [s.I*x/2 for x in sigma]
P = p[0]*s.eye(2) + sum((s.I*p[i+1]*sigma[i] for i in range(3)),s.zeros(2))
Q = q[0]*s.eye(2) + sum((s.I*q[i+1]*sigma[i] for i in range(3)),s.zeros(2))
dot = sum(p[i]*q[i] for i in range(1,4))
G = -sum(s.trace(t*P)*s.trace(t*Q) for t in basis)
R = s.trace(P*Q)
D = s.trace(P)*s.trace(Q)
D1 = D-R/2
eq('opposite-edge derivative contraction',G+dot)
eq('exact Fierz contraction',G-R/2+D/4)
eq('two-channel decomposition',G-s.Rational(3,8)*R+D1/4)
eq('outer trace coordinates',R-2*(p[0]*q[0]-dot))
eq('spin-one coordinates',D1-3*p[0]*q[0]-dot)

def haar_degree_two(poly):
    """Every argument has degree exactly two in each independent S^3 vector."""
    answer = s.S(0)
    for powers,coef in s.Poly(s.expand(poly),*(p+q)).terms():
        pp,qq=powers[:4],powers[4:]
        assert sum(pp)==sum(qq)==2
        if 2 in pp and 2 in qq:
            answer += coef/16
    return answer

eq('Haar R norm',haar_degree_two(R**2)-1)
eq('Haar D1 norm',haar_degree_two(D1**2)-s.Rational(3,4))
eq('Haar channel orthogonality',haar_degree_two(R*D1))
eq('Haar contraction norm',haar_degree_two(G**2)-s.Rational(3,16))
eq('Haar plaquette product norm',haar_degree_two(D**2)-1)

# Product rule for the common link: each fundamental trace has Δ=-3/4.
delta_D = -s.Rational(3,2)*D+2*G
eq('shared-edge spin-one Casimir',delta_D+2*D1)
eq('outer-loop free energy',6*s.Rational(3,4)-s.Rational(9,2))
eq('spin-one total free energy',6*s.Rational(3,4)+2-s.Rational(13,2))

k,b,z,g,a=s.symbols('kappa b z g a',positive=True)
eq('actual B leading coefficient',-2*b*G/3-(-b*R/4+b*D1/6))
eq('actual B squared leading norm',haar_degree_two((-2*b*G/3)**2)-b*b/12)
I_at_k=(b*b/(16*(s.Rational(9,2)*k+k))
        +b*b/(48*(s.Rational(13,2)*k+k)))
J_at_k=(b*b/(16*(s.Rational(9,2)*k+k)**2)
        +b*b/(48*(s.Rational(13,2)*k+k)**2))
eq('resolvent inner coefficient',I_at_k-s.Rational(7,495)*b*b/k)
eq('resolvent squared norm coefficient',J_at_k-s.Rational(199,81675)*b*b/k**2)
eq('Rayleigh improvement coefficient',I_at_k+4*k*J_at_k
   -s.Rational(1951,81675)*b*b/k)
eq('original coupling coefficient',
   s.Rational(1951,81675)*(1/(2*g**2*a))**2/(2*g**2/a)
   -s.Rational(1951,653400)/(g**6*a))
eq('original coupling parameter',(1/(2*g**2*a))/(2*g**2/a)-1/(4*g**4))

eq('vacuum second coefficient against loop square',s.Rational(1,3)/8-s.Rational(1,24))
r2=s.Rational(3,9)+2*s.Rational(1,24)-s.Rational(2,9)
eq('actual loop second moment coefficient',r2-s.Rational(7,36))
d2=r2-s.Rational(2,3)**2
eq('actual loop variance coefficient',d2+s.Rational(1,4))
ret2=-r2-3*d2
eq('absolute retained Rayleigh coefficient',ret2-s.Rational(5,9))
eq('absolute corrected Rayleigh coefficient',ret2-s.Rational(1951,81675)
   -s.Rational(43424,81675))

root=Path(__file__).resolve().parent
proof=root/'adjacent_plaquette_quantum_correction.md'
receipt={'status':'PASS','checks':checks,'check_count':len(checks),
         'proof_bytes':proof.stat().st_size,
         'proof_sha256':sha256(proof.read_bytes()).hexdigest(),
         'scope':'Exact coefficient checks; not a computed interacting vacuum or continuum gap.'}
(root/'ADJACENT_PLAQUETTE_CHECKS.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
print(json.dumps(receipt,indent=2))

```

## Complete source: wilson_variation/BULK_PLAQUETTE_EXTENSION.md

```markdown
# The adjacent-plaquette quantum correction in a full finite three-dimensional Wilson box

8 September 2026. All links and all elementary spatial plaquettes of the box are retained in the Hamiltonian. The only integration used to define the conditional projection eliminates one specified link from the **actual ground-state density**. This calculation neither replaces that density by a one-time Wilson density nor takes a spatial continuum or infinite-volume limit.

## 1. Exact statement, lattice, metric, and coupling dictionary

Let \(L\geq2\) be an integer. The vertices are

\[
\mathsf V_L=\{-L,-L+1,\ldots,L\}^3.
\]

There is one positively directed physical link \((n,i)\), from \(n\) to \(n+\mathbf e_i\), whenever both endpoints belong to \(\mathsf V_L\). Its variable is \(U_i(n)\in SU(2)\). A negatively traversed link contributes \(U_i(n)^{-1}\), not an independent variable. The set \(\mathsf E_L\) contains every such link. The set \(\mathsf P_L\) contains every elementary square \((n;i,j)\), \(1\leq i<j\leq3\), whose four vertices belong to \(\mathsf V_L\), with holonomy

\[
U_{n;i,j}=U_i(n)U_j(n+\mathbf e_i)
 U_i(n+\mathbf e_j)^{-1}U_j(n)^{-1},
\qquad W_{n;i,j}=\operatorname{tr}U_{n;i,j}.
\tag{1.1}
\]

Every \(W_p\) is real. There are

\[
N=|\mathsf E_L|=3(2L)(2L+1)^2,
\qquad M=|\mathsf P_L|=3(2L)^2(2L+1).
\tag{1.2}
\]

Indeed, a link direction has \(2L\) initial coordinates in that direction and \(2L+1\) choices in either transverse direction. A face plane has \(2L\) choices in each of its two directions and \(2L+1\) in the third. The three choices of direction, or plane, give (1.2). Boundary conditions are open; there are no periodic identifications.

Use \(T_a=-i\sigma_a/2\), \(a=1,2,3\), where \(\sigma_a\) are the Pauli matrices. Thus

\[
-2\operatorname{tr}(T_aT_b)=\delta_{ab},\quad
X_{e,a}f=\left.\frac{d}{dt}f(\ldots,e^{tT_a}U_e,\ldots)\right|_{t=0},
\quad \Delta_e^T=\sum_aX_{e,a}^2.
\tag{1.3}
\]

The companion two-plaquette calculation uses the opposite basis
\(T_a^{\mathrm{pair}}=+i\sigma_a/2\). The exact dictionary is
\(T_a=-T_a^{\mathrm{pair}}\), hence
\(X_{e,a}=-X_{e,a}^{\mathrm{pair}}\). It leaves
\(\sum_aX_{e,a}^2\) unchanged. Both factors in each derivative
contraction change sign: in particular
\(G=\sum_a(X_{e,a}W_P)(X_{e,a}W_Q)\) is unchanged, and the score
\(\sigma_{e,a}\) defined in (4.5) changes sign together with
\(X_{e,a}f\). Thus the operator B in (4.5), its norm, and the
Rayleigh coefficients below agree exactly with that convention.

The Hilbert space is \(\mathcal H=L^2(SU(2)^{\mathsf E_L},dU)\), where \(dU\) is product Haar probability measure. For \(\kappa,b>0\), the full nonlinear Wilson Hamiltonian is

\[
H_{\kappa,b}=-\kappa\sum_{e\in\mathsf E_L}\Delta_e^T
 +b\sum_{p\in\mathsf P_L}(2-W_p).
\tag{1.4}
\]

No term in either sum is dropped. Put \(\xi=b/\kappa\), \(H_0=-\sum_e\Delta_e^T\), and \(\mathcal V=\sum_{p\in\mathsf P_L}W_p\). Then the exact, including constant, identity is

\[
\boxed{H_{\kappa,b}=\kappa(H_0-\xi\mathcal V)+2bM\,I.}
\tag{1.5}
\]

The original metric is \(c(X,Y)=-\tfrac12\operatorname{tr}(XY)\), which is one quarter of the metric in (1.3). Its orthonormal basis is \(2T_a\), so \(X_{e,a}^c=2X_{e,a}\) and \(\Delta_e^c=4\Delta_e^T\). The original physical parameters are retained without substitution:

\[
\kappa=\frac{2g_{\mathrm{YM}}^2}{a},\qquad
b=\frac{1}{2g_{\mathrm{YM}}^2a},\qquad
\xi=\frac{1}{4g_{\mathrm{YM}}^4}.
\tag{1.6}
\]

Consequently the kinetic term in (1.4) is also

\[
-\frac{g_{\mathrm{YM}}^2}{2a}\sum_e\Delta_e^c.
\]

Let \(\psi_\xi>0\) be the normalized ground state of (1.4), \(\rho_\xi=\psi_\xi^2\), and \(E_\xi\) its ground energy. Define the particular faces and links

\[
Q=((0,0,0);1,2),\quad P=((-1,0,0);1,2),
\quad e=((0,0,0),2),\quad s=((-1,0,0),2).
\tag{1.7}
\]

Eliminate \(S=\{s\}\); retain \(R=\mathsf E_L\setminus\{s\}\). Write the retained centered observable as

\[
f_\xi=W_Q-\int W_Q\rho_\xi\,dU.
\tag{1.8}
\]

The conditional projection, the operator \(B_\xi\), the eliminated form operator \(C_\xi\), and the corrected physical vector \(u_\xi\) are defined in Sections 4 and 7 below, with their domains. The conclusions are

\[
\boxed{\|B_\xi f_\xi\|_{L^2(\rho_\xi dU)}^2
=\frac{b^2}{12}+O_L\!\left(\frac{b^3}{\kappa}\right),}
\tag{1.9}
\]

and

\[
\boxed{\mathcal R_{\mathrm{ret}}(\xi)-\mathcal R_{\mathrm{corr}}(\xi)
=\frac{1951}{81675}\frac{b^2}{\kappa}
 +O_L\!\left(\frac{b^3}{\kappa^2}\right).}
\tag{1.10}
\]

Here both quotients are exact quadratic-form Rayleigh quotients for \(H_{\kappa,b}-E_\xi\), the latter on a corrected full-system, gauge-invariant, vacuum-orthogonal vector. For each fixed \(L\), the remainders mean bounds by constants depending on that box for sufficiently small positive \(\xi\). The statements follow from convergent analytic perturbation locally at zero, not a formal substitution for the vacuum. In particular \(B_\xi f_\xi\ne0\) and the improvement is strict on an actual nonempty interval \(0<\xi<\epsilon_L\). No lower bound on \(\epsilon_L\) uniform in \(L\) is asserted.

The explicit resolvent Neumann disk supplied by the all-plaquette potential is

\[
\boxed{|\xi|<\frac{3}{16M}.}
\tag{1.11}
\]

It controls the isolated ground spectral projection as proved below. It is not an assertion that every local remainder estimate or strict-positivity test has the entire disk as its optimal radius.

## 2. Literal full-box incidence and orientations

A face containing the direction-2 link \(s=((-1,0,0),2)\) must lie in plane \(12\) or \(23\). In plane \(12\), it must extend from that link either in the positive or the negative direction 1. In plane \(23\), it must extend either in the positive or the negative direction 3. Thus its complete incidence star is

\[
\begin{split}
\mathsf I(s)=\{&((-1,0,0);1,2),\;((-2,0,0);1,2),\\
              &((-1,0,0);2,3),\;((-1,0,-1);2,3)\}.
\end{split}
\tag{2.1}
\]

All four faces exist when \(L\geq2\). This enumeration exhausts the possibilities because an elementary square has two coordinate directions, one of which must be the direction of its specified boundary link, and its unit transverse extent has only the two stated choices.

The last three faces in (2.1) have first coordinate at most \(-1\) at every vertex. Every vertex of \(Q\) has first coordinate 0 or 1. Hence each of those three faces has no vertex, and therefore no physical edge, in common with \(Q\). The remaining face is \(P\), and direct inspection of (1.1) gives

\[
\partial P\cap\partial Q=\{e\},\qquad
\{(p,i):p\in\mathsf I(s),\ i\in\partial p\cap\partial Q\}
=\{(P,e)\}.
\tag{2.2}
\]

The intersection here is of unoriented physical edges. The occurrence of \(e\) in \(P\) is positive, while its occurrence in \(Q\) is negative. The occurrence of \(s\) in \(P\) is negative. This proves the asserted incidence with no implicit exclusion of any other box plaquette.

For the based calculations, let

\[
\begin{split}
A&=U_1(-1,1,0)^{-1}U_2(-1,0,0)^{-1}U_1(-1,0,0),\\
B&=U_1(0,0,0)U_2(1,0,0)U_1(0,1,0)^{-1}.
\end{split}
\tag{2.3}
\]

Coordinates displayed as arguments are triples. Cyclically rotating the corresponding plaquette words in (1.1) gives the exactly equal Wilson traces of the based matrices

\[
P_*=U_eA,\qquad Q_*=U_e^{-1}B,\qquad Q'_*=BU_e^{-1}.
\tag{2.4}
\]

The products \(A,B\) use six distinct outer physical links and neither uses \(e\). The link \(s\) appears once, inversely, in \(A\), and does not appear in \(B\). The union of the two plaquette boundaries has exactly seven physical links. Every other link of the full box is still present in (1.4).

## 3. The actual all-plaquette vacuum and its controlled expansion

### 3.1 Free spectrum, bounded interaction, and the exact radius

On a single \(SU(2)\) factor with (1.3), the spin-\(j\) matrix coefficients have \(-\Delta^T\) eigenvalue \(j(j+1)\), for \(j=0,\tfrac12,1,\ldots\). To fix its normalization directly, \(T_a=-i\sigma_a/2\) gives \(-\sum_aT_a^2=\tfrac34I\) on the fundamental representation. On the spin-\(j\) representation the corresponding angular momenta satisfy \(J_3v_m=mv_m\) and \(J_\pm v_m=\sqrt{(j\mp m)(j\pm m+1)}v_{m\pm1}\); therefore \(J_3^2+(J_+J_-+J_-J_+)/2=j(j+1)I\). The matrix coefficients form the complete Peter--Weyl orthogonal decomposition. Taking their tensor products gives the complete product spectrum as sums of these eigenvalues. The free eigenvalue 0 is simple, represented by the constant 1, and the first nonzero eigenvalue on the full, not gauge-reduced, Hilbert space is \(3/4\).

Since \(W_p\in[-2,2]\), one has \(\|\mathcal V\|_\infty\leq2M\). At the all-identity configuration \(\mathcal V=2M\). Continuity and positive Haar measure of every neighborhood of that configuration give the reverse essential-supremum inequality. Thus

\[
\|\mathcal V\|_{\mathcal H\to\mathcal H}=2M.
\tag{3.1}
\]

For \(z\) on \(|z|=3/8\), the distance from \(z\) to the free spectrum is at least \(3/8\), so

\[
\|(z-H_0)^{-1}\|\leq\frac83.
\]

Factoring \(z-H_0+\xi\mathcal V\) gives a norm-convergent resolvent Neumann series whenever

\[
q:=\frac{16M}{3}|\xi|<1.
\tag{3.2}
\]

The contour projection

\[
\Pi_\xi=\frac{1}{2\pi i}\oint_{|z|=3/8}
 (z-H_0+\xi\mathcal V)^{-1}\,dz
\tag{3.3}
\]

is analytic throughout (1.11). Its rank is locally constant because it is a norm-continuous family of projections; the disk is connected, and its rank at zero is one. It therefore has rank one throughout that disk. This establishes (1.11) with the full \(2M\) potential norm and with no two-face replacement.

For real \(\xi\) in that interval, the bottom eigenvalue \(e(\xi)\) of \(H_0-\xi\mathcal V\) lies between \(-2M|\xi|\) and 0. The upper bound uses the constant trial vector and \(\int\mathcal V\,dU=0\). By the min--max principle the second eigenvalue is at least \(3/4-2M|\xi|>3/8\), whereas \(-3/8<e(\xi)\leq0\). Consequently (3.3) is the actual ground projection for every such real \(\xi\). The energy of (1.4) is exactly

\[
E_\xi=\kappa e(\xi)+2bM.
\tag{3.4}
\]

Existence of a smooth ground eigenfunction follows from compact resolvent and elliptic regularity of the compact product Laplacian with smooth bounded potential. It can be taken nonnegative: the local identity \(|\nabla|u||\leq|\nabla u|\), obtained first away from \(u=0\) and then by approximating \(|u|\) by \(\sqrt{|u|^2+\varepsilon^2}\), shows that replacing a minimizer by its modulus does not increase its form energy. The strong maximum principle for the resulting elliptic eigen-equation on this connected manifold makes that nonnegative eigenfunction strictly positive. Simplicity can also be checked directly: for a positive ground state \(\psi\), integration by parts and its eigen-equation give

\[
\langle\psi F,(H-E)\psi F\rangle
=\kappa\sum_{i,a}\int |X_{i,a}F|^2\psi^2\,dU
\tag{3.5}
\]

for smooth \(F\). Polarization and density extend this to the form domain. A second ground eigenfunction divided by \(\psi\) would make every derivative on the right vanish and hence would be constant. This also proves uniqueness of the positive normalized state used here.

### 3.2 Haar orthogonality and the first derivative

For each face \(p\), Haar integration over any one of its four distinct edges annihilates \(W_p\). Indeed, \(\int_{SU(2)}U\,dU=0\): multiplying the integration variable by the central element \(-I\) changes this integral to its negative. The same statement holds for \(U^{-1}\), and it remains true after multiplication by matrices independent of that edge. Thus \(\int W_p=0\).

For distinct elementary faces in an open box, their sets of four boundary edges differ. Choose an edge in one set absent from the other and integrate it first. This proves \(\int W_pW_q=0\) when \(p\ne q\). To justify the asserted difference of boundary sets without a geometric assumption, two adjacent perpendicular coordinate directions and the minima of the vertex coordinates are recovered from the four-edge set of an elementary square; this recovers its plane and lower corner uniquely. Finally \(\int W_p^2=1\): integrate three edges first or fix them and use Haar invariance on the fourth to reduce to \(\int_{SU(2)}(\operatorname{tr}U)^2dU\). With \(U=u_0I+i\sum_{a=1}^3u_a\sigma_a\), Haar measure is uniform on the unit sphere in \(\mathbb R^4\), so \(\int u_0^2=1/4\), and this integral is 1. We have proved

\[
\int W_pW_q\,dU=\delta_{pq},\qquad
\|\mathcal V\|_2^2=M,\qquad H_0W_p=3W_p.
\tag{3.6}
\]

The last identity uses four fundamental edge Casimirs \(3/4\), with all other edges acting trivially.

Choose the analytic ground representative \(\phi_\xi\) near zero by \(\int\phi_\xi dU=1\) and \(\phi_0=1\). This is a legitimate local analytic normalization: the resolvent bound gives

\[
\|\Pi_\xi-\Pi_0\|\leq\frac{q}{1-q},
\tag{3.7}
\]

by integrating the Neumann-series difference over a circle of length \(2\pi(3/8)\). For \(q<1/2\), \(\langle1,\Pi_\xi1\rangle\ne0\), and \(\phi_\xi=\Pi_\xi1/\langle1,\Pi_\xi1\rangle\) supplies the normalization. The spectral-projection disk (1.11) itself did not require this auxiliary choice of vector normalization on the full complex disk.

Differentiating \((H_0-\xi\mathcal V)\phi_\xi=e(\xi)\phi_\xi\) at zero and taking its Haar mean yields \(e'(0)=-\int\mathcal V=0\). The remaining equation and the normalization give

\[
H_0\phi'_0=\mathcal V,\qquad \int\phi'_0=0,
\qquad \phi'_0=\frac13\mathcal V.
\tag{3.8}
\]

These are expansions of the actual eigenvector. Their remainders hold in every fixed \(C^k\) norm, not only in \(L^2\). Here is the regularity argument. Define Sobolev norms on the compact product group by the elliptic operator \(H_0+1\). Multiplication by the fixed smooth function \(\mathcal V\) is bounded in each integer Sobolev norm, and \((H_0+1)^{-1}:H^m\to H^{m+2}\) is bounded. The equation

\[
\phi_\xi=(H_0+1)^{-1}\big[(e(\xi)+1+\xi\mathcal V)\phi_\xi\big]
\]

therefore upgrades analyticity successively from \(L^2\) to \(H^2,H^4,\ldots\). Sobolev embedding in the fixed dimension \(3N\) then gives analytic \(C^k\) representatives and bounded Taylor remainders on a sufficiently small disk. All constants may depend on \(L,k\). On the real interval, the chosen ground vector is positive by the preceding ground-state argument.

Set \(Z_\xi=\int\phi_\xi^2dU\) and \(\psi_\xi=\phi_\xi/\sqrt{Z_\xi}\), taking the square root that is positive for real \(\xi\) near zero. Because every higher Taylor coefficient of \(\phi_\xi\) has zero Haar mean, (3.6)--(3.8) give

\[
\begin{split}
\phi_\xi&=1+\frac\xi3\sum_{p\in\mathsf P_L}W_p+O_{L,k}(\xi^2),\\
Z_\xi&=1+\frac M9\xi^2+O_L(\xi^3),\\
\psi_\xi&=1+\frac\xi3\sum_{p\in\mathsf P_L}W_p+O_{L,k}(\xi^2),\\
\log\rho_\xi&=\frac{2\xi}{3}\sum_{p\in\mathsf P_L}W_p+O_{L,k}(\xi^2).
\end{split}
\tag{3.9}
\]

The \(M/9\) normalization coefficient explicitly records all the box plaquettes. Logarithms are taken of the actual positive density, which is uniformly close to 1 for sufficiently small real \(\xi\) in any fixed box.

## 4. Exact conditional projection and the surviving quantum coupling

Write \(U=(u,r)\), with \(u=U_s\), and define

\[
\rho_{R,\xi}(r)=\int_{SU(2)}\rho_\xi(u,r)\,du,
\quad p_\xi(u\mid r)=\frac{\rho_\xi(u,r)}{\rho_{R,\xi}(r)}.
\tag{4.1}
\]

Let \(Jf(u,r)=f(r)\), and let

\[
(J_\xi^*v)(r)=\int v(u,r)p_\xi(u\mid r)\,du.
\tag{4.2}
\]

Direct integration shows that \(J\) is an isometry from \(L^2(\rho_{R,\xi}dr)\) into \(L^2(\rho_\xi dU)\), and (4.2) is its adjoint. Define \(P_\xi=JJ_\xi^*\) and \(Q_\xi=I-P_\xi\). Then \(P_\xi\) is the orthogonal projection onto functions independent of \(u\), and \(\mathcal K_\xi=\operatorname{ran}Q_\xi=\ker J_\xi^*\).

Conjugating by the true vacuum gives the nonnegative operator

\[
\mathscr L_\xi=\psi_\xi^{-1}(H_{\kappa,b}-E_\xi)\psi_\xi
=-\kappa\sum_{i\in\mathsf E_L,a}
 \big[X_{i,a}^2+(X_{i,a}\log\rho_\xi)X_{i,a}\big],
\tag{4.3}
\]

with closed form

\[
q_\xi(v,w)=\kappa\sum_{i,a}\int
 \overline{X_{i,a}v}\,X_{i,a}w\,\rho_\xi dU,
\quad D(q_\xi)=H^1(SU(2)^{\mathsf E_L}).
\tag{4.4}
\]

The form domain equality follows because \(\rho_\xi\) is smooth, strictly positive, and bounded above and below on the finite compact configuration manifold. Formula (4.3) is obtained by the Leibniz rule, cancellation of the ground-state eigen-equation, and \(2X\log\psi=X\log\rho\); it retains the exact kinetic coefficient \(\kappa\).

For a retained smooth \(f\), the \(s\) derivatives vanish. Differentiating (4.1) under its finite compact integral gives

\[
X_{i,a}\log\rho_{R,\xi}
=\int (X_{i,a}\log\rho_\xi)p_\xi\,du
\quad(i\in R).
\]

It follows from (4.3) that the exact eliminated coupling is

\[
\begin{split}
B_\xi f&:=Q_\xi\mathscr L_\xi Jf
 =-\kappa\sum_{i\in R,a}\sigma_{i,a,\xi}X_{i,a}f,\\
\sigma_{i,a,\xi}&=X_{i,a}\log\rho_\xi-X_{i,a}\log\rho_{R,\xi},
\qquad J_\xi^*\sigma_{i,a,\xi}=0.
\end{split}
\tag{4.5}
\]

In particular second derivatives of \(f\) cancel exactly; no second-order term has been discarded in (4.5).

If \(p\in\mathsf I(s)\), integration over \(u\) kills \(W_p\), and also kills each \(X_{i,a}W_p\), \(i\in R\), since that derivative commutes with integration over \(u\). If \(p\notin\mathsf I(s)\), \(W_p\) is independent of \(u\). Consequently (3.9) gives, with \(C^k\) remainders,

\[
\begin{split}
\log\rho_{R,\xi}
 &=\frac{2\xi}{3}\sum_{p\notin\mathsf I(s)}W_p+O_{L,k}(\xi^2),\\
\sigma_{i,a,\xi}
 &=\frac{2\xi}{3}\sum_{p\in\mathsf I(s)}X_{i,a}W_p
   +O_{L,k}(\xi^2).
\end{split}
\tag{4.6}
\]

Since \(Xf_\xi=XW_Q\), its only nonzero derivatives belong to edges of \(Q\). Combining (2.2), (4.5), and (4.6) therefore leaves exactly one face-edge pair:

\[
B_\xi f_\xi=-\frac{2b}{3}G+O_{L,k}\!\left(\frac{b^2}{\kappa}\right),
\qquad G=\sum_{a=1}^3(X_{e,a}W_P)(X_{e,a}W_Q).
\tag{4.7}
\]

Every other face in the Hamiltonian contributed to (3.9) and (4.6); it disappears from the displayed first derivative only by the proved conditional cancellation or the proved edge-disjointness. Higher orders still contain the full interacting box.

## 5. Exact Fierz contraction, Haar norms, and free electric modes

Under \(U_e\mapsto e^{tT_a}U_e\), (2.4) yields

\[
X_{e,a}W_P=\operatorname{tr}(T_aP_*),\qquad
X_{e,a}W_Q=-\operatorname{tr}(T_aQ'_*).
\tag{5.1}
\]

The Pauli completeness identity

\[
\sum_a(\sigma_a)_{ij}(\sigma_a)_{kl}
=2\delta_{il}\delta_{jk}-\delta_{ij}\delta_{kl}
\]

gives, by multiplying by matrix entries and summing indices,

\[
\sum_a\operatorname{tr}(T_aC)\operatorname{tr}(T_aD)
=-\frac12\operatorname{tr}(CD)+\frac14\operatorname{tr}C\operatorname{tr}D.
\tag{5.2}
\]

Define functions on the **full** configuration space by

\[
R_0=\operatorname{tr}(AB),\qquad D_0=W_PW_Q,
\qquad D_1=D_0-\frac12R_0.
\tag{5.3}
\]

Since \(\operatorname{tr}(P_*Q'_*)=\operatorname{tr}(U_eABU_e^{-1})=R_0\), equations (5.1)--(5.2) give

\[
G=\frac12R_0-\frac14D_0
=\frac38R_0-\frac14D_1.
\tag{5.4}
\]

These functions are gauge invariant: \(W_P,W_Q\) are traces of closed holonomies, and \(AB\) is the closed six-edge outer loop after cancellation of the common edge. They have zero Haar conditional mean over \(s\). In fact \(R_0\) contains \(U_s^{-1}\) once, \(D_0\) contains it once in \(W_P\), and \(W_Q\) is independent of it; the Haar annihilation used in Section 3 proves each assertion.

For their norms, condition on \(U_e\). The disjoint outer-link products \(A,B\) are independent Haar-distributed matrices: for any fixed values of the other factors, a product containing a single Haar factor or its inverse is Haar by left/right invariance. Thus \(P_*=U_eA\) and \(Q'_*=BU_e^{-1}\) are independent Haar matrices even conditionally on \(U_e\). Write

\[
P_*=p_0I+i\sum_ap_a\sigma_a,\qquad
Q'_*=q_0I+i\sum_aq_a\sigma_a.
\]

The vectors \(p,q\) are independent uniform unit vectors in \(\mathbb R^4\). Their second moments are \(\mathbb E[p_\alpha p_\beta]=\delta_{\alpha\beta}/4\), and likewise for \(q\): off-diagonal moments vanish by sign symmetries, diagonal moments agree by rotational symmetry, and their sum is 1. Matrix multiplication and (5.1) now give

\[
G=-\sum_{a=1}^3p_aq_a,\quad
R_0=2\left(p_0q_0-\sum_{a=1}^3p_aq_a\right),\quad
D_1=3p_0q_0+\sum_{a=1}^3p_aq_a.
\tag{5.5}
\]

Set \(x=p_0q_0\), \(y=\sum_{a=1}^3p_aq_a\). The moments just proved give \(\mathbb E x^2=1/16\), \(\mathbb E y^2=3/16\), and \(\mathbb E xy=0\). Hence

\[
\|R_0\|_0^2=1,\quad \|D_1\|_0^2=\frac34,
\quad\langle R_0,D_1\rangle_0=0,
\quad\|G\|_0^2=\frac3{16}.
\tag{5.6}
\]

The subscript 0 denotes Haar inner product on the entire box. All additional link integrals are integrals of 1, so (5.6) contains no omitted factor depending on the number of additional links.

On any of the six outer links, \(R_0,D_0,D_1\) are linear combinations of fundamental matrix entries or inverse fundamental matrix entries. Each consequently has eigenvalue \(-3/4\) for that link Laplacian. On \(e\), \(R_0\) is independent of \(U_e\). The product rule, (5.4), and the fundamental plaquette Casimirs give

\[
\begin{split}
\Delta_e^T D_0
&=-\frac32D_0+2G
=R_0-2D_0=-2D_1,\\
\Delta_e^T R_0&=0,\qquad \Delta_e^T D_1=-2D_1.
\end{split}
\tag{5.7}
\]

On every link outside these seven, both \(R_0\) and \(D_1\) are constant. Such a link is in spin zero, with Casimir zero. Summing over **all** \(N\) links therefore gives the exact full-box identities

\[
H_0R_0=\frac92R_0,\qquad H_0D_1=\frac{13}{2}D_1.
\tag{5.8}
\]

Combining (4.7) and (5.4) yields

\[
B_\xi f_\xi=b\left(-\frac14R_0+\frac16D_1\right)
 +O_{L,k}(\kappa\xi^2).
\tag{5.9}
\]

As \(\rho_\xi=1+O_L(\xi)\), (5.6) proves

\[
\begin{split}
\|B_\xi f_\xi\|_\xi^2
&=b^2\left(\frac1{16}+\frac1{36}\frac34\right)
 +O_L(\kappa^2\xi^3)\\
&=\frac{b^2}{12}+O_L\!\left(\frac{b^3}{\kappa}\right).
\end{split}
\tag{5.10}
\]

In particular the positive leading coefficient is independent of the fixed box size, although the remainder is not.

## 6. The exact retained form and its first vacuum moments

For the centered \(f_\xi\), put

\[
m_\xi=\int W_Q\rho_\xi dU,\quad
r_\xi=\int W_Q^2\rho_\xi dU,\quad
d_\xi=\|Jf_\xi\|_\xi^2=r_\xi-m_\xi^2,
\]

and

\[
a_\xi=q_\xi(Jf_\xi,Jf_\xi)
=\kappa\sum_{i\in\partial Q,a}\int
 |X_{i,a}W_Q|^2\rho_\xi dU.
\tag{6.1}
\]

For any used edge of a simple \(SU(2)\) loop, its derivative is, up to an orientation sign, \(\operatorname{tr}(T_aC)\), with \(C\) a based version of its holonomy. Writing \(C=c_0I+i\sum_ac_a\sigma_a\) gives \(\operatorname{tr}(T_aC)=c_a\), so

\[
\sum_a|X_{i,a}W_Q|^2=\sum_ac_a^2
=1-\frac14W_Q^2.
\]

The four edges of \(Q\) give the exact identities

\[
a_\xi=\kappa(4-r_\xi),\qquad
\mathcal R_{\mathrm{ret}}(\xi)=\frac{a_\xi}{d_\xi}
=\kappa\frac{4-r_\xi}{r_\xi-m_\xi^2}.
\tag{6.2}
\]

The true vacuum is present in both moments. Equations (3.6) and (3.9) give \(m_\xi=2\xi/3+O_L(\xi^2)\). They also give \(r_\xi=1+O_L(\xi^2)\). For the latter claim, the linear term is \(\tfrac23\sum_p\int W_Q^2W_p\). If \(p\ne Q\), an edge of \(p\) outside \(Q\) annihilates the integral; if \(p=Q\), multiplying any one \(Q\)-edge by \(-I\) changes \(W_Q^3\) to its negative. Thus every summand is zero. Consequently

\[
d_\xi=1+O_L(\xi^2),\qquad
a_\xi=3\kappa+O_L(\kappa\xi^2),\qquad
\mathcal R_{\mathrm{ret}}(\xi)=3\kappa+O_L(\kappa\xi^2).
\tag{6.3}
\]

Strict positivity of \(d_\xi\) follows directly as well: the density has full support and the continuous nonconstant function \(W_Q\) cannot have zero variance.

## 7. Eliminated form domain and a genuine improved quantum vector

The definition of the eliminated operator does not assume that a formal product \(Q_\xi\mathscr L_\xi Q_\xi\) has any particular operator domain. First note that \(P_\xi,Q_\xi\) preserve \(H^1\). For \(i\in R\), differentiating (4.2) yields

\[
X_{i,a}J_\xi^*v
=J_\xi^*(X_{i,a}v)+J_\xi^*(\sigma_{i,a,\xi}v).
\tag{7.1}
\]

Conditional Cauchy--Schwarz bounds each right-hand term in \(L^2(\rho_{R,\xi})\) by the corresponding full \(L^2(\rho_\xi)\) norm, with the bounded score coefficient on the second term. The \(s\) derivative of \(P_\xi v\) is zero. This proves the \(H^1\) assertion. It also shows that \(P_\xi,Q_\xi\) preserve smooth functions. Smooth functions are dense in \(H^1\); applying \(Q_\xi\) to smooth approximants proves that

\[
\mathcal D_\xi=H^1\cap\mathcal K_\xi
\]

is dense in \(\mathcal K_\xi\), and is the form closure of its smooth elements. It is closed for the \(H^1\) norm because \(\mathcal K_\xi\) is closed in the weighted \(L^2\) norm. Thus \(q_\xi|_{\mathcal D_\xi}\) is a densely defined closed nonnegative form. Define \(C_\xi\) to be its self-adjoint operator by the explicit representation condition

\[
\begin{split}
D(C_\xi)=\{w\in\mathcal D_\xi: &\text{there is }h\in\mathcal K_\xi
\text{ with }q_\xi(v,w)=\langle v,h\rangle_\xi\text{ for all }v\in\mathcal D_\xi\},\\
C_\xi w&=h.
\end{split}
\tag{7.2}
\]

Put \(g_\xi=B_\xi f_\xi\in\mathcal K_\xi\), and define

\[
w_\xi=(C_\xi+\kappa)^{-1}g_\xi,
\qquad u_\xi=\psi_\xi(Jf_\xi-w_\xi).
\tag{7.3}
\]

Existence and uniqueness of \(w_\xi\) follow already by applying the coercive-form representation to \(q_\xi+\kappa\langle\cdot,\cdot\rangle_\xi\) on \(\mathcal D_\xi\). In particular \(w_\xi\in\mathcal D_\xi\). Since multiplication by the smooth positive \(\psi_\xi\) maps \(H^1\) to itself, \(u_\xi\) belongs to the full quadratic-form domain of \(H_{\kappa,b}\).

Moreover, \(\langle1,w_\xi\rangle_\xi=0\), since the constant belongs to the retained range. Centering (1.8) therefore proves \(\langle\psi_\xi,u_\xi\rangle=0\). The denominator \(d_\xi+\|w_\xi\|_\xi^2\) is positive, so the physical vector is nonzero.

All operators and this vector respect the Gauss constraint. In the convention \(U_e\mapsto g_{s(e)}U_eg_{t(e)}^{-1}\), Wilson traces, Haar measure, and the product kinetic energy are invariant. Uniqueness of the positive normalized vacuum makes \(\psi_\xi\) invariant. In (4.2), changing the eliminated variable by the corresponding left/right multiplications proves that conditional expectation intertwines the induced action on retained variables. Thus \(J,P_\xi,Q_\xi\), the closed forms, and their uniquely defined resolvents intertwine gauge transformations; \(f_\xi,g_\xi,w_\xi,u_\xi\) are invariant. The original convention \(U_e\mapsto h_{s(e)}^{-1}U_eh_{t(e)}\) is the same action with \(g_v=h_v^{-1}\) at every vertex. No gauge convention or coefficient is changed.

Set

\[
I_\xi=\langle g_\xi,w_\xi\rangle_\xi,
\qquad J_\xi^{\mathrm{num}}=\|w_\xi\|_\xi^2.
\tag{7.4}
\]

The superscript distinguishes this scalar from the lift \(J\). Testing the weak resolvent equation with \(w_\xi\) shows

\[
I_\xi=q_\xi(w_\xi,w_\xi)+\kappa J_\xi^{\mathrm{num}}\geq0.
\tag{7.5}
\]

For smooth \(Jf_\xi\), integration by parts against \(w_\xi\in H^1\), followed by (4.5) and \(P_\xi w_\xi=0\), gives \(q_\xi(Jf_\xi,w_\xi)=\langle g_\xi,w_\xi\rangle_\xi=I_\xi\). Orthogonality of the retained and eliminated ranges and (3.5) now give the **exact** corrected quotient

\[
\mathcal R_{\mathrm{corr}}(\xi)
:=\frac{\|(H_{\kappa,b}-E_\xi)^{1/2}u_\xi\|^2}{\|u_\xi\|^2}
=\frac{a_\xi-I_\xi-\kappa J_\xi^{\mathrm{num}}}{d_\xi+J_\xi^{\mathrm{num}}}.
\tag{7.6}
\]

Only form-domain membership is needed; an unproved operator-domain assertion about \(u_\xi\) is not used. Subtracting (7.6) from (6.2) gives

\[
\mathcal R_{\mathrm{ret}}-\mathcal R_{\mathrm{corr}}
=\frac{I_\xi+(\kappa+\mathcal R_{\mathrm{ret}})J_\xi^{\mathrm{num}}}
 {d_\xi+J_\xi^{\mathrm{num}}}.
\tag{7.7}
\]

If \(g_\xi\ne0\), then \(w_\xi\ne0\), and (7.5) gives \(I_\xi>0\). Since the retained form is nonnegative, (7.7) is then strictly positive. This is a correction of an actual excitation estimate in the full interacting Hilbert space, not the energy of a separately postulated marginal dynamics.

## 8. Resolvent expansion with the moving conditional kernel controlled

It remains to prove that the free modes (5.8) really determine the displayed second-order coefficient despite the changing density and the changing eliminated subspace. We work on a fixed Sobolev space and prove that step explicitly.

At \(\xi=0\), conditional expectation is ordinary Haar integration over \(s\), denoted \(P_0\). Integration commutes with every retained derivative and annihilates the integral of every \(s\) derivative by Haar invariance. Thus \(P_0\) commutes with \(H_0\) on smooth functions and, by the spectral or closed-form extension, on its natural domains. From (5.3) and Haar annihilation, \(R_0,D_1\in\mathcal K_0\). Equations (5.8) are therefore also the eigenvalue equations for \(C_0=\kappa H_0|_{\mathcal K_0}\).

Regard functions and projections for small real \(\xi\) on the same underlying unweighted \(L^2(dU)\) and \(H^1\) spaces. Equation (3.9) gives \(\rho_\xi=1+O_{L,1}(\xi)\), \(\rho_{R,\xi}=1+O_{L,1}(\xi)\), and \(p_\xi(u\mid r)=1+O_{L,1}(\xi)\). The integral formula (4.2) and Cauchy--Schwarz imply

\[
\|P_\xi-P_0\|_{L^2\to L^2}=O_L(|\xi|),\qquad
\|P_\xi-P_0\|_{H^1\to H^1}=O_L(|\xi|).
\tag{8.1}
\]

For the second bound, differentiate the kernel formula: its derivative is the integral of the differentiated input against \(p_\xi-1\), plus the input against a derivative of \(p_\xi\); both kernels have the stated \(O_L(|\xi|)\) supremum bound. Derivatives in the eliminated variable of the output are zero. This proves the bound in all first-derivative directions.

All \(P_\xi\) have exactly the same range, namely functions independent of \(s\), and act as the identity on that range. As operators on the common function space this gives

\[
P_\xi P_0=P_0,\quad P_0P_\xi=P_\xi,
\quad Q_0Q_\xi=Q_0,\quad Q_\xi Q_0=Q_\xi.
\tag{8.2}
\]

In particular

\[
T_\xi:=Q_\xi|_{\mathcal K_0}:\mathcal K_0\longrightarrow\mathcal K_\xi
\]

is a bounded bijection with inverse \(Q_0|_{\mathcal K_\xi}\). The same holds between the form spaces \(\mathcal D_0\) and \(\mathcal D_\xi\), and \(T_\xi-I=O_L(|\xi|)\) as a map from \(\mathcal D_0\) into \(H^1\), by (8.1).

On the fixed Hilbert form space \(\mathcal D_0=H^1\cap\mathcal K_0\), pull back the dimensionless resolvent form:

\[
\mathfrak a_\xi(v,h)
=\kappa^{-1}q_\xi(T_\xi v,T_\xi h)
 +\langle T_\xi v,T_\xi h\rangle_\xi.
\tag{8.3}
\]

Choose the explicit equivalent first-order Sobolev norm

\[
\|v\|_{H^1}^2=\|v\|_0^2+\sum_{i,a}\|X_{i,a}v\|_0^2.
\]

Then \(\mathfrak a_0(v,v)=\|v\|_{H^1}^2\). Density boundedness, (8.1), and Cauchy--Schwarz give

\[
|\mathfrak a_\xi(v,h)-\mathfrak a_0(v,h)|
\leq C_L|\xi|\|v\|_{H^1}\|h\|_{H^1}.
\tag{8.4}
\]

For sufficiently small \(|\xi|\), this also yields \(\mathfrak a_\xi(v,v)\geq\tfrac12\|v\|_{H^1}^2\). No estimate is required uniformly in \(L\).

Write

\[
g_1=-\frac14R_0+\frac16D_1,
\qquad g_\xi=\kappa\xi g_1+O_L(\kappa\xi^2)
\quad\hbox{in }L^2.
\tag{8.5}
\]

If \(h_\xi=T_\xi^{-1}w_\xi\), its exact weak equation is

\[
\mathfrak a_\xi(v,h_\xi)
=\kappa^{-1}\langle T_\xi v,g_\xi\rangle_\xi
=\xi\langle v,g_1\rangle_0
 +O_L(\xi^2)\|v\|_{H^1}.
\tag{8.6}
\]

The last remainder follows from (8.1), (8.5), and \(\rho_\xi-1=O_L(\xi)\). By (5.8), the unique vector satisfying \(\mathfrak a_0(v,h_1)=\langle v,g_1\rangle_0\) is

\[
h_1=(H_0+1)^{-1}g_1
=-\frac1{22}R_0+\frac1{45}D_1.
\tag{8.7}
\]

Subtract \(\xi\mathfrak a_\xi(v,h_1)\) from (8.6) and use (8.4). The resulting functional is \(O_L(\xi^2)\|v\|_{H^1}\). Test it with \(v=h_\xi-\xi h_1\); coercivity gives

\[
\|h_\xi-\xi h_1\|_{H^1}=O_L(\xi^2).
\]

Finally \(T_\xi h_1=h_1+O_L(\xi)\) in \(H^1\). We have proved the genuine moving-domain resolvent expansion

\[
\boxed{w_\xi=\xi\left(-\frac1{22}R_0+\frac1{45}D_1\right)
 +O_L(\xi^2)\quad\hbox{in }H^1.}
\tag{8.8}
\]

This argument uses no unverified derivative of an operator with changing domain and no finite-mode approximation to the interacting vacuum. The two modes suffice for the leading coefficient because the exact forcing has the leading term (8.5) and their free eigenvalues are known; every other box mode remains in the exact resolvent and in its proved remainder.

## 9. The exact second-order coefficient and its meaning

Equations (5.6), (8.5), (8.8), and \(\rho_\xi=1+O_L(\xi)\) give

\[
\begin{split}
I_\xi
&=\kappa\xi^2\left(\frac1{88}+\frac1{360}\right)
 +O_L(\kappa\xi^3)
=\frac7{495}\frac{b^2}{\kappa}
 +O_L\!\left(\frac{b^3}{\kappa^2}\right),\\
J_\xi^{\mathrm{num}}
&=\xi^2\left(\frac1{484}+\frac1{2700}\right)+O_L(\xi^3)
=\frac{199}{81675}\frac{b^2}{\kappa^2}
 +O_L\!\left(\frac{b^3}{\kappa^3}\right).
\end{split}
\tag{9.1}
\]

For example, the \(D_1\) contribution to \(I_\xi/(\kappa\xi^2)\) is \(\tfrac16\cdot\tfrac1{45}\cdot\tfrac34=1/360\); its contribution to \(J_\xi^{\mathrm{num}}/\xi^2\) is \(\tfrac1{45^2}\cdot\tfrac34=1/2700\). Thus the multiplicity and normalization of this second mode have not been suppressed.

Substituting (6.3) and (9.1) into the exact quotient difference (7.7), and using \(d_\xi+J_\xi^{\mathrm{num}}=1+O_L(\xi^2)\), yields

\[
\begin{split}
\mathcal R_{\mathrm{ret}}-\mathcal R_{\mathrm{corr}}
&=\kappa\xi^2\left(\frac7{495}+4\frac{199}{81675}\right)
 +O_L(\kappa\xi^3)\\
&=\frac{1951}{81675}\frac{b^2}{\kappa}
 +O_L\!\left(\frac{b^3}{\kappa^2}\right).
\end{split}
\tag{9.2}
\]

This proves (1.10). Together with (5.10) and (7.7), it proves the actual strict improvement for every sufficiently small positive \(\xi\) in each fixed full box. More explicitly, the proved remainder in (5.10) has an upper bound \(C_L\kappa^2\xi^3\) on some interval. Restricting that interval so \(C_L\xi<1/24\) gives \(\|g_\xi\|_\xi^2\geq\kappa^2\xi^2/24>0\). This deduction requires no sign assumption about any unknown higher coefficient.

In the original physical parameters (1.6), the leading difference is

\[
\frac{1951}{653400}\frac{1}{g_{\mathrm{YM}}^6a},
\qquad O_L\!\left(\frac{1}{g_{\mathrm{YM}}^{10}a}\right)
\tag{9.3}
\]

for the remainder. The exact Wilson constant shift is \(2bM=M/(g_{\mathrm{YM}}^2a)\). It contributes to \(E_\xi\) in (3.4) and cancels from the excitation operator \(H-E_\xi\), not from the Hamiltonian definition by omission.

The parameter conversion of the remainder scale, including its fixed numerical factor, is \(b^3/\kappa^2=1/(32g_{\mathrm{YM}}^{10}a)\); the corresponding leading scale is \(b^2/\kappa=1/(8g_{\mathrm{YM}}^6a)\).

The correction is an upper-bound improvement for the finite-box physical excitation gap: the spectral theorem and vacuum orthogonality give \(\operatorname{gap}(H|_{\mathrm{Gauss}})\leq\mathcal R_{\mathrm{corr}}<\mathcal R_{\mathrm{ret}}\) on the stated small-coupling interval. The retained quotient approaches \(3\kappa\), not zero, as \(\xi\to0\) at fixed \(\kappa\). A positive improvement of that quotient does not assert a vanishing gap. The explicit Neumann disk shrinks as \(M^{-1}\), and no other bound here removes that volume dependence. Thus the calculation establishes a genuinely full, finite, interacting three-dimensional spatial-lattice excitation correction without asserting a four-dimensional continuum mass-gap conclusion.

## 10. Provenance and exact checker

This extension supplies the full-box incidence, the all-plaquette vacuum expansion and norm/radius, and the controlled passage to the two leading free modes. The corresponding two-face calculation is in `../adjacent_plaquette_quantum_correction.md`; the general infinite-rank conditional-form construction is in `spatial_vacuum_elimination.tex`. All specific form-domain and coefficient arguments needed for this extension are reproduced above. The Schur/projection correction is not claimed as a new general method; primary-source attribution for that method is given in the companion proof (including Dusson--Sigal--Stamm, *The Feshbach--Schur map and perturbation theory*, arXiv:2105.02058v1, DOI `10.4171/ECR/18-1/5`). No new remote source retrieval was used for this bounded extension.

`check_bulk_plaquette_incidence.py` enumerates the entire open cubical graph and every face for \(L=2,3,4,5\). It checks the counts (1.2), face-edge containment, oriented occurrences of \(e,s\), the complete four-face star, the unique surviving pair (2.2), injectivity of elementary-face edge supports, and the exact rational Neumann-bound identity. Using rational arithmetic only, it checks the two free eigenvalues, \(1/12\), \(7/495\), \(199/81675\), \(1951/81675\), and the physical factor \(1951/653400\). These finite checks diagnose incidence and algebra; the continuum-free analytic and operator-domain proofs are Sections 3--9, not inferred from numerical computation.

```

## Complete source: wilson_variation/check_bulk_plaquette_incidence.py

```python
"""Exact full-open-box incidence and rational-coefficient diagnostics.

This enumerates the entire finite graph, not a two-face truncation.  It does
not approximate the vacuum, perform a continuum calculation, or use floating
point arithmetic.  The analytic argument is in BULK_PLAQUETTE_EXTENSION.md.
"""

from fractions import Fraction as F
from itertools import combinations, product


def shifted(vertex, axis):
    result = list(vertex)
    result[axis] += 1
    return tuple(result)


def oriented_boundary(face):
    vertex, (i, j) = face
    return (
        ((vertex, i), 1),
        ((shifted(vertex, i), j), 1),
        ((shifted(vertex, j), i), -1),
        ((vertex, j), -1),
    )


def edge_set(face):
    return {edge for edge, sign in oriented_boundary(face)}


q_face = ((0, 0, 0), (0, 1))
p_face = ((-1, 0, 0), (0, 1))
s_edge = ((-1, 0, 0), 1)
e_edge = ((0, 0, 0), 1)
expected_incident = {
    p_face,
    ((-2, 0, 0), (0, 1)),
    ((-1, 0, 0), (1, 2)),
    ((-1, 0, -1), (1, 2)),
}

assert dict(oriented_boundary(p_face))[e_edge] == 1
assert dict(oriented_boundary(q_face))[e_edge] == -1
assert dict(oriented_boundary(p_face))[s_edge] == -1
assert edge_set(p_face) & edge_set(q_face) == {e_edge}
assert len(edge_set(p_face) | edge_set(q_face)) == 7
assert len((edge_set(p_face) | edge_set(q_face)) - {e_edge}) == 6
assert s_edge not in edge_set(q_face)

box_results = []
for half_side in (2, 3, 4, 5):
    vertices = set(product(range(-half_side, half_side + 1), repeat=3))
    edges = {
        (vertex, axis)
        for vertex in vertices
        for axis in range(3)
        if vertex[axis] < half_side
    }
    faces = {
        (vertex, axes)
        for vertex in vertices
        for axes in combinations(range(3), 2)
        if all(vertex[axis] < half_side for axis in axes)
    }
    edge_count = 3 * (2 * half_side) * (2 * half_side + 1) ** 2
    face_count = 3 * (2 * half_side) ** 2 * (2 * half_side + 1)
    assert len(edges) == edge_count
    assert len(faces) == face_count
    assert all(edge_set(face) <= edges for face in faces)
    assert p_face in faces and q_face in faces

    incident = {face for face in faces if s_edge in edge_set(face)}
    assert incident == expected_incident
    intersections = {face: edge_set(face) & edge_set(q_face) for face in incident}
    assert intersections[p_face] == {e_edge}
    assert all(not common for face, common in intersections.items() if face != p_face)
    surviving_pairs = {
        (face, edge)
        for face in incident
        for edge in edge_set(face) & edge_set(q_face)
    }
    assert surviving_pairs == {(p_face, e_edge)}

    # Distinct elementary faces have an edge absent from the other face.
    # This is the incidence input to Haar orthogonality, checked without
    # quadratic pair enumeration by injectivity of the four-edge supports.
    assert len({frozenset(edge_set(face)) for face in faces}) == face_count

    # At the strict Neumann-radius boundary the norm bound is exactly one.
    radius = F(3, 16 * face_count)
    assert F(8, 3) * (2 * face_count) * radius == 1
    assert 2 * face_count * radius == F(3, 8)
    box_results.append((half_side, edge_count, face_count, radius))

# Haar mode norms and the actual dimensionless free electric eigenvalues.
norm_r = F(1)
norm_d = F(3, 4)
lambda_r = 6 * F(3, 4)
lambda_d = 6 * F(3, 4) + 2
assert lambda_r == F(9, 2)
assert lambda_d == F(13, 2)

g_r, g_d = -F(1, 4), F(1, 6)
h_r = g_r / (lambda_r + 1)
h_d = g_d / (lambda_d + 1)
assert h_r == -F(1, 22)
assert h_d == F(1, 45)
norm_g = g_r**2 * norm_r + g_d**2 * norm_d
i_coefficient = g_r * h_r * norm_r + g_d * h_d * norm_d
j_coefficient = h_r**2 * norm_r + h_d**2 * norm_d
improvement = i_coefficient + 4 * j_coefficient
assert norm_g == F(1, 12)
assert i_coefficient == F(7, 495)
assert j_coefficient == F(199, 81675)
assert improvement == F(1951, 81675)
assert improvement / 8 == F(1951, 653400)

for half_side, edges, faces, radius in box_results:
    print(f"L={half_side}: all {edges} links and {faces} faces; "
          f"unique surviving pair (P,e); Neumann radius {radius}")
print("PASS: exact orientation, whole-box incidence, Haar-support injectivity, "
      "free electric energies, and all correction coefficients.")

```

## Complete source: magnetic_translation_true_vacuum.md

```markdown
# Magnetic continuation, Gauss projection, and the interacting vacuum

8 September 2026. Complete finite-regulator calculation. The connection to
the original cusp is a map of its magnetic background into the full Wilson
Hilbert space. Every spatial plaquette and the original electric coefficient
are retained. No continuum vacuum or mass-gap conclusion is assumed.
Only the explicit regular-fibre period and magnetic-bundle data are used;
the claimed identification of a completed complex threefold with S6 is
not an input to this calculation.

## 1. Original objects and the reference-frame map

Let \(L\ge2\) be an integer. Vertices are \(n\in\{-L,\ldots,L\}^3\);
a physical edge \(e=(n,i)\) has positive direction i and exists whenever
n and \(n+e_i\) lie in the box. Its independent variable is
\(U_i(n)\in SU(2)\). Negative traversal uses its inverse. Every
elementary face \(p=(n;i,j)\), \(i<j\), is present, with
\[
 W_p(U)=\operatorname{tr}\bigl(U_i(n)U_j(n+e_i)
                 U_i(n+e_j)^{-1}U_j(n)^{-1}\bigr).
\]
There are \(N=3(2L)(2L+1)^2\) links and \(M=3(2L)^2(2L+1)\) faces.
The configuration manifold is \(Q=SU(2)^N\) and dU is product Haar
probability measure. The Hilbert inner product is conjugate-linear in
its first argument. Put \(T_a=-i\sigma_a/2\) and define
\[
 X_{e,a}f(U)=\left.\frac{d}{dt}\right|_{t=0}
 f(\ldots,e^{tT_a}U_e,\ldots),\qquad
 \Delta_e^T=\sum_{a=1}^3X_{e,a}^2.
\]
Haar invariance proves X is skew-adjoint. The original Lie metric is
\(c(A,B)=-\operatorname{tr}(AB)/2\): its orthonormal frame is 2T_a,
so \(\Delta_e^c=4\Delta_e^T\). The Hamiltonian is
\[
 H=-\kappa\sum_e\Delta_e^T+V,\qquad
 V=b\sum_p(2-W_p),\qquad
 \kappa=\frac{2g_{\rm YM}^2}{a},\quad
 b=\frac{1}{2g_{\rm YM}^2a},\quad \xi=\frac b\kappa.
\tag{1.1}
\]
Equivalently its kinetic coefficient in the original metric is
\(-g_{\rm YM}^2/(2a)\) times \(\sum_e\Delta_e^c\).
The full constant 2bM is part of H.

Gauge transformations act as
\((g\cdot U)_e=g_{s(e)}U_eg_{t(e)}^{-1}\).
Let \(R_gf(U)=f(g^{-1}\cdot U)\), and
\(\Pi=\int_{SU(2)^{\mathsf V}}R_g\,dg\).
Haar invariance gives \(R_g^*=R_{g^{-1}}\); averaging proves
\(\Pi^*=\Pi^2=\Pi\). Its range is the gauge-invariant Hilbert space.
The kinetic energy is bi-invariant on each link and the face traces are
invariant, so H and its closed quadratic form commute with Pi.

It is important to specify what is translated. Let M_e and R_e be,
respectively, the original magnetic and a fixed reference parallel
transport, in the same endpoint frames. Define
\[
 h_e=M_eR_e^{-1},\qquad (T_hf)(U)=f((h_e^{-1}U_e)_e).
\tag{1.2}
\]
Here the reference symbol R_e is not the gauge-representation operator R_g.
Under a frame change both transports change by endpoint conjugation;
therefore
\[
 M'_e=g_sM_eg_t^{-1},\quad R'_e=g_sR_eg_t^{-1},\quad
 h'_e=g_sh_eg_s^{-1},\quad R_gT_hR_g^{-1}=T_{h'}.
\tag{1.3}
\]
This proves the exact background-to-state covariance. Translating by
the magnetic transport while changing its frames but not those of the
reference would not be the same construction. In the original fixed
frames the flat reference is R_e=I. All statements below retain that
reference; no assertion that left multiplication is addition of arbitrary
non-Abelian connections is needed.

The original nonwrapping magnetic links, in the physical plane identified
explicitly below, are
\[
 h_1(n)=\exp(-\theta n_2 H_c),\quad h_2(n)=h_3(n)=I,
 \qquad H_c=i\sigma_3=-2T_3,\qquad
 \theta=\frac{2\pi a^2}{D},\quad D=L_Tq_T+6m_T^2.
\tag{1.4}
\]
The period parameters are \(L_T=\operatorname{Im}\tau_T\),
\(q_T=-\operatorname{Im}\beta_T\), \(m_T=\operatorname{Im}\mu_T\),
and D>0. The box is a nonwrapping physical patch; it is not the entire
periodic fibre with transition edges removed. In the original periodic
coordinates u, the underlying connection and transition are
\[
 d+2\pi u_1H_c\,du_2,\qquad
 G_k(u)=\exp(-2\pi k_1u_2H_c).
\]
Its exact finite-vertex frame change is
\(h(n)=\exp(-2\pi H_cn_1n_2/N_0^2)\), where N_0 is the number of
subdivisions in each original compact direction, not the number N of
links. It gives U_1=exp(-2pi H_c n_2/N_0^2) and U_2=I on nonwrapping
edges; on n_2=N_0-1 the second-direction link is exp(2pi H_c n_1/N_0).
These wrap factors and the full period-matrix map are retained in the
companion cusp calculation. The physical-coordinate dictionary for the
patch used here can also be written exactly. In original real coordinates
\((x_1,x_2,x_3,x_4)=(\operatorname{Re}z_1,\operatorname{Im}z_1,
\operatorname{Re}z_2,\operatorname{Im}z_2)\), the imaginary period block is
\[
 B=\begin{pmatrix}6m_T&L_T\\-q_T&m_T\end{pmatrix},\qquad
 \begin{pmatrix}u_1\\u_2\end{pmatrix}
 =\frac1D\begin{pmatrix}m_T&-L_T\\q_T&6m_T\end{pmatrix}
       \begin{pmatrix}x_2\\x_4\end{pmatrix}.
\]
The real period block and the covered real periods are not set to zero:
they determine the other coordinates in the full period map; they do not
enter this displayed exact inverse for u_1,u_2. Choose Euclidean temporal
coordinate y_0=x_3 and spatial coordinates
\((y_1,y_2,y_3)=(x_2,x_4,x_1)\). The full permutation
\((y_0,y_1,y_2,y_3)=(x_3,x_2,x_4,x_1)\) has determinant +1 and
preserves the Euclidean metric; thus no scale or orientation is suppressed.
Direct exterior multiplication gives
\(du_1\wedge du_2=D^{-1}dy_1\wedge dy_2\).

The original connection on this patch is exactly
\[
 A_{\rm orig}=\frac{2\pi H_c}{D^2}
 (m_Ty_1-L_Ty_2)(q_Tdy_1+6m_Tdy_2).
\]
Set \(\mathfrak b=2\pi/D\) and
\[
 f(y)=\frac{2\pi}{D^2}
 \left(\frac{m_Tq_T}{2}y_1^2-L_Tq_Ty_1y_2-3m_TL_Ty_2^2\right).
\]
Expanding both components proves
\(A_{\rm orig}=\mathfrak bH_c y_1dy_2+H_cdf\).
The frame change exp(-H_c f), under
\(A\mapsto g^{-1}Ag+g^{-1}dg\), therefore gives
\(A_0=\mathfrak bH_c y_1dy_2\). The further frame change
\(\exp(-\mathfrak bH_c y_1y_2)\) gives
\(A_1=-\mathfrak bH_c y_2dy_1\). These are exact frame maps of the
same magnetic connection, with all m_T,L_T,q_T terms shown. Using the
stated inverse-parallel-transport convention, integrating A_1 over
the edge from y=a n to y+a e_i gives precisely (1.4).
The reference R_e=I in (1.2) is chosen in this final displayed frame;
subsequent frame changes act on it as well as on M_e by (1.3).
The 12-face holonomy is exp(theta H_c); the 13 and 23 holonomies are I.

## 2. Actual vacuum and exact finite-translation identities

The product Laplacian on this compact connected manifold is elliptic,
with domain \(H^2\) and closed form domain \(H^1\). V is smooth and bounded, so
H has the same domains and compact resolvent. Its bottom eigenvector
can be chosen nonnegative: taking the absolute value does not increase
the gradient form, as follows by differentiating
\(\sqrt{|u|^2+\varepsilon^2}\) and passing to the limit. Elliptic
regularity and the strong maximum principle give a smooth strictly
positive eigenvector psi. Choose \(\int\psi^2dU=1\), let E be its
eigenvalue, and put \(\mathcal A=H-E\).

For a smooth function F, integration by parts and H psi=E psi give
\[
 \mathfrak q_{\mathcal A}[\psi F]
 =\kappa\sum_{e,a}\int |X_{e,a}F|^2\psi^2\,dU.
\tag{2.1}
\]
The same formula after polarization holds on H1 by density. If another
ground eigenfunction existed, its quotient by the positive psi would
make the right hand side zero, hence be constant on Q. This proves
simplicity. Gauge transformations preserve the positive normalized
ground state, so \(\Pi\psi=\psi\). Compactness and simplicity give
a positive finite-regulator first excited energy, but no uniform bound
as L or a varies is asserted here.

Translation T_h is unitary by Haar invariance, preserves smooth functions
and all Sobolev spaces, and commutes with the full electric Laplacian.
Define
\[
 c_h=\langle\psi,T_h\psi\rangle,
 \qquad \chi_h=\Pi T_h\psi-c_h\psi.
\tag{2.2}
\]
The scalar c_h is real and positive, since both pointwise functions in
the integral are positive. The state is gauge invariant, smooth, and
vacuum orthogonal. Its exact norm and excitation form energy are
\[
 d_h=\|\chi_h\|^2
 =\langle T_h\psi,\Pi T_h\psi\rangle-c_h^2,
\qquad
 n_h=\mathfrak q_{\mathcal A}[\Pi T_h\psi].
\tag{2.3}
\]
When d_h>0 its Rayleigh quotient is n_h/d_h. No division by a presumed
nonzero norm is made.

There is also an exact comparison with the unprojected state:
\[
 0\le n_h\le\mathfrak q_{\mathcal A}[T_h\psi]
 =\int\psi(U)^2\,[V((h_eU_e)_e)-V(U)]\,dU.
\tag{2.4}
\]
Indeed Pi commutes with the nonnegative operator A, so its retained and
orthogonal components have additive nonnegative energies. The last
identity follows from
\(T_h^*HT_h=H+V(hU)-V(U)\) and H psi=E psi. Thus even the
unprojected magnetic energy is an average in the actual vacuum, not
the action of the magnetic configuration alone. Formula (2.4) supplies
an energy numerator, not a lower bound on d_h.

## 3. General infinitesimal projection, with the zero branch resolved

For real coefficients alpha_{e,a}, set
\(A_e=\sum_a\alpha_{e,a}T_a\),
\(Y=\sum_{e,a}\alpha_{e,a}X_{e,a}\), and
\(h_e(t)=\exp(tA_e)\). Then \(T_t=\exp(-tY)\) exactly.
All expansions in this section are applied to smooth psi in any fixed
Sobolev norm. Taylor's formula for the smooth translation flow, with
its bounded integral remainder on the compact group, justifies every
term and its form-domain use.

The conjugation rule obtained by differentiating (1.3) is
\[
 R_gX_e(A)R_g^{-1}=X_e(\operatorname{Ad}_{g_{s(e)}}A).
\tag{3.1}
\]
The adjoint SU(2) representation acts by all rotations on the three real
coefficients in the chosen orthonormal Lie basis. Haar averaging of a
vector is zero. Averaging a pair gives
\(\int(\operatorname{Ad}_g u)_a(\operatorname{Ad}_g v)_b,dg
=(u\cdot v)\delta_{ab}/3\): invariance makes the matrix scalar, and
its trace is u dot v. Different vertices have independent Haar variables.
Applying these identities to invariant psi proves
\[
 \Pi Y\psi=0,\qquad
 K_2\psi:=\Pi Y^2\psi
 =\frac13\sum_v\sum_{s(e)=s(f)=v}
 (\alpha_e\cdot\alpha_f)\sum_a X_{e,a}X_{f,a}\psi.
\tag{3.2}
\]
The second sum is ordered: e=f terms and both orders of unequal edges
are retained. The grouping is by the sources of the chosen positive
edges, not by an unrecorded change to incoming-edge derivatives.

Since Y is skew-adjoint and psi is real, its overlap has
\(c'(0)=\langle\psi,-Y\psi\rangle=0\) and
\(c''(0)=\langle\psi,Y^2\psi\rangle=-\|Y\psi\|^2\).
Define
\[
 S=\|Y\psi\|^2,\qquad \eta=K_2\psi+S\psi.
\]
Then the exact centered physical state obeys
\[
 \chi_t=\frac{t^2}{2}\eta+O_{H^1}(t^3),\qquad
 \|\chi_t\|^2=\frac{t^4}{4}\|\eta\|^2+O(t^5),
\quad
 \mathfrak q_{\mathcal A}[\chi_t]
 =\frac{t^4}{4}\mathfrak q_{\mathcal A}[\eta]+O(t^5).
\tag{3.3}
\]
The energy remainder follows from continuity of the form on H1;
it is not obtained by treating an unbounded Hamiltonian as bounded.

There is no unexamined branch where eta vanishes but a later derivative
is the first excitation. The Haar integral of every X derivative is zero,
so \(\int K_2\psi\,dU=0\). If eta=0, integrating its defining
identity gives \(S\int\psi\,dU=0\); positivity of psi gives S=0.
Hence Y psi=0, the translation flow fixes psi, and chi_t=0 for every t.
Conversely that identity implies eta=0. Therefore a translation either
fixes the vacuum exactly or has strictly positive quartic leading norm.
In the nontrivial case the finite-regulator limiting excitation quotient is
\[
 \lim_{t\to0}\frac{\mathfrak q_{\mathcal A}[\chi_t]}{\|\chi_t\|^2}
 =\frac{\mathfrak q_{\mathcal A}[\eta]}{\|\eta\|^2}>0.
\tag{3.4}
\]
Strict positivity follows because eta is nonzero, gauge invariant and
orthogonal to psi, whose eigenvalue is simple. This statement holds at
fixed regulator and arbitrary positive original coupling. It does not
take L to infinity or a to zero.

## 4. Exact class-convolution map for the native magnetic translation

For (1.4), there is at most one nonidentity translated edge with any given
source vertex. Conjugating T_h by R_g and averaging therefore factorizes
into independent averages for these edges. On invariant inputs,
\[
 \Pi T_h\Pi=K_\theta\Pi,\qquad
 K_\theta=\prod_{e=(n,1)}C_{e,\theta n_2},
\tag{4.1}
\]
where the full single-edge operator is
\[
 C_{e,s}f(U)=\int_{SU(2)}
 f(\ldots,(g e^{-sH_c}g^{-1})^{-1}U_e,\ldots)\,dg.
\tag{4.2}
\]
Different link factors commute. Every C is a contraction and preserves
positive functions, since it averages unitary translations with a
probability measure. Its conjugacy-class measure is central and invariant
under inversion: in SU(2), e^{sH_c} and e^{-sH_c} are conjugate, for example
by i sigma_1. Consequently C is self-adjoint and even in s. These facts
do not claim it has nonnegative spectral eigenvalues.

Here is its exact Peter--Weyl action, including all representations. On
a spin-j matrix coefficient on edge e, j=0,1/2,1,..., averaging the
conjugated representation matrix commutes with the irreducible SU(2)
representation. It is scalar by Schur's lemma, and its trace fixes that
scalar to the character divided by the dimension. The weights
m=-j,-j+1,...,j give
\[
 c_j(s)=\frac{1}{2j+1}\sum_{m=-j}^j e^{2ims}
 =\frac{\sin((2j+1)s)}{(2j+1)\sin s}.
\tag{4.3}
\]
The sum is the definition at sin s=0 and gives its continuous value;
no singular denominator is used there. Since the product coefficients
are a complete orthogonal basis, (4.3) defines K_theta on the entire
Hilbert space. It commutes with each left and right link translation,
with Pi, and with the full electric energy.

Thus (2.2)--(2.3) become the exact full-vacuum formulas
\[
 c_\theta=\langle\psi,K_\theta\psi\rangle,\quad
 d_\theta=\langle\psi,K_\theta^2\psi\rangle-c_\theta^2,
\quad n_\theta=\mathfrak q_{\mathcal A}[K_\theta\psi].
\tag{4.4}
\]
On smooth psi the numerator also has the exact double-commutator form
\[
 n_\theta=\frac12\langle\psi,
 [K_\theta,[H,K_\theta]]\psi\rangle
 =\frac12\langle\psi,[K_\theta,[V,K_\theta]]\psi\rangle.
\tag{4.5}
\]
Expanding the first double commutator gives
2KHK-K^2H-HK^2, and applying H psi=E psi proves the first equality.
The second uses the proved commutation with the electric Laplacian.
No magnetic term disappears: V is still the sum over all M faces.

## 5. Leading physical state for the magnetic angle, at every b>0

In (3.2) the native generator has
\(\alpha_{(n,1),3}=2n_2\) and all other components zero. Indeed
\(-n_2H_c=2n_2T_3\) in h_1=exp(-theta n_2 H_c), and T_theta
uses the inverse translation exp(-theta Y). Since a source has only
one such edge, (3.2) yields
\[
 K_2=\frac43\sum_{e=(n,1)}n_2^2\Delta_e^T
 =-\frac43\Gamma,
\qquad \Gamma=\sum_{e=(n,1)}n_2^2(-\Delta_e^T).
\tag{5.1}
\]
The same coefficient follows from the retained character sum: symmetry
gives sum m=0 and
\(\sum_{m=-j}^jm^2=(2j+1)j(j+1)/3\), so
\(c_j(s)=1-2j(j+1)s^2/3+O_j(s^4)\).
For the full operator the correct expansion is on smooth vectors, or
as a map H^{k+4} to H^k:
\[
 K_\theta\psi=\psi-\frac23\theta^2\Gamma\psi
                  +O_{H^k}(\theta^4).
\tag{5.2}
\]
One need not sum unbounded representation-wise errors to justify it.
Apply Taylor's integral formula to the averaged link-translation flow:
four derivatives are bounded H^{k+4} to H^k, uniformly over the compact
averaging group and small theta. Evenness of each C, hence of their
product, removes the odd terms. There is no same-Sobolev-space bounded
operator expansion with the unbounded Gamma silently treated as bounded.

Put
\[
 \gamma=\langle\psi,\Gamma\psi\rangle,\qquad
 v=(\Gamma-\gamma)\psi.
\]
Equations (4.4) and (5.2), with the actual vacuum scalar retained, give
\[
 \chi_\theta=-\frac23\theta^2v+O_{H^1}(\theta^4),
\quad d_\theta=\frac49\theta^4\|v\|^2+O(\theta^6),
\quad n_\theta=\frac49\theta^4\mathfrak q_{\mathcal A}[v]
                         +O(\theta^6).
\tag{5.3}
\]
In particular \(\|v\|^2=\langle\psi,\Gamma^2\psi\rangle-\gamma^2\)
is the actual quantum variance of this specified weighted electric
operator, not a variance in an independently postulated link measure.

For this native translation v is nonzero for every b>0. To prove it,
suppose Gamma psi=gamma psi. Integrate against Haar, not psi: every
Laplacian has zero Haar integral, and \(\int\psi>0\), so gamma=0.
Taking its inner product with psi yields
\[
 0=\langle\psi,\Gamma\psi\rangle
   =\sum_{e=(n,1),a}n_2^2\|X_{e,a}\psi\|^2.
\]
Thus psi is independent of each direction-1 link with n_2 nonzero;
the three derivative fields span that connected SU(2) factor. Select
e=((0,1,0),1). It exists in every box L>=2 and has exactly four incident
faces. In the eigen-equation, after this independence is proved, all
kinetic terms and the factor psi are independent of U_e. Fix all other
link variables to I; smoothness permits this pointwise evaluation and
strict positivity makes the fixed value of psi nonzero. The potential
as a function of U_e is precisely
\[
 V(U_e,I_{\ne e})=4b(2-\operatorname{tr}U_e).
\]
Nonincident faces have trace 2; every incident face has trace tr U_e
or tr U_e^{-1}, which are equal in SU(2). This nonconstant potential
contradicts the eigen-equation for b>0. We have proved v!=0, without a
small-b assumption and without calculating the full vacuum by Haar
substitution.

Consequently for every fixed box, a, and g_YM>0,
\[
 \lim_{\theta\to0}\frac{n_\theta}{d_\theta}
 =\frac{\mathfrak q_{\mathcal A}[v]}{\|v\|^2}>0.
\tag{5.4}
\]
The original magnetic angle and scale are still theta=2pi a^2/D.
Both numerator and norm tend to zero at the same fourth order, so a
small classical magnetic action does not by itself determine this
physical Rayleigh quotient. Formula (5.4) does not bound that quotient
uniformly when L, a, g_YM and D vary together. Those joint dependences
remain to be calculated rather than inferred from the fixed-box limit.

## 6. Exact derivatives retaining every magnetic plaquette

For completeness the numerator in (5.4) has no hidden electric-operator
commutator. Gamma commutes with the full electric part of H, and hence
\[
 (H-E)\Gamma\psi=[V,\Gamma]\psi,
\qquad
 [V,\Gamma]F
 =\sum_{e=(n,1),a}n_2^2
       \bigl[(X_{e,a}^2V)F+2(X_{e,a}V)X_{e,a}F\bigr].
\tag{6.1}
\]
The formula is the product rule for each original derivative. Thus
\[
 \mathfrak q_{\mathcal A}[v]
 =\langle\Gamma\psi,[V,\Gamma]\psi\rangle
 =\frac12\langle\psi,[\Gamma,[V,\Gamma]]\psi\rangle.
\tag{6.2}
\]
All functions are smooth, so these unbounded-operator products are
well-defined on the vector being used. Defining
\(q_p=(3/4)\sum_{e\in\partial p,\ e=(n,1)}n_2^2\), the four-edge
fundamental Casimir gives
\[
 \Gamma W_p=q_pW_p,\quad
 \Gamma V=-b\sum_pq_pW_p,\quad
 X_{e,a}V=-b\sum_{p\ni e}X_{e,a}W_p.
\tag{6.3}
\]
These are exact expressions over the same full face set, including the
13-plane faces for which the chosen background has identity curvature.
They provide explicit coefficients for calculating the vacuum moments;
they do not assign those moments their free-Haar values.

## 7. Exact map to the discrete electric representation variables

Choose an orthonormal product Peter--Weyl basis with a spin j_e on each
edge. The electric eigenvalue is \(\kappa\sum_ej_e(j_e+1)\).
Each joint edge-spin subspace is finite dimensional and invariant under
vertex gauge transformations, since left and right multiplication do
not change the edge representation. Applying Pi in that subspace and
choosing an orthonormal basis of its range gives vectors \(\Phi_s\),
where the index s records all edge spins and the invariant multiplicity
label. Their union is a complete orthonormal basis of the physical
Hilbert space: the full Peter--Weyl expansion is complete, Pi is bounded,
and its finite-spin images are dense in its range.

Expand the actual vacuum, without changing it, as
\[
 \psi=\sum_s a_s\Phi_s,\quad \sum_s|a_s|^2=1,\qquad
 k_s(\theta)=\prod_{e=(n,1)}
 \frac{\sin((2j_e+1)\theta n_2)}{(2j_e+1)\sin(\theta n_2)}.
\tag{7.1}
\]
Each factor has the finite-sum interpretation of (4.3) at a zero
denominator. K acts by k_s on the entire invariant multiplicity space,
because it already acts by that scalar on the surrounding full joint
edge-spin subspace. Hence the exact vacuum overlap and physical state
norm become
\[
 c_\theta=\sum_s|a_s|^2k_s(\theta),\quad
 \chi_\theta=\sum_s a_s(k_s(\theta)-c_\theta)\Phi_s,
\quad
 d_\theta=\sum_s|a_s|^2(k_s(\theta)-c_\theta)^2.
\tag{7.2}
\]
The scalar sums converge absolutely since |k_s|<=1; the vector sum
converges in Hilbert norm. It also converges in the form domain because
psi is smooth and K commutes with the electric Sobolev operator. Thus
(7.2) is a unitary coordinate map, not an identification of the
unknown coefficients a_s with independent free-field weights.

Retain the entire magnetic matrix
\[
 V_{st}=\langle\Phi_s,V\Phi_t\rangle
 =2bM\delta_{st}-b\sum_p\langle\Phi_s,W_p\Phi_t\rangle.
\]
For a growing sequence of finite joint-spin cutoffs F_R tending to the
identity, (4.5) gives the exact convergent expression
\[
 n_\theta=-\frac12\lim_{R\to\infty}
 \sum_{s,t\in F_R}\overline{a_s}a_t\,
 (k_s(\theta)-k_t(\theta))^2 V_{st}.
\tag{7.3}
\]
Here the notation s in F_R means basis indices in that cutoff. To
justify the limit, expand the finite sum as the expectation on F_R psi
of the bounded operator \([K,[V,K]]/2\). Explicitly,
the matrix entry of \([K,[V,K]]\) is
\(-(k_s-k_t)^2V_{st}\). Thus the finite sum is the expectation of
\([K,[V,K]]/2\) on F_R psi. The operator is bounded because K and V
are bounded, and F_R psi tends to psi. No unproved absolute convergence
of an infinite double matrix sum is required. The full scalar 2bM has
zero contribution in (7.3), since its matrix is diagonal and the displayed
difference then vanishes; it remains in H and in E.

Equations (7.1)--(7.3) retain the exact relation between the continuous
magnetic angle and all discrete electric channels. The non-Abelian
plaquettes couple those channels through the specified V_st. Their
individual summands are not assumed nonnegative and are not dropped.
A conclusion about arbitrarily low physical energies requires the
limiting ratio of these two actual-vacuum expressions, not only the
smallness of each change in k_s or of the classical field strength.

## 8. A finite-range energy kernel and the full covariance denominator

The same state can be expressed directly through local electric operators,
without knowing their vacuum expectations in advance. For each physical
edge let \(E_e=-\Delta_e^T\),
\(\gamma_e=\langle\psi,E_e\psi\rangle\), and
\(v_e=(E_e-\gamma_e)\psi\). These are smooth gauge-invariant vectors
orthogonal to psi. Define the two exact finite matrices
\[
 C_{ef}=\langle v_e,v_f\rangle,
 \qquad N_{ef}=\mathfrak q_{\mathcal A}(v_e,v_f).
\tag{8.1}
\]
They are positive semidefinite by their Gram definitions, with no
assumption about signs of individual entries. Because psi, E_e and
H preserve real functions, both matrices are real and symmetric.
Different link Casimirs commute, and an operator commutes with itself,
so \([E_e,E_f]=0\) for every pair. Expanding the double commutator
on the smooth vacuum gives
\[
 \boxed{N_{ef}=\frac12\langle\psi,[E_e,[H,E_f]]\psi\rangle
              =\frac12\langle\psi,[E_e,[V,E_f]]\psi\rangle.}
\tag{8.2}
\]
Indeed its four terms have expectation
\(\langle E_e\psi,HE_f\psi\rangle+
\langle E_f\psi,HE_e\psi\rangle-
2E\langle E_e\psi,E_f\psi\rangle\).
Reality and symmetry make this exactly twice the centered form in (8.1).
The second equality retains the original kinetic coefficient: every E_e
commutes with its whole electric sum, so that commutator is identically
zero, not approximated by zero.

This gives an exact finite-range support statement for the numerator:
\[
 N_{ef}=\frac b2\sum_{p:\ e,f\in\partial p}
 \langle\psi,[E_e,[2-W_p,E_f]]\psi\rangle.
\tag{8.3}
\]
To prove it, if f does not belong to p then E_f differentiates a
different group variable and commutes with multiplication by W_p.
If f belongs but e does not, the first commutator differentiates only
f and has coefficients depending only on p's variables; it therefore
commutes with E_e. These statements follow term by term from the product
rule, including all first-derivative terms. Thus a term can remain only
when both edges belong to the same face, including the diagonal case
e=f. No vacuum-factorization or correlation-decay assumption is involved.

For the native state set w_e=n_2^2 on e=(n,1), and w_e=0 otherwise.
Equations (5.1) and (8.1) imply exactly
\[
 v=\sum_e w_ev_e,\qquad
 \|v\|^2=\sum_{e,f}w_ew_fC_{ef},\qquad
 \mathfrak q_{\mathcal A}[v]=\sum_{e,f}w_ew_fN_{ef}.
\tag{8.4}
\]
The denominator is positive by Section 5. The small-angle physical
excitation quotient (5.4) is therefore the fully specified ratio
\[
 \boxed{\frac{\sum_{e,f}w_ew_fN_{ef}}
              {\sum_{e,f}w_ew_fC_{ef}}.}
\tag{8.5}
\]
Its numerator couples only edges sharing an elementary plaquette;
its denominator retains all electric correlations of the actual
interacting vacuum, including separated edges. This is an exact
local-energy/global-covariance relation. It neither asserts that the
denominator grows faster nor rules that out. Estimating these two sums
along the original geometric and coupling sequence is the precise
remaining spectral calculation for this family of physical states.

## 9. Context, sources, and scope

This uses the Hamiltonian formulation of lattice gauge theory of J. Kogut
and L. Susskind, *Physical Review D* 11 (1975), 395--408,
<https://doi.org/10.1103/PhysRevD.11.395>. The coefficient dictionary from
the original anisotropic Wilson transfer and the full compact-group
ground-state form are proved in the companion temporal-transfer and
interacting-Wilson sources. Haar projection and Schur averaging are
established compact-group tools; no novelty of those general tools is
claimed here. The particular original background, its reference-frame
map, all orientations, the physical state, and the nonzero all-b magnetic
variance are explicitly calculated above.

The four-dimensional target includes construction of the interacting
quantum theory and a statement about its physical spectrum; see
A. Jaffe and E. Witten, *Quantum Yang--Mills Theory*,
<https://www.claymath.org/wp-content/uploads/2022/06/yangmills.pdf>.
The present theorem tests an explicit background-to-quantum-state map at
a finite spatial regulator. It neither assumes a uniform volume estimate
nor claims a construction or disproof of the continuum theory. The next
calculation evaluates the actual vacuum coefficients of this state with
all box plaquettes present; its full derivation accompanies this note.

```

## Complete source: check_magnetic_geometry_projection.py

```python
"""Exact geometry, derivative-coefficient and representation diagnostics.

These checks support the complete analytic proof. They do not compute an
unknown interacting vacuum or establish a joint continuum spectral limit.
"""
from pathlib import Path
from hashlib import sha256
import itertools
import json
import sympy as s

checks = []

def zero(name, value):
    assert s.expand(value) == 0, (name, value)
    checks.append(name)

m, lt, q, y1, y2 = s.symbols('m L_T q y1 y2', real=True)
d = lt*q + 6*m*m
bmat = s.Matrix([[6*m, lt], [-q, m]])
binv_num = s.Matrix([[m, -lt], [q, 6*m]])
assert bmat*binv_num == d*s.eye(2)
checks.append('original imaginary-block inverse with all sixes')
zero('original imaginary-block determinant', bmat.det()-d)
perm = s.zeros(4)
for row,col in enumerate((2,1,3,0)):
    perm[row,col]=1
assert perm.det()==1 and perm*perm.T==s.eye(4)
checks.append('physical space/time permutation preserves orientation and metric')
u1=(m*y1-lt*y2)/d
u2=(q*y1+6*m*y2)/d
zero('original magnetic two-form',
     s.cancel(s.diff(u1,y1)*s.diff(u2,y2)-s.diff(u1,y2)*s.diff(u2,y1)-1/d))
f=2*s.pi/d**2*(m*q*y1**2/2-lt*q*y1*y2-3*m*lt*y2**2)
orig=[2*s.pi*u1*s.diff(u2,t) for t in (y1,y2)]
zero('first exact gauge derivative y1',s.cancel(orig[0]-s.diff(f,y1)))
zero('first exact gauge derivative y2',s.cancel(orig[1]-2*s.pi*y1/d-s.diff(f,y2)))
f2=-2*s.pi*y1*y2/d
zero('second exact gauge derivative y1',s.diff(f2,y1)+2*s.pi*y2/d)
zero('second exact gauge derivative y2',2*s.pi*y1/d+s.diff(f2,y2))

rotations=[]
for p in itertools.permutations(range(3)):
    for signs in itertools.product((-1,1), repeat=3):
        r=s.zeros(3)
        for i,col in enumerate(p):
            r[i,col]=signs[i]
        if r.det()==1:
            rotations.append(r)
assert len(rotations)==24
for i,j in itertools.product(range(3), repeat=2):
    zero(f'rotation first moment {i}{j}',sum(r[i,j] for r in rotations)/s.Integer(24))
for a,b,c,e in itertools.product(range(3), repeat=4):
    zero(f'rotation second moment {a}{b}{c}{e}',
         sum(r[a,b]*r[c,e] for r in rotations)/s.Integer(24)
         -s.Rational(1,3)*int(a==c)*int(b==e))

for dim in range(1,13):
    j=s.Rational(dim-1,2)
    weights=[-j+k for k in range(dim)]
    zero(f'spin {j} character quadratic coefficient',
         -2*sum(x*x for x in weights)/dim+s.Rational(2,3)*j*(j+1))
zero('original Hc frame and quartic factor',s.Rational(1,4)*s.Rational(4,3)**2-s.Rational(4,9))

ks=s.symbols('k0:3',real=True)
vm=s.Matrix(3,3,lambda i,j:s.Symbol(f'V{i}{j}'))
km=s.diag(*ks)
comm=km*(vm*km-km*vm)-(vm*km-km*vm)*km
for i,j in itertools.product(range(3),repeat=2):
    zero(f'exact magnetic channel double-commutator {i}{j}',
         comm[i,j]+(ks[i]-ks[j])**2*vm[i,j])

halfside,idx,offset=s.symbols('L index offset',integer=True,positive=True)
qm=idx**2+idx+s.Rational(1,2)
angular=(2*halfside*(2*halfside+1)*s.summation(qm**2,(idx,-halfside,halfside-1))
         +4*halfside**2*s.summation(idx**4,(idx,-halfside,halfside)))
angular_printed=halfside**2*(2*halfside+1)*(24*halfside**4+24*halfside**3
                        +8*halfside**2-4*halfside+3)/15
zero('full angular coefficient polynomial',angular-angular_printed)
error_coefficient=s.Rational(2,3)*(2*halfside*(2*halfside+1)
    *s.summation(qm**3,(idx,-halfside,halfside-1))
    +4*halfside**2*s.summation(idx**6,(idx,-halfside,halfside)))
positive_polynomial=s.Poly(s.expand((16*halfside**9-error_coefficient)
                                   .subs(halfside,offset+2)),offset)
assert all(c>0 for c in positive_polynomial.all_coeffs())
checks.append('explicit angular remainder bound for all integer L>=2')
zero('cusp coefficient leading factor',s.LC(s.Poly(angular,halfside))-s.Rational(16,5))

root=Path(__file__).resolve().parent
proof=root/'magnetic_translation_true_vacuum.md'
raw=proof.read_bytes()
receipt={'status':'PASS','check_count':len(checks),'checks':checks,
         'proof_bytes':len(raw),'proof_sha256':sha256(raw).hexdigest(),
         'scope':'Exact geometry/finite algebra only; analytic and vacuum claims proved in source.'}
(root/'MAGNETIC_GEOMETRY_CHECKS.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
print(json.dumps(receipt,indent=2))

```

## Complete source: wilson_variation/MAGNETIC_TRANSLATION_PLAQUETTE.md

```markdown
# Exact gauge-projected magnetic translation in a full Wilson box

8 September 2026. All links and all elementary spatial plaquettes are retained. The vacuum below is the actual normalized positive ground state, not the one-time Wilson density. This proof is a finite-box calculation; the geometric diagonal in Section 9 concerns its explicitly computed strong-coupling coefficient, not an interchange of quantum and volume limits.

## 1. Original objects, constants, and operators

For an integer \(L\ge2\), take the open vertex box \(\{-L,\ldots,L\}^3\), all positively directed physical links \(e=(n,i)\) from \(n\) to \(n+\mathbf e_i\) contained in the box, and all elementary faces \(p=(n;i,j)\), \(i<j\). Write these sets as \(\mathsf E_L,\mathsf P_L\). Their complete counts are

\[
N=3(2L)(2L+1)^2,\qquad M=3(2L)^2(2L+1).
\tag{1.1}
\]

A negative traversal uses the inverse of the same physical link, not an independent variable. The face word and its real \(SU(2)\) trace are

\[
U_p=U_i(n)U_j(n+\mathbf e_i)U_i(n+\mathbf e_j)^{-1}U_j(n)^{-1},
\qquad W_p=\operatorname{tr}U_p.
\tag{1.2}
\]

Work in \(\mathcal H=L^2(SU(2)^{\mathsf E_L},dU)\), with product Haar probability measure and inner product conjugate-linear in its first entry. Put

\[
T_a=-i\sigma_a/2,\quad -2\operatorname{tr}(T_aT_b)=\delta_{ab},\qquad
X_{e,a}f=\left.\frac{d}{dt}f(\ldots,e^{tT_a}U_e,\ldots)\right|_{t=0},
\quad \Delta_e^T=\sum_aX_{e,a}^2.
\tag{1.3}
\]

For \(\kappa,b>0\), define

\[
H_0=-\sum_{e\in\mathsf E_L}\Delta_e^T,\quad
\mathcal V=\sum_{p\in\mathsf P_L}W_p,\quad \xi=b/\kappa,
\]
\[
H_{\kappa,b}=\kappa H_0+b\sum_p(2-W_p)
=\kappa(H_0-\xi\mathcal V)+2bM I.
\tag{1.4}
\]

The exact Wilson constant is \(2bM\). The original metric and physical parameter dictionary remain

\[
c(X,Y)=-\tfrac12\operatorname{tr}(XY),\quad
\Delta_e^c=4\Delta_e^T,\quad
\kappa=\frac{2g_{\mathrm{YM}}^2}{a},\quad
b=\frac1{2g_{\mathrm{YM}}^2a},\quad
\xi=\frac1{4g_{\mathrm{YM}}^4}.
\tag{1.5}
\]

Thus the kinetic term is also \(-g_{\mathrm{YM}}^2(2a)^{-1}\sum_e\Delta_e^c\). Nothing is absorbed into a redefined coupling.

For fixed \(h=(h_e)\in SU(2)^{\mathsf E_L}\), set

\[
(\mathcal T_hf)(U)=f((h_e^{-1}U_e)_e).
\tag{1.6}
\]

This is unitary and preserves Haar integrals. Its adjoint is \(\mathcal T_{h^{-1}}\). At each vertex use an independent gauge variable \(g_v\), acting by
\[
(\alpha_gU)_e=g_{s(e)}U_eg_{t(e)}^{-1},\qquad
(\Pi f)(U)=\int f(\alpha_gU)\prod_vdg_v.
\tag{1.7}
\]

Haar invariance proves \(\Pi^2=\Pi=\Pi^*\); its range consists precisely of invariant functions. The original convention \(U_e\mapsto h_{s(e)}^{-1}U_eh_{t(e)}\) is the same action with vertex variables \(g_v=h_v^{-1}\); these vertex variables are distinct from the fixed link assignments in (1.6).

Both \(\mathcal T_h\) and gauge transformations commute with \(H_0\). For the first assertion, differentiation replaces the basis \(T_a\) by \(\operatorname{Ad}(h_e^{-1})T_a\), another orthonormal basis, leaving the sum of squares unchanged. Right multiplication in a gauge transformation commutes with left derivatives, and its left multiplication has the same orthonormal-basis argument. Consequently \(\mathcal T_h\) is an isometry and \(\Pi\) a contraction on every Sobolev space defined by \(H_0+1\). Since each \(W_p\) is invariant, \(\Pi\) commutes with \(H_{\kappa,b}\).

## 2. Full vertex integral, with the shared-source factor retained

For \(p=(n;i,j)\), abbreviate

\[
\begin{array}{llll}
U=U_i(n),&V=U_j(n+\mathbf e_i),&
Z=U_i(n+\mathbf e_j),&Y=U_j(n),\\
a_0=h_i(n),&d_0=h_j(n+\mathbf e_i),&
c_0=h_i(n+\mathbf e_j),&b_0=h_j(n).
\end{array}
\tag{2.1}
\]

These subscripted matrices are not the scalar couplings or mesh. The translated word is exactly

\[
\mathcal T_hW_p=
\operatorname{tr}(a_0^{-1}U\,d_0^{-1}V\,Z^{-1}c_0\,Y^{-1}b_0).
\tag{2.2}
\]

In particular, an inverse physical link contributes \((h_e^{-1}U_e)^{-1}=U_e^{-1}h_e\); its insertion must remain on that side.

Denote the four vertex variables by \(g_0,g_i,g_{ij},g_j\). Substituting (1.7) into (2.2), cancelling adjacent factors, and cyclically rotating the trace gives

\[
\operatorname{tr}\!\left[
(g_0^{-1}b_0a_0^{-1}g_0)\,
U(g_i^{-1}d_0^{-1}g_i)\,VZ^{-1}
(g_j^{-1}c_0g_j)\,Y^{-1}
\right].
\tag{2.3}
\]

The \(g_{ij}\) factors cancel completely. The two links with common canonical source \(n\) produce the one product \(b_0a_0^{-1}\), conjugated by the one variable \(g_0\). They cannot be averaged as independent insertions.

For every complex \(2\times2\) matrix \(C\),

\[
\int g^{-1}Cg\,dg=\tfrac12\operatorname{tr}(C)I.
\tag{2.4}
\]

Indeed the Haar integral commutes with every \(SU(2)\) matrix. Commutation with all three Pauli one-parameter groups forces it to be scalar, and taking the trace fixes that scalar. Apply (2.4) independently to the three remaining variables in (2.3). The exact answer for every face is

\[
\boxed{\Pi\mathcal T_hW_{n;i,j}=\alpha_{n;i,j}(h)W_{n;i,j},}
\]
\[
\boxed{\alpha_{n;i,j}(h)=
\frac{
\operatorname{tr}[h_j(n)h_i(n)^{-1}]
\operatorname{tr}[h_j(n+\mathbf e_i)^{-1}]
\operatorname{tr}[h_i(n+\mathbf e_j)]
}{8}.}
\tag{2.5}
\]

The three traces are real and lie in \([-2,2]\), so \(\alpha_p\in[-1,1]\). The factor \(2^{-3}\) is one dimension factor for each nonempty vertex insertion. The fourth vertex contributes 1.

This applies without modification to every coordinate plane and boundary face. Four vertices and four physical edges are distinct in this open box. A cyclic change of the starting point leaves the Wilson function unchanged. Reversing the traversal gives the same function because \(\operatorname{tr}C^{-1}=\operatorname{tr}C\) on \(SU(2)\). The \(h_e\) remain attached to canonical physical sources, not to sources invented by reorienting the traversal.

Two exact checks show what would go wrong with different prescriptions.

- If \(a_0=b_0=k\) and \(c_0=d_0=I\), then \(\alpha_p=1\). Independently twirling the two shared-source factors would instead give \((\operatorname{tr}k/2)^2\).
- If all four matrices are \(k\), then \(\alpha_p=(\operatorname{tr}k/2)^2\), whereas their background face word \(kkk^{-1}k^{-1}\) is \(I\). At \(k=i\sigma_3\), the two alleged coefficients are 0 and 1.

Thus the projected translated face is not generally the original face times half the trace of a background holonomy.

We shall also need the exact inverse relation

\[
\alpha_p(h^{-1})=\alpha_p(h).
\tag{2.6}
\]

For the first factor, \(\operatorname{tr}(h_j^{-1}h_i)=
\operatorname{tr}[(h_jh_i^{-1})^{-1}]=\operatorname{tr}(h_jh_i^{-1})\), using cyclicity and the \(SU(2)\) inverse-trace identity. The other two factors have the same inverse-trace identity separately. This proves (2.6), including noncommuting assignments.

## 3. The true all-plaquette vacuum and its analytic expansion

The compact product Laplacian has compact resolvent. Adding the smooth bounded real potential preserves self-adjointness on its operator domain and compact resolvent. A ground minimizer can be taken nonnegative by \(|\nabla|f||\le|\nabla f|\), with zeros treated by the approximation \(\sqrt{|f|^2+\varepsilon^2}\). Elliptic regularity makes the ground eigenfunction smooth, and the strong maximum principle makes it strictly positive on the connected configuration manifold. If \(\psi>0\) is a ground eigenfunction, integration by parts and its eigen-equation give

\[
\langle\psi F,(H-E)\psi F\rangle
=\kappa\sum_{e,a}\int\psi^2|X_{e,a}F|^2\,dU.
\tag{3.1}
\]

The identity extends from smooth \(F\) to the form domain by density; the positive smooth function \(\psi\) and its reciprocal are bounded on this finite compact manifold. A second ground eigenfunction divided by \(\psi\) would make every derivative on the right zero, and thus be constant. Hence the normalized positive vacuum \(\psi_\xi\) is unique. Gauge invariance of \(H\) gives \(\Pi\psi_\xi=\psi_\xi\).

Here the needed local expansion follows from the full potential, as can be proved directly. A fundamental matrix coefficient has free Casimir \(3/4\) since \(-\sum_aT_a^2=3I/4\). On spin \(j\), the usual matrices \(J_3v_m=mv_m\), \(J_\pm v_m=\sqrt{(j\mp m)(j\pm m+1)}v_{m\pm1}\) give Casimir \(j(j+1)\) by multiplication. The Peter--Weyl decomposition and its tensor products give the full product spectrum: a simple constant eigenfunction at zero and first nonzero eigenvalue \(3/4\). Each \(W_p\) uses four distinct fundamental links, so

\[
H_0W_p=3W_p,\qquad
\int W_p\,dU=0,\qquad
\int W_pW_q\,dU=\delta_{pq}.
\tag{3.2}
\]

For the Haar assertions, integration over a singly occurring physical link kills its fundamental entries: multiplication by the center \(-I\) changes their signs. Different elementary squares have different four-edge supports, so one can integrate an edge occurring in one but not the other. A four-edge support determines the two coordinate directions and the lower corner of an elementary square, proving the asserted difference of supports. For equal faces, Haar invariance reduces the integral to \(\int(\operatorname{tr}U)^2dU=1\): Haar \(SU(2)\) is the unit sphere in \(\mathbb R^4\), and its scalar coordinate has second moment \(1/4\).

The interaction norm is exactly \(\|\mathcal V\|_\infty=2M\). The upper bound follows from \(|W_p|\le2\); equality follows at the all-identity configuration and then for the essential supremum by continuity and positive measure of neighborhoods. On \(|z|=3/8\), the free resolvent norm is at most \(8/3\). Its Neumann series under perturbation by \(-\xi\mathcal V\) therefore converges for

\[
\boxed{|\xi|<\frac3{16M}.}
\tag{3.3}
\]

The contour projection is analytic and rank one on this disk, since its rank is locally constant and is one at zero. For real \(\xi\), the bottom eigenvalue of \(H_0-\xi\mathcal V\) lies in \([-2M|\xi|,0]\), while the next is at least \(3/4-2M|\xi|>3/8\); the contour thus contains the actual ground eigenvalue \(e(\xi)\).

A Haar-mean-one analytic eigenvector \(\phi_\xi\) exists locally at zero. Explicitly, if \(q=16M|\xi|/3\), the contour resolvent difference bounds the projection difference by \(q/(1-q)\); for \(q<1/2\), the projection of 1 has nonzero Haar mean and supplies this normalization. Differentiating the eigen-equation gives

\[
e(0)=e'(0)=0,\qquad \phi'_0=\mathcal V/3,\qquad
\int\phi_\xi^2dU=1+(M/9)\xi^2+O_L(\xi^3).
\tag{3.4}
\]

In the derivative equation the Haar mean forces \(e'(0)=0\), and (3.2) solves the mean-zero equation \(H_0\phi'_0=\mathcal V\). The squared normalization follows because all higher coefficients of \(\phi_\xi\) have zero Haar mean and \(\|\mathcal V\|_2^2=M\).

Analyticity and bounded Taylor remainders hold in every fixed Sobolev norm. The equation
\[
\phi_\xi=(H_0+1)^{-1}[(e(\xi)+1+\xi\mathcal V)\phi_\xi]
\]
upgrades analyticity by two derivatives at a time; multiplication by the fixed smooth \(\mathcal V\) is bounded on each integer Sobolev space. Sobolev embedding in the fixed dimension \(3N\) also gives \(C^k\) expansions for every fixed \(k\). Normalize positively for real \(\xi\). The actual vacuum then has

\[
\psi_\xi=1+\xi A+\xi^2D+O_L(\xi^3),\qquad
A=\frac13\sum_pW_p,\qquad \int D\,dU=-\frac12\|A\|_2^2=-\frac M{18}.
\tag{3.5}
\]

The last identity follows exactly from \(\|\psi_\xi\|_2=1\). The coefficient \(D\) here is a function, not an assumed truncation of the interacting vacuum. The physical ground energy is exactly
\[
E_\xi=\kappa e(\xi)+2bM.
\tag{3.6}
\]

All constants in these local analytic estimates may depend on the full box. The disk (3.3) is the guaranteed spectral-projection disk, not a uniform-volume bound on every Taylor remainder.

## 4. Exact physical state, norm, energy, and vanishing criterion

Define

\[
F_{\xi,h}=\Pi\mathcal T_h\psi_\xi,\quad
c_{\xi,h}=\langle\psi_\xi,\mathcal T_h\psi_\xi\rangle,\quad
\chi_{\xi,h}=F_{\xi,h}-c_{\xi,h}\psi_\xi.
\tag{4.1}
\]

These functions are real; the first two uncentered functions and the vacuum are strictly positive. Hence \(0<c_{\xi,h}\le1\), the upper bound following from unitarity. Since \(\Pi\psi_\xi=\psi_\xi\),

\[
\langle\psi_\xi,\chi_{\xi,h}\rangle=0,\qquad
\|\chi_{\xi,h}\|_2^2=\|F_{\xi,h}\|_2^2-c_{\xi,h}^2.
\tag{4.2}
\]

The state is smooth and invariant. Its exact excitation quotient when it is nonzero is

\[
\boxed{\mathcal Q_{\xi,h}
=\frac{\|(H_{\kappa,b}-E_\xi)^{1/2}\chi_{\xi,h}\|_2^2}
{\|\chi_{\xi,h}\|_2^2}
=\frac{\displaystyle\kappa\sum_{e,a}\int\psi_\xi^2
\left|X_{e,a}\left(\frac{F_{\xi,h}}{\psi_\xi}\right)\right|^2dU}
{\displaystyle\|F_{\xi,h}\|_2^2-c_{\xi,h}^2}.}
\tag{4.3}
\]

Apply (3.1) to \(F_{\xi,h}/\psi_\xi-c_{\xi,h}\) to prove this; the derivative of the centering constant vanishes. Smoothness and strict positivity on a compact configuration space justify the form domain and all displayed integrals. The true vacuum is kept in every factor.

Write the finite real coefficients

\[
\mathcal S_h=\sum_p(1-\alpha_p),\qquad
\mathcal R_h=\sum_p(1-\alpha_p^2),\qquad
\mathcal D_h=\sum_p(1-\alpha_p)^2.
\tag{4.4}
\]

All three are nonnegative and \(\mathcal D_h=2\mathcal S_h-\mathcal R_h\).

For every \(b>0\), not just perturbatively, the following complete classification holds:

\[
\boxed{
\chi_{\xi,h}=0
\ \Longleftrightarrow\ \mathcal T_h\psi_\xi=\psi_\xi
\ \Longleftrightarrow\ \mathcal T_h\mathcal V=\mathcal V
\ \Longleftrightarrow\ (\alpha_p=1\text{ for every }p)
\ \Longleftrightarrow\ \mathcal D_h=0.}
\tag{4.5}
\]

If \(\chi=0\), then \(F=c\psi\). Haar integration, preserved by both \(\Pi\) and \(\mathcal T_h\), yields \(\int\psi=c\int\psi\); strict positivity forces \(c=1\). Equality \(\|\Pi\mathcal T_h\psi\|=\|\mathcal T_h\psi\|=1\) in an orthogonal projection norm implies \((I-\Pi)\mathcal T_h\psi=0\) by Pythagoras. Thus \(\mathcal T_h\psi=\psi\).

If this last equality holds, apply \(\mathcal T_h\) to the eigen-equation. It commutes with \(H_0\), and translates multiplication by \(\mathcal V\) to multiplication by \(\mathcal T_h\mathcal V\). Subtracting the original equation gives
\(b(\mathcal T_h\mathcal V-\mathcal V)\psi=0\).
Since \(b>0\) and \(\psi>0\), the potentials agree. Project that equality by \(\Pi\), use (2.5), and pair with \(W_q\) in (3.2); every \(\alpha_q\) is 1.

Conversely, if every \(\alpha_p=1\), then
\(\|\Pi\mathcal T_hW_p\|_2=\|W_p\|_2=\|\mathcal T_hW_p\|_2\).
Projection norm equality gives \(\mathcal T_hW_p=W_p\), in \(L^2\) and hence pointwise by smoothness. Therefore \(\mathcal T_h\) preserves \(\mathcal V\), commutes with the full Hamiltonian, and fixes its unique positive normalized vacuum. This gives \(\chi=0\). A sum of real squares is zero exactly when each square is zero, completing (4.5). At \(b=0\) the vacuum is constant and every such centered state is zero; this explains why \(b>0\) is required in the classification.

There is also a compact exact unprojected energy identity, expressed in the true moments \(m_{p,\xi}=\int W_p\psi_\xi^2dU\):

\[
\boxed{\langle\mathcal T_h\psi_\xi,
(H_{\kappa,b}-E_\xi)\mathcal T_h\psi_\xi\rangle
=b\sum_p(1-\alpha_p)m_{p,\xi}.}
\tag{4.6}
\]

The kinetic expectation is unchanged by \(\mathcal T_h\), so subtracting the vacuum energy leaves
\(b\sum_p(m_{p,\xi}-\langle\psi_\xi,
(\mathcal T_h^{-1}W_p)\psi_\xi\rangle)\).
The density \(\psi_\xi^2\) is invariant, so the last multiplication function may be averaged by \(\Pi\). Equations (2.5)--(2.6) replace it exactly by \(\alpha_pW_p\), proving (4.6). No sign of any individual moment is assumed. The aggregate is nonnegative because \(H-E_\xi\) is nonnegative.

## 5. First nonzero norm and excitation quotient, with exact coupling parity

Equations (2.5) and (3.5) give the actual first-order vector

\[
\chi_{\xi,h}=\xi V_h+O_L(\xi^2),\qquad
V_h=\frac13\sum_p(\alpha_p-1)W_p.
\tag{5.1}
\]

The error is valid in \(H^2\) and every fixed higher Sobolev space. At this stage its constant may be chosen independently of \(h\) on the fixed box, because translations are Sobolev isometries and \(\Pi\) a Sobolev contraction. Equation (3.2) gives

\[
\|V_h\|_2^2=\mathcal D_h/9,\qquad H_0V_h=3V_h.
\tag{5.2}
\]

The second vacuum coefficient is not needed as a function to compute the scalar centering, but its exact normalization mean is needed. From (3.5), Haar preservation, and (3.2),

\[
\begin{split}
c_{\xi,h}
&=1+\xi^2\big(\langle A,\mathcal T_hA\rangle-\|A\|_2^2\big)+O_L(\xi^3)
=1-\frac{\xi^2}{9}\mathcal S_h+O_L(\xi^3),\\
\|F_{\xi,h}\|_2^2
&=1+\xi^2\big(\|\Pi\mathcal T_hA\|_2^2-\|A\|_2^2\big)+O_L(\xi^3)
=1-\frac{\xi^2}{9}\mathcal R_h+O_L(\xi^3).
\end{split}
\tag{5.3}
\]

For example, invariance of \(A\) gives
\(\langle A,\mathcal T_hA\rangle=\langle A,\Pi\mathcal T_hA\rangle
=\sum_p\alpha_p/9\). The loss of norm under Gauss projection, measured here by \(\mathcal R_h\), is not the same as the overlap loss \(\mathcal S_h\); both enter (4.2).

An exact central link transformation eliminates all odd terms of these scalar expansions. Define

\[
z_i(n)=(-1)^{\sum_{k<i}n_k}I,\qquad \mathcal Z=\mathcal T_z.
\tag{5.4}
\]

For a face \(i<j\), shifting \(n\) by \(\mathbf e_i\) changes \(z_j\) by a sign, whereas shifting by \(\mathbf e_j\) does not change \(z_i\). Multiplying the four link signs around the face therefore gives \(-1\). Each inverse sign equals the sign itself. Thus **every** face in **every** plane satisfies

\[
\mathcal ZW_p=-W_p,\qquad
\mathcal Z(H_0-\xi\mathcal V)\mathcal Z^{-1}=H_0+\xi\mathcal V.
\tag{5.5}
\]

The central translation \(\mathcal Z\) is a real unitary involution. Centrality implies it commutes with every gauge transformation and every \(\mathcal T_h\), hence with \(\Pi\). For the real analytic auxiliary family near zero, uniqueness of its positive normalized vacuum gives

\[
e(-\xi)=e(\xi),\quad
\psi_{-\xi}=\mathcal Z\psi_\xi,\quad
c_{-\xi,h}=c_{\xi,h},\quad
F_{-\xi,h}=\mathcal ZF_{\xi,h},\quad
\chi_{-\xi,h}=\mathcal Z\chi_{\xi,h}.
\tag{5.6}
\]

Negative \(\xi\) is only an analytic device here; the physical statements have \(b>0\). The exact excitation operator is
\(\kappa(H_0-\xi\mathcal V-e(\xi))\), since the scalar in (3.6) cancels exactly. It is conjugated to its negative-\(\xi\) version by \(\mathcal Z\). Therefore the squared norm of \(\chi\), its excitation quadratic form, the centering scalar, and the squared norm of the uncentered projection are even real-analytic scalar functions of \(\xi\). In particular their cubic coefficients vanish. Equations (4.2), (5.2), and (5.3) prove

\[
\boxed{\begin{split}
c_{\xi,h}&=1-\frac{\xi^2}{9}\mathcal S_h+O_L(\xi^4),\\
\|F_{\xi,h}\|_2^2&=1-\frac{\xi^2}{9}\mathcal R_h+O_L(\xi^4),\\
\|\chi_{\xi,h}\|_2^2&=\frac{\xi^2}{9}\mathcal D_h+O_L(\xi^4).
\end{split}}
\tag{5.7}
\]

To compute the energy, use the \(H^2\) expansion (5.1) in the exact excitation operator and \(e(\xi)=O_L(\xi^2)\). The first term is
\(\kappa\xi^2\langle V_h,H_0V_h\rangle\), and evenness removes the cubic term. Hence

\[
\boxed{\|(H_{\kappa,b}-E_\xi)^{1/2}\chi_{\xi,h}\|_2^2
=\frac{\kappa\xi^2}{3}\mathcal D_h+O_L(\kappa\xi^4).}
\tag{5.8}
\]

For each fixed \(h\) with \(\mathcal D_h>0\), the vector is nonzero for every \(b>0\) by (4.5). Its first nonzero norm and leading exact excitation quotient as \(\xi\downarrow0\) are

\[
\boxed{
\|\chi_{\xi,h}\|_2=\frac{\xi}{3}\sqrt{\mathcal D_h}+O_{L,h}(\xi^3),
\qquad \mathcal Q_{\xi,h}=3\kappa+O_{L,h}(\kappa\xi^2).}
\tag{5.9}
\]

The dependence after division must not be discarded near zero \(\mathcal D_h\). More explicitly, take a fixed-box constant \(C_L\) bounding both remainders in the last line of (5.7) and in (5.8), after extraction of \(\xi^4\) and \(\kappa\xi^4\), on a sufficiently small real interval. Such a constant can be chosen uniformly in \(h\): the previous Sobolev and analytic bounds hold uniformly for the compact family of translations, and the spectral expansion is the same vacuum. If \(C_L\xi^2\le\mathcal D_h/18\), then

\[
|\mathcal Q_{\xi,h}-3\kappa|
\le\frac{72C_L}{\mathcal D_h}\,\kappa\xi^2.
\tag{5.10}
\]

Indeed write the quotient as
\(\kappa(\mathcal D_h/3+\xi^2r_1)/(\mathcal D_h/9+\xi^2r_2)\)
with \(|r_i|\le C_L\). Subtracting \(3\kappa\) gives a numerator of magnitude at most \(4C_L\kappa\xi^2\); the denominator is at least \(\mathcal D_h/18\).

In the original physical constants, the leading squared norm is
\(\mathcal D_h/(144g_{\mathrm{YM}}^8)\), the leading unnormalized excitation form is \(\mathcal D_h/(24g_{\mathrm{YM}}^6a)\), and the leading quotient is \(6g_{\mathrm{YM}}^2/a\). The exact remainder scale of the quotient before its dimensionless constant is
\(\kappa\xi^2=1/(8g_{\mathrm{YM}}^6a)\). These are substitutions into the proved finite-box expressions, not claims about weak coupling or a continuum limit.

## 6. Native nonwrapping flux: exact coefficients for all three planes

Now take precisely

\[
h_1(n)=\exp(-\theta n_2H_c),\qquad h_2(n)=h_3(n)=I,\qquad
H_c=i\sigma_3=-2T_3,\qquad \theta\in\mathbb R.
\tag{6.1}
\]

Here \(c(H_c,H_c)=1\) and its squared norm in (1.3) is 4. Its eigenvalues are \(i,-i\), giving
\(\operatorname{tr}\exp(-tH_c)/2=\cos t\).
No integer coordinate has been wrapped or rescaled, and no factor of 2 has been absorbed into \(\theta\).

Substitution into the exact full-vertex formula (2.5), with \(m=n_2\), yields

\[
\boxed{
\begin{array}{ll}
\alpha_{n;1,2}=\cos(m\theta)\cos((m+1)\theta),&-L\le m\le L-1,\\
\alpha_{n;1,3}=\cos^2(m\theta),&-L\le m\le L,\\
\alpha_{n;2,3}=1.&
\end{array}}
\tag{6.2}
\]

The \(13\)-coefficient is not always one, despite the trivial background holonomy in that plane. The \(12\)-coefficient is not generally the background normalized trace \(\cos\theta\). Both facts follow from the actual independent vertex twirls, rather than from a curvature substitution.

For each permitted \(m\), the number of \(12\)-faces is \(2L(2L+1)\): \(n_1\) has \(2L\) choices and \(n_3\) has \(2L+1\). The number of \(13\)-faces for each \(m\) is \(4L^2\). Thus the exact coefficient entering (5.7)--(5.10) is

\[
\boxed{\begin{split}
\mathcal D_L(\theta)
={}&2L(2L+1)\sum_{m=-L}^{L-1}
[1-\cos(m\theta)\cos((m+1)\theta)]^2\\
&+4L^2\sum_{m=-L}^{L}\sin^4(m\theta).
\end{split}}
\tag{6.3}
\]

The separately relevant overlap coefficient is

\[
\begin{split}
\mathcal S_L(\theta)
={}&2L(2L+1)\sum_{m=-L}^{L-1}
[1-\cos(m\theta)\cos((m+1)\theta)]\\
&+4L^2\sum_{m=-L}^{L}\sin^2(m\theta).
\end{split}
\tag{6.4}
\]

The projection loss is exactly \(\mathcal R_L=2\mathcal S_L-\mathcal D_L\). The first-order vector itself is

\[
\begin{split}
V_\theta=\frac13\bigg[
&\sum_{p=(n;1,2)}(\cos(n_2\theta)\cos((n_2+1)\theta)-1)W_p\\
&-\sum_{p=(n;1,3)}\sin^2(n_2\theta)W_p
\bigg],\qquad \chi_{\xi,\theta}=\xi V_\theta+O_L(\xi^2).
\end{split}
\tag{6.5}
\]

Every \(23\)-plaquette is still present in the full potential and actual vacuum; only its displayed first-order coefficient is zero.

### 6.1 Finite Fourier form with no undefined resonances

Define the finite trigonometric polynomials

\[
\mathcal O_L(t)=\sum_{m=-L}^{L-1}\cos((2m+1)t),\qquad
\mathcal K_L(t)=\sum_{m=-L}^{L}\cos(mt).
\tag{6.6}
\]

Finite geometric summation gives, whenever their denominators are nonzero,

\[
\mathcal O_L(t)=\frac{\sin(2Lt)}{\sin t},\qquad
\mathcal K_L(t)=\frac{\sin((L+\tfrac12)t)}{\sin(t/2)}.
\tag{6.7}
\]

At all other arguments, their values are the finite sums (6.6), equivalently the continuous extensions. In particular
\(\mathcal O_L(k\pi)=2L(-1)^k\) and
\(\mathcal K_L(2k\pi)=2L+1\).

With \(a_\theta=1-\tfrac12\cos\theta\), product-to-sum and the identity
\(\sin^4x=(3-4\cos2x+\cos4x)/8\) give exactly

\[
\begin{split}
\sum_{m=-L}^{L-1}[1-\cos(m\theta)\cos((m+1)\theta)]^2
&=2L(a_\theta^2+\tfrac18)-a_\theta\mathcal O_L(\theta)
+\tfrac18\mathcal O_L(2\theta),\\
\sum_{m=-L}^{L}\sin^4(m\theta)
&=\tfrac38(2L+1)-\tfrac12\mathcal K_L(2\theta)
+\tfrac18\mathcal K_L(4\theta).
\end{split}
\tag{6.8}
\]

Multiplying by the respective face counts in (6.3) gives the exact closed Fourier form of \(\mathcal D_L\). The two unsquared sums in (6.4) are respectively

\[
2La_\theta-\tfrac12\mathcal O_L(\theta),\qquad
\tfrac12(2L+1)-\tfrac12\mathcal K_L(2\theta).
\tag{6.9}
\]

These expressions are finite polynomial identities and remain valid at every resonance with (6.6); they introduce no singular angles.

### 6.2 Exact zero angles, special values, and elementary bounds

The coefficient \(\mathcal D_L\) is even and \(2\pi\)-periodic. Its \(m=0,-1\) terms in the first sum give

\[
4L(2L+1)(1-\cos\theta)^2\le\mathcal D_L(\theta).
\tag{6.10}
\]

Each term in that sum is at most 4 and each sine fourth power at most 1, giving the nonoptimal but explicit full-box upper bound

\[
\mathcal D_L(\theta)\le5(2L)^2(2L+1)=5M/3.
\tag{6.11}
\]

At \(\theta\in2\pi\mathbb Z\), every \(h_e=I\). Together with (6.10), this proves

\[
\mathcal D_L(\theta)=0\ \Longleftrightarrow\ \theta\in2\pi\mathbb Z.
\tag{6.12}
\]

The exact all-coupling classification (4.5) therefore gives

\[
\boxed{\chi_{\xi,\theta}=0\ \Longleftrightarrow\
\theta\in2\pi\mathbb Z,\qquad b>0.}
\tag{6.13}
\]

At those angles the quotient of this zero vector is undefined, not zero. At every other angle it is the quotient of a nonzero, invariant, vacuum-orthogonal physical vector.

Two explicit nonzero values are

\[
\mathcal D_L(\pi)=16L^2(2L+1),\qquad
\mathcal D_L(\pi/2)=4L^2(3L+1+\varepsilon_L),\quad
\varepsilon_L=L\bmod2.
\tag{6.14}
\]

At \(\pi\), every \(12\)-coefficient is \(-1\) and the \(13,23\) coefficients are 1, proving the first value by counting faces. At \(\pi/2\), consecutive cosine factors have zero product, giving contribution 1 from every \(12\)-face. Among \(-L,\ldots,L\) there are \(L+\varepsilon_L\) odd integers, which are exactly the nonzero fourth-power sine terms. This proves the second value with its parity dependence.

## 7. Exact small-angle polynomial and a signed explicit remainder

For each integer \(m\), put \(r_m=m^2+m+\tfrac12\). Elementary Taylor expansion gives

\[
1-\cos(m\theta)\cos((m+1)\theta)=r_m\theta^2+O_L(\theta^4),
\qquad \sin^2(m\theta)=m^2\theta^2+O_L(\theta^4)
\tag{7.1}
\]

uniformly over the finite index ranges of the fixed box. Thus

\[
\mathcal D_L(\theta)=\mathcal A_L\theta^4+O_L(\theta^6),
\]
\[
\begin{split}
\mathcal A_L
&=2L(2L+1)\sum_{m=-L}^{L-1}r_m^2+4L^2\sum_{m=-L}^{L}m^4\\
&=\boxed{\frac{L^2(2L+1)}{15}
(24L^4+24L^3+8L^2-4L+3)}\\
&=\frac{16}{5}L^7+\frac{24}{5}L^6+\frac83L^5+\frac2{15}L^3+\frac15L^2.
\end{split}
\tag{7.2}
\]

Here are the exact finite sums needed to verify every coefficient:

\[
\sum_{m=-L}^{L-1}r_m^2=\frac{L(4L^4+1)}{10},\qquad
\sum_{m=-L}^{L}m^4
=\frac{L(L+1)(2L+1)(3L^2+3L-1)}{15}.
\tag{7.3}
\]

For the first identity, expand \(r_m^2=m^4+2m^3+2m^2+m+\tfrac14\). Each polynomial identity in (7.3) is proved directly by its value at \(L=1\) and by subtracting its value at \(L\) from its value at \(L+1\): the left side adds exactly the two new endpoint terms, and expansion of the displayed right side gives those same terms. Substituting (7.3) and multiplying gives (7.2), so its degree-seven dependence has not been hidden in a remainder.

The unsquared overlap coefficient has the distinct exact leading polynomial

\[
\mathcal S_L(\theta)=\mathcal B_L\theta^2+O_L(\theta^4),\qquad
\mathcal B_L=\frac{2L^2(2L+1)(4L^2+2L+1)}3.
\tag{7.4}
\]

In fact
\(\sum_{m=-L}^{L-1}r_m=L(2L^2+1)/3\) and
\(\sum_{m=-L}^{L}m^2=L(L+1)(2L+1)/3\);
the same endpoint-increment proof establishes both identities. Multiplication by the respective face counts in (6.4) proves (7.4).

We now replace the unspecified remainder in (7.2) by an explicit bound. For every real \(t\),

\[
0\le\tfrac12t^2-(1-\cos t)\le t^4/24.
\tag{7.5}
\]

The lower bound is \(1-\cos t=2\sin^2(t/2)\le t^2/2\); the upper bound is Taylor's theorem with the fourth derivative of cosine bounded by 1. For real \(x,y\), set
\[
u=1-\cos x\cos y,\qquad q=(x^2+y^2)/2.
\]
Using \(u=\tfrac12[(1-\cos(x+y))+(1-\cos(x-y))]\) in (7.5) gives

\[
0\le u\le q,\quad
0\le q-u\le\frac{(x+y)^4+(x-y)^4}{48}
=\frac{x^4+6x^2y^2+y^4}{24}\le q^2/3.
\tag{7.6}
\]

The last inequality is equivalent to \((x^2-y^2)^2\ge0\). It follows that

\[
0\le q^2-u^2=(q-u)(q+u)\le\tfrac23q^3.
\tag{7.7}
\]

Similarly, with \(u=\sin^2x=(1-\cos2x)/2\) and \(q=x^2\), (7.5) gives \(0\le q-u\le q^2/3\), hence (7.7) again. Substituting \(x=m\theta,y=(m+1)\theta\) in the first case and \(x=m\theta\) in the second proves the signed exact bound

\[
\boxed{0\le\mathcal A_L\theta^4-\mathcal D_L(\theta)
\le\mathcal E_L|\theta|^6,}
\]
\[
\mathcal E_L=\frac23\left[
2L(2L+1)\sum_{m=-L}^{L-1}r_m^3+
4L^2\sum_{m=-L}^{L}m^6\right].
\tag{7.8}
\]

This proof is valid for every real \(\theta\), in particular for the requested regime \(|\theta|(L+1)\le1\).

The finite polynomial sum in (7.8) can be written exactly as

\[
\mathcal E_L=
\frac{L^2(2L+1)}{315}
(240L^6+360L^5+156L^4-120L^3-10L^2+40L-1).
\tag{7.9}
\]

For explicit verification, the two sums before multiplication are

\[
\begin{split}
\sum_{m=-L}^{L-1}r_m^3
&=\frac27L^7-\frac15L^5+\frac16L^3-\frac1{420}L,\\
\sum_{m=-L}^{L}m^6
&=\frac{L(L+1)(2L+1)(3L^4+6L^3-3L+1)}{21}.
\end{split}
\tag{7.10}
\]

The first polynomial has value \(1/4\) at \(L=1\), and its increment from \(L\) to \(L+1\) is \(2(L^2+L+\tfrac12)^3\), exactly the new two terms. The second has value 2 at \(L=1\) and increment \(2(L+1)^6\). This proves both formulas by induction, and substitution into (7.8) gives (7.9).

A simpler upper bound needs no signed polynomial comparison. On \(-L\le m\le L-1\), \(0<r_m\le L^2\); on \(-L\le m\le L\), \(m^6\le L^6\). Thus
\[
\begin{split}
\mathcal E_L
&\le\frac23\big[2L(2L+1)(2L)L^6+
4L^2(2L+1)L^6\big]\\
&=\frac{16}{3}L^8(2L+1)\le16L^9
\end{split}
\]
for \(L\ge1\). We have established the fully explicit form

\[
\boxed{|\mathcal D_L(\theta)-\mathcal A_L\theta^4|
\le16L^9|\theta|^6,\qquad L\ge2,\ \theta\in\mathbb R,}
\tag{7.11}
\]
with the stronger sign information in (7.8).

## 8. The order of the finite-box quantum and angular statements

For each fixed box and angle, the proved actual-vacuum expansion gives

\[
\lim_{\xi\downarrow0}\frac{\|\chi_{\xi,\theta}\|_2^2}{\xi^2}
=\frac{\mathcal D_L(\theta)}9.
\tag{8.1}
\]

Combining it with (7.2) gives the iterated, and therefore unambiguous, small-angle statement

\[
\lim_{\theta\to0}\frac1{\theta^4}
\left(\lim_{\xi\downarrow0}\frac{\|\chi_{\xi,\theta}\|_2^2}{\xi^2}\right)
=\frac{\mathcal A_L}{9}.
\tag{8.2}
\]

For every fixed \(\theta\notin2\pi\mathbb Z\), the quotient tends to \(3\kappa\) as \(\xi\downarrow0\), by (5.9). Its leading angular coefficient cancels because the entire first-order vector lies in the proved free eigenvalue-3 eigenspace (5.2). The coefficient has not vanished from the norm, the overlap, or the explicit denominator-sensitive error estimate (5.10).

The smallness of a centered state's norm is not by itself smallness of the energy quotient after normalization. In particular (8.2) is not a zero-gap conclusion. No fixed-\(b\) small-angle theorem is inferred by interchanging the limits in (8.2); the parent operator calculation treats that separate order directly.

## 9. Original admissible cusp diagonal: exact coefficient scaling

Retain the original geometric sequence, with no alteration of its units or integer coordinates:

\[
L_j=j^2,\qquad a_j=\frac1{100j},\qquad
T_j^{\mathrm{cusp}}=j^2,\qquad M_j^{\mathrm{cover}}=j,
\qquad D_j^{\mathrm{geom}}=j^4(1+O(j^{-2})).
\tag{9.1}
\]

The determinant \(D_j^{\mathrm{geom}}\) and its asymptotic in (9.1) are the original retained-cusp geometric data from the parent calculation, not the number \(M\) of lattice faces and not the function \(\mathcal D_L\). Their map to the native link parameter is

\[
\theta_j=\frac{2\pi a_j^2}{D_j^{\mathrm{geom}}}
=Cj^{-6}(1+O(j^{-2})),\qquad C=\frac{2\pi}{10^4}.
\tag{9.2}
\]

The second equality follows by substituting \(a_j^2=1/(10^4j^2)\) and inverting \(1+O(j^{-2})\), which is bounded away from zero for all sufficiently large \(j\). Consequently
\(|\theta_j|(L_j+1)=O(j^{-4})\), so the requested small-angle box regime holds eventually.

The exact polynomial (7.2) gives

\[
\mathcal A_{j^2}=\frac{16}{5}j^{14}(1+O(j^{-2})).
\tag{9.3}
\]

Meanwhile (7.11), with its explicit constant rather than a box-dependent Taylor symbol, gives

\[
0\le j^{10}\big(\mathcal A_{j^2}\theta_j^4
-\mathcal D_{j^2}(\theta_j)\big)
\le16j^{28}|\theta_j|^6=O(j^{-8}).
\tag{9.4}
\]

The fourth power in (9.2) and (9.3) gives
\(j^{10}\mathcal A_{j^2}\theta_j^4
=(16/5)C^4(1+O(j^{-2}))\).
Squeezing with (9.4) proves the exact geometric coefficient limit

\[
\boxed{\lim_{j\to\infty}j^{10}\mathcal D_{j^2}(\theta_j)
=\frac{16}{5}\left(\frac{2\pi}{10^4}\right)^4.}
\tag{9.5}
\]

In particular the sequential true-vacuum coefficient has
\[
\lim_{j\to\infty}j^{10}
\left(\lim_{\xi\downarrow0}
\frac{\|\chi_{\xi,\theta_j}\|_2^2}{\xi^2}\right)
=\frac{16}{45}\left(\frac{2\pi}{10^4}\right)^4.
\tag{9.6}
\]
The inner limit in (9.6) is taken separately on each finite box \(L_j\), exactly as in (8.1). Equation (9.6) is not a simultaneous quantum limit.

Indeed the number of all faces on this diagonal is
\[
M_j^{\mathrm{faces}}=12j^4(2j^2+1),
\]
so the explicit spectral-projection disk (3.3) is exactly

\[
|\xi|<\frac1{64j^4(2j^2+1)}
\sim\frac1{128j^6}.
\tag{9.7}
\]

The Sobolev/Taylor constants \(C_{L_j}\) in (5.7)--(5.10) also remain box-dependent, and (5.10) further divides by \(\mathcal D_{j^2}(\theta_j)\), which is of order \(j^{-10}\). These facts are displayed to prevent use of an unproved uniform remainder.

For the original mesh and fixed \(g_{\mathrm{YM}}>0\),
\[
\kappa_j=200g_{\mathrm{YM}}^2j,\qquad
b_j=\frac{50j}{g_{\mathrm{YM}}^2},\qquad
\xi_j=\frac1{4g_{\mathrm{YM}}^4},\qquad
3\kappa_j=600g_{\mathrm{YM}}^2j.
\tag{9.8}
\]

The ratio \(\xi_j\) is fixed, not shrinking, and eventually exceeds the sufficient disk (9.7). Consequently neither the leading quotient \(3\kappa_j\) nor its fixed-box remainder justifies a fixed-\(g_{\mathrm{YM}}\), growing-box quantum limit. Equations (9.5)--(9.6) concern the explicit coefficient and the displayed order of limits only. They neither prove nor refute a four-dimensional continuum gap.

## 10. Exact verification and provenance

The companion checker, check_magnetic_translation.py, uses integer and rational quaternion arithmetic. The four conjugations by \(I,-i\sigma_1,-i\sigma_2,-i\sigma_3\) average every \(2\times2\) matrix exactly to its scalar part: each imaginary coefficient has two positive and two negative conjugation signs, while the scalar coefficient is fixed. Thus their discrete average is precisely (2.4), not a numerical Haar sample. After the cancellations in (2.3), each independent vertex appears in only one such matrix twirl. The checker's full \(4^4=256\)-term vertex average is therefore exact for the original plaquette integrand. It evaluates the original translated, gauge-transformed word before using the projected formula, including noncommuting rational assignments, shared-source cancellation, and the explicit failure of the background-holonomy rule.

For \(L=2,\ldots,7\), the checker tests the whole-box angular sums at the rational-cosine angles \(0,\pi/2,\pi,\pi/3\), the Fourier identities, special angles, both leading \(L\)-polynomials, and the sign of the central cochain on every face in every plane. It also tests the sixth-order error polynomial and its explicit upper bound. These are exact algebra/incidence diagnostics, not a vacuum simulation or a continuum computation.

The full-box vacuum construction and metric dictionary agree with BULK_PLAQUETTE_EXTENSION.md; the ground-state form agrees with spatial_vacuum_elimination.tex. All specific definitions and proofs used in this calculation are written above. Standard compact-group and elliptic spectral facts are used with the displayed compact state space, exact Casimir, domain, and bounded potential; no external numerical claim or unproved marginal closure enters. No remote action, new agent, PDF generation, or heavy job was used. The result is an exact full-vertex projection and a controlled finite interacting quantum excitation calculation, together with the explicit geometric coefficient limit (9.5).

```

## Complete source: wilson_variation/check_magnetic_translation.py

```python
"""Exact finite Haar-twirl, box-sum, and coefficient checks.

Only integers and fractions are used.  The four quaternion conjugations
twirl every 2-by-2 matrix exactly; they are not a numerical Haar sample.
Analytic-vacuum and operator-domain proofs are in the companion Markdown.
"""

from fractions import Fraction as F
from itertools import product


def qmul(a, b):
    """SU(2) quaternion convention q0 I - i sum(qk sigma_k)."""
    a0, a1, a2, a3 = a
    b0, b1, b2, b3 = b
    return (
        a0*b0-a1*b1-a2*b2-a3*b3,
        a0*b1+a1*b0+a2*b3-a3*b2,
        a0*b2+a2*b0+a3*b1-a1*b3,
        a0*b3+a3*b0+a1*b2-a2*b1,
    )


def qinv(a):
    return (a[0], -a[1], -a[2], -a[3])


def qproduct(*factors):
    out = (F(1), F(0), F(0), F(0))
    for factor in factors:
        out = qmul(out, factor)
    return out


def unit(a):
    return sum(x*x for x in a) == 1


identity = (F(1), F(0), F(0), F(0))
twirl = tuple(tuple(F(int(i == j)) for i in range(4)) for j in range(4))
links = (
    (F(3, 5), F(4, 5), F(0), F(0)),
    (F(5, 13), F(0), F(12, 13), F(0)),
    (F(8, 17), F(0), F(0), F(15, 17)),
    (F(1, 2), F(1, 2), F(1, 2), F(1, 2)),
)
generic_h = (
    (F(7, 25), F(24, 25), F(0), F(0)),
    (F(20, 29), F(0), F(21, 29), F(0)),
    (F(12, 37), F(0), F(0), F(35, 37)),
    (F(1, 2), -F(1, 2), F(1, 2), -F(1, 2)),
)
for quaternion in links + generic_h + twirl:
    assert unit(quaternion)

# Four conjugations annihilate all imaginary coordinates and fix the scalar.
for test in generic_h + ((F(2), F(3), F(5), F(7)),):
    avg = tuple(
        sum(qproduct(qinv(g), test, g)[i] for g in twirl)/4
        for i in range(4)
    )
    assert avg == (test[0], F(0), F(0), F(0))


def alpha(h):
    bottom, right, top, left = h
    return qproduct(left, qinv(bottom))[0] * qinv(right)[0] * top[0]


def actual_vertex_twirl(h):
    """Translate the four independently gauge-transformed physical links."""
    total = F(0)
    for g00, g10, g11, g01 in product(twirl, repeat=4):
        gauge_links = (
            qproduct(g00, links[0], qinv(g10)),
            qproduct(g10, links[1], qinv(g11)),
            qproduct(g01, links[2], qinv(g11)),
            qproduct(g00, links[3], qinv(g01)),
        )
        translated = tuple(qproduct(qinv(k), u) for k, u in zip(h, gauge_links))
        word = qproduct(
            translated[0], translated[1],
            qinv(translated[2]), qinv(translated[3]),
        )
        total += 2*word[0]
    return total/F(4**4)


wilson = 2*qproduct(links[0], links[1], qinv(links[2]), qinv(links[3]))[0]
assert wilson != 0
shared = generic_h[0]
cases = (
    (identity,)*4,
    generic_h,
    (shared, identity, identity, shared),
    (twirl[3],)*4,
)
for h in cases:
    assert actual_vertex_twirl(h) == alpha(h)*wilson
    assert alpha(tuple(qinv(matrix) for matrix in h)) == alpha(h)
assert alpha(cases[2]) == 1  # shared source factors cancel BEFORE twirling
assert alpha(cases[3]) == 0
flat_background_word = qproduct(cases[3][0], cases[3][1],
                               qinv(cases[3][2]), qinv(cases[3][3]))
assert flat_background_word[0] == 1  # naive background-holonomy coefficient

# Exact cosine cycles for theta = 0, pi/2, pi, pi/3.
cycles = {
    "0": (F(1),),
    "pi/2": (F(1), F(0), -F(1), F(0)),
    "pi": (F(1), -F(1)),
    "pi/3": (F(1), F(1, 2), -F(1, 2), -F(1), -F(1, 2), F(1, 2)),
}


def norm_coefficient(L, cosine):
    a = 2*L*(2*L+1)
    b = 4*L*L
    s12 = sum((1-cosine(m)*cosine(m+1))**2 for m in range(-L, L))
    s13 = sum((1-cosine(m)**2)**2 for m in range(-L, L+1))
    return a*s12+b*s13


for L in range(2, 8):
    a = 2*L*(2*L+1)
    b = 4*L*L
    moment12 = sum((F(m*m+m)+F(1, 2))**2 for m in range(-L, L))
    moment13 = sum(F(m)**4 for m in range(-L, L+1))
    assert moment12 == F(L*(4*L**4+1), 10)
    assert moment13 == F(L*(L+1)*(2*L+1)*(3*L*L+3*L-1), 15)
    polynomial = F(L*L*(2*L+1)*(24*L**4+24*L**3+8*L*L-4*L+3), 15)
    assert a*moment12+b*moment13 == polynomial
    overlap_moment = (
        a*sum(F(m*m+m)+F(1, 2) for m in range(-L, L))
        + b*sum(F(m*m) for m in range(-L, L+1))
    )
    assert overlap_moment == F(2*L*L*(2*L+1)*(4*L*L+2*L+1), 3)
    moment_cube = sum((F(m*m+m)+F(1, 2))**3 for m in range(-L, L))
    moment_six = sum(F(m)**6 for m in range(-L, L+1))
    assert moment_cube == F(2*L**7, 7)-F(L**5, 5)+F(L**3, 6)-F(L, 420)
    assert moment_six == F(L*(L+1)*(2*L+1)*(3*L**4+6*L**3-3*L+1), 21)
    error_coefficient = F(2, 3)*(a*moment_cube+b*moment_six)
    error_polynomial = F(
        L*L*(2*L+1)*(240*L**6+360*L**5+156*L**4-120*L**3-10*L*L+40*L-1),
        315,
    )
    assert error_coefficient == error_polynomial
    assert 0 < error_coefficient <= 16*L**9
    face_count_diagonal = 12*L**4*(2*L*L+1)
    assert F(3, 16*face_count_diagonal) == F(1, 64*L**4*(2*L*L+1))

    for angle, cycle in cycles.items():
        cosine = lambda m, seq=cycle: seq[m % len(seq)]
        direct = norm_coefficient(L, cosine)
        odd1 = sum(cosine(2*m+1) for m in range(-L, L))
        odd2 = sum(cosine(2*(2*m+1)) for m in range(-L, L))
        even2 = sum(cosine(2*m) for m in range(-L, L+1))
        even4 = sum(cosine(4*m) for m in range(-L, L+1))
        a_theta = 1-cosine(1)/2
        fourier12 = 2*L*(a_theta*a_theta+F(1, 8))-a_theta*odd1+odd2/8
        fourier13 = F(3*(2*L+1), 8)-even2/2+even4/8
        assert direct == a*fourier12+b*fourier13
        if angle == "0":
            assert direct == 0
        elif angle == "pi":
            assert direct == 16*L*L*(2*L+1)
        elif angle == "pi/2":
            assert direct == 4*L*L*(3*L+1+(L % 2))
        else:
            assert direct > 0

    # The exact central cochain flips EVERY face, including planes 13 and 23.
    vertices = product(range(-L, L+1), repeat=3)
    for n in vertices:
        for i, j in ((0, 1), (0, 2), (1, 2)):
            if n[i] == L or n[j] == L:
                continue
            ni, nj = list(n), list(n)
            ni[i] += 1
            nj[j] += 1
            sign = lambda x, k: -1 if sum(x[:k]) % 2 else 1
            assert sign(n, i)*sign(ni, j)*sign(nj, i)*sign(n, j) == -1

print("PASS: four exact 256-term vertex twirls, including noncommuting h,")
print("shared-source cancellation, and the failure of the naive holonomy rule.")
print("PASS: exact whole-box angular/Fourier sums, exceptional angles,")
print("both small-angle L-polynomials, and all-plane coupling-parity cochain")
print("for L=2,...,7. No floating point or sampled Haar integration used.")
print("PASS: exact sixth-order error polynomial, the bound 16 L^9,")
print("and the original diagonal's full-face spectral radius.")

```

## Complete source: local_energy_current_true_vacuum.md

```markdown
# Local energy currents and the first surviving quantum state

8 September 2026. This calculation keeps every link and every elementary
plaquette of the interacting three-dimensional spatial Wilson box. Time
is the Hamiltonian time; no fourth spatial coordinate is added. The
weighted electric operator from the magnetic continuation is extended by
the matching magnetic energy, with the extension written explicitly.
The first plaquette contribution then cancels. The next contribution is
calculated below, rather than inferred to have zero norm or zero energy.

## 1. Full Hamiltonian, state space, and weighted operator

Fix an integer \(L\ge2\). Vertices are
\(\{-L,\ldots,L\}^3\). A positively oriented physical link
\(e=(n,i)\) exists when both \(n\) and \(n+\mathbf e_i\) are
vertices. Its variable is \(U_e\in SU(2)\); inverse traversal uses
\(U_e^{-1}\). For every elementary face \(p=(n;i,j)\), \(i<j\), put
\[
 W_p=\operatorname{tr}\{U_i(n)U_j(n+\mathbf e_i)
                  U_i(n+\mathbf e_j)^{-1}U_j(n)^{-1}\}.
\tag{1.1}
\]
The full link and face sets are denoted \(\mathsf E_L,\mathsf P_L\).
Their cardinalities are
\[
 N=3(2L)(2L+1)^2,\qquad M=3(2L)^2(2L+1).
\]
All sums below use these sets, including boundary links and faces in all
three planes. On \(\mathcal H=L^2(SU(2)^N,dU)\), with product Haar
probability measure, use
\[
 T_a=-i\sigma_a/2,\quad
 X_{e,a}F=\left.\frac{d}{dt}F(\ldots,e^{tT_a}U_e,\ldots)\right|_{t=0},
 \quad E_e=-\sum_{a=1}^3X_{e,a}^2.
\]
These conventions give fundamental Casimir \(3/4\). The original metric
\(c(A,B)=-\operatorname{tr}(AB)/2\) has orthonormal basis \(2T_a\),
so \(-\Delta_e^c=4E_e\). Retain
\[
 H=\kappa H_0+V,\quad H_0=\sum_e E_e,\quad
 V=\sum_p V_p,\quad V_p=b(2-W_p),
 \quad \kappa=\frac{2g_{\rm YM}^2}{a},\quad
 b=\frac{1}{2g_{\rm YM}^2a},\quad \xi=\frac b\kappa.
\tag{1.2}
\]
In particular \(\xi=1/(4g_{\rm YM}^4)\), and the constant \(2bM\)
is part of H. It is not removed from the energy origin.

Gauge transformations act by \(U_e\mapsto g_{s(e)}U_eg_{t(e)}^{-1}\).
Each \(E_e\) is bi-invariant and each \(W_p\) is gauge invariant.
Hence every operator used below preserves the gauge-invariant subspace.

The compact connected configuration space, elliptic kinetic operator,
and bounded smooth V give a compact-resolvent self-adjoint H with domain
\(H^2\) and form domain \(H^1\). Its bottom eigenvector \(\psi>0\)
is smooth and unique after fixing \(\int\psi^2dU=1\). Here is the
argument needed below. Taking the modulus of a form minimizer does not
increase its gradient energy, by approximation with
\(\sqrt{|u|^2+\varepsilon^2}\). Elliptic regularity and the strong
maximum principle make a nonnegative minimizer smooth and strictly
positive. If its eigenvalue is \(\mathcal E\), integration by parts
gives, for smooth F,
\[
 \mathfrak q_{H-\mathcal E}[\psi F]
 =\kappa\sum_{e,a}\int |X_{e,a}F|^2\psi^2dU.
\tag{1.3}
\]
A second bottom eigenvector divided by \(\psi\) would have every
derivative zero and hence be constant. This proves uniqueness, and gauge
transformations therefore fix \(\psi\). Write \(\mathcal A=H-\mathcal E\).

For arbitrary real link weights \(f_e\), including signed weights, define
\[
 f_p=\frac14\sum_{e\in\partial p}f_e,\quad
 D_f=\kappa\sum_e f_eE_e+\sum_p f_pV_p,
 \quad \zeta_f=(D_f-\langle\psi,D_f\psi\rangle)\psi.
\tag{1.4}
\]
Thus the coefficient \(1/4\) distributes each *same* face energy among
its four boundary links. The magnetic extension is explicit: if
\(\Gamma=\sum_{e=(n,1)}n_2^2E_e\) is the original magnetic-translation
operator, take \(f_{(n,1)}=n_2^2\), \(f_{(n,2)}=f_{(n,3)}=0\).
Then \(D_f=\kappa\Gamma+\sum_p f_pV_p\); it is a new physical trial
operator in the original Hamiltonian, not an assertion that its magnetic
term was already present in \(\Gamma\).

The signed kinetic sum in (1.4) is self-adjoint on its diagonal
Peter--Weyl spectral domain: a coefficient with spins \(j_e\) has
eigenvalue \(\kappa\sum_e f_ej_e(j_e+1)\). Its domain is the set
whose squared coefficients times this eigenvalue squared are summable.
This domain need not equal \(H^2\) when weights are signed. Adding the
bounded real potential in (1.4) preserves self-adjointness on that domain.
All smooth vectors lie in it, and D_f maps smooth vectors to smooth
vectors. Thus \(\zeta_f\) is a well-defined smooth, gauge-invariant,
vacuum-orthogonal state. Every product and commutator below is evaluated
on smooth vectors; no bounded-operator claim about D_f is needed.

## 2. Exact energy current and spectral moments at arbitrary positive coupling

The product rule with the above sign of \(E_e\) gives
\[
 [E_e,V_p]F=-\sum_a\{(X_{e,a}^2V_p)F
                       +2(X_{e,a}V_p)X_{e,a}F\}.
\tag{2.1}
\]
It vanishes when \(e\notin\partial p\). Since all link Casimirs
commute and all potential multiplication operators commute,
\[
 [H,D_f]=\kappa\sum_{p}\sum_{e\in\partial p}
                         (f_p-f_e)[E_e,V_p].
\tag{2.2}
\]
This is an exact weighted-difference formula, not an expansion in the
background angle or coupling. All derivatives of every V_p in (2.1)
remain, including the first-derivative terms acting on F.

Define local energy operators and antisymmetric currents by
\[
 h_e=\kappa E_e+\frac14\sum_{p\ni e}V_p,\qquad
 J_{ef}=i[h_e,h_f]
       =\frac{i\kappa}{4}\sum_{p:\ e,f\in\partial p}
                         ([E_e,V_p]-[E_f,V_p]).
\tag{2.3}
\]
For \(e=f\) both sides of the last formula are zero. Each face is
counted four times in \(\sum_e h_e\), so \(\sum_e h_e=H\).
The exact Heisenberg derivative and its weighted form are therefore
\[
 i[H,h_e]=-\sum_fJ_{ef},\qquad
 i[H,D_f]=\frac12\sum_{e,f}(f_f-f_e)J_{ef}.
\tag{2.4}
\]
The second equality follows by exchanging e and f in one of the two
terms, using \(J_{ef}=-J_{fe}\). Expanding (2.3) also gives (2.2).
Currents between links that share no face vanish exactly. A constant
weight gives D_f equal to that constant times H and \(\zeta_f=0\)
exactly, not merely to a computed order.

Let \(d_f=\|\zeta_f\|^2\), \(n_f=\mathfrak q_{\mathcal A}[\zeta_f]\).
The vacuum eigen-equation and expansion of the double commutator give
\[
 \mathcal A\zeta_f=[H,D_f]\psi,\qquad
 n_f=\frac12\langle\psi,[D_f,[H,D_f]]\psi\rangle,
 \qquad
 \|\mathcal A\zeta_f\|^2=\|i[H,D_f]\psi\|^2.
\tag{2.5}
\]
For example the double commutator expands to
\(2D_fHD_f-D_f^2H-HD_f^2\); its expectation is twice
\(\langle D_f\psi,(H-\mathcal E)D_f\psi\rangle\).
There is no change of vacuum in these formulas.

To specify their spectral content, choose a complete orthonormal
eigenbasis \(u_0=\psi,u_1,u_2,\ldots\) of the physical Hamiltonian,
with \(\mathcal A u_\ell=\lambda_\ell u_\ell\),
\(\lambda_\ell>0\) for \(\ell\ge1\). Set
\[
 d\mu_f(\lambda)=\sum_{\ell\ge1}
 |\langle u_\ell,D_f\psi\rangle|^2\delta_{\lambda_\ell}(d\lambda).
\]
Completeness, smoothness, and (2.5) prove
\[
 d_f=\int d\mu_f,\quad n_f=\int\lambda\,d\mu_f,\quad
 \|i[H,D_f]\psi\|^2=\int\lambda^2d\mu_f.
\tag{2.6}
\]
Thus a small current matrix element is accompanied by a specified state
norm, rather than being identified with an excitation energy on its own.

## 3. The second coefficient of the actual all-plaquette vacuum

Put \(S=\sum_pW_p\). The exact Hamiltonian is
\(H=\kappa(H_0-\xi S)+2bM\). The first nonzero full-Hilbert-space
eigenvalue of H_0 is \(3/4\). Also \(\|S\|_\infty=2M\): the upper
bound follows from \(|W_p|\le2\), and the all-identity configuration
and its positive-measure neighborhoods give equality. On the circle
\(|z|=3/8\), the free resolvent has norm at most \(8/3\). Factoring
\(z-H_0+\xi S\) therefore yields a convergent Neumann series when
\[
 |\xi|<\frac{3}{16M}.
\tag{3.1}
\]
The contour spectral projection is analytic and rank one there, by
continuity from \(\xi=0\). For real \(\xi\) in this interval,
min--max bounds place the lowest eigenvalue in
\([-2M|\xi|,0]\) and every other eigenvalue above
\(3/4-2M|\xi|>3/8\), so this is the actual ground projection.
Its positive unit-norm eigenvector is real analytic in a neighborhood
of zero. Elliptic regularity applied successively to the eigen-equation
gives analyticity in each fixed Sobolev space. Neighborhood and remainder
constants here may depend on L; no volume-uniform disk is asserted.

Integrating a single boundary link proves
\[
 \int W_p=0,\qquad \int W_pW_q=\delta_{pq},\qquad H_0W_p=3W_p.
\tag{3.2}
\]
For distinct faces there is an edge in only one of them; multiplication
of that link by \(-I\) changes the integrand's sign. For equal faces,
Haar invariance reduces the integral to
\(\int_{SU(2)}(\operatorname{tr}U)^2dU=1\). The latter follows from
\(U=u_0I+i\sum_au_a\sigma_a\), uniform on the unit 3-sphere,
where \(\int u_0^2=1/4\). Four fundamental Casimirs give the last
identity in (3.2).

Write the positive unit-norm vacuum and dimensionless bottom energy as
\[
 \psi_\xi=1+\xi A+\xi^2B+O_{H^k,L}(\xi^3),\quad
 A=\frac13S,\quad e(\xi)=-\frac M3\xi^2+O_L(\xi^3).
\]
Coefficient comparison in \((H_0-\xi S)\psi_\xi=e(\xi)\psi_\xi\)
and the retained unit-norm condition give
\[
 H_0B=\frac13(S^2-M),\qquad \int B=-\frac M{18}.
\tag{3.3}
\]
Let \(R_0\) act as zero on constants and as the inverse of H_0 on
their orthogonal complement. Then B is the completely specified finite
polynomial \(R_0(S^2-M)/3-M/18\). Its fully resolved terms are as follows.

For an unordered pair of distinct faces sharing an edge e, define
\[
 P_{pq,0}=\int_{SU(2)}W_pW_q\,dU_e,\qquad
 P_{pq,1}=W_pW_q-P_{pq,0}.
\tag{3.4}
\]
The first expression is a function of the other links. It is one half
of the fundamental trace around the six-edge boundary, with either
orientation giving the same SU(2) trace. To see the coefficient, reverse
one of the face words if necessary so the shared link is oppositely
traversed, and cyclically write the traces as
\(\operatorname{tr}(U_eA)\) and \(\operatorname{tr}(U_e^{-1}B)\).
The fundamental Haar identity
\(\int U_{ij}\overline{U}_{kl}dU=\delta_{ik}\delta_{jl}/2\)
gives \(P_{pq,0}=\operatorname{tr}(AB)/2\). A,B use six distinct
outer links. Their products are independent Haar variables when those
links are integrated. The shared-link tensor product has spins 0 and 1,
while every outer link has spin \(1/2\). Consequently
\[
 H_0P_{pq,0}=\frac92P_{pq,0},\quad
 H_0P_{pq,1}=\frac{13}2P_{pq,1},\quad
 \|P_{pq,0}\|^2=\frac14,\quad \|P_{pq,1}\|^2=\frac34.
\tag{3.5}
\]
The total squared norm of \(W_pW_q\) is 1 by integrating A and B
first; the Haar projection is orthogonal, proving the last norm.

A repeated face gives \(W_p^2-1\), the spin-1 character, with
H_0 eigenvalue 8. An edge-disjoint pair gives \(W_pW_q\) with
H_0 eigenvalue 6, even if its faces share a vertex. These statements
exhaust the face pairs. Thus no term is hidden in the inverse:
\[
 \boxed{B=-\frac M{18}
 +\sum_p\frac{W_p^2-1}{24}
 +\sum_{\{p,q\}:\partial p\cap\partial q=\varnothing}\frac{W_pW_q}{9}
 +\sum_{\{p,q\}:|\partial p\cap\partial q|=1}
       \left(\frac4{27}P_{pq,0}+\frac4{39}P_{pq,1}\right).}
\tag{3.6}
\]
Each sum over distinct pairs is unordered. Every independent link of
the full Hamiltonian is still present; (3.6) is a coefficient of its
vacuum, not a replacement by separate two-face Hamiltonians.

## 4. Cancellation and the first surviving state, with all constants

Set \(F_f=\sum_pf_p\), \(S_f=\sum_pf_pW_p\),
\(E_f=\sum_ef_eE_e\). Equation (1.4) is exactly
\[
 D_f=\kappa\{E_f-\xi S_f+2\xi F_fI\}.
\tag{4.1}
\]
The link Casimir gives \(E_fA=S_f\), since
\(E_fW_p=(3/4)\sum_{e\in\partial p}f_eW_p=3f_pW_p\).
Thus the first-order vector of the centered state cancels for *every*
chosen weight profile. Its scalar expectation, retaining its origin, is
\[
 \langle\psi_\xi,D_f\psi_\xi\rangle
 =\kappa\left(2\xi F_f-\frac{\xi^2}3F_f\right)+O_L(\kappa\xi^3),
\]
because \(\langle A,E_fA\rangle=F_f/3\) and
\(\langle S_f\rangle_{\psi_\xi^2}=2\xi F_f/3+O_L(\xi^2)\).
Subtracting this scalar times the same vacuum gives
\[
 \zeta_f=\kappa\xi^2 Z_f+O_{H^k,L,f}(\kappa\xi^3),\qquad
 Z_f=E_fB-S_fA+\frac{F_f}{3}.
\tag{4.2}
\]

Inserting (3.6) resolves every cancellation. For a repeated face,
\(E_f(W_p^2-1)=8f_p(W_p^2-1)\), so its contribution in (4.2) is
\(f_p(W_p^2-1)/3-f_pW_p^2/3+f_p/3=0\).
For an edge-disjoint pair, \(E_f(W_pW_q)=3(f_p+f_q)W_pW_q\);
its B term cancels the two corresponding ordered terms of S_fA.

For an adjacent pair with shared edge e, all six outer edges have
Casimir \(3/4\) and the shared edge has Casimir 0 or 2. Therefore
\[
 E_fP_{pq,0}=\left(3(f_p+f_q)-\frac32f_e\right)P_{pq,0},\qquad
 E_fP_{pq,1}=\left(3(f_p+f_q)+\frac12f_e\right)P_{pq,1}.
\]
Define \(\delta_{pq}(f)=f_p+f_q-2f_e\). Subtracting the two terms
from S_fA leaves the exact finite sum
\[
 \boxed{Z_f=\sum_{\{p,q\}:\partial p\cap\partial q=\{e\}}
 \delta_{pq}(f)\left(\frac{P_{pq,0}}9-\frac{P_{pq,1}}{39}\right).}
\tag{4.3}
\]
The denominators 9 and 39 arise from the distinct \(9/2\) and
\(13/2\) electric channels, not from dropping their interaction.

Different unordered adjacent pairs are orthogonal in both channels.
Here is a direct proof covering coplanar and hinged pairs. Both channel
functions are odd under \(U_l\mapsto -U_l\) on each of the six
outer boundary edges and even on the shared edge. Two distinct pairs
have different six-edge boundaries: otherwise the symmetric difference
of their two face sets would be a nonempty mod-2 two-cycle with at most
four faces. Choose a face in that cycle. Each of its four boundary
edges needs another face. Two distinct elementary square faces share
at most one edge, so four distinct other faces would be needed, at
least five in total, a contradiction. Multiplication by \(-I\) on
an edge in just one of the boundaries now annihilates the cross integral.
The same holds with H_0 applied, because of (3.5).

Put \(\mathcal D_f=\sum_{\{p,q\}\ \text{adjacent}}\delta_{pq}(f)^2\).
Using both norms and both electric eigenvalues in (3.5) gives
\[
 \boxed{\|Z_f\|^2=\frac{49}{13689}\mathcal D_f,\qquad
 \langle Z_f,H_0Z_f\rangle=\frac{2}{117}\mathcal D_f.}
\tag{4.4}
\]
Explicitly the first coefficient is
\(1/(4\cdot9^2)+3/(4\cdot39^2)=49/13689\); the second is
\((9/2)/(4\cdot9^2)+3(13/2)/(4\cdot39^2)=2/117\).

All odd scalar powers vanish. Indeed the central link transformation
\(z_i(n)=(-1)^{\sum_{j<i}n_j}I\) gives an involutive Haar unitary
\(\mathcal Z\) sending *every* W_p to \(-W_p\), and commuting with
every E_e. It sends \(H_0-\xi S\) to \(H_0+\xi S\), so uniqueness
gives \(\psi_{-\xi}=\mathcal Z\psi_\xi\). Equation (4.1) gives
\(D_{f,-\xi}=\mathcal ZD_{f,\xi}\mathcal Z-4\kappa\xi F_fI\).
This scalar is exactly removed by centering, and hence
\(\zeta_{f,-\xi}=\mathcal Z\zeta_{f,\xi}\). The centered H transforms
in the same way. Consequently the squared norm and excitation form
are even real-analytic functions locally at zero. Combining this with
(4.2)--(4.4) proves
\[
 d_f=\kappa^2\xi^4\frac{49}{13689}\mathcal D_f
                         +O_{L,f}(\kappa^2\xi^6),\qquad
 n_f=\kappa^3\xi^4\frac{2}{117}\mathcal D_f
                         +O_{L,f}(\kappa^3\xi^6).
\tag{4.5}
\]
For each fixed profile with \(\mathcal D_f>0\), this proves a
nonzero state for a genuine sufficiently small positive interval of
\(\xi\), and
\[
 \frac{n_f}{d_f}=\frac{234}{49}\kappa+O_{L,f}(\kappa\xi^2).
\tag{4.6}
\]
The squared norm, not the unsquared norm, is analytic in the preceding
statement. When \(\mathcal D_f=0\), formula (4.3) says exactly that
this coefficient vanishes; it does not by itself assert the full state
vanishes. Constant f was resolved exactly in Section 2.

## 5. An exact spatial profile and its full boundary count

Take a fixed coordinate direction r and the link-midpoint weights
\[
 f_{(n,i)}=n_r+\frac12\delta_{ir}.
\tag{5.1}
\]
These are the original lattice coordinates, without replacing the
signed profile by its absolute value. Their face average is the face
center coordinate
\(f_{(n;i,j)}=n_r+(\delta_{ir}+\delta_{jr})/2\).
If physical midpoint length is wanted, it is exactly a times (5.1);
then D_f and \(\zeta_f\) are multiplied by a and both (4.5) scalars
by \(a^2\). The Rayleigh quotient is unchanged by this stated map.

For an edge of direction i, the centers of two incident faces are
\(x(e)+s\mathbf e_j/2\) and \(x(e)+t\mathbf e_k/2\), where
j,k differ from i and the signs indicate which available side is used.
For coplanar distinct faces j=k and s=-t, so \(\delta_{pq}=0\).
For hinged pairs j differs from k,
\[
 \delta_{pq}=\frac12(s\delta_{jr}+t\delta_{kr}).
\]
It is zero when i=r and has squared value \(1/4\) when i differs
from r. At a transverse coordinate \(n_j\), the number of available
incident j-faces is \(a_j(n_j)=1\) at either endpoint \(\pm L\)
and 2 otherwise. Its sum over \(-L,\ldots,L\) is \(4L\).
Thus the complete number of hinged pairs sharing direction-i edges is
\((2L)(4L)^2=32L^3\). There are two directions i differing from r.
This proves, including every boundary case,
\[
 \mathcal D_f=\frac14\cdot2\cdot32L^3=16L^3.
\tag{5.2}
\]
The explicit leading results are therefore
\[
 d_f=\frac{784}{13689}\kappa^2\xi^4L^3
                         +O_L(\kappa^2\xi^6),\qquad
 n_f=\frac{32}{117}\kappa^3\xi^4L^3
                         +O_L(\kappa^3\xi^6).
\tag{5.3}
\]
The profile's energy expectation is actually zero for every positive b.
Reflection \(n_r\mapsto-n_r\) induces a Haar-preserving link-variable
map; links whose orientation reverses are inverted. It preserves H,
every link Casimir, and the unique positive vacuum, and changes all
the midpoint and face-center weights in (5.1) to their negatives.
Thus its unitary conjugates D_f to \(-D_f\). Taking the vacuum
expectation proves \(\langle D_f\rangle=0\) exactly. This does not
assert the nonzero-state conclusion uniformly at every coupling.

There is also an exact all-coupling statement for *all* affine profiles,
not only their computed Taylor coefficient. Write
\[
 f_e=c+\sum_{r=1}^3t_r x_r(e),\qquad
 x_r((n,i))=n_r+\frac12\delta_{ir},\qquad t_r,c\in\mathbb R.
\]
Let \(\zeta_r=D_{x_r}\psi\); the reflection argument just proved its
expectation is zero. Since the constant-weight operator is cH,
\(\zeta_f=\sum_rt_r\zeta_r\) exactly. For every Borel set
\(B\subset(0,\infty)\), let \(P_B=1_B(\mathcal A)\). Reflection in
coordinate r commutes with \(P_B\), changes \(\zeta_r\) to its negative,
and fixes \(\zeta_s\) when \(s\ne r\). Consequently
\(\langle\zeta_r,P_B\zeta_s\rangle=0\) for \(r\ne s\).
Coordinate permutations also preserve the box and H and exchange the
three midpoint profiles, so the three diagonal expectations agree.
Thus the *entire* spectral measures, not only their first moments, obey
\[
 \boxed{\mu_f(B)=(t_1^2+t_2^2+t_3^2)\,\mu_{x_1}(B)}
 \qquad\text{for every }b>0.
\tag{5.4}
\]
The group-variable inversion needed on an orientation-reversed link
is Haar preserving and preserves its Casimir; reversed face traces
equal the original traces in SU(2). These facts justify both symmetry
actions on the actual Hilbert space. All original affine coefficients
are retained in (5.4). Its content is that varying a slope's direction,
size or constant term within this specified family changes the spectral
weight by the displayed scalar, not its positive-energy support.
It makes no assertion that a non-affine profile has the same measure.
In particular \(\mathcal D_f=16L^3(t_1^2+t_2^2+t_3^2)\), also obtained
by taking the coefficient of \(\xi^4\) in this exact identity.

The physical coefficient dictionary remains
\[
 \kappa^2\xi^4=\frac{1}{64g_{\rm YM}^{12}a^2},\quad
 \kappa^3\xi^4=\frac{1}{32g_{\rm YM}^{10}a^3},\quad
 \frac{234}{49}\kappa=\frac{468g_{\rm YM}^2}{49a}.
\tag{5.5}
\]
The common \(L^3\) in (5.3) is a computed Taylor coefficient, not
a statement that the all-coupling remainder is uniform in L. The
proved disk (3.1) itself shrinks with M. Sending L to infinity at a
fixed positive coupling cannot be justified by inserting that limit
in (5.3).

## 6. Relation to the spectral target and literature

Equations (2.2)--(2.6) give the exact energy-current map and spectral
measure for these physical states at arbitrary positive coupling.
Equations (3.6)--(5.5) calculate the actual first surviving coefficient
after the local electric/magnetic cancellation. In this explicit regime
the cancellation produces the two adjacent-face channels, with quotient
\(234\kappa/49\), rather than an arbitrarily small excitation energy.
It does not decide the joint large-volume, small-spacing quantum limit.
That limit requires control of the actual spectral measure (2.6) with
the original coupling and geometry retained; neither the smoothness of
a classical background nor the exact constant-weight zero state
supplies its nonzero low-energy weight.

The Hamiltonian conventions are those of J. Kogut and L. Susskind,
*Hamiltonian formulation of Wilson's lattice gauge theories*, Physical
Review D **11** (1975), 395--408,
<https://doi.org/10.1103/PhysRevD.11.395>, with the explicit metric and
coefficient dictionary in (1.2). The use of an observable applied to
the true vacuum and a ratio of its spectral moments belongs to the
variational tradition exemplified by R. P. Feynman, *Atomic Theory of
the Two-Fluid Model of Liquid Helium*, Physical Review **94** (1954),
262--277, <https://doi.org/10.1103/PhysRev.94.262>. No helium structure
factor or helium dispersion is imported into this gauge theory.

For compact-graph gauge projection, a primary comparison is B. Bahr
and T. Thiemann, *Gauge-invariant coherent states for loop quantum
gravity. II. Non-Abelian gauge groups*, Classical and Quantum Gravity
**26** (2009), 045012, <https://doi.org/10.1088/0264-9381/26/4/045012>,
<https://arxiv.org/abs/0709.4636>. Its product-Haar vertex projection
acts on the same kind of compact link Hilbert space. Here the seed
is the actual interacting Wilson vacuum, not a heat-kernel coherent
state; no gravitational dynamics is identified with H.

The four-dimensional quantum target is the construction and spectral
statement in A. Jaffe and E. Witten, *Quantum Yang--Mills Theory*,
<https://www.claymath.org/wp-content/uploads/2022/06/yangmills.pdf>.
No continuum construction or mass-gap disproof is claimed in this note.

```

## Complete source: wilson_variation/ELECTRIC_COVARIANCE_UNSIGNED_INCIDENCE_20260908.md

```markdown
# Actual-vacuum electric covariance, the full unsigned incidence kernel, and its first surviving states

8 September 2026. The Hamiltonian contains every link and every elementary plaquette of the full open three-dimensional \(SU(2)\) spatial box. This proof computes its true-vacuum covariance and energy matrices, gives the entire finite unsigned incidence kernel, and calculates the first nonzero interacting vacuum state for every nonzero real weight in that leading kernel. The kernel is not identified with an exact all-coupling zero-state space.

## 1. Complete finite model and domains

Fix an integer \(L\ge2\), put \(m=2L\), and let the vertices be \(n\in\{-L,\ldots,L\}^3\). The physical links are all \(e=(n,i)\), directed from \(n\) to \(n+\mathbf e_i\) when both endpoints are in the box. A reversed traversal uses \(U_e^{-1}\). The elementary faces \(p=(n;i,j)\), \(i<j\), have Wilson functions

\[
W_p=\operatorname{tr}\big[
U_i(n)U_j(n+\mathbf e_i)U_i(n+\mathbf e_j)^{-1}U_j(n)^{-1}
\big].
\tag{1.1}
\]

The full edge and face sets are \(\mathsf E_L,\mathsf P_L\), with

\[
N=3m(m+1)^2,\qquad M=3m^2(m+1).
\tag{1.2}
\]

These counts follow by choosing the direction of a link, or plane of a face, then its allowed coordinate ranges. There are no periodic identifications.

Use product Haar probability measure \(dU\) on \(SU(2)^{\mathsf E_L}\), and

\[
T_a=-i\sigma_a/2,\quad -2\operatorname{tr}(T_aT_b)=\delta_{ab},\qquad
X_{e,a}f=\left.\frac{d}{dt}f(\ldots,e^{tT_a}U_e,\ldots)\right|_{t=0},
\]
\[
E_e=-\Delta_e^T=-\sum_aX_{e,a}^2,\quad
H_0=\sum_eE_e,\quad \mathcal V=\sum_pW_p,\quad \xi=b/\kappa,
\]
\[
H_{\kappa,b}=\kappa H_0+b\sum_p(2-W_p)
=\kappa(H_0-\xi\mathcal V)+2bM I,\qquad \kappa,b>0.
\tag{1.3}
\]

All \(E_e\) are nonnegative self-adjoint link Casimirs and commute with one another on the common smooth core and in their joint product spectral decomposition. The original metric and physical constants remain

\[
c(X,Y)=-\tfrac12\operatorname{tr}(XY),\quad
\Delta_e^c=4\Delta_e^T,\quad
\kappa=\frac{2g_{\mathrm{YM}}^2}{a},\quad
b=\frac1{2g_{\mathrm{YM}}^2a},\quad
\xi=\frac1{4g_{\mathrm{YM}}^4}.
\tag{1.4}
\]

The exact Wilson scalar \(2bM\) is retained in (1.3).

Let \(\psi_\xi>0\) be the normalized positive vacuum and \(E_\xi\) its physical ground energy. Compactness and ellipticity give a smooth ground eigenfunction and compact resolvent; the bounded smooth potential preserves the free operator domain. The ground minimizer can be taken nonnegative by the form inequality \(|\nabla|f||\le|\nabla f|\), with zeros handled by \(\sqrt{|f|^2+\varepsilon^2}\). The strong maximum principle makes it strictly positive. Integration by parts against its eigen-equation gives

\[
\mathfrak q_\xi(\psi_\xi F,\psi_\xi G)
=\kappa\sum_{e,a}\int\psi_\xi^2\,
\overline{X_{e,a}F}X_{e,a}G\,dU,
\tag{1.5}
\]

where \(\mathfrak q_\xi\) is the closed form of \(H_{\kappa,b}-E_\xi\). A second ground state divided by \(\psi_\xi\) would make every derivative in (1.5) zero, hence would be constant. This proves uniqueness. Gauge transformations act by \(U_e\mapsto g_{s(e)}U_eg_{t(e)}^{-1}\); link Casimirs and Wilson traces intertwine this action. Uniqueness makes \(\psi_\xi\) invariant. The original convention \(U_e\mapsto h_{s(e)}^{-1}U_eh_{t(e)}\) is exactly this action with \(g_v=h_v^{-1}\).

Define smooth invariant, vacuum-orthogonal vectors and finite real matrices by

\[
\gamma_{e,\xi}=\langle\psi_\xi,E_e\psi_\xi\rangle,\qquad
v_{e,\xi}=(E_e-\gamma_{e,\xi})\psi_\xi,
\]
\[
C_{ef}(\xi)=\langle v_{e,\xi},v_{f,\xi}\rangle,\qquad
\mathcal N_{ef}(\xi)=\mathfrak q_\xi(v_{e,\xi},v_{f,\xi}).
\tag{1.6}
\]

Both matrices are positive semidefinite and real symmetric by their Gram definitions and reality of every operator and state. Smoothness ensures all vectors belong to the physical form and operator domains. All perturbation remainders below are on the fixed finite box and may depend on \(L\); no volume-uniform estimate is asserted.

## 2. True-vacuum expansion and the leading matrices

The free single-link spin-\(j\) Casimir is \(j(j+1)\). Its normalization is fixed by \(-\sum_aT_a^2=3I/4\) on the fundamental representation; the general value follows from the angular-momentum raising/lowering matrices. The Peter--Weyl tensor decomposition gives a simple free constant eigenvector and full-space first nonzero eigenvalue \(3/4\). Each elementary face uses four distinct fundamental links, so

\[
E_eW_p=\tfrac34\,\mathbf1_{\{e\in\partial p\}}W_p,\qquad
H_0W_p=3W_p,\qquad
\int W_pW_q\,dU=\delta_{pq},\qquad \int W_p\,dU=0.
\tag{2.1}
\]

For the Haar identities, a singly occurring link can be multiplied by \(-I\) to reverse the sign of its fundamental entries. Distinct elementary faces have distinct four-edge supports, so one integrates an edge in only one of the supports. Equal faces reduce to \(\int(\operatorname{tr}U)^2dU=1\), since the scalar component of a uniformly distributed unit quaternion has second moment \(1/4\). A square's two directions and coordinate minima can be recovered from its edge support, justifying the distinct-support assertion.

The potential norm is exactly \(\|\mathcal V\|_\infty=2M\), by \(|W_p|\le2\) and the all-identity configuration. The free resolvent on \(|z|=3/8\) has norm at most \(8/3\), giving the explicit spectral-projection Neumann disk

\[
|\xi|<\frac3{16M}.
\tag{2.2}
\]

Its contour projection has rank one analytically near zero and throughout that disk. For real \(\xi\) in it, the lowest eigenvalue of \(H_0-\xi\mathcal V\) lies in \([-2M|\xi|,0]\), while the next is at least \(3/4-2M|\xi|>3/8\), so it is the actual ground projection. A local analytic Haar-mean-one eigenvector \(\phi_\xi\) is obtained by projecting 1 and dividing by its nonzero Haar mean. Differentiating its eigen-equation and then normalizing in \(L^2\) gives

\[
\psi_\xi=1+\xi A+\xi^2D+O_L(\xi^3),\qquad
A=\tfrac13\mathcal V,\qquad
\int D\,dU=-M/18.
\tag{2.3}
\]

Here the auxiliary dimensionless eigenvalue has \(e(0)=e'(0)=0\), and \(E_\xi=\kappa e(\xi)+2bM\) exactly. Analyticity and its remainders hold in every fixed Sobolev space: from
\[
\phi_\xi=(H_0+1)^{-1}[(e(\xi)+1+\xi\mathcal V)\phi_\xi]
\]
one gains two derivatives at a time, because multiplication by the fixed smooth potential is bounded on those spaces. Thus applying any fixed number of the differential operators below is justified on the actual analytic vacuum.

Let \(r_e=|\{p:e\in\partial p\}|\), and
\[
\mathsf I_{pe}=\mathbf1_{\{e\in\partial p\}},\qquad
t_{ef}=\sum_p\mathsf I_{pe}\mathsf I_{pf}.
\tag{2.4}
\]
Thus \(t_{ef}\) is the number of elementary faces containing both physical edges; \(t_{ee}=r_e\). Equation (2.1) gives

\[
E_eA=\tfrac14\sum_{p\ni e}W_p,\qquad
\gamma_{e,\xi}=\frac{\xi^2}{12}r_e+O_L(\xi^3),\qquad
v_{e,\xi}=\frac{\xi}{4}\sum_{p\ni e}W_p+O_L(\xi^2).
\tag{2.5}
\]

For the expectation coefficient, all terms pairing an \(E_e\)-derivative against the constant vanish by Haar integration, and
\(\langle A,E_eA\rangle=(3/4)r_e/9=r_e/12\). Equation (2.5) holds in every fixed sufficiently high Sobolev norm, not merely weakly.

The exact parity that improves all scalar remainders is the central link cochain

\[
z_i(n)=(-1)^{\sum_{k<i}n_k}I,\qquad
(\mathcal Zf)(U)=f((z_e^{-1}U_e)_e).
\tag{2.6}
\]

For a face \(i<j\), the factor \(z_j(n+\mathbf e_i)\) has the opposite sign from \(z_j(n)\), while \(z_i(n+\mathbf e_j)=z_i(n)\). Thus the product of its four center factors is \(-1\), on every face in all three planes. Therefore
\[
\mathcal Z\mathcal V=-\mathcal V,\quad
\mathcal Z(H_0-\xi\mathcal V)\mathcal Z^{-1}=H_0+\xi\mathcal V.
\]
The real unitary involution \(\mathcal Z\) commutes with every \(E_e\). Uniqueness of the positive vacuum gives
\[
\psi_{-\xi}=\mathcal Z\psi_\xi,\quad e(-\xi)=e(\xi),\quad
\gamma_{e,-\xi}=\gamma_{e,\xi},\quad
v_{e,-\xi}=\mathcal Zv_{e,\xi}.
\tag{2.7}
\]
Negative \(\xi\) is used only in this finite analytic argument. The physical coupling is positive. Both matrix entries in (1.6) are even real-analytic functions of \(\xi\), because the excitation operator \(\kappa(H_0-\xi\mathcal V-e(\xi))\) is conjugated to its negative-\(\xi\) version by \(\mathcal Z\).

Using (2.1), (2.5), and this evenness now proves, with all constants,

\[
\boxed{
C_{ef}(\xi)=\frac{\xi^2}{16}\,t_{ef}+O_L(\xi^4),\qquad
\mathcal N_{ef}(\xi)=\frac{3\kappa\xi^2}{16}\,t_{ef}
+O_L(\kappa\xi^4).}
\tag{2.8}
\]

The expectation in (2.5) likewise has remainder \(O_L(\xi^4)\). There are finitely many entries, so the matrix remainder bounds also hold in any fixed matrix norm, with a box-dependent constant. In particular \(\mathcal N=3\kappa C+O_L(\kappa\xi^4)\), but this does not justify taking their quotient along a weight on which the leading matrix vanishes.

For completeness the numerator has the exact, not perturbative, finite-range identity

\[
\mathcal N_{ef}
=\tfrac12\langle\psi_\xi,[E_e,[H_{\kappa,b},E_f]]\psi_\xi\rangle
=\frac b2\sum_{p:\,e,f\in\partial p}
\langle\psi_\xi,[E_e,[2-W_p,E_f]]\psi_\xi\rangle.
\tag{2.9}
\]

Expand the double commutator into four terms, use the vacuum equation on the two endpoint \(H\)'s, and use commutation of \(E_e,E_f\). Reality and symmetry turn the result into twice (1.6). The electric Hamiltonian commutes with each \(E_f\). If \(f\notin p\), its derivatives commute with multiplication by \(W_p\); if \(f\in p\) but \(e\notin p\), the resulting differential coefficients involve only \(p\)'s variables, and commute with \(E_e\). This proves the support in (2.9). No comparable all-coupling finite-range claim is made for \(C\).

## 3. Entire kernel of the unsigned edge-to-face map

For real or complex weights \(w=(w_e)\), define

\[
(\mathsf Iw)_{n;i,j}
=w_i(n)+w_j(n+\mathbf e_i)+w_i(n+\mathbf e_j)+w_j(n).
\tag{3.1}
\]

The leading covariance kernel in (2.8) is exactly \(\ker\mathsf I\), because
\(\sum_{e,f}\overline{w_e}t_{ef}w_f=\sum_p|(\mathsf Iw)_p|^2\).
We now give all such weights, with unique finite parameters.

Let \(\ell=-L\), and put \(\varepsilon(n)=(-1)^{n_1+n_2+n_3}\). Write
\[
w_i(n)=\varepsilon(n)a_i(n),\qquad
D_iF(n)=F(n+\mathbf e_i)-F(n).
\tag{3.2}
\]
Substituting into (3.1) gives
\[
\mathsf Iw=0\quad\Longleftrightarrow\quad
D_ja_i+D_ia_j=0\quad (i\ne j)
\tag{3.3}
\]
on every contained face. These are equations on the actual edge arrays; their differences are taken only where all displayed points exist.

Choose freely:

- one function \(f_i(x)\) for each \(i\), with \(\ell\le x\le L-1\);
- one function \(\varphi_{ij}(x,y)\) for each \(i<j\), on \(\ell\le x,y\le L\), with the two exact anchor conditions
\[
\varphi_{ij}(\ell,y)=0,\qquad \varphi_{ij}(x,\ell)=0.
\tag{3.4}
\]

Then every kernel weight is represented uniquely by

\[
\boxed{
a_i(n)=f_i(n_i)
+\sum_{j>i}D_i\varphi_{ij}(n_i,n_j)
-\sum_{j<i}D_i\varphi_{ji}(n_j,n_i),\qquad
w_i(n)=\varepsilon(n)a_i(n).}
\tag{3.5}
\]

In the last sum, \(D_i\) differentiates the second argument, namely the coordinate \(n_i\); in the first it differentiates the first argument. All parameters have their stated edge or vertex domains, so (3.5) is defined at every physical link.

First, (3.5) satisfies (3.3). For a pair \(i<j\), all unrelated summands have zero cross derivative; its two relevant terms are \(D_jD_i\varphi_{ij}\) and \(-D_iD_j\varphi_{ij}\), which cancel. Thus every choice of parameters gives a kernel weight.

To prove completeness, take any solution of (3.3). For three distinct indices \(i,j,k\), the equations and commuting finite differences on every contained cube give
\[
D_kD_ja_i=-D_kD_ia_j
=D_iD_ja_k=-D_jD_ka_i.
\]
Therefore \(D_kD_ja_i=0\). For each fixed \(n_i\), the array \(a_i\) has zero mixed difference in its two transverse coordinates. Summing that mixed-difference equation across a transverse rectangle gives
\[
a_i(n)=f_i(n_i)+u_{ij}(n_i,n_j)+u_{ik}(n_i,n_k),
\tag{3.6}
\]
where
\[
f_i(x)=a_i(x\mathbf e_i+\ell\mathbf e_j+\ell\mathbf e_k),\qquad
u_{ij}(x,y)=a_i(x\mathbf e_i+y\mathbf e_j+\ell\mathbf e_k)-f_i(x).
\]
In particular \(u_{ij}(x,\ell)=0\). The original pair equation reduces to
\[
D_ju_{ij}+D_iu_{ji}=0.
\tag{3.7}
\]
For \(i<j\), define the anchored potential explicitly by the finite sum
\[
\varphi_{ij}(x,y)=\sum_{r=\ell}^{x-1}u_{ij}(r,y).
\tag{3.8}
\]
The empty sum is zero. This satisfies both (3.4) anchors and \(D_i\varphi_{ij}=u_{ij}\). Summing (3.7) in the first coordinate gives
\(D_j\varphi_{ij}=-u_{ji}\), because \(u_{ji}(y,\ell)=0\). Equations (3.6) and (3.8) now give exactly (3.5). They also reconstruct all its parameters uniquely from \(a\), proving uniqueness.

There are \(3m\) free \(f_i\) values and \(3m^2\) free anchored potential values. Thus

\[
\boxed{\dim\ker\mathsf I=3m(m+1)=N-M,\qquad
\operatorname{rank}\mathsf I=M.}
\tag{3.9}
\]

In particular this unsigned incidence map is onto the full face array space. This conclusion follows from the proved parametrization and rank-nullity, not from a numerical rank test.

A useful explicit family in the kernel is

\[
w_1(n)=(-1)^{n_2+n_3}F(n_1),\qquad w_2(n)=w_3(n)=0
\tag{3.10}
\]
for any prescribed function \(F\) on the direction-1 edge coordinate. Its opposite direction-1 edges cancel on every \(12\) and \(13\) face, while every \(23\) face has zero weight. In (3.5) it corresponds to \(f_1(n_1)=(-1)^{n_1}F(n_1)\), other \(f_i=0\), and all potentials zero.

The actual state for a real weight is
\[
\Gamma_w=\sum_ew_eE_e,\quad
\gamma_{w,\xi}=\langle\psi_\xi,\Gamma_w\psi_\xi\rangle,\quad
v_{w,\xi}=(\Gamma_w-\gamma_{w,\xi})\psi_\xi=\sum_ew_ev_{e,\xi}.
\tag{3.11}
\]
Equations (2.5) and (3.1) give
\[
v_{w,\xi}=\frac{\xi}{4}\sum_p(\mathsf Iw)_pW_p+O_{L,w}(\xi^2).
\tag{3.12}
\]
For \(w\in\ker\mathsf I\), this merely removes its order-\(\xi\) state. The next sections compute, rather than assume, what remains.

## 4. Exact adjacent-face modes and the complete second vacuum coefficient

Let \(\mathscr P_2\) be the set of unordered pairs of distinct elementary faces sharing an edge. Distinct faces in this open cubical box share at most one edge. For \(\{p,q\}\in\mathscr P_2\), denote that edge by \(e=e(p,q)\). Reverse one face traversal if necessary and cyclically base both words at an endpoint of \(e\), so they have the form

\[
P_*=U_eA,\qquad Q_*=U_e^{-1}B,\qquad Q'_*=BU_e^{-1}.
\tag{4.1}
\]

This does not change either \(SU(2)\) trace: trace is cyclic and \(\operatorname{tr}U^{-1}=\operatorname{tr}U\). The outer words \(A,B\) use three physical links each, disjoint from one another and from \(e\), with their actual inherited orientations. Define

\[
R_{pq}=\operatorname{tr}(AB),\qquad
D_{pq,0}=W_pW_q,\qquad
D_{pq,1}=D_{pq,0}-\tfrac12R_{pq}.
\tag{4.2}
\]

The first is the six-edge outer boundary Wilson loop. Its trace is independent of the choice of starting endpoint or total reversal, as is the definition of \(D_{pq,1}\).

The normalization (1.3) gives the Pauli completeness contraction

\[
\sum_a\operatorname{tr}(T_aC)\operatorname{tr}(T_aD)
=-\tfrac12\operatorname{tr}(CD)+\tfrac14\operatorname{tr}C\operatorname{tr}D.
\tag{4.3}
\]

This follows by multiplying the elementary matrix identity
\(\sum_a(\sigma_a)_{ij}(\sigma_a)_{kl}
=2\delta_{il}\delta_{jk}-\delta_{ij}\delta_{kl}\)
by the two matrices' entries and summing. On the shared edge the two derivatives are respectively
\(\operatorname{tr}(T_aP_*)\) and \(-\operatorname{tr}(T_aQ'_*)\), since the second occurrence is inverse. Therefore

\[
G_{pq}:=\sum_a(X_{e,a}W_p)(X_{e,a}W_q)
=\tfrac12R_{pq}-\tfrac14D_{pq,0}
=\tfrac38R_{pq}-\tfrac14D_{pq,1}.
\tag{4.4}
\]

Each outer edge acts with Casimir \(3/4\) on both functions in (4.2), because its fundamental or inverse fundamental matrix entries occur linearly. On \(e\), \(R_{pq}\) is constant. The product rule and (4.4) give
\[
\Delta_e^TD_{pq,0}=-\tfrac32D_{pq,0}+2G_{pq}
=R_{pq}-2D_{pq,0}=-2D_{pq,1}.
\]
Consequently the joint edge-Casimir labels and full electric eigenvalues are

\[
\begin{array}{c|ccc|c}
 &\text{six outer edges}&\text{shared edge }e&\text{all other edges}&H_0\\ \hline
R_{pq}&3/4&0&0&9/2\\
D_{pq,1}&3/4&2&0&13/2.
\end{array}
\tag{4.5}
\]

This retains every additional box link as spin zero, rather than deleting it from the Hamiltonian.

For their norms, condition on \(U_e\). The disjoint outer words \(A,B\) are independent Haar matrices by left/right Haar invariance and independence of their link variables. Thus \(P_*,Q'_*\) are independent Haar matrices. Write them as
\(p_0I+i\sum_ap_a\sigma_a\) and \(q_0I+i\sum_aq_a\sigma_a\). The two coefficient vectors are independent uniform points on the unit sphere in \(\mathbb R^4\), with second moments \(\mathbb E p_\alpha p_\beta=\delta_{\alpha\beta}/4\). Matrix multiplication gives
\[
R_{pq}=2(x-y),\qquad D_{pq,1}=3x+y,\qquad
x=p_0q_0,\quad y=\sum_{a=1}^3p_aq_a.
\]
Here \(\mathbb E x^2=1/16\), \(\mathbb E y^2=3/16\), and \(\mathbb E xy=0\). It follows that

\[
\|R_{pq}\|_0^2=1,\qquad
\|D_{pq,1}\|_0^2=3/4,\qquad
\langle R_{pq},D_{pq,1}\rangle_0=0.
\tag{4.6}
\]

All norms are full-box Haar norms; every extra link contributes the integral of 1.

The modes belonging to different unordered pairs are orthogonal as well. We give the geometry needed for that claim. The outer boundary of two coplanar adjacent unit faces is the edge set of a \(2\)-by-\(1\) rectangle. Its plane, bounding rectangle, and its unique two unit squares can be read from that edge set. For two perpendicular adjacent faces, their bounding box is a unit cube. Their outer six-edge boundary contains exactly six of its vertices; the two absent vertices form the edge opposite the shared edge. The missing edge and the cube determine the shared edge and its two incident faces uniquely. The coplanar and perpendicular cases have respectively two and three nonzero coordinate spans and cannot coincide. Therefore distinct unordered adjacent pairs have distinct six-edge outer supports.

Two \(R\)-modes with different outer supports have different eigenvalues for at least one \(E_f\) (fundamental versus zero), so self-adjointness makes them orthogonal. An \(R\)-mode and any \(D_1\)-mode are orthogonal because the latter has shared-edge eigenvalue 2 while the former has only eigenvalues 0 or \(3/4\). Two \(D_1\)-modes with different shared edges differ in the eigenvalue-2 location; if the shared edge is equal, the distinct outer supports give a \(3/4\)-versus-zero location. They are therefore also orthogonal. This proves full pairwise orthogonality of the displayed family on the whole box.

We can now write the actual complete second vacuum coefficient \(D\) in (2.3). The Haar-mean-one vacuum equation gives
\[
e(\xi)=-\frac M3\xi^2+O_L(\xi^3),\qquad
H_0\phi_2=\tfrac13(\mathcal V^2-M),\qquad \int\phi_2\,dU=0.
\tag{4.7}
\]
The first equality follows by pairing the second-order equation with 1 and using \(\langle\mathcal V,A\rangle=M/3\). The normalized coefficient is \(D=\phi_2-M/18\).

For a repeated face, \(W_p^2-1\) is the adjoint character: in eigenvalues \(e^{it},e^{-it}\), it equals \(e^{2it}+1+e^{-2it}\), the spin-1 character. On each of its four links its Casimir is 2, so its full eigenvalue is 8. For two faces without a common physical edge, the product has eight distinct fundamental link factors and full eigenvalue 6, even if the faces share a vertex. For adjacent faces use (4.2), (4.5). Inverting \(H_0\) on its mean-zero eigenfunctions in (4.7) gives

\[
\boxed{\begin{split}
D={}&-\frac M{18}+\frac1{24}\sum_p(W_p^2-1)\\
&+\frac19\sum_{\substack{\{p,q\}\\p\ne q,\ \partial p\cap\partial q=\varnothing}}W_pW_q\\
&+\sum_{\{p,q\}\in\mathscr P_2}
\left(\frac2{27}R_{pq}+\frac4{39}D_{pq,1}\right).
\end{split}}
\tag{4.8}
\]

The second and third sums are over unordered face pairs; the factor 2 for each distinct pair in \(\mathcal V^2\) is included in their coefficients. All cases of the full square \((\sum_pW_p)^2\) occur in (4.8). It is an exact Taylor coefficient of the true vacuum, not a two-face model for that vacuum.

## 5. First surviving state for every leading-null real weight

Take \(w\in\ker\mathsf I\), real. Then
\(\Gamma_w1=0\), \(\Gamma_wW_p=(3/4)(\mathsf Iw)_pW_p=0\), and hence \(\Gamma_wA=0\). It follows from the normalized analytic expansion that
\[
\gamma_{w,\xi}=O_{L,w}(\xi^4).
\tag{5.1}
\]
Indeed every term paired against a constant vanishes by self-adjointness and \(\Gamma_w1=0\). The order-\(\xi^2\) expectation is \(\langle A,\Gamma_wA\rangle=0\). The expectation is even by (2.7), so the cubic coefficient also vanishes.

Every repeated-face term in (4.8) is annihilated by \(\Gamma_w\): all its used edges have eigenvalue 2, giving \(2(\mathsf Iw)_p=0\). A pair without a shared edge is annihilated because its weighted Casimir is \((3/4)[(\mathsf Iw)_p+(\mathsf Iw)_q]=0\).

For an adjacent pair with shared edge \(e\), the sum of its six outer weights is
\[
\sum_{f\text{ outer}}w_f=(\mathsf Iw)_p+(\mathsf Iw)_q-2w_e=-2w_e.
\]
The joint Casimirs (4.5) therefore give exactly

\[
\Gamma_wR_{pq}=-\tfrac32w_eR_{pq},\qquad
\Gamma_wD_{pq,1}=\tfrac12w_eD_{pq,1}.
\tag{5.2}
\]

Apply these identities to the full expression (4.8), and then use (5.1) in the centered state (3.11). The actual first surviving term is

\[
\boxed{
v_{w,\xi}=\xi^2S_w+O_{L,w}(\xi^3),\qquad
S_w=\sum_{\{p,q\}\in\mathscr P_2}
w_{e(p,q)}\left(-\frac19R_{pq}+\frac2{39}D_{pq,1}\right).}
\tag{5.3}
\]

The error holds in every fixed Sobolev norm after applying \(\Gamma_w\), because the vacuum remainder was established in every sufficiently high Sobolev norm. Centering affects no term in (5.3).

Let

\[
\mathcal K_L(w,z)=\sum_{e\in\mathsf E_L}\binom{r_e}{2}w_ez_e,\qquad
\mathcal K_L(w)=\mathcal K_L(w,w).
\tag{5.4}
\]

Each unordered adjacent pair has a unique shared edge. Thus summing its shared-edge weight product is exactly (5.4). The pairwise mode orthogonality and norms (4.5)--(4.6) give, for real \(w,z\in\ker\mathsf I\),

\[
\begin{split}
\langle S_w,S_z\rangle_0
&=\left(\frac1{81}+\frac34\frac4{1521}\right)\mathcal K_L(w,z)
=\frac{196}{13689}\mathcal K_L(w,z),\\
\langle S_w,H_0S_z\rangle_0
&=\left(\frac{9/2}{81}+\frac{13}2\frac34\frac4{1521}\right)\mathcal K_L(w,z)
=\frac8{117}\mathcal K_L(w,z).
\end{split}
\tag{5.5}
\]

Every box edge has at least two incident faces: if \(e\) is direction \(i\), each of its two transverse coordinate directions supplies at least one face extending inward from the box boundary. Explicitly,
\[
r_{(n,i)}=d(n_j)+d(n_k),\qquad
d(x)=\begin{cases}1,&x=-L\text{ or }L,\\2,&-L<x<L,\end{cases}
\quad \{i,j,k\}=\{1,2,3\}.
\tag{5.6}
\]
Thus \(2\le r_e\le4\) and \(\mathcal K_L(w)>0\) for every nonzero real weight. In particular \(S_w\ne0\): all leading-null nonzero weights have a genuinely surviving second-order state.

Evenness (2.7) applies to every fixed real linear combination \(v_w\) and to its polarized norm and energy forms. The leading state in (5.3) is order \(\xi^2\); its scalar products therefore have leading order \(\xi^4\), and their possible \(\xi^5\) terms vanish. The exact excitation operator is \(\kappa(H_0-\xi\mathcal V-e(\xi))\). Equations (5.3)--(5.5) prove the complete restricted leading forms

\[
\boxed{\begin{split}
\langle v_{w,\xi},v_{z,\xi}\rangle
&=\frac{196}{13689}\xi^4\mathcal K_L(w,z)+O_{L,w,z}(\xi^6),\\
\mathfrak q_\xi(v_{w,\xi},v_{z,\xi})
&=\frac{8\kappa}{117}\xi^4\mathcal K_L(w,z)+O_{L,w,z}(\kappa\xi^6).
\end{split}}
\tag{5.7}
\]

For each fixed nonzero \(w\) in the kernel, its squared norm is positive for all sufficiently small positive \(\xi\), and division yields

\[
\boxed{
\frac{\mathfrak q_\xi(v_{w,\xi},v_{w,\xi})}{\|v_{w,\xi}\|_2^2}
=\frac{234}{49}\kappa+O_{L,w}(\kappa\xi^2).}
\tag{5.8}
\]

This quotient is the energy of the actual smooth invariant, vacuum-orthogonal vector in (3.11), not of a substituted free vacuum. Its leading value is between the two displayed free energies \(9\kappa/2\) and \(13\kappa/2\). The leading incidence kernel raises the first surviving order and removes the one-face energy \(3\kappa\); it does not make the normalized energy vanish.

One can make the distinction from an exact zero-state kernel stronger on each fixed box. Decompose the real edge space as \((\ker\mathsf I)^\perp\oplus\ker\mathsf I\). On the first summand (2.8) has a strictly positive \(\xi^2\) leading form, because \(\mathsf I\) is injective there. On the second, (5.7) has a strictly positive \(\xi^4\) leading form. Mixed matrix entries have zero \(\xi^2\) term and, by evenness, zero \(\xi^3\) term, hence are \(O_L(\xi^4)\). All are fixed finite matrices. If \(u,z\) belong respectively to these summands, their mixed contribution is bounded by \(B_L\xi^4\|u\|\|z\|\). The elementary inequality \(2ab\le a^2+b^2\), scaled by the positive \(\xi^2\) lower bound on the first summand, absorbs it into a portion of that bound plus \(O_L(\xi^6)\|z\|^2\). For sufficiently small positive \(\xi\), the latter is smaller than a portion of the positive \(\xi^4\) bound on the second summand. Thus the entire actual covariance matrix \(C(\xi)\) is positive definite on the real edge space for all sufficiently small positive \(\xi\), with a box-dependent interval. No assertion about arbitrary \(b/\kappa\) is inferred from this local result.

## 6. Explicit alternating family and the original native weight

For (3.10), the first surviving term is given explicitly by (5.3). Take first \(F(n_1)=1\). Only pairs whose shared edge is in direction 1 contribute, with the signed coefficient \((-1)^{n_2+n_3}\). The squared weight of each is 1. To count them exactly, hold \(n_1\) fixed. If both transverse coordinates are interior there are \((m-1)^2\) such edges with \(r_e=4\); if exactly one is on the boundary there are \(4(m-1)\) with \(r_e=3\); if both are on the boundary there are 4 with \(r_e=2\). Therefore

\[
\sum_{n_2,n_3}\binom{r_{(n,1)}}2
=6(m-1)^2+12(m-1)+4=6m^2-2.
\]
There are \(m\) possible \(n_1\), giving

\[
\boxed{\mathcal K_L(w)=m(6m^2-2)=48L^3-4L.}
\tag{6.1}
\]

For the complete family with arbitrary real \(F\),
\[
\mathcal K_L(w)=(6m^2-2)\sum_{n_1=-L}^{L-1}F(n_1)^2.
\tag{6.2}
\]
If \(F\ne0\), this is strictly positive. Substitution into (5.3), (5.7), and (5.8) gives the exact first surviving actual-vacuum state, its norm and energy coefficients, and its leading quotient for that specified family, with all faces retained.

The original native weights are instead

\[
w^{\mathrm{nat}}_{(n,1)}=n_2^2,\qquad
w^{\mathrm{nat}}_{(n,2)}=w^{\mathrm{nat}}_{(n,3)}=0.
\tag{6.3}
\]

Their unsigned sums, with \(t=n_2\), are
\[
(\mathsf Iw^{\mathrm{nat}})_{n;1,2}=t^2+(t+1)^2=2(t^2+t+\tfrac12),
\]
\[
(\mathsf Iw^{\mathrm{nat}})_{n;1,3}=2t^2,\qquad
(\mathsf Iw^{\mathrm{nat}})_{n;2,3}=0.
\tag{6.4}
\]
They are not in the leading kernel: in particular the \(12\) sum is strictly positive for every integer \(t\). Keeping each face multiplicity gives

\[
\sum_p|(\mathsf Iw^{\mathrm{nat}})_p|^2=4\mathcal A_L,
\]
\[
\begin{split}
\mathcal A_L
&=2L(2L+1)\sum_{t=-L}^{L-1}(t^2+t+\tfrac12)^2+
4L^2\sum_{t=-L}^{L}t^4\\
&=\frac{L^2(2L+1)}{15}(24L^4+24L^3+8L^2-4L+3).
\end{split}
\tag{6.5}
\]

The finite sum formulas are
\(\sum_{t=-L}^{L-1}(t^2+t+\tfrac12)^2=L(4L^4+1)/10\) and
\(\sum_{t=-L}^{L}t^4=L(L+1)(2L+1)(3L^2+3L-1)/15\).
They follow by expansion, or by checking \(L=1\) and the two added endpoint terms under \(L\mapsto L+1\). Substitution gives the polynomial in (6.5).

Equations (2.8), (3.12), and (6.5) therefore yield, for the actual native state,

\[
\|v_{w^{\mathrm{nat}},\xi}\|^2=\frac{\xi^2}{4}\mathcal A_L+O_L(\xi^4),
\qquad
\mathfrak q_\xi(v_{w^{\mathrm{nat}},\xi},v_{w^{\mathrm{nat}},\xi})
=\frac{3\kappa\xi^2}{4}\mathcal A_L+O_L(\kappa\xi^4),
\tag{6.6}
\]
and quotient \(3\kappa+O_L(\kappa\xi^2)\) on this fixed box. This agrees with the native projected magnetic-translation coefficient: its fixed-state small-angle leading vector is \(-\tfrac23\theta^2v_{w^{\mathrm{nat}},\xi}\), so the \(\xi^2\theta^4\) squared-norm coefficient is \((4/9)(\mathcal A_L/4)=\mathcal A_L/9\).

The exact comparison is therefore: native nonnegative \(n_2^2\) weights retain the one-face modes at order \(\xi\), whereas transverse alternating weights cancel those modes and reveal two-face modes at order \(\xi^2\). This is a proved state-space distinction and does not assert a favorable infinite-volume scaling of either actual quotient.

## 7. The minimum over all real electric weights, including coupling-dependent ones

The fixed-weight conclusions do not by themselves control weights approaching the leading kernel as \(\xi\to0\). We now close that possibility by inequalities valid simultaneously for every real edge weight on the fixed box, without changing any physical state, coefficient, or denominator.

Write the original real edge space as the orthogonal direct sum
\[
\mathbb R^{\mathsf E_L}=\mathscr R_L\oplus\mathscr Z_L,\qquad
\mathscr Z_L=\ker\mathsf I,\quad \mathscr R_L=(\ker\mathsf I)^\perp,
\qquad w=u+z.
\tag{7.1}
\]
Orthogonality here is the ordinary coordinate inner product on the finite list of physical edge weights. It is used to state estimates, not as a replacement for the actual covariance denominator \(w^TC(\xi)w\).

Because \(\mathsf I\) is injective on \(\mathscr R_L\), finite-dimensional compactness gives the strictly positive constant
\[
\lambda_L=\min_{\substack{u\in\mathscr R_L\\\|u\|=1}}\|\mathsf Iu\|^2>0.
\tag{7.2}
\]
Set \(r_0=\lambda_L/16\) and \(d_0=196/13689\). The proved matrix remainders in (2.8) and (5.7), together with evenness of the mixed block, give on some fixed-box interval \(0<\xi<\epsilon_L\)
\[
u^TCu\ge\tfrac12r_0\xi^2\|u\|^2,\qquad
z^TCz\ge\tfrac12d_0\xi^4\|z\|^2,\qquad
|u^TCz|\le B_L\xi^4\|u\|\|z\|,
\tag{7.3}
\]
where \(B_L<\infty\). The second inequality uses
\(\mathcal K_L(z)\ge\|z\|^2\) from \(r_e\ge2\). Every bound is between fixed finite matrix blocks and therefore holds for all their vectors with one common box-dependent constant.

The elementary inequality
\[
2B_L\xi^4\|u\|\|z\|
\le\tfrac14r_0\xi^2\|u\|^2+
\frac{4B_L^2}{r_0}\xi^6\|z\|^2
\tag{7.4}
\]
follows by expanding the square of
\(\sqrt{r_0}\xi\|u\|/2-(2B_L/\sqrt{r_0})\xi^3\|z\|\).
Shrink the already nonempty interval so
\((4B_L^2/r_0)\xi^2\le d_0/4\); if \(B_L=0\) this step is unnecessary. Adding the three blocks in (7.3) then proves the simultaneous physical denominator bound
\[
\boxed{w^TC(\xi)w\ge c_L\xi^2\|u\|^2+
\tfrac14d_0\xi^4\|z\|^2,\qquad c_L=r_0/4=\lambda_L/64>0.}
\tag{7.5}
\]
In particular the actual centered state is nonzero for every nonzero real \(w\) on this interval. No component has been scaled by a power of \(\xi\) in this argument.

Now define the actual matrix difference
\[
\mathcal B(\xi)=\kappa^{-1}\mathcal N(\xi)-3C(\xi).
\tag{7.6}
\]
Its \(\mathscr R_L\)-block and mixed block are \(O_L(\xi^4)\) by (2.8). Its restriction to \(\mathscr Z_L\) has the strictly positive leading form
\[
z^T\mathcal Bz=\delta_0\xi^4\mathcal K_L(z)+O_L(\xi^6)\|z\|^2,
\qquad
\delta_0=\frac8{117}-3\frac{196}{13689}
=\frac{348}{13689}=\frac{116}{4563}>0.
\tag{7.7}
\]
Hence, on a possibly smaller nonempty interval, there are finite \(A_L,B'_L\) such that simultaneously
\[
u^T\mathcal Bu\ge-A_L\xi^4\|u\|^2,\quad
|u^T\mathcal Bz|\le B'_L\xi^4\|u\|\|z\|,\quad
z^T\mathcal Bz\ge\tfrac12\delta_0\xi^4\|z\|^2.
\tag{7.8}
\]
Complete the square in the last two terms, or use
\[
\tfrac12\delta_0\|z\|^2-2B'_L\|u\|\|z\|
\ge-\frac{2(B'_L)^2}{\delta_0}\|u\|^2.
\]
It follows that
\[
w^T\mathcal Bw\ge-K_L\xi^4\|u\|^2,\qquad
K_L=A_L+\frac{2(B'_L)^2}{\delta_0}.
\tag{7.9}
\]
The retained physical denominator (7.5) now gives the uniform-in-weight lower estimate
\[
\boxed{
\frac{w^T\mathcal N(\xi)w}{w^TC(\xi)w}
=3\kappa+\kappa\frac{w^T\mathcal B(\xi)w}{w^TC(\xi)w}
\ge3\kappa-\frac{K_L}{c_L}\kappa\xi^2
\quad\text{for every real }w\ne0.}
\tag{7.10}
\]
This includes arbitrary \(\xi\)-dependent weights, including ones whose component ratio \(\|u\|/\|z\|\) tends to zero or infinity.

For the matching upper estimate on the minimum, choose one fixed face \(p_0\) in the box and its original edge-indicator weight
\[
(u_0)_e=\mathbf1_{\{e\in\partial p_0\}}.
\tag{7.11}
\]
For every \(z\in\mathscr Z_L\), \(\langle u_0,z\rangle=(\mathsf Iz)_{p_0}=0\), so \(u_0\in\mathscr R_L\). Its actual four entries equal 1 and \(\|u_0\|^2=4\). The absolute \(\mathscr R_L\)-block bound on \(\mathcal B\), together with (7.5), gives
\[
\left|\frac{u_0^T\mathcal N u_0}{u_0^TCu_0}-3\kappa\right|
\le\frac{A_L}{c_L}\kappa\xi^2,
\tag{7.12}
\]
enlarging \(A_L\) to bound that entire block in absolute value if necessary. Both numerator and denominator in (7.12) are the original state forms; no rescaled state norm has replaced either.

Since \(C(\xi)\) is positive definite, this continuous homogeneous quotient attains its minimum on the nonzero real weight rays: equivalently one applies finite-dimensional compactness on a coordinate unit sphere while keeping the denominator \(w^TCw\) unchanged. Combining (7.10) and (7.12) proves
\[
\boxed{
\min_{w\in\mathbb R^{\mathsf E_L}\setminus\{0\}}
\frac{\mathfrak q_\xi(v_{w,\xi},v_{w,\xi})}{\|v_{w,\xi}\|^2}
=3\kappa+O_L(\kappa\xi^2),\qquad \xi\downarrow0.}
\tag{7.13}
\]
This is uniform over all weights on the fixed box, not uniform in \(L\). It uses the actual positive fourth-order form on the leading kernel; deleting that form would leave the degenerating denominator uncontrolled.

## 8. Verification and limits of the result

The companion check_electric_covariance_incidence_20260908.py enumerates all links and all elementary faces for \(L=2,3,4\). It verifies edge and face counts, the incident-face numbers \(r_e\), uniqueness of the six-edge support for every unordered adjacent pair, the full anchored kernel construction and reconstruction, and every individual parameter basis vector for the entire \(L=2\) box. These boxes have respectively kernel dimensions 60, 126, 216 and adjacent-pair counts 1128, 3852, 9168. It verifies both the alternating family and the native \(n_2^2\) coefficient, along with exact rational arithmetic for the two-face vacuum coefficients, the norm coefficient \(196/13689\), the energy coefficient \(8/117\), and quotient \(234/49\).

The rank and kernel theorem itself is proved for every \(L\) in Section 3; it is not inferred from those finite checks. Likewise the checks do not replace the actual-vacuum analytic and domain arguments in Sections 1, 2, 4, and 5. No floating-point vacuum approximation, numerical Haar sampling, continuum replacement, remote action, PDF generation, new agent, or heavy job is used.

The parent finite-range matrix construction is in magnetic_translation_true_vacuum.md, Section 8; the standalone full-vertex projection and native angular coefficient are in MAGNETIC_TRANSLATION_PLAQUETTE.md; the adjacent-mode normalization is consistent with BULK_PLAQUETTE_EXTENSION.md. All constants and the specific proofs needed for the present calculation are given above. Every conclusion concerns a fixed finite, full interacting box with a controlled local expansion in \(b/\kappa\). The guaranteed disk \(3/(16M)\) and all stated remainder constants are retained; no uniform-volume, fixed-coupling joint-limit, or four-dimensional continuum gap conclusion is claimed.

For historical convention context, see J. Kogut and L. Susskind, “Hamiltonian formulation of Wilson's lattice gauge theories,” *Physical Review D* **11**, 395–408 (1975), [doi:10.1103/PhysRevD.11.395](https://doi.org/10.1103/PhysRevD.11.395). This is a convention reference, not a substitution of its coupling normalization for (1.3)--(1.4). The full incidence kernel, its mode coefficients, and the all-weight estimates used here are proved in this source.

```

## Complete source: wilson_variation/check_electric_covariance_incidence_20260908.py

```python
"""Exact finite-box incidence, kernel, and second-vacuum-mode diagnostics.

No vacuum sampling, floating point, or continuum approximation is used.
"""

from fractions import Fraction as F
from itertools import combinations, product


def plus(n, i):
    out = list(n)
    out[i] += 1
    return tuple(out)


def boundary(p):
    n, i, j = p
    return frozenset(((n, i), (plus(n, i), j), (plus(n, j), i), (n, j)))


def sign(n):
    return -1 if sum(n) % 2 else 1


def kernel_values(L, f_values, phi_values):
    def potential(i, j, x, y):
        return phi_values.get((i, j, x, y), 0)

    out = {}
    for n in product(range(-L, L + 1), repeat=3):
        for i in range(3):
            if n[i] == L:
                continue
            value = f_values.get((i, n[i]), 0)
            for j in range(i + 1, 3):
                value += potential(i, j, n[i] + 1, n[j]) - potential(i, j, n[i], n[j])
            for j in range(i):
                value -= potential(j, i, n[j], n[i] + 1) - potential(j, i, n[j], n[i])
            out[n, i] = sign(n)*value
    return out


for L in (2, 3, 4):
    vertices = list(product(range(-L, L + 1), repeat=3))
    edges = [(n, i) for n in vertices for i in range(3) if n[i] < L]
    faces = [(n, i, j) for n in vertices for i, j in combinations(range(3), 2)
             if n[i] < L and n[j] < L]
    assert len(edges) == 3*(2*L)*(2*L+1)**2
    assert len(faces) == 3*(2*L)**2*(2*L+1)
    star = {e: [] for e in edges}
    for face in faces:
        for edge in boundary(face):
            star[edge].append(face)
    assert all(2 <= len(p) <= 4 for p in star.values())

    # An adjacent unordered pair has a unique shared edge and outer boundary.
    outer_supports = {}
    adjacent_pairs = []
    for edge, incident in star.items():
        for p, q in combinations(incident, 2):
            assert boundary(p) & boundary(q) == {edge}
            outer = (boundary(p) | boundary(q)) - {edge}
            assert len(outer) == 6
            assert outer not in outer_supports
            outer_supports[outer] = (edge, p, q)
            adjacent_pairs.append((edge, p, q))
    count_one_direction = 48*L**3-4*L
    assert len(adjacent_pairs) == 3*count_one_direction

    alternating = {(n, i): (-1 if (n[1]+n[2]) % 2 else 1) if i == 0 else 0
                   for n, i in edges}
    native = {(n, i): n[1]**2 if i == 0 else 0 for n, i in edges}
    face_sums_alt = {p: sum(alternating[e] for e in boundary(p)) for p in faces}
    assert all(value == 0 for value in face_sums_alt.values())
    weighted_pair_norm = sum(
        len(star[e])*(len(star[e])-1)//2 * alternating[e]**2 for e in edges
    )
    assert weighted_pair_norm == count_one_direction
    native_squared_face_sums = sum(sum(native[e] for e in boundary(p))**2 for p in faces)
    angular_poly = F(L*L*(2*L+1)*(24*L**4+24*L**3+8*L*L-4*L+3), 15)
    assert native_squared_face_sums == 4*angular_poly

    f_parameters = {(i, x): (i+1)*(x+L+1)**2
                    for i in range(3) for x in range(-L, L)}
    phi_parameters = {(i, j, x, y): (x+L)*(y+L)*((i+1)*x+(j+2)*y+x*y)
                      for i, j in combinations(range(3), 2)
                      for x in range(-L+1, L+1) for y in range(-L+1, L+1)}
    weights = kernel_values(L, f_parameters, phi_parameters)
    assert all(sum(weights[e] for e in boundary(p)) == 0 for p in faces)
    for edge, p, q in adjacent_pairs:
        outer = (boundary(p) | boundary(q)) - {edge}
        weighted_outer_sum = sum(weights[f] for f in outer)
        assert weighted_outer_sum == -2*weights[edge]
        assert F(3, 4)*weighted_outer_sum == -F(3, 2)*weights[edge]
        assert F(3, 4)*weighted_outer_sum+2*weights[edge] == F(1, 2)*weights[edge]
    for n, i, j in faces:
        central_sign = lambda x, k: -1 if sum(x[:k]) % 2 else 1
        assert (
            central_sign(n, i)*central_sign(plus(n, i), j)
            *central_sign(plus(n, j), i)*central_sign(n, j)
        ) == -1
    # Reconstruct the independent anchored parameters from the edge field.
    def a_value(n, i):
        return sign(n)*weights[n, i]
    for (i, x), expected in f_parameters.items():
        n = [-L, -L, -L]
        n[i] = x
        assert a_value(tuple(n), i) == expected
    for (i, j, x, y), expected in phi_parameters.items():
        total = 0
        for r in range(-L, x):
            n = [-L, -L, -L]
            n[i], n[j] = r, y
            total += a_value(tuple(n), i)-f_parameters[i, r]
        assert total == expected
    kernel_dimension = len(f_parameters)+len(phi_parameters)
    assert kernel_dimension == 3*(2*L)*(2*L+1)
    assert len(edges)-kernel_dimension == len(faces)

    # Verify every anchored coordinate basis vector in one whole box.
    if L == 2:
        for key in f_parameters:
            basis = kernel_values(L, {key: 1}, {})
            assert all(sum(basis[e] for e in boundary(p)) == 0 for p in faces)
        for key in phi_parameters:
            basis = kernel_values(L, {}, {key: 1})
            assert all(sum(basis[e] for e in boundary(p)) == 0 for p in faces)
    print(f"L={L}: {len(edges)} links, {len(faces)} faces, "
          f"kernel dimension {kernel_dimension}, {len(adjacent_pairs)} distinct pair modes.")

# Vacuum and mode coefficients use the original -2 tr metric.
assert F(1, 3)*F(3, 4) == F(1, 4)
assert F(3, 4)/9 == F(1, 12)
lambda_r, lambda_d = F(9, 2), F(13, 2)
vacuum_r = F(2, 3)*F(1, 2)/lambda_r
vacuum_d = F(2, 3)/lambda_d
assert vacuum_r == F(2, 27)
assert vacuum_d == F(4, 39)
state_r, state_d = vacuum_r*(-F(3, 2)), vacuum_d*F(1, 2)
assert state_r == -F(1, 9)
assert state_d == F(2, 39)
norm_coefficient = state_r**2 + F(3, 4)*state_d**2
energy_coefficient = lambda_r*state_r**2 + lambda_d*F(3, 4)*state_d**2
assert norm_coefficient == F(196, 13689)
assert energy_coefficient == F(8, 117)
assert energy_coefficient/norm_coefficient == F(234, 49)
positive_kernel_difference = energy_coefficient-3*norm_coefficient
assert positive_kernel_difference == F(348, 13689) == F(116, 4563)
print("PASS: full kernel parametrization/reconstruction, all L=2 kernel basis vectors,")
print("distinct pair supports, alternating/native weights, and all exact state coefficients.")

```

## Complete source: first_physical_excitation_band.md

```markdown
# The actual first physical excitation band of the open SU(2) box

8 September 2026. The calculation below concerns the eigenvalues of the full
interacting Hamiltonian, not only the energy of a chosen trial state. It retains
all spatial links and plaquettes, the two shared-link spin channels, the actual
vacuum energy, and the original physical coefficients. Its finite-box error
bound is explicit. The large-box limit computed here is a limit of a Taylor
coefficient, not an interchange of the volume and coupling limits.

## 1. Hamiltonian and the result

Fix an integer \(L\geq2\). The vertices are
\(\mathsf V_L=\{-L,\ldots,L\}^3\). Let \(\mathsf E_L\) contain
each positively oriented nearest-neighbor link \(e=(n,i)\) whose endpoints
belong to this set, and let \(\mathsf P_L\) contain every elementary square
\(p=(n;i,j)\), \(i<j\), including the boundary squares. Write
\[
 m=2L,\qquad N=3m(m+1)^2,\qquad M=3m^2(m+1).
\tag{1.1}
\]
For \(U_e\in SU(2)\), inverse traversal means \(U_e^{-1}\), and
\[
 W_p(U)=\operatorname{tr}\!left(
 U_i(n)U_j(n+\mathbf e_i)U_i(n+\mathbf e_j)^{-1}U_j(n)^{-1}\right).
\tag{1.2}
\]
The trace is real. Use product Haar probability measure on \(SU(2)^N\),
\(T_a=-i\sigma_a/2\), and
\[
 X_{e,a}f=\left.\frac{d}{dt}f(\ldots,e^{tT_a}U_e,\ldots)\right|_{t=0},
 \qquad E_e=-\sum_{a=1}^3X_{e,a}^2.
\tag{1.3}
\]
The spin-\(j\) eigenvalue of \(E_e\) is \(j(j+1)\). In particular the
fundamental value is \(3/4\). The original Lie metric
\(c(A,B)=-\operatorname{tr}(AB)/2\) has orthonormal basis \(2T_a\),
so \(-\Delta_e^c=4E_e\); this factor is retained in
\[
 \begin{split}
 H&=\kappa H_0+b\sum_p(2-W_p)
    =\kappa K_\xi+2bM I,\qquad H_0=\sum_eE_e,\\
 K_\xi&=H_0-\xi S,\qquad S=\sum_pW_p,\\
 \kappa&=\frac{2g_{\rm YM}^2}{a},\qquad
 b=\frac{1}{2g_{\rm YM}^2a},\qquad
 \xi=\frac b\kappa=\frac{1}{4g_{\rm YM}^4}.
 \end{split}
\tag{1.4}
\]
Here \(a>0\) is spatial lattice spacing. There are three spatial dimensions
and Hamiltonian time. No spatial dimension, link, or interaction is removed.

The physical Hilbert space \(\mathcal H_{\rm phys}\) is the closed subspace
of \(L^2(SU(2)^N,dU)\) invariant under
\(U_e\mapsto g_{s(e)}U_eg_{t(e)}^{-1}\) at every vertex. Both \(H_0\) and
\(S\) preserve it. The full operator has Sobolev domain \(H^2\) and form
domain \(H^1\); on the physical subspace use their intersections with
\(\mathcal H_{\rm phys}\). Bounded smooth multiplication by \(S\) preserves
self-adjointness and compact resolvent. The heat kernel of the link Laplacian
is strictly positive on the connected compact configuration space, and the
bounded real potential preserves positivity improvement by its heat-kernel
product formula. Consequently the lowest eigenfunction can be chosen
strictly positive and is unique up to a scalar. Alternatively, its modulus
minimizes the form, elliptic regularity and the maximum principle make it
strictly positive, and integration by parts gives
\[
 \langle\psi f,(H-\mathcal E)\psi f\rangle
   =\kappa\sum_{e,a}\int|X_{e,a}f|^2\psi^2dU.
\tag{1.5}
\]
Any other lowest eigenfunction divided by \(\psi\) is therefore constant.
Gauge transformations fix this positive unit vector. Thus the full and
physical bottoms agree. Write
\(\mathcal E(\xi)=2bM+\kappa e(\xi)\), and let
\(\operatorname{gap}_L\) be the least strictly positive physical eigenvalue
of \(H-\mathcal E(\xi)I\).

Define the finite face graph as follows. Two distinct faces are adjacent
exactly when they share a physical edge. Its adjacency matrix is
\(A_L\), its face degrees are \(d_p\), and
\[
 D_L^{\rm face}=\operatorname{diag}(d_p),\qquad
 Q_L=D_L^{\rm face}+A_L,\qquad q_L=\lambda_{\max}(Q_L),\qquad
 \nu_L=\frac7{15}-\frac{q_L}{21}.
\tag{1.6}
\]
The superscript distinguishes this degree matrix from any original cusp
determinant. No cusp coordinate or determinant has been identified with it.

The result is
\[
 \boxed{\operatorname{gap}_L
   =\kappa\left(3+\nu_L\xi^2+\mathcal R_L(\xi)\right),\qquad
 |\mathcal R_L(\xi)|\leq
 \frac73\left(\frac{64M}{3}\right)^4|\xi|^4,
 \quad |\xi|\leq\frac{3}{128M}.}
\tag{1.7}
\]
The error bound concerns the actual physical eigenvalue. Moreover
\[
 \boxed{0<\nu_L+\frac{71}{105}
       \leq\frac{4(6L+1)}{21L(2L+1)},\qquad
       \lim_{L\to\infty}\nu_L=-\frac{71}{105}.}
\tag{1.8}
\]
In particular \(\nu_L<0\) for every \(L\geq2\). The original coefficients
in (1.7) are equivalently
\[
 \operatorname{gap}_L=
 \frac{6g_{\rm YM}^2}{a}
 +\frac{\nu_L}{8g_{\rm YM}^6a}
 +\frac{2g_{\rm YM}^2}{a}\mathcal R_L\!\left(\frac1{4g_{\rm YM}^4}\right).
\tag{1.9}
\]
Thus no change of energy units or coupling is hidden in the negative second
coefficient. Sections 2--6 prove all parts of these statements.

## 2. The free physical eigenspace and its isolation

Peter--Weyl decomposition on each link gives an orthogonal decomposition by
spin assignments \((j_e)\). Gauge invariance is imposed by taking the invariant
tensor space at each vertex, with dual representations on oppositely oriented
indices. This is an orthogonal projection because it is the integral of the
unitary vertex action. Tensor products of the resulting invariant contractions
span the physical subspace, by applying that bounded projection to the dense
product Peter--Weyl span. Their free energies are exactly
\(\sum_ej_e(j_e+1)\).

The support of a nonconstant such contraction is the graph of links with
\(j_e>0\). It cannot have a vertex of degree one: its tensor factor there
would be a single nontrivial irreducible representation, which has no
invariant vector. Every nonempty finite graph of minimum degree at least two
contains a cycle, by continuing an edge path until a vertex repeats. The
cubic lattice graph is simple and bipartite, so every cycle has length at
least four. Each support edge contributes at least \(3/4\). Hence every
nonzero physical energy is at least \(3\).

If the energy is strictly below \(9/2\), there are at most five support
edges. A cycle in this bipartite graph must then have length four. A fifth
edge cannot form a separate component of minimum degree two, cannot have an
endpoint outside the four-cycle without producing degree one, and cannot
be a chord: the possible new chords join vertices in the same bipartition
class. Therefore the support is just that four-cycle. Every four-cycle in
the cubic nearest-neighbor graph is one elementary square: closing a
four-step simple path requires one positive and one negative step in each
of two distinct coordinate directions.

At a degree-two vertex, Schur orthogonality implies that an invariant
contraction exists only when the two incident spins agree; it is then
one-dimensional. Thus a square has the same spin \(j\) on all four edges,
with energy \(4j(j+1)\). Below \(9/2\), only \(j=1/2\) occurs, giving
energy \(3\) and the fundamental Wilson trace \(W_p\). The next possible
physical energy is exactly \(9/2\), realized by the fundamental trace on a
six-edge \(1\)-by-\(2\) rectangle in the box.

Single-link Haar integration gives
\[
 \int W_p\,dU=0,\qquad \langle W_p,W_q\rangle=\delta_{pq},\qquad
 H_0W_p=3W_p.
\tag{2.1}
\]
For distinct squares a link in only one boundary makes the integral zero
under multiplication of that link by \(-I\). For equal squares their
holonomy is Haar distributed and the fundamental character has squared norm
one. This last identity also follows by writing a Haar element as
\(u_0I+i\sum_au_a\sigma_a\) on the unit three-sphere and using
\(\int u_0^2=1/4\). Consequently
\[
 \ker H_0=\mathbb C1,\qquad
 \ker(H_0-3)=\mathcal P:=\operatorname{span}\{W_p:p\in\mathsf P_L\},
 \qquad\operatorname{spec}(H_0)\cap(3,9/2)=\varnothing.
\tag{2.2}
\]
In this section spectra and kernels are physical ones. Let \(P\) be the
orthogonal projection onto \(\mathcal P\), let \(Q=I-P\) on the physical
space, and set
\[
 R_3=Q\bigl(Q(H_0-3)Q\bigr)^{-1}Q.
\tag{2.3}
\]
The inverse is bounded, since zero is excluded by (2.2). It acts by
\(-1/3\) on constants. Omitting this negative denominator would give an
incorrect excitation matrix.

## 3. Every virtual channel, with its exact Haar map

The elementary central link map
\[
 U_{(n,i)}\longmapsto z_i(n)U_{(n,i)},\qquad
 z_i(n)=(-1)^{\sum_{j<i}n_j}I
\tag{3.1}
\]
induces a Haar unitary involution \(\mathcal Z\). Around an \(ij\) face
with \(i<j\), the exponent in \(z_j(n+\mathbf e_i)\) differs by one
from that in \(z_j(n)\), while the other pair agrees. Thus every
\(W_p\) changes sign. The map commutes with every link Casimir and every
vertex gauge action, fixes the constant function, and is \(-I\) on
\(\mathcal P\). It follows in particular that \(PSP=0\).

Resolve the product of two face traces as follows. For a repeated face put
\(Y_p=W_p^2-1\). The character identity
\(\chi_{1/2}^2=\chi_0+\chi_1\) gives
\[
 H_0Y_p=8Y_p,\qquad\|Y_p\|^2=1.
\tag{3.2}
\]
For two distinct edge-disjoint faces, \(W_pW_q\) has energy \(6\) and
squared norm one, even if their boundaries meet at a vertex. Each of the
eight links has fundamental spin; integration of one independent link of
each face establishes the norm.

If distinct \(p,q\) share one edge \(e\), define the exact orthogonal
Haar projection and its complement
\[
 Z_{pq,0}=\int_{SU(2)}W_pW_q\,dU_e,\qquad
 Z_{pq,1}=W_pW_q-Z_{pq,0}.
\tag{3.3}
\]
Reverse one face traversal if needed, which preserves its real SU(2) trace,
and cyclically write the traces as \(\operatorname{tr}(U_eA)\) and
\(\operatorname{tr}(U_e^{-1}B)\). The six outer link variables in A,B
are distinct. The identity
\(\int U_{ij}\overline U_{kl}\,dU=\delta_{ik}\delta_{jl}/2\) gives
\[
 Z_{pq,0}=\tfrac12\operatorname{tr}(AB).
\tag{3.4}
\]
This is the fundamental trace on their six-edge boundary with its actual
factor \(1/2\), not a trace rescaled to unit norm. The shared-edge tensor
product decomposes into spin zero and spin one. Hence
\[
 \begin{array}{c|cc}
 &Z_{pq,0}&Z_{pq,1}\\ \hline
 H_0\text{ eigenvalue}&9/2&13/2\\
 \text{squared norm}&1/4&3/4\\
 R_3\text{ multiplier}&2/3&2/7
 \end{array}
\tag{3.5}
\]
The first norm follows from (3.4). The total product norm is one by
integrating the outer independent Haar words A and B first, and the two
channels are orthogonal because (3.3) is an orthogonal projection.

There are no missing cross terms between different unordered pairs.
Indeed a product associated with \(\{p,q\}\) has odd central-link parity
precisely on \(\partial p\mathbin\triangle\partial q\), in either channel.
If two different unordered pairs had the same boundary parity, the symmetric
difference of their face sets would be a nonempty closed mod-two collection
of at most four squares. Any square in it would need another square on each
of its four edges. Distinct elementary squares share at most one edge, so
four distinct other squares would be necessary, contradicting the maximum
of four squares in the collection. Thus some link has unequal parity and
its Haar integration kills every mixed inner product. The repeated-face
vectors have even parity everywhere, so are orthogonal to these pairs;
different repeated-face vectors are orthogonal by their different joint
link-spin assignments. All these orthogonalities remain true after applying
\(H_0\) or \(R_3\).

For \(v=\sum_pa_pW_p\), the entire first-order dressing of the spectral
subspace is consequently
\[
 \begin{split}
 R_3Sv={}&-\frac13\sum_pa_p
 +\frac15\sum_pa_pY_p\\
 &+\frac13\sum_{\{p,q\}\ {m edge\!\!-\!\!disjoint}}
                      (a_p+a_q)W_pW_q\\
 &+\sum_{\{p,q\}\ {\rm adjacent}}(a_p+a_q)
                  \left(\frac23Z_{pq,0}+\frac27Z_{pq,1}\right).
 \end{split}
\tag{3.6}
\]
The sums over distinct pairs are unordered. This is an exact map from each
free physical face vector into all of its first-order virtual states.

## 4. Degenerate perturbation and the vacuum subtraction

The second effective coefficient before subtracting the bottom energy is
\[
 K^{(2)}=-PSR_3SP.
\tag{4.1}
\]
For completeness, this follows directly by writing the analytically
transported vector as \(v+\xi v_1+\xi^2v_2+\cdots\) with
\(Pv_1=0\). The first coefficient of the eigen-equation or spectral
intertwining equation gives \((H_0-3)v_1=QSv\), hence \(v_1=R_3Sv\).
Projecting the next coefficient onto \(\mathcal P\) gives (4.1).
This works for the whole degenerate subspace; no individual face is assumed
to remain an eigenvector. The exact analytic subspace map used here is
constructed in Section 5.

The vacuum intermediate state contributes \(+1/3\) to every matrix entry
in the \(W_p\) basis. A distinct edge-disjoint pair contributes
\(-1/3\) to its two diagonal entries and its two mutual off-diagonal
entries. An adjacent pair contributes the same pattern with value
\[
 -\left(\frac{1/4}{9/2-3}+\frac{3/4}{13/2-3}\right)
       =-\left(\frac16+\frac3{14}\right)=-\frac8{21}.
\tag{4.2}
\]
A repeated-face channel contributes \(-1/5\) to its diagonal. Therefore
\[
 \begin{split}
 K^{(2)}_{pp}
  &=\frac13-\frac15-\frac{M-1-d_p}{3}-\frac8{21}d_p
    =\frac7{15}-\frac M3-\frac{d_p}{21},\\
 K^{(2)}_{pq}
  &=\begin{cases}-1/21,&p,q\text{ adjacent},\\0,&p\ne q\text{ not adjacent}.
    \end{cases}
 \end{split}
\tag{4.3}
\]
In particular the nonlocal rank-one vacuum contribution cancels the
edge-disjoint off-diagonal contribution, rather than either one being omitted.

For the actual positive unit vacuum, coefficient comparison yields
\[
 \psi_\xi=1+\frac\xi3S+O_{H^2,L}(\xi^2),\qquad
 e(\xi)=-\frac M3\xi^2+O_L(\xi^4).
\tag{4.4}
\]
The first equation follows because \(H_0S=3S\). Pairing the second-order
equation with constants gives \(-\langle S,S\rangle/3=-M/3\).
The error is even by (3.1), as proved below. Thus the physical excitation
coefficient is
\[
 \boxed{F_L=K^{(2)}+\frac M3I
          =\frac7{15}I-\frac1{21}(D_L^{\rm face}+A_L).}
\tag{4.5}
\]
The first term in (3.6) also explicitly checks the vacuum-orthogonality
sign. Pairing \(v+\xi R_3Sv\) with (4.4) gives at order \(\xi\)
the two cancelling scalars \(-\sum_pa_p/3\) and \(+\sum_pa_p/3\).
The exact transported subspace is orthogonal to the exact vacuum at real
coupling, since their spectral contours are disjoint.

## 5. Exact spectral transport, evenness, and an explicit remainder

This section supplies the operator error bound in (1.7). Work throughout in
\(\mathcal H_{\rm phys}\). Put
\[
 r=\frac{3}{64M},\qquad \mathcal C_3=\{z:|z-3|=3/4\}.
\tag{5.1}
\]
On \(\mathcal C_3\), equation (2.2) gives
\(\|(z-H_0)^{-1}\|\leq4/3\). Since \(\|S\|=2M\), the Neumann
factor is at most \(1/8\) for complex \(|\xi|\leq r\). Equality in
\(\|S\|=2M\) follows from the all-identity link configuration and its
positive-measure neighborhoods. Consequently the analytic resolvent
\(R_\xi(z)=(z-K_\xi)^{-1}\) satisfies
\[
 \|R_\xi(z)\|\leq\frac{32}{21},\qquad
 P_\xi=\frac1{2\pi i}\int_{\mathcal C_3}R_\xi(z)\,dz,
 \qquad \|P_\xi-P\|\leq\frac17.
\tag{5.2}
\]
For the last bound, integrate the resolvent difference, using
\((3/4)(4/3)^2(2Mr)/(1-1/8)=1/7\). The contour integral is an
idempotent of rank M, by its continuous deformation from P.

On \(\mathcal P\) set \(T_\xi=PP_\xi P|_{\mathcal P}\). The convergent
binomial series at I defines \(T_\xi^{-1/2}\) analytically, since
\(\|T_\xi-I\|\leq1/7\), with
\(\|T_\xi^{-1/2}\|\leq\sqrt{7/6}\). Define exact maps
\[
 V_\xi=P_\xi P T_\xi^{-1/2}:\mathcal P\longrightarrow
                    \operatorname{ran}P_\xi,\qquad
 U_\xi=T_\xi^{-1/2}PP_\xi:\operatorname{ran}P_\xi\longrightarrow
                    \mathcal P.
\tag{5.3}
\]
Idempotence gives \(U_\xi V_\xi=I\); equal finite dimensions give
the reverse identity on \(\operatorname{ran}P_\xi\). For real \(\xi\),
\(P_\xi\) is orthogonal, \(U_\xi=V_\xi^*\), and \(V_\xi\) is an
isometry. Formula (5.3) retains the whole Gram factor; it is not a removal
of a physical field amplitude or scale. Its derivative at zero has
\(PV'_0=0\), as differentiating \(P_\xi^2=P_\xi\) gives
\(PP'_0P=0\). Differentiating its spectral intertwining equation then
gives exactly \(V'_0=R_3SP\), as used in (3.6) and (4.1).

The exact finite matrix representing the cluster is
\[
 B_\xi=U_\xi K_\xi V_\xi
      =T_\xi^{-1/2}P(K_\xi P_\xi)P T_\xi^{-1/2}.
\tag{5.4}
\]
The products are bounded because \(K_\xi P_\xi\) is its contour integral
\((2\pi i)^{-1}\int zR_\xi(z)dz\). In particular
\[
 \begin{split}
 \|B_\xi-3I\|
 &\leq\frac76\left\|\frac1{2\pi i}
       \int_{\mathcal C_3}(z-3)R_\xi(z)\,dz\right\|\\
 &\leq\frac76\left(\frac34\right)^2\frac{32}{21}=1.
 \end{split}
\tag{5.5}
\]
The corresponding contour \(|z|=3/4\) around the physical free bottom
has the same resolvent bounds and rank one. Its unique eigenvalue e(ξ)
is analytic and lies within that circle, so \(|e(\xi)|\leq3/4\).

Equation (3.1) gives \(K_{-\xi}=\mathcal ZK_\xi\mathcal Z\),
\(P_{-\xi}=\mathcal ZP_\xi\mathcal Z\), and
\(T_{-\xi}=T_\xi\), since \(\mathcal ZP=-P\). Thus
\(V_{-\xi}=-\mathcal ZV_\xi\), \(U_{-\xi}=-U_\xi\mathcal Z\), and
\[
 B_{-\xi}=B_\xi,\qquad e(-\xi)=e(\xi).
\tag{5.6}
\]
These are analytic identities, not a choice of labels at a degenerate
eigenvalue. Therefore the matrix
\(G_\xi=B_\xi-e(\xi)I-3I\) is even analytic on \(|\xi|\leq r\),
has \(G_0=0\), has second coefficient F_L by (4.5), and has norm at
most \(7/4\). Cauchy's coefficient estimate followed by the geometric
series gives, for \(|\xi|\leq r/2\),
\[
 \|G_\xi-\xi^2F_L\|
 \leq\frac74\sum_{k\geq2}\left(\frac{|\xi|}{r}\right)^{2k}
 \leq\frac73r^{-4}|\xi|^4.
\tag{5.7}
\]
There is a neighborhood beyond the closed radius r where the contours and
series above exist, since each displayed Neumann and Gram bound is strict
at its analytic threshold, so Cauchy's estimate at r is legitimate.

For real \(|\xi|\leq r/2\), the perturbation norm is at most
\(2M|\xi|\leq3/64\). The min--max principle moves each ordered physical
eigenvalue of H_0 by no more than this number. There is one bottom, M
eigenvalues near 3, and all remaining eigenvalues are at least
\(9/2-3/64\); hence the first positive physical excitation is precisely
the lowest eigenvalue of \(\kappa(B_\xi-e(\xi)I)\). For Hermitian
matrices the min--max principle bounds the change of every ordered
eigenvalue by the perturbation norm. Applying it to (5.7), and observing
that \(\lambda_{\min}(F_L)=7/15-q_L/21\), proves (1.7), including its
absolute error bound.

The constant \(2bM\) has not disappeared by fiat: both the ground energy
and every physical cluster eigenvalue of H are their K_ξ counterparts
multiplied by κ and then increased by \(2bM\). Their difference is (1.7).

## 6. The unchanged open-box graph and its coefficient limit

For a link in direction i, let j,k be the other directions and put
\[
 a_j(n_j)=\begin{cases}1,&n_j=\pm L,\\2,&-L<n_j<L.\end{cases}
 \qquad r_e=a_j(n_j)+a_k(n_k).
\tag{6.1}
\]
This is exactly the number of faces incident to e. The face degree is
\(d_p=\sum_{e\in\partial p}(r_e-1)\), since two different squares
share at most one edge. Hence \(d_p\leq12\), with strict inequality
for some boundary faces. The number \(\mathcal A_L\) of unordered
adjacent face pairs is
\[
 \mathcal A_L=\sum_e\binom{r_e}{2}=144L^3-12L.
\tag{6.2}
\]
Here are the finite sums establishing the coefficient. For either transverse
coordinate, \(\sum a_j=2m\) and \(\sum a_j^2=4m-2\). For one direction
i, summing \(r_e(r_e-1)\) over the two transverse coordinates gives
\[
 2(m+1)(4m-2)+2(2m)^2-2(m+1)(2m)=12m^2-4.
\]
There are m positions along i, three choices of i, and the factor \(1/2\)
in (6.2), giving \(18m^3-6m=144L^3-12L\). In particular
\(\sum_pd_p=2\mathcal A_L\).

The constant face vector gives the Rayleigh lower bound
\[
 q_L\geq\frac{4\mathcal A_L}{M}
       =\frac{48L^2-4}{L(2L+1)},\qquad q_L\leq24.
\tag{6.3}
\]
The upper bound follows from the maximum absolute row sum of Q_L, equal
to \(2\max_pd_p\leq24\). It is strict. The face graph is connected:
within a coordinate plane the square tiling is connected by edge adjacency;
neighboring parallel layers connect through a square in a transverse plane,
and that same adjacency joins the three plane orientations. A maximizing
eigenvector of the real symmetric nonnegative Q_L can be chosen nonnegative,
because replacing its entries by their absolute values does not decrease
its quadratic form. Connectedness and the eigen-equation make all entries
positive. If its eigenvalue were 24, an entry of maximum size would force
its degree to equal 12 and every neighboring entry to have the same size.
Propagation through the connected graph would force every face degree to
equal 12, contradicting the boundary faces. Thus \(q_L<24\).

Subtracting (6.3) from 24 gives
\[
 0<24-q_L\leq\frac{24L+4}{L(2L+1)}.
\tag{6.4}
\]
Equations (1.6) and (6.4) prove (1.8). Also
\(24-(24L+4)/(L(2L+1))\geq24-14/L\geq17\) for \(L\geq2\).
Since \(17>49/5\), (6.3) gives \(\nu_L<7/15-(49/5)/21=0\).
This proof used the actual open incidence sets, not periodic boundaries.

## 7. Meaning of the coefficient and relation to previous states

At each fixed box, the interacting first physical eigenvalue decreases from
\(3\kappa\) at second order in ξ. This statement is stronger than a
change in one proposed Rayleigh quotient: Sections 2 and 5 isolate the
entire first physical cluster, and Section 4 diagonalizes its full
second-order operator. Its neighbor coefficient \(-1/21\) and the
degree contribution are exact effects of both retained spin channels.

The earlier electric and magnetic-translation trial families have leading
energy \(3\kappa\) in their non-kernel directions. The exact map from
that leading face space to the actual first spectral subspace is V_ξ in
(5.3), with the first correction (3.6). It includes the vacuum subtraction,
repeated-face spin-one terms, all edge-disjoint pairs, and all hinged or
coplanar adjacent pairs. Thus this calculation supplies their full first
spectral dressing rather than claiming those trial families and the
physical spectrum are unrelated.

No zero of a truncated polynomial is asserted to be a zero of the physical
gap. The guaranteed interval in (1.7) shrinks as \(M^{-1}\), while its
explicit fourth-order bound grows as \(M^4\). Equation (1.8) is a
coefficient limit and does not prove a fixed-positive-coupling infinite-volume
limit of (1.7). The state-space and spectral transport are exact at each
finite box; extending the spectral estimates to the original interacting
spatial continuum remains a mathematical calculation not supplied by this
coefficient alone.

## 8. Primary literature and attribution of this calculation

The Hamiltonian lattice framework is that of J. Kogut and L. Susskind,
*Hamiltonian formulation of Wilson's lattice gauge theories*, Physical
Review D **11** (1975), 395--408,
<https://doi.org/10.1103/PhysRevD.11.395>. Equations (1.3)--(1.4) give
the complete conventions actually used here, rather than borrowing a
coefficient from a differently parametrized Hamiltonian.

Strong-coupling scalar-gap series in three spatial dimensions already have
an extensive literature, including A. C. Irving, T. E. Preece, and C. J.
Hamer, *Cluster expansion approach to non-abelian lattice gauge theory in
(3+1)D (I). SU(2)*, Nuclear Physics B **270** (1986), 536--552,
<https://doi.org/10.1016/0550-3213(86)90567-5>. The publisher's abstract
identifies its vacuum-energy, string-tension and scalar-gap expansions.
The present derivation is self-contained and does not claim historical
novelty for a strong-coupling coefficient; no unread coefficient table from
that article is used as a proof or as a claimed numerical match.

The interacting four-dimensional continuum target is the construction and
spectral assertion in A. Jaffe and E. Witten, *Quantum Yang--Mills Theory*,
<https://www.claymath.org/wp-content/uploads/2022/06/yangmills.pdf>.
Neither that continuum construction nor a counterexample to its mass-gap
assertion is claimed by the finite-box result (1.7).

```

## Complete source: wilson_variation/first_excitation_face_graph.md

```markdown
# The full open-box face graph, its bulk symbol, and the first-band coefficient limit

8 September 2026. This calculation retains every boundary face of the original open spatial box. The infinite and periodic graphs are defined independently, and their relation to the open graph is an explicit zero-extension identity. The interior sine function is a trial vector in the actual finite open graph, not a change of boundary conditions.

## 1. Original open box, physical orientations, and the face operator

Let \(L\ge2\) be an integer, put \(m=2L\), and take vertices in \(\{-L,\ldots,L\}^3\). A physical edge \(e=(n,i)\) runs from \(n\) to \(n+\mathbf e_i\), whenever both endpoints belong to the box. The face \(p=(n;i,j)\), \(i<j\), has the canonical oriented edge word

\[
(n,i)^+\,(n+\mathbf e_i,j)^+\,
(n+\mathbf e_j,i)^-\,(n,j)^-.
\tag{1.1}
\]

Its underlying set of four physical edges is denoted \(\partial p\); signs in (1.1) do not create additional edges. All contained elementary faces are included in \(\mathsf P_L\). The number of faces is

\[
M_L=|\mathsf P_L|=3m^2(m+1)=12L^2(2L+1).
\tag{1.2}
\]

Indeed each of the three face planes has \(m\) base choices in each plane direction and \(m+1\) in its normal direction.

Two distinct faces are adjacent exactly when their physical edge sets intersect. Two distinct elementary squares in the open box share at most one physical edge: coplanar unit squares can meet along only one side, while perpendicular coordinate squares intersect in at most a single unit coordinate segment. Thus the adjacency matrix \(\mathsf A_L\) is a simple unweighted symmetric matrix:
\[
(\mathsf A_L)_{pq}=\mathbf1_{\{p\ne q,\ \partial p\cap\partial q\ne\varnothing\}}.
\]
Let \(d_p=\sum_q(\mathsf A_L)_{pq}\), and define the actual open signless face Laplacian

\[
\boxed{\mathsf Q_L=\operatorname{diag}(d_p)+\mathsf A_L.}
\tag{1.3}
\]

For every complex face vector \(x\),
\[
\langle x,\mathsf Q_Lx\rangle
=\sum_{\{p,q\}\text{ adjacent}}|x_p+x_q|^2.
\tag{1.4}
\]
This follows by expanding each square: each diagonal \(|x_p|^2\) occurs \(d_p\) times, and every cross term agrees with the adjacency quadratic form. In particular \(\mathsf Q_L\) is positive semidefinite. This is the signless operator, not \(\operatorname{diag}(d)-\mathsf A_L\).

If \(\mathsf I_{pe}=\mathbf1_{\{e\in\partial p\}}\) is the original unsigned face-edge incidence matrix, the same one-edge intersection fact gives
\[
\mathsf I\mathsf I^T=4I+\mathsf A_L,\qquad
\mathsf Q_L=\mathsf I\mathsf I^T+\operatorname{diag}(d_p-4).
\tag{1.5}
\]
The diagonal 4 in this incidence product is not the adjacency degree, which varies at the boundary.

## 2. Exact degrees, all boundary multiplicities, and connectedness

For an edge \(e=(n,i)\), let \(r_e\) be the number of contained elementary faces incident on it. If \(j,k\) are its two transverse directions, then

\[
r_e=\delta(n_j)+\delta(n_k),\qquad
\delta(t)=
\begin{cases}
1,&t=-L\text{ or }L,\\
2,&-L<t<L.
\end{cases}
\tag{2.1}
\]

In each transverse direction a face can extend on both sides in the interior and only inward at the boundary. Thus \(2\le r_e\le4\). Every neighbor of a fixed face is counted at its unique shared edge, so
\[
d_p=\sum_{e\in\partial p}(r_e-1).
\tag{2.2}
\]

For a face \(p=(n;i,j)\), write \(k\) for its normal direction and define, on the plane base-coordinate range \(-L\le t\le L-1\),
\[
\beta(t)=\mathbf1_{\{t=-L\}}+\mathbf1_{\{t=L-1\}}.
\tag{2.3}
\]
Since \(\delta(t)+\delta(t+1)=4-\beta(t)\), summing (2.1) over the four edges in (2.2) gives the exact boundary formula

\[
\boxed{
d_{n;i,j}=
\begin{cases}
12-\beta(n_i)-\beta(n_j),&-L<n_k<L,\\
8-\beta(n_i)-\beta(n_j),&n_k=-L\text{ or }L.
\end{cases}}
\tag{2.4}
\]

This produces all six degree classes, with no excluded faces:

| Degree | Exact number of faces |
|---:|---:|
| \(12\) | \(3(m-1)(m-2)^2\) |
| \(11\) | \(12(m-1)(m-2)\) |
| \(10\) | \(12(m-1)\) |
| \(8\) | \(6(m-2)^2\) |
| \(7\) | \(24(m-2)\) |
| \(6\) | \(24\) |

To verify the table, there are \(m-1\) interior normal-coordinate values or two boundary values. In either plane direction there are \(m-2\) bases with \(\beta=0\) and two with \(\beta=1\). Their products give respectively \((m-2)^2\), \(4(m-2)\), and 4 plane-coordinate pairs with sum of the two \(\beta\)'s equal to 0, 1, or 2. Multiply by the three planes and the appropriate normal-coordinate count. Summing the table gives (1.2).

The exact number \(a_L\) of unordered adjacent pairs can be obtained either by summing this degree table and dividing by 2, or directly by the incident edge stars. For each edge direction, hold its \(m\) longitudinal bases fixed. There are \((m-1)^2\) transverse interior positions with \(r_e=4\), \(4(m-1)\) positions with exactly one boundary coordinate and \(r_e=3\), and 4 positions with two boundary coordinates and \(r_e=2\). Each contributes \(\binom{r_e}{2}\), with no pair counted twice. Therefore

\[
\boxed{a_L=3m[6(m-1)^2+12(m-1)+4]
=18m^3-6m=144L^3-12L.}
\tag{2.5}
\]

In particular
\[
\sum_pd_p=2a_L,\qquad
\sum_p(12-d_p)=12m(3m+1).
\tag{2.6}
\]

The whole face graph is connected. First, the \(12\)-faces in any fixed \(n_3\) layer form a connected rectangular face grid, by coplanar edge adjacency. Consecutive \(n_3\) layers are joined through a \(13\)-face: its bottom and top direction-1 edges belong to \(12\)-faces in the two layers. For instance choose fixed permissible \(n_1,n_2\) and the \(13\)-face between the two layers; both neighboring \(12\)-faces exist. Hence all \(12\)-layers lie in one connected component. Every \(13\)-face has a direction-1 edge which belongs to a \(12\)-face, choosing the latter's direction-2 extension inward if that edge is on a boundary. Every \(23\)-face likewise has a direction-2 edge belonging to a \(12\)-face, with direction-1 extension chosen inward. Thus every face belongs to that one component.

## 3. Full open-box bounds and strict inequality at finite volume

Let \(\Lambda_L=\lambda_{\max}(\mathsf Q_L)\). The unchanged constant face vector has squared norm \(M_L\) and, by (1.4), quadratic form \(4a_L\). Hence

\[
\boxed{
\frac{48L^2-4}{L(2L+1)}
=\frac{4a_L}{M_L}\le\Lambda_L.}
\tag{3.1}
\]

The boundary formula gives \(d_p\le12\). A particularly useful exact deficit identity is

\[
\boxed{
\langle x,(24I-\mathsf Q_L)x\rangle
=\sum_{\{p,q\}\text{ adjacent}}|x_p-x_q|^2
+2\sum_p(12-d_p)|x_p|^2.}
\tag{3.2}
\]

Indeed the first sum is the quadratic form of \(\operatorname{diag}(d)-\mathsf A_L\), and adding the second term gives \(24I-\operatorname{diag}(d)-\mathsf A_L\). Both terms are nonnegative. Equality would force \(x_p=x_q\) on every adjacency and \(x_p=0\) on every degree-deficient face. Connectedness makes \(x\) constant, and the nonempty degree-6 boundary class forces that constant to be zero. Therefore, in this finite-dimensional space,

\[
\boxed{\frac{48L^2-4}{L(2L+1)}\le\Lambda_L<24.}
\tag{3.3}
\]

This already proves \(\Lambda_L\to24\). It also records why the constant vector is not an eigenvector at the open boundary: its row values are \(2d_p\), which are not constant.

## 4. Independently defined bulk and periodic graphs, with full translations

The infinite graph has vertices \((n;\alpha)\), where \(n\in\mathbb Z^3\) and the plane type \(\alpha\) is one of \(12,13,23\). Its physical edges and oriented faces use (1.1) on the entire infinite cubic lattice. Two faces are adjacent by the same shared-physical-edge rule. Every edge has four incident faces, every face has twelve distinct neighbors, and its signless operator on
\(\ell^2(\mathbb Z^3;\mathbb C^3)\) is
\[
\mathsf Q_\infty=12I+\mathsf A_\infty.
\tag{4.1}
\]

Here is its entire translation list. Within plane \(ij\), the four neighbors of \((n;ij)\) are \((n\pm\mathbf e_i;ij)\) and \((n\pm\mathbf e_j;ij)\). Between different planes, for \(a,b\in\{0,1\}\),

| Source plane | Target plane | Shared direction | Target base |
|---|---|---:|---|
| \(12\) | \(13\) | \(1\) | \(n+a\mathbf e_2-b\mathbf e_3\) |
| \(12\) | \(23\) | \(2\) | \(n+a\mathbf e_1-b\mathbf e_3\) |
| \(13\) | \(23\) | \(3\) | \(n+a\mathbf e_1-b\mathbf e_2\) |

Each row has four distinct offsets, including the zero offset, and the reverse neighbors have their negatives.

To prove the list with orientations retained, the two direction-\(i\) edges of a face \(ij\) lie at \(n\) and \(n+\mathbf e_j\) with signs \(+,-\); its two direction-\(j\) edges lie at \(n\) and \(n+\mathbf e_i\) with signs \(-,+\). A common physical edge between two planes is obtained by equating one of their two bases in the shared direction. For the first row this equates \(n+a\mathbf e_2\) with the target base plus \(b\mathbf e_3\), yielding the displayed offset. The other two rows follow by equating the direction-2 or direction-3 bases. The traversal signs in the three rows are respectively \(((-1)^a,(-1)^b)\), \((-(-1)^a,(-1)^b)\), and \((-(-1)^a,-(-1)^b)\). The graph is unsigned and so includes all four sign combinations; none is discarded or counted twice. This proves both the exact translations and the multiplicity 12.

A separate finite periodic graph can be defined by taking base coordinates in
\[
\mathbb Z/N_1\mathbb Z\times\mathbb Z/N_2\mathbb Z\times\mathbb Z/N_3\mathbb Z,
\qquad N_i\ge3,
\tag{4.2}
\]
and using the same physical edge labels and face words modulo those periods. The condition \(N_i\ge3\) prevents the \(+\mathbf e_i\) and \(-\mathbf e_i\) neighbors from coinciding and prevents two elementary faces sharing multiple physical edges. The neighbor list above is then valid modulo the periods, still with twelve distinct neighbors per face. This definition is independent of the original open box; it is not imposed on \(\mathsf P_L\).

## 5. Exact three-plane Fourier symbol and the mode attaining 24

For a finitely supported infinite face field, define
\[
\widehat f_\alpha(k)=\sum_{n\in\mathbb Z^3}f_\alpha(n)e^{-ik\cdot n},
\qquad k\in[-\pi,\pi]^3,
\tag{5.1}
\]
with inverse measure \(dk/(2\pi)^3\). Orthogonality of the exponentials proves the isometry on finite sums, which extends by density to a unitary map from \(\ell^2(\mathbb Z^3;\mathbb C^3)\) onto the corresponding \(L^2\) space. The translation \(f_\beta(n+\delta)\) gives the multiplier \(e^{ik\cdot\delta}\). In the order \(12,13,23\), the neighbor list therefore gives the exact Hermitian symbol

\[
\boxed{
\widehat{\mathsf Q}(k)=12I+
\begin{pmatrix}
2\cos k_1+2\cos k_2&
(1+e^{ik_2})(1+e^{-ik_3})&
(1+e^{ik_1})(1+e^{-ik_3})\\
(1+e^{-ik_2})(1+e^{ik_3})&
2\cos k_1+2\cos k_3&
(1+e^{ik_1})(1+e^{-ik_2})\\
(1+e^{-ik_1})(1+e^{ik_3})&
(1+e^{-ik_1})(1+e^{ik_2})&
2\cos k_2+2\cos k_3
\end{pmatrix}.}
\tag{5.2}
\]

No common translation phases have been suppressed. If one instead uses each face center as its Fourier origin, define the explicit unitary fiber change
\[
\mathsf D(k)=\operatorname{diag}
\big(e^{i(k_1+k_2)/2},e^{i(k_1+k_3)/2},e^{i(k_2+k_3)/2}\big),
\qquad \widehat f=\mathsf D(k)\,u.
\tag{5.3}
\]
Writing \(c_i=\cos(k_i/2)\), one obtains the real centered symbol

\[
\boxed{
\mathsf D(k)^*\widehat{\mathsf Q}(k)\mathsf D(k)
=
\begin{pmatrix}
12+2\cos k_1+2\cos k_2&4c_2c_3&4c_1c_3\\
4c_2c_3&12+2\cos k_1+2\cos k_3&4c_1c_2\\
4c_1c_3&4c_1c_2&12+2\cos k_2+2\cos k_3
\end{pmatrix}.}
\tag{5.4}
\]

For example the phase of the \(12,13\) entry in (5.2) is \(e^{i(k_2-k_3)/2}\), which cancels exactly with the two center phases in (5.3). Thus (5.4) is a unitary change of fiber coordinates, not a replacement of physical translation phases.

At zero momentum,
\[
\widehat{\mathsf Q}(0)=12I+4\mathbf1\mathbf1^T,
\tag{5.5}
\]
with eigenvalues 24 on the equal-plane vector \((1,1,1)\), and 12 twice on its orthogonal complement.

This is the only Bloch mode at eigenvalue 24, modulo reciprocal-lattice momenta. To prove it, for an original-base amplitude \(\eta\in\mathbb C^3\), the exact quadratic form of \(24I-\widehat{\mathsf Q}(k)=12I-\widehat{\mathsf A}(k)\) is
\[
\sum_{\alpha=ij}\sum_{r\in\{i,j\}}
|\eta_\alpha-e^{ik_r}\eta_\alpha|^2
+\sum_{\alpha<\beta}\sum_{\delta\in\mathsf T_{\alpha\beta}}
|\eta_\alpha-e^{ik\cdot\delta}\eta_\beta|^2,
\tag{5.6}
\]
where \(\mathsf T_{\alpha\beta}\) is the four-offset set in Section 4. Expanding this expression recovers (5.2): each component receives four units of same-plane diagonal contribution and eight from the cross-plane rows. It is nonnegative. Each cross-plane offset set includes zero, so equality forces all three amplitudes to agree. If they are nonzero, the same-plane terms force \(e^{ik_1}=e^{ik_2}=e^{ik_3}=1\). Conversely that momentum and equal amplitudes give (5.5). Hence
\[
\lambda_{\max}(\widehat{\mathsf Q}(k))\le24,
\]
with equality exactly at \(k\in(2\pi\mathbb Z)^3\) and the stated equal-plane eigenvector.

On the independently defined periodic graph (4.2), the same proof uses the discrete momenta \(k_i=2\pi r_i/N_i\). Its maximum eigenvalue is exactly 24, achieved only by the constant equal-plane field. On the infinite graph, the constant Bloch field is not in \(\ell^2\). The symbol implies operator norm 24: its continuous eigenvalue near zero gives fields supported in arbitrarily small momentum neighborhoods with Rayleigh values arbitrarily close to 24. There is no nonzero \(\ell^2\) eigenvector at 24, because equality in (5.6) would require its Fourier transform to be supported at the measure-zero momentum \(k=0\).

## 6. Exact map from the infinite graph to the unchanged open graph

Let \(J_L:\mathbb C^{\mathsf P_L}\to\ell^2(\mathbb Z^3;\mathbb C^3)\) extend a face vector by zero on every face outside the open box. This is an isometry in the original counting inner products. The open face graph is the induced subgraph of the infinite one: two contained faces share a physical edge in the finite box exactly when they do so in the infinite lattice. Consequently

\[
\boxed{
J_L^*\mathsf Q_\infty J_L=12I+\mathsf A_L,\qquad
\mathsf Q_L=J_L^*\mathsf Q_\infty J_L
-\operatorname{diag}(12-d_p).}
\tag{6.1}
\]

This is the exact comparison, including the boundary correction. Replacing the open operator by its bulk compression would add the nonzero boundary diagonal \(\operatorname{diag}(12-d_p)\); replacing it by a periodic graph would also add different adjacency edges. Neither operation is performed here.

The following stronger bound is a trial calculation in \(\mathsf Q_L\) itself. Put
\[
\ell=2L-2,\qquad t=\frac{\pi}{2L-1}=\frac{\pi}{\ell+1},\qquad c=\cos t,
\]
and define on the integer line
\[
f_r=
\begin{cases}
\sin(rt),&1\le r\le\ell,\\
0,&\text{otherwise}.
\end{cases}
\tag{6.2}
\]
For a face of any of the three plane types with base \(n\), set
\[
x_{n;\alpha}=g(n),\qquad
g(n)=\prod_{i=1}^3f_{n_i+L}.
\tag{6.3}
\]
This is a vector on every face of the original open box, with zero entries whenever any base coordinate is outside \([-L+1,L-2]\). Every face in its support has degree exactly 12 by (2.4). Thus the boundary diagonal in (6.1) vanishes on the support, and
\[
\langle x,\mathsf Q_Lx\rangle
=\langle J_Lx,\mathsf Q_\infty J_Lx\rangle.
\tag{6.4}
\]
No outer face or boundary interaction is deleted from the finite operator: its trial amplitude is simply zero. Equation (6.4) proves the required map of this particular interior trial to the actual open signless graph.

To calculate its quotient exactly, let
\[
S=\sum_{r=1}^{\ell}f_r^2>0,\qquad
T=\sum_{r=1}^{\ell-1}f_rf_{r+1}.
\]
The discrete sine equation \(f_{r-1}+f_{r+1}=2cf_r\), with \(f_0=f_{\ell+1}=0\), multiplied by \(f_r\) and summed, gives \(T=cS\). Direct product factorization gives
\[
\sum_ng(n)^2=S^3,\quad
\sum_ng(n)g(n+\mathbf e_i)=TS^2,\quad
\sum_ng(n)g(n+\mathbf e_i-\mathbf e_j)=T^2S\quad(i\ne j).
\tag{6.5}
\]
All sums are over the zero-extended integer lattice and hence are finite.

The squared norm of (6.3) is \(3S^3\). The diagonal contribution of \(\mathsf Q_\infty\) is \(36S^3\). The same-plane adjacency contribution, from two directions in each of three planes and both signs of each shift, is \(12TS^2\). For each of three unordered plane pairs, the four shifts in Section 4 contribute \(S^3+2TS^2+T^2S=S(S+T)^2\); the reverse matrix entries double this, giving total \(6S(S+T)^2\). Thus (6.4) yields the exact open-graph trial quotient

\[
\boxed{
\frac{\langle x,\mathsf Q_Lx\rangle}{\|x\|^2}
=\frac{36S^3+12TS^2+6S(S+T)^2}{3S^3}
=14+8c+2c^2.}
\tag{6.6}
\]

In particular the full open-box estimates can be sharpened to

\[
\boxed{
\max\left\{\frac{48L^2-4}{L(2L+1)},\
14+8\cos\frac{\pi}{2L-1}+2\cos^2\frac{\pi}{2L-1}\right\}
\le\Lambda_L<24.}
\tag{6.7}
\]

Since \(24-(14+8c+2c^2)=2(1-c)(5+c)\) and
\(1-\cos t=2\sin^2(t/2)\le t^2/2\), the deficit satisfies

\[
\boxed{
0<24-\Lambda_L
\le\min\left\{
\frac{24L+4}{L(2L+1)},\
2(1-c)(5+c)\right\}
\le\frac{6\pi^2}{(2L-1)^2}.}
\tag{6.8}
\]

The last bound is quantitative \(O(L^{-2})\), obtained without imposing periodic conditions or dropping the actual boundary diagonal.

## 7. Exact consequence for the specified second-order coefficient matrix

Define the finite matrix requested by the excitation calculation, with its given constants, by

\[
\mathsf F_L=\frac7{15}I-\frac1{21}\mathsf Q_L.
\tag{7.1}
\]

This note proves the spectrum of this explicitly specified graph matrix. The derivation identifying (7.1) with the physical true-vacuum second-order excitation matrix is the separate parent band calculation; no replacement of that physical calculation is assumed here.

Because \(\mathsf F_L\) is an affine polynomial in the real symmetric \(\mathsf Q_L\), they have the same orthonormal eigenvectors, with the exact eigenvalue map \(q\mapsto7/15-q/21\). Therefore

\[
\lambda_{\min}(\mathsf F_L)=\frac7{15}-\frac{\Lambda_L}{21}.
\tag{7.2}
\]
Equations (6.8) and (7.2) give the strict and quantitative coefficient bounds

\[
\boxed{
0<\lambda_{\min}(\mathsf F_L)+\frac{71}{105}
\le\frac1{21}\min\left\{
\frac{24L+4}{L(2L+1)},\
2(1-c)(5+c)\right\}
\le\frac{2\pi^2}{7(2L-1)^2}.}
\tag{7.3}
\]
Here \(7/15-24/21=-71/105\) exactly. In particular
\[
\boxed{\lim_{L\to\infty}\lambda_{\min}(\mathsf F_L)=-\frac{71}{105}.}
\tag{7.4}
\]

The constant equal-plane bulk mode supplies the limiting edge of this coefficient matrix, while the finite open maximizer has the strictly smaller value in (6.7). These statements concern the explicit finite Taylor-coefficient matrices and their large-box limit. They do not control any remainder of the physical perturbation series uniformly in volume, and they do not establish an infinite-volume gap or a four-dimensional continuum limit.

## 8. Lightweight exact verification

The companion check_first_excitation_face_graph.py enumerates every face and adjacency of the full open boxes \(L=2,3,4,5\). It checks the six exact degree classes, connectedness, all edge-star multiplicities, the constant-vector quotient, and all boundary deficits. The four graph sizes are respectively:

| \(L\) | Faces | Unordered adjacencies |
|---:|---:|---:|
| 2 | 240 | 1128 |
| 3 | 756 | 3852 |
| 4 | 1728 | 9168 |
| 5 | 3300 | 17940 |

The checker directly computes the quadratic form of an integer-valued separable interior trial on the unchanged whole open graph and verifies the exact factorization in (6.6) before the sine substitution. For the sine itself it uses the exact polynomials \(f_r/\sin t=U_{r-1}(c)\), where \(U_r\) are the Chebyshev polynomials and \(U_\ell(c)=0\). It verifies \(T=cS\) and the full trial quotient by polynomial division with zero remainder, not by a numerical trigonometric eigenvalue estimate.

An independently generated periodic graph with periods \((3,4,5)\) checks the full translation list and twelve-neighbor multiplicity. Exact Laurent variables \(x_i=e^{ik_i/2}\) verify the Fourier symbol and center-phase change; at \(x_i=1\) the exact characteristic polynomial is \((\lambda-24)(\lambda-12)^2\). The rational coefficient \(-71/105\) is checked exactly.

The all-\(L\) graph statements, the infinite/periodic symbol, and both open variational bounds are proved above; finite checks are diagnostics, not a substitute for those proofs. No numerical eigenvalue, spatial continuum approximation, remote action, new agent, PDF, or heavy job was used.

```

## Complete source: wilson_variation/first_excitation_band_independent.md

```markdown
# The actual first physical excitation band: independent derivation

8 September 2026. This calculation retains the full finite open three-
dimensional spatial Wilson box, every plaquette, the actual ground energy,
and all virtual channels. It computes the degenerate first physical
excitation cluster, not a single trial quotient. All perturbative
statements are at a fixed finite box unless an explicit coefficient
limit is separately stated.

## 1. Original Hamiltonian and physical Hilbert space

Fix an integer \(L\geq2\), vertices
\(\mathsf V_L=\{-L,\ldots,L\}^3\), and every positive physical link
\(e=(n,i)\) whose endpoints lie in the box. A negative traversal uses
the inverse of that same variable \(U_e\in SU(2)\). Every elementary
face \(p=(n;i,j)\), \(i<j\), is retained, with
\[
W_p=\operatorname{tr}\bigl[
U_i(n)U_j(n+\mathbf e_i)
U_i(n+\mathbf e_j)^{-1}U_j(n)^{-1}\bigr].
\]
The numbers of links and faces are
\[
N=3(2L)(2L+1)^2,\qquad M=3(2L)^2(2L+1).
\]
Use product Haar probability measure on \(SU(2)^N\), an inner product
conjugate-linear in its first argument, and the original derivatives
\[
T_a=-i\sigma_a/2,\qquad
X_{e,a}F=\left.\frac{d}{dt}\right|_0
F(\ldots,e^{tT_a}U_e,\ldots),\qquad
E_e=-\sum_aX_{e,a}^2,\qquad H_0=\sum_eE_e .
\]
The metric \(c(A,B)=-\operatorname{tr}(AB)/2\) has orthonormal basis
\(2T_a\), hence \(-\Delta_e^c=4E_e\). Retain
\[
H=\kappa(H_0-\xi S)+2bM I,\qquad
S=\sum_pW_p,\quad \xi=b/\kappa,\quad
\kappa=\frac{2g_{\rm YM}^2}{a},\quad
b=\frac1{2g_{\rm YM}^2a}.
\tag{1.1}
\]
Both \(\kappa,b\) are positive in the physical model.

Let \(\Pi\) be product vertex Haar projection for
\(U_e\mapsto g_sU_eg_t^{-1}\), and let
\(\mathcal H_{\rm phys}=\Pi L^2(SU(2)^N)\).
Every link Casimir is bi-invariant and every face trace is gauge
invariant. Thus \(H_0,S,H\) reduce this physical subspace. On it,
the operator domain is \(H^2\cap\mathcal H_{\rm phys}\) and the
form domain is \(H^1\cap\mathcal H_{\rm phys}\).
The bounded smooth multiplication by \(S\), of norm \(2M\), preserves
self-adjointness and compact resolvent. The strictly positive smooth
normalized full ground state \(\psi_\xi\) is unique: a ground form
minimizer can be replaced by its modulus; elliptic regularity and the
strong maximum principle give positivity; integration by parts gives
\[
\mathfrak q_{H-\mathcal E_0}[\psi_\xi F]
=\kappa\sum_{e,a}\int\psi_\xi^2|X_{e,a}F|^2\,dU .
\]
A second ground eigenfunction divided by \(\psi_\xi\) must therefore
be constant. Gauge transformations fix the unique positive normalized
ground state, so it belongs to \(\mathcal H_{\rm phys}\).

## 2. Exact free physical eigenspace and upward gap

The product Peter--Weyl decomposition labels each edge by
\(j_e\in\{0,\tfrac12,1,\ldots\}\), with Casimir \(j_e(j_e+1)\).
The fundamental value is \(3/4\), since
\(-\sum_aT_a^2=3I/4\). At each vertex, the Haar projection is the
projection onto invariant tensors of the incident representation
indices, with duals chosen according to edge orientation.

Ignore spin-zero edges and call the remaining edge graph the active
support. A vertex of degree one in this graph has a single nontrivial
irreducible representation and no invariant tensor. Its Haar projector
is zero. Thus every nonempty active component of a physical coefficient
has minimum degree at least two. Such a finite component contains a
cycle. The open cubic graph is simple and bipartite, with parity
\(n_1+n_2+n_3\bmod2\), so every cycle has length at least four.

If a physical free energy is below \(9/2\), it has at most five active
edges, since each contributes at least \(3/4\). There can be only
one active component: two components would each require at least
four edges. A connected simple bipartite graph with minimum degree
two and at most five edges must be a four-cycle. To prove this,
its number of vertices is at most its number of edges. Three or
fewer vertices cannot support a bipartite cycle. With four vertices
the bipartite graph has at most four edges, so it is a four-cycle.
With five vertices and at most five edges, minimum degree two
forces every degree to be two, giving a five-cycle, impossible
in a bipartite graph.

At a degree-two vertex, an invariant tensor between two incident
irreducible representations exists only when their spins agree;
its dimension is then one by Schur's lemma and self-duality of
\(SU(2)\) representations. Thus the spin is the same around this
four-cycle. Its energy is \(4j(j+1)\), equal to 3 for \(j=1/2\)
and at least 8 for the next nonzero spin. Every simple four-cycle
in the unit cubic graph is an elementary square: its closed
four-step displacement uses two different coordinate directions,
each once positively and once negatively. Its invariant fundamental
contraction is precisely \(W_p\).

The Haar identities are
\[
\int W_p\,dU=0,\qquad
\langle W_p,W_q\rangle=\delta_{pq}.
\tag{2.1}
\]
Distinct faces have different edge supports; central multiplication
of an edge in only one face by \(-I\) annihilates the mixed integral.
For equal faces Haar invariance reduces the norm to
\(\int(\operatorname{tr}U)^2dU=1\).
Consequently the free physical spectrum starts with
\[
\boxed{\lambda_0=0\text{ simple},\qquad
\lambda_1=\cdots=\lambda_M=3,\qquad
\operatorname{span}\{W_p:p\in\mathsf P_L\}
=\ker(H_0-3)\cap\mathcal H_{\rm phys}.}
\tag{2.2}
\]
There is no other physical eigenvalue in \((0,9/2)\).
A fundamental trace around a \(1\times2\) rectangle uses six distinct
edges and is gauge invariant, with energy \(6(3/4)=9/2\).
Such a rectangle exists in every stated box. Hence the next distinct
physical eigenvalue is exactly \(9/2\); the upward isolation of the
first cluster is exactly \(3/2\).

## 3. Fixed-box analytic cluster and exact even effective matrix

Let \(P\) be the physical orthogonal projection onto the span in (2.2),
and \(Q=I-P\) on the physical Hilbert space. Define
\[
K_\xi=H_0-\xi S .
\]
On the circle \(|z-3|=3/4\), the free physical resolvent norm is at
most \(4/3\). Since \(\|S\|=2M\), its Neumann parameter is
\(q=8M|\xi|/3\). The perturbed spectral projection \(P_\xi\) around
this circle is analytic for \(|\xi|<3/(8M)\). In the smaller disk
\[
|\xi|<\frac3{16M},
\tag{3.1}
\]
the contour bound gives
\(\|P_\xi-P\|\leq q/(1-q)<1\). For real \(\xi\), \(P_\xi\) is
orthogonal of rank \(M\). The bounded-perturbation min--max bound
moves each ordered free eigenvalue by at most \(2M|\xi|<3/8\).
Thus this cluster is still precisely the first \(M\) physical excited
eigenvalues: the ground remains separated below, and the next
physical free level remains above \(9/2-3/8\).

On \(\operatorname{ran}P\), put
\[
B_\xi=PP_\xi P,\qquad
V_\xi=P_\xi P B_\xi^{-1/2}.
\tag{3.2}
\]
For real \(\xi\) satisfying (3.1), \(B_\xi\) is positive invertible,
and \(V_\xi\) is an isometry from \(\operatorname{ran}P\) onto
\(\operatorname{ran}P_\xi\). Indeed
\(V_\xi^*V_\xi=B_\xi^{-1/2}B_\xi B_\xi^{-1/2}=I_P\);
the two spaces have equal finite dimension. Analytic matrix
functional calculus near \(B_0=I_P\) gives a real-analytic family.
The finite Hermitian matrix
\[
\mathsf A_\xi=V_\xi^*K_\xi V_\xi
\tag{3.3}
\]
has exactly the actual cluster eigenvalues. Its definition uses the
operator domain: the range of \(P_\xi\) consists of smooth eigenvectors.
Analyticity into \(H^2\), and then higher fixed Sobolev spaces, follows
from the contour resolvent and the elliptic eigen-equation.

The central cochain
\[
z_i(n)=(-1)^{\sum_{j<i}n_j}I,\qquad
\mathcal ZF(U)=F((z_eU_e)_e)
\]
is a real Haar-unitary involution commuting with \(H_0\) and \(\Pi\).
Every face sign is \(-1\): for \(i<j\), shifting \(z_j\) in direction
\(i\) changes its sign, while shifting \(z_i\) in direction \(j\)
does not. Thus \(\mathcal ZS\mathcal Z=-S\) and
\[
\mathcal Z|_{\operatorname{ran}P}=-I_P,\qquad
P_{-\xi}=\mathcal ZP_\xi\mathcal Z,\quad
B_{-\xi}=B_\xi,\quad
V_{-\xi}=-\mathcal ZV_\xi .
\]
Substituting in (3.3) proves the exact matrix equality
\[
\boxed{\mathsf A_{-\xi}=\mathsf A_\xi.}
\tag{3.4}
\]
In particular all its odd Taylor coefficients vanish; this is a
matrix identity, not an assumption about labels of crossing eigenvalues.
It also proves \(PSP=0\) directly: \(S\) is odd under \(\mathcal Z\),
while both external vectors belong to its negative eigenspace.

Define the bounded reduced free resolvent
\[
R_3=Q(H_0-3)^{-1}Q .
\tag{3.5}
\]
It is well-defined on the physical complement by (2.2), and equals
\(-1/3\) on the vacuum. Differentiating the invariant-subspace equation
at zero gives
\[
V_1:=V_\xi'|_0=R_3SP,\qquad PV_1=0.
\tag{3.6}
\]
For example \(Q(H_0-3)V_1=QSP\); differentiating the isometry and
its explicit positive-overlap convention in (3.2) gives the zero
in-cluster first derivative. Writing
\(V_\xi=P+\xi V_1+\xi^2V_2+\cdots\), normalization gives
\(PV_2+V_2^*P=-V_1^*V_1\).
The quadratic coefficient of (3.3) is therefore
\[
V_1^*(H_0-3)V_1-PSV_1-V_1^*SP
=-PSR_3SP .
\]
Together with (3.4),
\[
\boxed{\mathsf A_\xi=3I_P+\xi^2\mathsf K+O_L(\xi^4),\qquad
\mathsf K=-PSR_3SP.}
\tag{3.7}
\]
The remainder is in finite-matrix operator norm and follows from
convergent real-analytic Taylor expansion.

## 4. Every virtual channel, with complete orthogonality

For each external face \(p\),
\[
SW_p=W_p^2+\sum_{q\ne p}W_pW_q
=1+C_p+\sum_{q\ne p}W_pW_q,\qquad C_p=W_p^2-1 .
\tag{4.1}
\]
The repeated-face function \(C_p\) is the spin-1 character of the
face, with \(H_0C_p=8C_p\), Haar mean zero and squared norm 1.
Its norm follows from character orthogonality, or directly from
\(\int W_p^4=2\), \(\int W_p^2=1\).
Different repeated-face functions are orthogonal: an edge in one
face but not the other carries a nontrivial spin-1 matrix coefficient
with zero Haar integral.

For an edge-disjoint pair of distinct faces, \(W_pW_q\) has eight
fundamental edges, \(H_0\) eigenvalue 6, squared norm 1 and zero
mean. Sharing a vertex but no edge does not change these facts.

For an adjacent unordered pair with shared edge \(e\), invert and
cyclically rotate whole face traversals if needed, keeping their
unchanged \(SU(2)\) traces, to write
\[
W_p=\operatorname{tr}(U_eA),\qquad
W_q=\operatorname{tr}(U_e^{-1}B).
\]
The two outer three-edge paths \(A,B\) use six distinct physical
links. Fundamental Haar integration gives
\[
Z_{pq,0}=\int W_pW_q\,dU_e=\frac12\operatorname{tr}(AB),\qquad
Z_{pq,1}=W_pW_q-Z_{pq,0}.
\tag{4.2}
\]
The shared-edge channels are spins 0 and 1, while the six outer
edges are fundamental. Thus
\[
H_0Z_{pq,0}=\frac92Z_{pq,0},\qquad
H_0Z_{pq,1}=\frac{13}2Z_{pq,1}.
\tag{4.3}
\]
The projection integrating \(U_e\) is orthogonal. Independent Haar
integration of the outer paths gives
\[
\|Z_{pq,0}\|^2=\frac14,\qquad
\|W_pW_q\|^2=1,\qquad
\|Z_{pq,1}\|^2=\frac34,\qquad
\langle Z_{pq,0},Z_{pq,1}\rangle=0 .
\tag{4.4}
\]
These are the original normalizations; no channel is replaced by
the unhalved outer-loop trace.

All different unordered pair sectors are orthogonal. For any pair
of distinct faces, its odd-edge parity support is
\(\partial p\mathbin{\triangle}\partial q\), containing eight edges
for a disjoint pair and six for an adjacent pair. Each adjacent
channel has that same support: the shared edge is even, and the
six outer edges are odd. Distinct unordered pairs have distinct
parity supports. Otherwise their symmetric difference as face
chains would be a nonempty mod-2 2-cycle with at most four faces.
Choose a face in that cycle. Each of its four boundary edges
requires another face. Distinct elementary faces share at most
one edge, so four distinct additional faces would be needed,
at least five faces in total, a contradiction.

A central Haar transformation \(U_e\mapsto-U_e\) on an edge in
exactly one of two parity supports therefore kills their cross
inner product. It also makes every pair sector orthogonal to the
vacuum and all \(C_p\), which are even on every edge. The repeated-
face sectors are mutually orthogonal as proved above. These
arguments remain valid with \(R_3\) applied, since all listed
components are exact free eigenvectors. They exhaust (4.1).

The complete virtual data are consequently
\[
\begin{array}{c|c|c|c}
\text{sector}&H_0& H_0-3&\text{squared norm}\\ \hline
1&0&-3&1\\
C_p&8&5&1\\
W_pW_q\text{ edge-disjoint}&6&3&1\\
Z_{pq,0}\text{ adjacent}&9/2&3/2&1/4\\
Z_{pq,1}\text{ adjacent}&13/2&7/2&3/4
\end{array}
\tag{4.5}
\]
In particular the pair resolvent expectations are
\[
r_{\rm dis}=\frac13,\qquad
r_{\rm adj}=\frac{1/4}{3/2}+\frac{3/4}{7/2}
=\frac16+\frac3{14}=\frac8{21}.
\tag{4.6}
\]

For any \(v=\sum_pa_pW_p\), the first dressing (3.6) is explicitly
\[
\begin{split}
R_3Sv={}&-\frac13\sum_pa_p
+\frac15\sum_pa_pC_p\\
&+\frac13\sum_{\{p,q\}\ {\rm disjoint}}(a_p+a_q)W_pW_q\\
&+\sum_{\{p,q\}\ {\rm adjacent}}(a_p+a_q)
\left(\frac23Z_{pq,0}+\frac27Z_{pq,1}\right).
\end{split}
\tag{4.7}
\]
The negative vacuum component is essential. Since the actual ground
state begins \(1+\xi S/3+O_L(\xi^2)\), the order-\(\xi\) overlap
of \(V_\xi v\) with it is
\(-\sum_pa_p/3+\sum_pa_p/3=0\), as required.

## 5. The effective matrix and actual vacuum subtraction

Let two distinct faces be adjacent exactly when they share an edge.
Write \(\mathsf A_{\rm adj}\) for that zero-diagonal adjacency matrix,
\(r_e=\#\{p:e\in\partial p\}\), and
\[
d_p=\sum_{e\in\partial p}(r_e-1),\qquad
\mathsf D_{\rm adj}=\operatorname{diag}(d_p).
\tag{5.1}
\]
No other face is counted twice in \(d_p\), because distinct faces
share at most one edge.

For a diagonal matrix entry of \(\mathsf K\), (4.1)--(4.6) give
\[
\begin{split}
\mathsf K_{pp}
&=\frac13-\frac15-\frac{M-1-d_p}{3}
-\frac8{21}d_p\\
&=\frac7{15}-\frac M3-\frac{d_p}{21}.
\end{split}
\tag{5.2}
\]
The \(+1/3\) is the minus sign in (3.7) acting on the negative
vacuum denominator \(-3\). For distinct external faces \(p,q\),
the only shared virtual components in \(SW_p\) and \(SW_q\) are
the vacuum and the pair \(W_pW_q\). The orthogonality proof above
excludes every other mixed contribution. Thus
\[
\mathsf K_{pq}
=\frac13-r_{pq}
=\begin{cases}
0,&p,q\text{ not adjacent},\\
-1/21,&p,q\text{ adjacent}.
\end{cases}
\tag{5.3}
\]
Dropping vacuum mixing would incorrectly leave a nonlocal
off-diagonal \(-1/3\) for disjoint pairs.

The actual dimensionless ground energy is computed in the same full
Hilbert space. At first order its coefficient is zero since
\(\int S=0\). The first vacuum eigenvector coefficient is \(S/3\)
because \(H_0S=3S\). Integrating the next coefficient equation gives
\[
e_0(\xi)=-\frac13\langle S,S\rangle\xi^2+O_L(\xi^3)
=-\frac M3\xi^2+O_L(\xi^3).
\]
The central transformation \(\mathcal Z\) fixes the free vacuum
and conjugates \(\xi\) to \(-\xi\), so uniqueness makes this scalar
even. Hence
\[
\boxed{\mathcal E_0
=2bM-\kappa\frac M3\xi^2+O_L(\kappa\xi^4).}
\tag{5.4}
\]
The constant \(2bM\) remains in this absolute energy.

Subtracting this actual ground energy from the cluster (3.7),
the full effective excitation matrix is
\[
\boxed{
\mathsf F=\mathsf K+\frac M3I
=\frac7{15}I-\frac1{21}
(\mathsf D_{\rm adj}+\mathsf A_{\rm adj}).}
\tag{5.5}
\]
Thus the proposed signless-adjacency formula is correct with exactly
the stated face convention. It is not the ordinary graph Laplacian.

Let \(\nu_1\leq\cdots\leq\nu_M\) be the ordered eigenvalues of
\(\mathsf F\). Finite-dimensional min--max applied to the
operator-norm remainder in (3.7) yields all actual first-cluster
excitation energies, counted with multiplicity:
\[
\boxed{\mathcal E_j-\mathcal E_0
=3\kappa+\kappa\xi^2\nu_j+O_L(\kappa\xi^4),
\qquad 1\leq j\leq M.}
\tag{5.6}
\]
For fixed \(L\), the error is uniform over these finitely many
indices. This statement does not require unproved analyticity of
chosen eigenvectors through internal degeneracies.
The corresponding absolute energies are
\[
\mathcal E_j
=2bM+3\kappa
+\kappa\xi^2\left(\nu_j-\frac M3\right)
+O_L(\kappa\xi^4).
\tag{5.7}
\]
All original constants and the vacuum subtraction are visible.

## 6. Exact finite-box coefficient bounds

The face adjacency graph is connected. Coplanar edge-sharing steps
translate a face within its coordinate plane. To move a face one
step in its normal direction, use a hinged face joining an edge
of the original face to the corresponding edge at the next level;
the latter edge belongs to the translated parallel face. These
two adjacency steps are available whenever the target level is
inside the box. Hinged steps also connect the three face planes.
This connects every face to a fixed reference face.

Every edge belongs to at most four faces, so \(d_p\leq12\).
Interior faces attain 12, while boundary faces have smaller degree.
The nonnegative irreducible matrix
\(\mathsf Q=\mathsf D_{\rm adj}+\mathsf A_{\rm adj}\) consequently
has a simple largest eigenvalue \(q_{\max}\) and a strictly positive
eigenvector. Its row sums are \(2d_p\leq24\). They are not all 24.
The Perron eigenvalue is therefore strictly below 24: equality
would force every component adjacent to a maximum component of
its positive eigenvector to have that same maximum value, and
connectedness would then force all row sums to be 24.

The exact total degree can be counted by edge stars. For a
direction-\(i\) edge with transverse coordinates \(m,n\),
\[
r_e=a(m)+a(n),\qquad
a(t)=1\ \text{at }t=\pm L,\quad a(t)=2\ \text{otherwise}.
\]
Then
\(\sum a=4L\), \(\sum a^2=8L-2\), and
\(\sum(a^2-a)=4L-2\).
For each edge direction, summation over its \(2L\) initial longitudinal
coordinates and both transverse coordinates gives
\[
\sum_{e\text{ in that direction}}r_e(r_e-1)
=2L\bigl[2(2L+1)(4L-2)+2(4L)^2\bigr]
=96L^3-8L.
\]
Summing three directions,
\[
\boxed{\sum_pd_p=\sum_er_e(r_e-1)=288L^3-24L.}
\tag{6.1}
\]
The unit-vector Rayleigh quotient of \(\mathsf Q\) is
\[
\frac{2\sum_pd_p}{M}
=\frac{48L^2-4}{L(2L+1)}
\leq q_{\max}<24.
\tag{6.2}
\]
The least coefficient \(\nu_1=7/15-q_{\max}/21\) therefore satisfies
\[
\boxed{
0<\nu_1+\frac{71}{105}
\leq\frac{4(6L+1)}{21L(2L+1)}.}
\tag{6.3}
\]
In particular \(\nu_1\to-71/105\) as a finite-matrix coefficient
limit when \(L\to\infty\). This is not an interchange with the
fixed-box quantum expansion. The guaranteed disk (3.1) shrinks
with \(M\), and its remainder constants have not been made uniform.

Since \(q_{\max}\) is simple, \(\nu_1\) is simple. For every fixed
box, the gap from \(\nu_1\) to the next finite-matrix coefficient
is strictly positive. Equation (3.7), divided by \(\xi^2\), then
shows that the actual first excited eigenvalue is simple for
sufficiently small nonzero real \(\xi\), with a leading in-cluster
vector given by the positive Perron coefficient vector on the
literal basis \(W_p\). Its vacuum and two-face dressing is (4.7).
This simplicity is a local finite-box consequence, not an
all-coupling assertion.

## 7. Exact checks and scope

The accompanying check_first_excitation_band_independent.py verifies
every rational virtual denominator, the vacuum-energy subtraction,
the diagonal and off-diagonal matrix coefficients, complete face
incidence and degree sums, and the finite-box bound coefficients.
It also checks every unordered distinct face-pair parity support
in the \(L=2\) full box, including disjoint and adjacent pairs.
The proof of injectivity and the spectral/domain arguments are
given above; finite enumeration does not replace them.

No independent-link interacting vacuum, omitted face family, deleted
vacuum channel, or trial-state quotient substitutes for the actual
cluster. The second-order coefficient decreases the first excitation
energy from \(3\kappa\) in the stated finite strong-coupling regime.
It does not imply a vanishing finite energy or establish a
four-dimensional continuum limit.

## 8. Fully explicit finite-box fourth-order remainder

The preceding remainder can be made numerical without a
volume-uniform assumption. Put
\[
\boxed{r=\frac3{64M}.}
\tag{8.1}
\]
All resolvents and projections in this section act on the physical
Hilbert space. This qualifier is essential for the ground contour
used below: the unreduced free Hilbert space has an eigenvalue
exactly \(3/4\), whereas the physical next eigenvalue is 3.

For complex \(|\xi|\leq r\), on the cluster contour
\(|z-3|=3/4\), the free resolvent norm is at most \(4/3\), and
\[
\|\xi S(z-H_0)^{-1}\|
\leq r(2M)(4/3)=\frac18.
\]
Thus the Neumann series gives
\[
\|(z-K_\xi)^{-1}\|\leq\frac{4/3}{1-1/8}=\frac{32}{21}.
\]
The resolvent-difference contour bound gives
\[
\|P_\xi-P\|
\leq\frac{1/8}{1-1/8}=\frac17.
\tag{8.2}
\]
This uses contour radius times the free resolvent bound equal to 1.
On the finite space \(\operatorname{ran}P\), set
\(T_\xi=PP_\xi P\). Its holomorphic inverse square root is defined
by the convergent binomial series around the identity. Since
\(\|T_\xi-I_P\|\leq1/7\), its positive majorant gives
\[
\|T_\xi^{-1/2}\|^2\leq(1-1/7)^{-1}=\frac76.
\tag{8.3}
\]

The holomorphic extension of the real Hermitian effective matrix
(3.3) is
\[
\mathsf B_\xi
=T_\xi^{-1/2}P(K_\xi P_\xi)P T_\xi^{-1/2}.
\tag{8.4}
\]
For real \(\xi\), idempotence of \(P_\xi\), its commutation with
\(K_\xi\), and its orthogonality show that (8.4) equals
\(V_\xi^*K_\xi V_\xi=\mathsf A_\xi\).
For complex \(\xi\), (8.4) avoids introducing an antiholomorphic
adjoint and is the required analytic matrix for Cauchy's estimate.

Subtracting \(3I_P\) in (8.4) leaves
\(T_\xi^{-1/2}P((K_\xi-3)P_\xi)PT_\xi^{-1/2}\).
Contour functional calculus gives
\[
(K_\xi-3)P_\xi
=\frac1{2\pi i}\oint_{|z-3|=3/4}
(z-3)(z-K_\xi)^{-1}\,dz .
\]
Hence
\[
\|\mathsf B_\xi-3I_P\|
\leq\frac76\left(\frac34\right)^2\frac{32}{21}=1 .
\tag{8.5}
\]

For the ground energy, use the physical contour \(|z|=3/4\).
The free physical spectrum is zero and then at least 3, so its
resolvent bound is again \(4/3\); the same Neumann estimate applies.
Its analytic projection remains rank one throughout \(|\xi|\leq r\).
The enclosed eigenvalue \(e_0(\xi)\) is holomorphic and lies inside
this contour, so
\[
|e_0(\xi)|\leq\frac34.
\tag{8.6}
\]
For real \(\xi\), min--max identifies it with the actual ground
energy of \(K_\xi\). The central conjugation makes both
\(\mathsf B_\xi\) and \(e_0(\xi)\) even, also for complex \(\xi\).

Define
\(\mathsf C_\xi=\mathsf B_\xi-3I_P-e_0(\xi)I_P\).
It is even and holomorphic, with \(\mathsf C_0=0\),
quadratic coefficient \(\mathsf F\), and
\(\sup_{|\xi|\leq r}\|\mathsf C_\xi\|\leq7/4\).
Cauchy's coefficient estimate in this finite operator norm yields
\(\|\mathsf C_{2k}\|\leq(7/4)r^{-2k}\).
For real \(|\xi|\leq r/2\), summing every remaining even term gives
\[
\begin{split}
\|\mathsf C_\xi-\xi^2\mathsf F\|
&\leq\frac74\sum_{k\geq2}(|\xi|/r)^{2k}\\
&\leq\frac73r^{-4}\xi^4 .
\end{split}
\]
Finite-dimensional min--max therefore gives the fully explicit
error for every member of the actual first excitation band:
\[
\boxed{
\left|(\mathcal E_j-\mathcal E_0)
-3\kappa-\kappa\xi^2\nu_j\right|
\leq\kappa\frac73\left(\frac{64M}{3}\right)^4\xi^4,
\quad |\xi|\leq\frac3{128M},\quad 1\leq j\leq M.}
\tag{8.7}
\]
The bound is deliberately volume dependent. It neither asserts that
its radius covers fixed coupling at growing volume nor discards
the \(M^4\) remainder coefficient.

```

## Complete source: wilson_variation/check_first_excitation_face_graph.py

```python
"""Exact open-box face graph, separate periodic graph, and symbol checks.

The graph arithmetic is integral/rational. Symbol checks use exact SymPy
polynomials; no numerical eigenvalue is used to assert a spectral bound.
"""

from collections import Counter, deque
from fractions import Fraction as F
from itertools import combinations, product
import sympy as s


def shift(n, i, step=1, periods=None):
    out = list(n)
    out[i] += step
    if periods is not None:
        out[i] %= periods[i]
    return tuple(out)


def boundary(face, periods=None):
    n, i, j = face
    return frozenset(((n, i), (shift(n, i, periods=periods), j),
                      (shift(n, j, periods=periods), i), (n, j)))


def graph(faces, periods=None):
    stars = {}
    for p in faces:
        for edge in boundary(p, periods):
            stars.setdefault(edge, []).append(p)
    adj = {p: set() for p in faces}
    seen_pairs = set()
    for incident in stars.values():
        for p, q in combinations(incident, 2):
            key = frozenset((p, q))
            assert key not in seen_pairs  # no double-shared physical edges
            seen_pairs.add(key)
            adj[p].add(q)
            adj[q].add(p)
    return adj, seen_pairs


for L in range(2, 6):
    m = 2*L
    faces = [(n, i, j) for n in product(range(-L, L+1), repeat=3)
             for i, j in combinations(range(3), 2) if n[i] < L and n[j] < L]
    adj, pairs = graph(faces)
    assert len(faces) == 12*L*L*(2*L+1)
    assert len(pairs) == 144*L**3-12*L
    degrees = Counter(len(adj[p]) for p in faces)
    assert degrees == {
        12: 3*(m-1)*(m-2)**2, 11: 12*(m-1)*(m-2), 10: 12*(m-1),
        8: 6*(m-2)**2, 7: 24*(m-2), 6: 24,
    }
    for n, i, j in faces:
        k = 3-i-j
        beta = lambda x: int(x == -L or x == L-1)
        expected = (8 if n[k] in (-L, L) else 12)-beta(n[i])-beta(n[j])
        assert len(adj[n, i, j]) == expected
    seen = {faces[0]}
    queue = deque(seen)
    while queue:
        p = queue.popleft()
        for q in adj[p]:
            if q not in seen:
                seen.add(q)
                queue.append(q)
    assert len(seen) == len(faces)
    assert F(4*len(pairs), len(faces)) == F(48*L*L-4, L*(2*L+1))
    assert sum(12-len(adj[p]) for p in faces) == 12*m*(3*m+1)

    # An exact integer product test verifies the factorized interior trial
    # quadratic form on the ORIGINAL whole open graph.
    ell = m-2
    one_d = {r: r*(ell+1-r) for r in range(1, ell+1)}
    sq = sum(v*v for v in one_d.values())
    cross = sum(one_d[r]*one_d[r+1] for r in range(1, ell))
    trial = {}
    for p in faces:
        n = p[0]
        value = 1
        for x in n:
            value *= one_d.get(x+L, 0)
        trial[p] = value
        if value:
            assert len(adj[p]) == 12
    norm = sum(value*value for value in trial.values())
    qform = sum((trial[p]+trial[q])**2 for p, q in (tuple(pair) for pair in pairs))
    assert norm == 3*sq**3
    assert qform == 36*sq**3+12*cross*sq**2+6*sq*(sq+cross)**2

    # f_r=sin(r t)/sin(t)=U_(r-1)(c), c=cos(pi/(ell+1)).
    # Prove the needed recurrence identities modulo U_ell(c)=0 exactly.
    c = s.symbols("c")
    sequence = [s.chebyshevu(r-1, c) for r in range(1, ell+1)]
    ss = s.expand(sum(v*v for v in sequence))
    jj = s.expand(sum(sequence[r]*sequence[r+1] for r in range(ell-1)))
    modulus = s.chebyshevu(ell, c)
    assert s.rem(jj-c*ss, modulus, c) == 0
    exact_trial = 36*ss**3+12*jj*ss**2+6*ss*(ss+jj)**2
    assert s.rem(exact_trial-(14+8*c+2*c*c)*3*ss**3, modulus, c) == 0
    print(f"L={L}: {len(faces)} faces, {len(pairs)} adjacencies; "
          "all boundary degrees, connectivity, and interior trial identities passed.")

# Independently defined periodic graph, all periods >=3.
periods = (3, 4, 5)
periodic_faces = [(n, i, j) for n in product(*(range(q) for q in periods))
                  for i, j in combinations(range(3), 2)]
periodic_adj, periodic_pairs = graph(periodic_faces, periods)
assert all(len(neighbors) == 12 for neighbors in periodic_adj.values())
assert len(periodic_pairs) == 18*periods[0]*periods[1]*periods[2]
plane_types = ((0, 1), (0, 2), (1, 2))
for p in periodic_faces:
    n, i, j = p
    expected = set()
    for direction in (i, j):
        for sign in (-1, 1):
            expected.add((shift(n, direction, sign, periods), i, j))
    for k, l in plane_types:
        if (k, l) == (i, j):
            continue
        shared = ({i, j} & {k, l}).pop()
        transverse_p = ({i, j}-{shared}).pop()
        transverse_q = ({k, l}-{shared}).pop()
        for a, b in product((0, 1), repeat=2):
            base = shift(shift(n, transverse_p, a, periods), transverse_q, -b, periods)
            expected.add((base, k, l))
    assert expected == periodic_adj[p]

# Half-phase variables x_i=e^(ik_i/2) retain all offset phases exactly.
x1, x2, x3 = s.symbols("x1 x2 x3", nonzero=True)
x = (x1, x2, x3)
symbol = s.zeros(3)
for a, (i, j) in enumerate(plane_types):
    symbol[a, a] = 12+x[i]**2+x[i]**-2+x[j]**2+x[j]**-2
for a, b in combinations(range(3), 2):
    common = (set(plane_types[a]) & set(plane_types[b])).pop()
    p = (set(plane_types[a])-{common}).pop()
    q = (set(plane_types[b])-{common}).pop()
    symbol[a, b] = (1+x[p]**2)*(1+x[q]**-2)
    symbol[b, a] = (1+x[p]**-2)*(1+x[q]**2)
phase = s.diag(*(x[i]*x[j] for i, j in plane_types))
centered = phase.inv()*symbol*phase
for a, b in combinations(range(3), 2):
    common = (set(plane_types[a]) & set(plane_types[b])).pop()
    p = (set(plane_types[a])-{common}).pop()
    q = (set(plane_types[b])-{common}).pop()
    assert s.simplify(centered[a, b]-(x[p]+1/x[p])*(x[q]+1/x[q])) == 0
    assert s.simplify(centered[a, b]-centered[b, a]) == 0
zero_momentum = symbol.subs({x1: 1, x2: 1, x3: 1})
assert zero_momentum == 12*s.eye(3)+4*s.ones(3)
t = s.symbols("t")
assert s.factor(zero_momentum.charpoly(t).as_expr()) == (t-24)*(t-12)**2
assert F(7, 15)-F(24, 21) == -F(71, 105)
print("PASS: separately specified periodic multiplicities, complete Laurent symbol,")
print("centered-face phase dictionary, zero-mode eigenvalues, and -71/105 coefficient.")

```

## Complete source: wilson_variation/check_first_excitation_band_independent.py

```python
"""Exact rational channels and bounded full-box incidence for the true band."""
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations, product
from pathlib import Path
import json

vacuum = F(-1, 3)
repeated = F(1, 5)
disjoint = F(1, 3)
adjacent = F(1, 4)/F(3, 2) + F(3, 4)/F(7, 2)
assert adjacent == F(8, 21)
assert -vacuum-disjoint == 0
assert -vacuum-adjacent == -F(1, 21)
assert F(3, 4)*F(4, 3) == 1
assert F(3, 64)*2*F(4, 3) == F(1, 8)
assert F(4, 3)/(1-F(1, 8)) == F(32, 21)
assert F(1, 8)/(1-F(1, 8)) == F(1, 7)
assert 1/(1-F(1, 7)) == F(7, 6)
assert F(7, 6)*F(3, 4)**2*F(32, 21) == 1
assert (1+F(3, 4))/(1-F(1, 4)) == F(7, 3)


def shift(n, i):
    out = list(n)
    out[i] += 1
    return tuple(out)


rows = []
for L in (2, 3, 4, 5):
    vertices = list(product(range(-L, L+1), repeat=3))
    edges = [(n, i) for n in vertices for i in range(3) if n[i] < L]
    stars = {e: [] for e in edges}
    supports = []
    for n in vertices:
        for i, j in combinations(range(3), 2):
            if n[i] == L or n[j] == L:
                continue
            support = frozenset(((n, i), (shift(n, i), j),
                                 (shift(n, j), i), (n, j)))
            p = len(supports)
            supports.append(support)
            for e in support:
                stars[e].append(p)
    M = len(supports)
    assert M == 3*(2*L)**2*(2*L+1)
    assert len(edges) == 3*(2*L)*(2*L+1)**2
    neighbors = [set() for _ in range(M)]
    for incident in stars.values():
        for p, q in combinations(incident, 2):
            assert q not in neighbors[p]
            neighbors[p].add(q)
            neighbors[q].add(p)
    degrees = [len(x) for x in neighbors]
    assert max(degrees) == 12 and min(degrees) < 12
    assert sum(degrees) == 288*L**3-24*L
    assert sum(len(ps)*(len(ps)-1) for ps in stars.values()) == sum(degrees)
    for p, support in enumerate(supports):
        d = degrees[p]
        assert d == sum(len(stars[e])-1 for e in support)
        actual_cluster_diagonal = -vacuum-repeated-(M-1-d)*disjoint-d*adjacent
        excitation_diagonal = actual_cluster_diagonal+F(M, 3)
        assert actual_cluster_diagonal == F(7, 15)-F(M, 3)-F(d, 21)
        assert excitation_diagonal == F(7, 15)-F(d, 21)
    reached = {0}
    pending = [0]
    while pending:
        p = pending.pop()
        for q in neighbors[p]-reached:
            reached.add(q)
            pending.append(q)
    assert len(reached) == M
    lower_q = F(2*sum(degrees), M)
    assert lower_q == F(48*L*L-4, L*(2*L+1))
    assert F(24)-lower_q == F(4*(6*L+1), L*(2*L+1))
    assert F(7, 15)-F(24, 21) == -F(71, 105)

    parity_count = None
    if L == 2:
        seen = set()
        for p, q in combinations(range(M), 2):
            overlap = supports[p] & supports[q]
            assert len(overlap) in (0, 1)
            parity = supports[p] ^ supports[q]
            assert len(parity) == (6 if overlap else 8)
            assert parity not in seen
            seen.add(parity)
            coefficient = -vacuum-(adjacent if overlap else disjoint)
            assert coefficient == (-F(1, 21) if q in neighbors[p] else 0)
        parity_count = len(seen)
        assert parity_count == M*(M-1)//2
    rows.append({
        "L": L, "links": len(edges), "faces": M,
        "adjacent_pairs": sum(degrees)//2,
        "total_degree": sum(degrees),
        "min_degree": min(degrees), "max_degree": max(degrees),
        "connected": len(reached) == M,
        "all_distinct_pair_parity_supports_checked": parity_count,
        "signless_eigenvalue_lower_bound": str(lower_q),
    })

root = Path(__file__).resolve().parent
proof = root / "first_excitation_band_independent.md"
raw = proof.read_bytes()
receipt = {
    "status": "PASS",
    "proof": proof.name,
    "proof_bytes": len(raw),
    "proof_sha256": sha256(raw).hexdigest(),
    "virtual_resolvent_channels": {
        "vacuum": str(vacuum), "repeated_face": str(repeated),
        "disjoint_pair": str(disjoint), "adjacent_pair": str(adjacent)
    },
    "excitation_diagonal": "7/15 - d_p/21",
    "excitation_offdiagonal": "-1/21 if adjacent, zero otherwise",
    "finite_volume_degree_sum": "288 L^3 - 24 L",
    "coefficient_limit": "-71/105",
    "explicit_even_remainder": "(7/3) (64 M/3)^4 kappa xi^4 for |xi| <= 3/(128 M)",
    "boxes": rows,
    "scope": "Exact finite rational/incidence checks, not an interacting-vacuum simulation or continuum limit."
}
(root / "FIRST_EXCITATION_BAND_INDEPENDENT_CHECKS.json").write_text(
    json.dumps(receipt, indent=2)+"\n", encoding="utf-8")
print(json.dumps(receipt, indent=2))

```

## Complete source: native_center_disorder_bridge.md

```markdown
# The exact center-disorder endpoint of the native magnetic translation

8 September 2026. This note calculates the relation between the continuous
native magnetic translation, discrete center transformations, Wilson loops,
and actual quantum spectral moments. It uses the full original open SU(2)
Wilson box. In particular a discrete transformation is not identified with
a nonzero excitation merely because it is not the identity on link variables.
Its action on the actual vacuum and its energy are calculated explicitly.

## 1. Original operator and all center cochains

Fix the open cubical complex with vertices \(\{-L,\ldots,L\}^3\),
\(L\geq2\), positive physical links \(\mathsf E_L\), and all elementary
faces \(\mathsf P_L\). Reverse traversal uses the inverse of the same link.
For \(p=(n;i,j)\), \(i<j\), set
\[
 W_p=\operatorname{tr}\{U_i(n)U_j(n+\mathbf e_i)
                  U_i(n+\mathbf e_j)^{-1}U_j(n)^{-1}\}.
\]
Work in product Haar probability \(L^2(SU(2)^{\mathsf E_L},dU)\), with
\(T_a=-i\sigma_a/2\), left derivatives \(X_{e,a}\), and
\(E_e=-\sum_aX_{e,a}^2\). Retain
\[
 H=\kappa\sum_eE_e+b\sum_p(2-W_p),\qquad
 \kappa=\frac{2g^2}{a},\quad b=\frac1{2g^2a},\quad
 \xi=\frac b\kappa=\frac1{4g^4},\quad a,g>0.
\tag{1}
\]
Its domain is the product Sobolev space \(H^2\), its form domain is
\(H^1\), and its potential is bounded and smooth. The positive unit vacuum
\(\psi\) exists and is unique: modulus decreases form energy, elliptic
regularity and the maximum principle give strict positivity, and the
identity
\[
 q_{H-\mathcal E}(\psi F)=\kappa\sum_{e,a}\int\psi^2|X_{e,a}F|^2dU
\tag{2}
\]
proves uniqueness by dividing another bottom eigenvector by \(\psi\).
The gauge action \(U_e\mapsto g_{s(e)}U_eg_{t(e)}^{-1}\) preserves the
operator and hence fixes \(\psi\). Put \(A=H-\mathcal E\).

Let \(z=(z_e)\), \(z_e\in\{+1,-1\}\), be any real center one-cochain
on the original physical edges; assign the same sign to the reverse edge,
which is its inverse in this group. Define
\[
 (D_zF)(U)=F((z_eU_e)_e),\qquad
 (\delta z)_p=\prod_{e\in\partial p}z_e,
 \quad\mathcal T_z=\{p:(\delta z)_p=-1\},
 \quad S_z=\sum_{p\in\mathcal T_z}W_p.
\tag{3}
\]
Here \(z_eU_e\) means multiplication by \(z_e I_2\). Haar invariance
gives \(D_z^*=D_z=D_z^{-1}\). These diffeomorphisms preserve all integer
Sobolev domains, commute with all link Casimirs, and commute with every
vertex gauge transformation because \(z_eI_2\) is central. They obey
\(D_zD_w=D_{zw}\).

Each face word gains exactly its four central factors, so, as operator
identities on \(H^2\),
\[
 D_zW_pD_z=(\delta z)_pW_p,\qquad
 \boxed{D_zHD_z=H+2bS_z.}
\tag{4}
\]
All faces outside \(\mathcal T_z\) remain present in both Hamiltonians.
The scalar \(2b|\mathsf P_L|\) is identical on both sides and has not
been suppressed. Equation (4) is a unitary relation to an explicitly
sign-twisted potential, not permission to erase that potential change.

## 2. Exact native magnetic endpoint and its Wilson algebra

The native smooth field in the retained cusp coordinates has link transports
\[
 h_1(n)=\exp(-\theta n_2H_c),\qquad h_2=h_3=I,
 \qquad H_c=i\sigma_3=-2T_3,\qquad
 \theta=\frac{2\pi a^2}{D_T},\quad
 D_T=L_Tq_T+6m_T^2>0.
\tag{5}
\]
Its translation is \((T_\theta F)(U)=F((h_e^{-1}U_e)_e)\), and
its physical translated state is obtained by vertex Haar projection
\(\Pi\). At the specified parameter value \(\theta=\pi\),
\[
 h_1(n)=(-1)^{n_2}I,
 \quad z^{\rm nat}_{(n,1)}=(-1)^{n_2},
 \quad z^{\rm nat}_{(n,2)}=z^{\rm nat}_{(n,3)}=1,
 \quad T_\pi=D_{z^{\rm nat}}.
\tag{6}
\]
Thus \(\Pi T_\pi\psi=T_\pi\psi\) exactly. Its face coboundary is
\[
 (\delta z^{\rm nat})_{12}=-1,\qquad
 (\delta z^{\rm nat})_{13}=(\delta z^{\rm nat})_{23}=1.
\tag{7}
\]
The two direction-1 signs on a 12 face are \((-1)^{n_2}\) and
\((-1)^{n_2+1}\), whereas they agree on a 13 face. There are
\((2L)^2(2L+1)\) twisted 12 faces, not all M faces. At \(\theta=2\pi\)
every h is the identity. Equations (5)--(7) keep both the continuous path
and its discrete endpoints. The endpoint \(\theta=\pi\) means precisely
\(D_T=2a^2\); it is not an assertion that the small-angle cusp exhaustion
reaches that endpoint with its original spacing and determinant.

For any closed oriented edge word C, allowing repeated traversals, let
\(W_C\) be the fundamental trace of its ordered holonomy and put
\(z(C)=\prod_{e\text{ traversed in }C}z_e\), with multiplicities.
Centrality and inversion give
\[
 \boxed{D_zW_C=z(C)W_CD_z.}
\tag{8}
\]
If a mod-two face chain \(\Sigma\) has boundary C modulo two, every
internal edge occurs twice, so
\[
 z(C)=\prod_{p\in\Sigma}(\delta z)_p
     =(-1)^{|\Sigma\cap\mathcal T_z|}.
\tag{9}
\]
This proves the discrete Wilson--disorder commutation pairing, including
its multiplicities and sign, directly in the original Hilbert space.
For (6), a rectangular 12 loop of integer side lengths r,s has
\(z^{\rm nat}(C)=(-1)^{rs}\). Its sign does not involve a rescaled area:
the physical area is \(a^2rs\), and (5) at \(\theta=\pi\) gives the
same phase \(\exp(\pi rsH_c)=(-1)^{rs}I\).

## 3. Vacuum overlap, both spectral moments, and the exact zero branch

For every center cochain set
\[
 c_z=\langle\psi,D_z\psi\rangle,\qquad
 \chi_z=D_z\psi-c_z\psi,\qquad d_z=\|\chi_z\|^2=1-c_z^2.
\tag{10}
\]
Strict positivity of \(\psi\) implies \(0<c_z\leq1\). All vectors in
(10) are smooth and gauge invariant, and \(\chi_z\perp\psi\).
Using (4), without replacing the vacuum, gives
\[
 \boxed{q_A(\chi_z)=2b\langle S_z\rangle_\psi,\qquad
        A\chi_z=-2bS_zD_z\psi,\qquad
        \|A\chi_z\|^2=4b^2\langle S_z^2\rangle_\psi.}
\tag{11}
\]
The first formula follows from
\(\langle D_z\psi,HD_z\psi\rangle-mathcal E
=\langle\psi,(D_zHD_z-H)\psi\rangle\); centering has no effect on
the form since \(A\psi=0\). For the second,
\(H D_z\psi-D_zH\psi=(H-D_zHD_z)D_z\psi=-2bS_zD_z\psi\).
Finally \(D_zS_zD_z=-S_z\), hence \(D_zS_z^2D_z=S_z^2\), proving
the last formula after Haar substitution.

If \(\mathcal T_z\) is empty, (4) commutes with H and uniqueness and
positivity of its unit vacuum imply \(D_z\psi=\psi\). Hence
\(c_z=1\) and \(\chi_z=0\) exactly. Conversely, if \(\chi_z=0\),
the norm and positive overlap force \(D_z\psi=\psi\). Apply (4) to
this vector and its original eigen-equation to get \(S_z\psi=0\).
Strict positivity makes \(S_z=0\) pointwise. Distinct elementary
\(W_p\)'s are orthonormal under product Haar measure: integrate a link
in only one boundary, and use \(\int(\operatorname{tr}U)^2dU=1\)
when the faces agree. Therefore
\(\|S_z\|_{L^2(dU)}^2=|\mathcal T_z|\), and the latter must be zero.
We have proved
\[
 \boxed{\chi_z=0\quad\Longleftrightarrow\quad\mathcal T_z=\varnothing.}
\tag{12}
\]
This also proves \(\langle S_z\rangle_\psi>0\) when
\(\mathcal T_z\ne\varnothing\): (11) is the strictly positive form of
a nonzero physical vacuum-orthogonal vector of a compact-resolvent
Hamiltonian with a unique bottom.

For a nonempty twist the full physical spectral probability is
\(\nu_z(B)=d_z^{-1}\langle\chi_z,\mathbf1_B(A)\chi_z\rangle\).
It has no zero atom, and (11) gives its exact moments
\[
 \boxed{\int\omega\,d\nu_z=
   \frac{2b\langle S_z\rangle_\psi}{1-c_z^2},\qquad
 \int\omega^2\,d\nu_z=
   \frac{4b^2\langle S_z^2\rangle_\psi}{1-c_z^2}.}
\tag{13}
\]
The second moment retains every mixed \(\langle W_pW_q\rangle_\psi\)
between twisted faces. No independence is assumed. The denominator is the
exact overlap loss, not an assumed unit excitation norm.

## 4. Small-coupling coefficient in the same vacuum

At each fixed box, the actual analytic positive vacuum of
\(H=\kappa(H_0-\xi\sum_pW_p)+2bM\) has
\[
 \psi_\xi=1+\frac\xi3\sum_pW_p+O_{H^2,L}(\xi^2).
\tag{14}
\]
One proof is to integrate the resolvent on \(|z|=3/8\) in the full
Hilbert space: the first free eigenvalue is \(3/4\),
\(\|\sum W_p\|=2M\), and a Neumann series converges for
\(|\xi|<3/(16M)\). Differentiating the eigen-equation gives (14),
because \(H_0W_p=3W_p\). Thus
\[
 (D_z-I)\psi_\xi=-\frac{2\xi}{3}S_z+O_{H^2,L,z}(\xi^2).
\]
For an involution and a real unit vector,
\(1-c_z=\tfrac12\|(D_z-I)\psi_\xi\|^2\). Consequently
\[
 \begin{split}
 1-c_z&=\frac{2|\mathcal T_z|}{9}\xi^2+O_L(\xi^4),\\
 d_z&=\frac{4|\mathcal T_z|}{9}\xi^2+O_L(\xi^4),\\
 q_A(\chi_z)&=\frac{4|\mathcal T_z|}{3}\kappa\xi^2
                         +O_L(\kappa\xi^4),\\
 \|A\chi_z\|^2&=4|\mathcal T_z|\kappa^2\xi^2
                         +O_L(\kappa^2\xi^4).
 \end{split}
\tag{15}
\]
To verify the even remainders, use the independent central cochain
\(\widetilde z_i(n)=(-1)^{\sum_{j<i}n_j}\), which changes every
elementary face sign. Its involution Z conjugates
\(H_0-\xi\sum W_p\) to \(H_0+\xi\sum W_p\), commutes with
\(D_z\), and sends \(S_z\) to \(-S_z\). Uniqueness gives
\(\psi_{-\xi}=Z\psi_\xi\). Thus c_z and
\(\langle S_z^2\rangle\) are even, whereas
\(\langle S_z\rangle\) is odd. Its first derivative from (14) is
\(2|\mathcal T_z|/3\), and its value at zero is zero. These facts
give precisely all errors in (15).

For a nonempty fixed twist, division of the displayed quantities proves
the leading first moment \(3\kappa+O_L(\kappa\xi^2)\) and second
moment \(9\kappa^2+O_L(\kappa^2\xi^2)\). Equivalently the spectral
probability in the energy variable \(\omega/\kappa\) tends to
\(\delta_3\) as \(\xi\to0\): its integral of \((\omega/\kappa-3)^2\)
tends to zero by these moments, and the resulting Chebyshev bound proves
weak convergence. This is a fixed-box limit. It supplies the complete
quantum dictionary for (6), not a large-volume gap assertion.

## 5. The original integer line flux and its adjoint center class

There is a second exact relation, now for the original smooth bundle rather
than the finite-link endpoint. On the marked two-torus let the original
Hermitian line bundle have transition phases \(e^{i\phi_{ab}}\), with
\(\phi_{ab}+\phi_{bc}+\phi_{ca}=2\pi n_{abc}\) on triple overlaps.
The canonical cusp connection on this line has integer curvature period
\((2\pi)^{-1}\int f=1\). Its embedded rank-two SU(2) bundle is
\(L\oplus L^{-1}\), with explicit transition matrices
\[
 g_{ab}=\operatorname{diag}(e^{i\phi_{ab}},e^{-i\phi_{ab}})
        =\exp(\phi_{ab}H_c),\qquad g_{ab}g_{bc}g_{ca}=I.
\tag{16}
\]
The product identity follows from the integer \(n_{abc}\); determinant
one is also exact. Under the adjoint representation,
\([!H_c,T_1!]=-2T_2\), \([!H_c,T_2!]=2T_1\), and H_c fixes
T_3. Hence
\[
 \begin{split}
 \operatorname{Ad}_{e^{\phi H_c}}T_1
   &=\cos(2\phi)T_1-\sin(2\phi)T_2,\\
 \operatorname{Ad}_{e^{\phi H_c}}T_2
   &=\sin(2\phi)T_1+\cos(2\phi)T_2.
 \end{split}
\tag{17}
\]
In the oriented real plane with complex coordinate \(v_1+iv_2\), this
is multiplication by \(e^{-2i\phi}\). Its winding/Chern number is
therefore \(-2c_1(L)\). More directly, the obstruction cocycle to lifting
the adjoint SO(3) transitions to SU(2) is identically \(+I\), because
(16) is already such a lift. Its \(\mathbb Z/2\) obstruction class is
zero. This proves the exact integer-to-center map for this particular
embedding, including the factor 2 and its orientation sign; it does not
erase the nonzero original integer curvature period.

The associated holonomy identities are
\(\exp(2\pi H_c)=I\) and \(\exp(\pi H_c)=-I\). Replacing (16)
by a half-angle lift would change its triple-overlap product to
\((-1)^{n_{abc}}I\), precisely the center obstruction. Such a change
is not the original line bundle with its original transition matrices.
The continuous field, its integer line data, the adjoint center class,
and the finite center-disorder endpoint are therefore related by the
explicit maps (5)--(9), (16)--(17), rather than by an assumed equality
of their flux labels.

## 6. Primary context and what the calculation establishes

Wilson--disorder pairing and center flux are established gauge-theory
constructions. A primary reference is G. 't Hooft, *On the phase transition
towards permanent quark confinement*, Nuclear Physics B **138** (1978),
1--25, DOI <https://doi.org/10.1016/0550-3213(78)90153-0>. The actual
compact-link operator and its pairing needed here are proved in (3)--(9).
For the SU(2) global-charge conventions, D. Tong, *Gauge Theory*, Sections
2.6.1--2.6.2, <https://www.damtp.cam.ac.uk/user/tong/gaugetheory.html>,
discusses the factor between adjoint and fundamental charge quantization;
(16)--(17) give it directly in the original H_c convention.

P. de Forcrand and L. von Smekal, *'t Hooft Loops, Electric Flux Sectors
and Confinement in SU(2) Yang--Mills Theory*, Physical Review D **66**
(2002), 011504, <https://doi.org/10.1103/PhysRevD.66.011504>,
<https://arxiv.org/abs/hep-lat/0107018v2>, study flux-sector free energies
at finite temperature. Their finite-temperature free energy is not
substituted for the vacuum excitation moment (13). The operator relation
and both moments used here were calculated directly in the full H.

The center endpoint gives a nonzero actual quantum state precisely for a
nonempty coboundary twist. A cocycle that commutes with H fixes its unique
finite-box vacuum and produces the zero centered vector. Nonempty twists
give the exact overlap-dependent moments (13), including every correlation.
These statements neither assume nor prove a continuum mass gap. They
identify the spectral quantities that the original magnetic path actually
reaches at its discrete endpoint, while retaining the smooth integer-flux
bundle and its explicit adjoint relation.

```

## Complete source: check_center_disorder_bridge.py

```python
"""Exact center-cochain, native endpoint, and Pauli-action diagnostics."""
from itertools import combinations, product
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import json
import sympy as s


def shift(n, i):
    out=list(n)
    out[i]+=1
    return tuple(out)


rows=[]
for L in (2,3,4):
    vertices=list(product(range(-L,L+1),repeat=3))
    edges=[(n,i) for n in vertices for i in range(3) if n[i]<L]
    native={e:(-1)**(e[0][1]%2) if e[1]==0 else 1 for e in edges}
    allface={e:(-1)**(sum(e[0][:e[1]])%2) for e in edges}
    faces=[]
    for n in vertices:
        for i,j in combinations(range(3),2):
            if n[i]>=L or n[j]>=L:
                continue
            boundary=((n,i),(shift(n,i),j),(shift(n,j),i),(n,j))
            faces.append((n,i,j,boundary))
            value=1
            parity=1
            for edge in boundary:
                value*=native[edge]
                parity*=allface[edge]
            assert value==(-1 if (i,j)==(0,1) else 1)
            assert parity==-1
    twisted=sum(1 for n,i,j,b in faces if (i,j)==(0,1))
    assert twisted==(2*L)**2*(2*L+1)
    # Test every 12 rectangle at a fixed retained third coordinate.
    rectangle_count=0
    for x0 in range(-L,L):
        for x1 in range(x0+1,L+1):
            for y0 in range(-L,L):
                for y1 in range(y0+1,L+1):
                    boundary=[((x,y0,0),0) for x in range(x0,x1)]
                    boundary += [((x1,y,0),1) for y in range(y0,y1)]
                    boundary += [((x,y1,0),0) for x in range(x0,x1)]
                    boundary += [((x0,y,0),1) for y in range(y0,y1)]
                    value=1
                    for edge in boundary:
                        value*=native[edge]
                    assert value==(-1)**(((x1-x0)*(y1-y0))%2)
                    rectangle_count+=1
    rows.append(dict(L=L,links=len(edges),faces=len(faces),
                     native_twisted_faces=twisted,rectangles=rectangle_count))

I=s.I
sigma=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-I],[I,0]]),s.diag(1,-1)]
T=[-I*x/2 for x in sigma]
Hc=I*sigma[2]
assert Hc==-2*T[2]
assert Hc*T[0]-T[0]*Hc==-2*T[1]
assert Hc*T[1]-T[1]*Hc==2*T[0]
assert (s.pi*Hc).exp()==-s.eye(2)
assert (2*s.pi*Hc).exp()==s.eye(2)
z=s.symbols('z',nonzero=True)
g=s.diag(z,1/z)
cos2=(z**2+z**-2)/2
sin2=(z**2-z**-2)/(2*I)
assert s.simplify(g*T[0]*g.inv()-(cos2*T[0]-sin2*T[1]))==s.zeros(2)
assert s.simplify(g*T[1]*g.inv()-(sin2*T[0]+cos2*T[1]))==s.zeros(2)
assert F(4,3)/F(4,9)==3
assert F(4)/F(4,9)==9
assert 2*F(2,9)==F(4,9)

base=Path(__file__).resolve().parent
source=base/'native_center_disorder_bridge.md'
raw=source.read_bytes()
receipt=dict(status='PASS',source=source.name,source_bytes=len(raw),
             source_sha256=sha256(raw).hexdigest(),boxes=rows,
             checks='Exact integer cochains, rectangle pairing, Pauli rotations, center endpoints, and leading moment ratios.',
             scope='Diagnostics for explicit algebra; the all-coupling operator and vacuum statements are proved in the complete source.')
(base/'CENTER_DISORDER_CHECKS.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
print(json.dumps(receipt,indent=2))

```

## Complete source: first_separated_electric_covariance.md

```markdown
# The first separated-link connected electric covariance

8 September 2026. Two links which share no elementary face nevertheless
develop a nonzero connected electric covariance through two adjacent faces.
This note calculates that coefficient in the actual full-box vacuum. The
calculation keeps both intermediate spin channels and the disconnected
expectation subtraction. It does not assume a volume-uniform remainder.

## 1. Original Hilbert space and the coefficient to be calculated

Fix \(L\geq2\), vertices \(\{-L,\ldots,L\}^3\), all positive contained
links e, and all contained elementary faces p. Write their complete counts
as \(N=3(2L)(2L+1)^2\) and \(M=3(2L)^2(2L+1)\). Link variables are
\(U_e\in SU(2)\), with the inverse on reverse traversal. The face trace is
\[
 W_{(n;i,j)}=\operatorname{tr}\{U_i(n)U_j(n+\mathbf e_i)
           U_i(n+\mathbf e_j)^{-1}U_j(n)^{-1}\},\qquad i<j.
\]
On product Haar probability space use \(T_a=-i\sigma_a/2\), left
derivatives \(X_{e,a}\), \(E_e=-\sum_aX_{e,a}^2\), and
\[
 H=\kappa\sum_eE_e+b\sum_p(2-W_p),\quad
 \kappa=2g^2/a,\quad b=1/(2g^2a),\quad\xi=b/\kappa=1/(4g^4).
\tag{1}
\]
The fundamental Casimir is \(3/4\). In the original metric
\(-\operatorname{tr}(AB)/2\), the Laplacian is four times the sum-of-squares
Laplacian in these generators, so the electric coefficient in that metric
is \(\kappa/4\). Neither this factor nor the Wilson scalar \(2bM\)
is changed.

The compact connected configuration manifold and bounded smooth potential
give a self-adjoint compact-resolvent operator of domain \(H^2\), form
domain \(H^1\), and unique smooth positive unit ground vector \(\psi_\xi\).
For precision, the modulus inequality supplies a nonnegative form minimizer,
elliptic regularity and the maximum principle make it positive, and the
identity
\(q_{H-\mathcal E}(\psi f)=\kappa\sum_{e,a}\int\psi^2|X_{e,a}f|^2\)
implies uniqueness by division by \(\psi\). Gauge transformations preserve
this vector and every link Casimir. All following vectors are thus physical.

Set \(r_e=\#\{p:e\in\partial p\}\),
\(\gamma_e=\langle\psi,E_e\psi\rangle\),
\(v_e=(E_e-\gamma_e)\psi\), and
\[
 C_{ef}=\langle v_e,v_f\rangle
   =\langle\psi,E_eE_f\psi\rangle-\gamma_e\gamma_f.
\tag{2}
\]
The operators commute for different links. Smoothness makes (2) legitimate
as an operator identity on the vacuum, not only a formal product of forms.

For distinct e,f that share no face, define the integer
\[
 a_{ef}=\#\{(p,q): e\in\partial p,\ f\in\partial q,
                     |\partial p\cap\partial q|=1\}.
\tag{3}
\]
The pair in (3) is ordered by which face contains e and which contains f;
there is no double counting because no face contains both links. All faces
are those of the original open box. The result is
\[
 \boxed{C_{ef}=\frac{127}{219024}\,a_{ef}\xi^4+O_L(\xi^6)
        \quad(e,f\text{ share no face}).}
\tag{4}
\]
In particular the coefficient is positive whenever a two-face channel
exists, even though the energy matrix between these links is exactly zero.
The latter assertion is proved in Section 4.

## 2. The full second vacuum coefficient, including both shared-link channels

Put \(H_0=\sum E_e\) and \(S=\sum W_p\), so
\(H=\kappa(H_0-\xi S)+2bM\). On \(|z|=3/8\) in the full Hilbert
space the resolvent of H_0 has norm at most \(8/3\), since its first
nonzero eigenvalue is \(3/4\). Also \(\|S\|=2M\). Therefore the
bounded perturbation Neumann series converges for
\(|\xi|<3/(16M)\), gives the analytic rank-one bottom projection, and
gives an analytic positive unit eigenvector for real \(\xi\) near zero.
Elliptic regularity applied repeatedly to the eigen-equation upgrades this
to analyticity in each fixed Sobolev space. Its radius and estimates may
depend on L. This suffices for the finite derivative calculations below.

Product Haar integration gives \(\int W_p=0\),
\(\langle W_p,W_q\rangle=\delta_{pq}\), and \(H_0W_p=3W_p\).
Indeed a link in only one of two distinct face boundaries has odd central
parity; for the same face integrate its Haar holonomy and use the fundamental
character squared norm one. Comparing coefficients in the actual equation
\((H_0-\xi S)\psi=e(\xi)\psi\), including its unit-vector condition,
gives
\[
 \psi=1+\xi A_1+\xi^2A_2+O_{H^k,L}(\xi^3),\quad A_1=S/3,
 \quad e(\xi)=-M\xi^2/3+O_L(\xi^3),
\]
\[
 H_0A_2=(S^2-M)/3,\qquad\int A_2=-M/18.
\tag{5}
\]
The inverse in (5) can be resolved entirely. For adjacent distinct faces
p,q sharing g put
\[
 Z_{pq,0}=\int W_pW_q\,dU_g,\qquad
 Z_{pq,1}=W_pW_q-Z_{pq,0}.
\]
After reversing one real trace if needed, their words are
\(\operatorname{tr}(U_gB)\), \(\operatorname{tr}(U_g^{-1}D)\), with
six distinct outer links. The fundamental Haar identity gives
\(Z_{pq,0}=\operatorname{tr}(BD)/2\). The shared-edge spin tensor
\(1/2\otimes1/2\) consists of spins zero and one, while all outer
links have spin \(1/2\). Thus
\[
 H_0Z_{pq,0}=\tfrac92 Z_{pq,0},\quad
 H_0Z_{pq,1}=\tfrac{13}2Z_{pq,1},\quad
 \|Z_{pq,0}\|^2=\tfrac14,\quad\|Z_{pq,1}\|^2=\tfrac34.
\tag{6}
\]
The norms use orthogonal Haar projection on g and total product norm one.
A repeated face has \(W_p^2-1=\chi_1(U_p)\) with free energy8 and norm
one. An edge-disjoint pair has energy6 and norm one, even when the faces
meet at a vertex. Consequently the full coefficient is
\[
 \boxed{A_2=-\frac M{18}+\sum_p\frac{W_p^2-1}{24}
 +\sum_{\{p,q\}\ {\rm edge\!\!-\!\!disjoint}}\frac{W_pW_q}{9}
 +\sum_{\{p,q\}\ {\rm adjacent}}
       \left(\frac4{27}Z_{pq,0}+\frac4{39}Z_{pq,1}\right).}
\tag{7}
\]
All distinct-pair sums in (7) are unordered; the factor two in S² has
already been included. No finite-face subsystem is substituted for H.

Different unordered pairs in (7) have different odd-link parity supports.
If their symmetric boundaries agreed, their symmetric face difference would
be a nonempty closed mod-two collection of at most four squares. A face
in that collection needs another face on each of its four boundary edges;
two distinct elementary squares share at most one edge, so at least four
other squares would be needed, a contradiction. Haar integration on a
link where parity differs makes the cross term zero. Repeated-face terms
are even everywhere, and different repeated-face terms have different
joint link spins. Thus all the displayed components, with their two spin
channels, are mutually orthogonal. This remains true after application of
any link Casimir, which preserves those parity and spin subspaces.

## 3. Exact connected fourth coefficient

Suppose e,f share no face. Then \(E_eE_f1=E_eE_fA_1=0\): each
term in A_1 is a single face and depends on at most one of these links.
Self-adjointness moves \(E_eE_f\) to either of these vectors, so every
term of degree less than four in \(\langle\psi,E_eE_f\psi\rangle\)
vanishes, and its degree-four term is exactly
\[
 \langle A_2,E_eE_fA_2\rangle.
\tag{8}
\]
In particular no third or fourth unknown coefficient of the vacuum is
being omitted from (8): its possible pairing with 1 or A_1 is identically
zero for the stated reason. Similarly
\[
 \gamma_e=\xi^2\langle A_1,E_eA_1\rangle+O_L(\xi^3)
          =\frac{r_e}{12}\xi^2+O_L(\xi^3).
\tag{9}
\]

Only a pair p,q with \(e\in p\), \(f\in q\) contributes to (8).
Repeated faces contribute zero. There are exactly \(r_er_f\) such
distinct unordered pairs when they are labeled as in (3). For an
edge-disjoint pair, both e and f carry fundamental spin, so its contribution
is \((3/4)^2/9^2=1/144\). For an adjacent pair, neither e nor f can
be its shared edge: otherwise the face containing the other link would
contain both e and f. They are therefore both outer fundamental edges in
each of the two channels (6), and the contribution is
\[
 \left(\frac34\right)^2
 \left[\left(\frac4{27}\right)^2\frac14
       +\left(\frac4{39}\right)^2\frac34\right]
       =\frac1{324}+\frac3{676}.
\tag{10}
\]
Equation (9) subtracts \(r_er_f/144\) at degree four in (2). Hence every
edge-disjoint pair cancels its disconnected contribution exactly; every
adjacent pair leaves
\[
 \frac1{324}+\frac3{676}-\frac1{144}
          =\frac{127}{219024}>0.
\tag{11}
\]
This proves the coefficient in (4).

For its stated even error, the center transformation
\(U_{(n,i)}\mapsto(-1)^{\sum_{j<i}n_j}U_{(n,i)}\) changes every face
trace sign, commutes with every E_e and preserves Haar measure. It
intertwines H_0−ξS with H_0+ξS and hence the positive unit vacua at
ξ and−ξ. Both terms in (2) are consequently even analytic functions of
ξ near zero. Their next possible order after four is six. This proves
the error in (4); it does not supply a volume-uniform analytic radius.

## 4. Exact support map and relation to the energy matrix

Define the edge adjacency matrix \(B\) by \(B_{eg}=1\) when e,g are
distinct physical links belonging to a common elementary face, and zero
otherwise. Two distinct links belong to at most one elementary square:
perpendicular incident links determine its two plane directions and base,
while parallel links in a square must be opposite sides and also determine
that square. Thus, for the e,f considered above,
\[
 \boxed{a_{ef}=(B^2)_{ef}.}
\tag{12}
\]
Indeed a pair p,q counted in (3) has a unique shared edge g, which is a
common neighbor of e,f. Conversely a common neighbor g determines the
unique p containing e,g and q containing g,f; these are distinct because
e,f share no face, and their unique shared edge is g. These two maps are
inverse. The covariance coefficient thus has support at graph distance
two, including boundary incidences, and no support beyond distance two
at this order. It makes no all-orders finite-range claim about C.

There are actual such channels in every L≥2. Take
\(e=((0,0,0),1)\) and \(f=((0,2,0),1)\). They share no face, but
the 12 faces based at \((0,0,0)\) and \((0,1,0)\) share the edge
\(((0,1,0),1)\), giving \(a_{ef}\geq1\). All of their vertices
are in the original box, including at L=2.

Put \(\mathcal N_{ef}=\langle v_e,(H-\mathcal E)v_f\rangle\).
Commuting the link operators on the smooth real vacuum gives
\[
 \mathcal N_{ef}=\tfrac12
 \langle\psi,[E_e,[H,E_f]]\psi\rangle.
\tag{13}
\]
To check (13), expand the double commutator, use \(H\psi=\mathcal E\psi\),
commute E_e,E_f, and use the real symmetry of their two matrix elements.
Only potential faces containing f occur in \([H,E_f]\). If e shares
no face with f, E_e commutes with every one of their multiplication and
derivative terms. Thus
\[
 \boxed{\mathcal N_{ef}=0\text{ exactly, at every positive coupling,
 when e,f share no face}.}
\tag{14}
\]
There is no contradiction between (4) and (14): a matrix-valued spectral
measure can have nonzero zeroth moment and zero first moment off diagonal.
Explicitly, for the spectral resolution of A=H−E on the physical space,
\[
 d\Sigma_{ef}(\omega)=\langle v_e,\mathbf1_{d\omega}(A)v_f\rangle,
 \quad C_{ef}=\int d\Sigma_{ef},\quad
 \mathcal N_{ef}=\int\omega\,d\Sigma_{ef}.
\tag{15}
\]
The measure matrix is positive semidefinite on every Borel set because
its quadratic form is the squared norm of a projected linear combination
of the v_e. An individual off-diagonal entry, however, need not be a
nonnegative measure; (15) retains its signs. Smoothness gives the finite
moments used here. These identities are the exact relation between the
nonlocal covariance contribution and the local energy matrix, not an
assumption that one determines the other's support.

Finally \(\xi^4=1/(256g^{16})\). The physical coefficient in (4) is
therefore \(127a_{ef}/(56070144g^{16})\); C has no extra energy factor,
whereas \(\mathcal N\) has one. The scalar energy shift remains in H
and cancels only in H−E. The fixed-box coefficient is a concrete next
input to the extensive denominator calculation; control of all higher
orders and summability at fixed coupling is not inferred from its finite
range at order four.

## 5. The complete fourth-order spectral functional and time correlation

The same calculation can resolve the energy dependence, rather than only
its zeroth moment. Put \(A_\xi=(H-\mathcal E)/\kappa\), and write
\[
 F_{ef,\xi}(h)=\langle v_e,h(A_\xi)v_f\rangle.
\]
For each fixed box, for distinct links sharing no face, and every bounded
continuous real or complex function h which is differentiable at 3,
\[
\boxed{\lim_{\xi\to0}\xi^{-4}F_{ef,\xi}(h)
 =a_{ef}\left[-\frac{59}{275184}h(3)-\frac1{336}h'(3)
             +\frac1{1296}h(9/2)+\frac3{132496}h(13/2)\right].}
\tag{16}
\]
Here the limit is a functional on the specified test functions. In
particular the derivative term must not be omitted or represented as an
ordinary positive spectral atom. Each original matrix-valued spectral
measure is still the exact positive-semidefinite measure (15).

We prove (16), including the relation to the actual first interacting
spectral subspace. Let P project onto the free physical energy-three space
\(\mathcal P=\operatorname{span}\{W_p\}\), and let
\[
 R_3=(I-P)((H_0-3)|_{\mathcal P^\perp})^{-1}(I-P).
\]
The inverse is on the physical space: its constant channel is -1/3.
To verify isolation, a nonzero physical spin network has no degree-one
support vertex. Its support contains a cycle of length at least four in
the bipartite cubic graph, costing at least 3. With fewer than six
nontrivial edges it must be one elementary square: a fifth edge would
have a new degree-one endpoint, or be a forbidden same-bipartition chord
of the four-cycle. The degree-two invariant contractions require equal
spins on that square. Only spin 1/2 has energy below 9/2. A six-edge
rectangular loop realizes energy 9/2. Thus the first physical free band
is exactly P, with the next energy 9/2.

For sufficiently small real \(\xi\), the contour \(|z-3|=3/4\)
defines the actual spectral projection \(P_\xi\), and the exact isometry
\[
 V_\xi=P_\xi P(PP_\xi P|_{\mathcal P})^{-1/2}
       :\mathcal P\longrightarrow\operatorname{ran}P_\xi
\tag{17}
\]
uses its full Gram factor. Indeed the free contour resolvent has norm
at most 4/3. For \(|\xi|\le3/(64M)\), its Neumann factor is at most
1/8, and integrating the resolvent difference gives
\(\|P_\xi-P\|\le1/7\). The displayed inverse square root therefore
exists by its binomial series; idempotence and orthogonality of the real
projection show \(V_\xi^*V_\xi=I\). Its range is smooth, and the
finite-rank resolvent formula and elliptic regularity justify all operator
products and fixed Sobolev derivatives below. It is orthogonal to the
actual vacuum for a smaller interval, for example
\(|\xi|\le3/(128M)\), by the free gaps and the bounded perturbation
estimate \(2M|\xi|\).

Let Q be the unchanged open-face signless adjacency matrix, with diagonal
the actual face degrees and off-diagonal 1 for shared-edge faces. Direct
virtual-channel calculation gives
\[
 V_\xi^*A_\xi V_\xi=3I+\xi^2F+O_L(\xi^4),\qquad
 F=\frac7{15}I-\frac1{21}Q.
\tag{18}
\]
Here is the coefficient calculation rather than an assumption of (18).
Differentiating (17) gives \(V'_0=R_3SP\). The second matrix coefficient
before vacuum subtraction is \(-PSR_3SP\). The vacuum channel gives
+1/3 to every entry; a repeated-face channel gives -1/5 to its diagonal;
an edge-disjoint pair gives -1/3 to its two diagonals and mutual entries;
an adjacent pair gives
\(- (1/4)/(9/2-3)-(3/4)/(13/2-3)=-8/21\)
to that same four-entry pattern. Thus the diagonal is
\(7/15-M/3-d_p/21\), and the off-diagonal is -1/21 exactly for adjacent
faces. The actual vacuum coefficient -M/3 from (5) gives (18).
The central cochain used in Section 3 acts as -I on P; it makes the
matrix in (18) even and accounts for the fourth-order remainder.

The electric vector can be treated with arbitrary fixed real link weights
w, retaining its linear dependence on all of them. Define
\(\Gamma_w=\sum w_eE_e\), \(a_p(w)=\sum_{e\in p}w_e/4\), and
\(v(w)=(\Gamma_w-\langle\Gamma_w\rangle)\psi\). Put
\[
 y_\xi(w)=V_\xi^*v(w),\qquad
 \rho_\xi(w)=(I-P_\xi)v(w).
\]
These are exact orthogonal components, both orthogonal to the actual
vacuum. Coefficient comparison using (7) and \(V'_0=R_3SP\) gives
\[
 y_\xi(w)=\xi x(w)+\xi^3z(w)+O_L(\xi^5),\qquad
 x(w)=\sum_pa_p(w)W_p,
\]
\[
 \rho_\xi(w)=\xi^2r(w)+O_{H^k,L}(\xi^3),
\tag{19}
\]
where, for \(s=a_p(w)+a_q(w)\) and g the shared edge,
\[
 r(w)=\sum_p\frac{2a_p(w)}{15}(W_p^2-1)
       +\sum_{\{p,q\}\ {\rm adjacent}}
       \left[-\frac{2(s+w_g)}9Z_{pq,0}
             +\frac{2(3s+7w_g)}{273}Z_{pq,1}\right].
\tag{20}
\]
For completeness, \(\Gamma_w\) has eigenvalues
\(8a_p\) on the repeated face, \(3s\) on an edge-disjoint pair,
and \(3s-3w_g/2,3s+w_g/2\) on the adjacent zero and one channels.
The shared edge is counted twice as fundamental in 3s; replacing that
by its actual spin accounts for precisely the last two corrections.
In \(\Gamma_w A_2\), the respective coefficients are
\(a_p/3,s/3,(4s-2w_g)/9,(12s+2w_g)/39\).
Subtract the full dressing \(R_3Sx(w)\), whose coefficients are
\(a_p/5,s/3,2s/3,2s/7\). The two constant coefficients are both
\(-\sum_pa_p/3\) and also cancel. This proves (20) with no omitted
channel. The centered projection identity
\(V_\xi^*\psi_\xi=0\) is exact. The same central cochain makes
\(y_\xi(w)\) odd, proving the first expansion (19).

For a single link e use the original weight \(w^{(e)}_g=\delta_{eg}\),
and denote the resulting x,z,r by \(x_e,z_e,r_e^{\rm vec}\).
This superscript distinguishes the vector from the incidence count r_e.
Then \(x_e=\sum_{p\ni e}W_p/4\). If e,f share no face,
\(\langle x_e,x_f\rangle=0\), and (18) gives exactly
\[
 \langle x_e,Fx_f\rangle=-a_{ef}/336.
\tag{21}
\]
Each ordered adjacent pair contributes \(-1/(4\cdot21\cdot4)\).
In the cross spectral measure of \(r_e^{\rm vec},r_f^{\rm vec}\),
only the pairs counted by (3) occur. Repeated-face cross terms vanish.
For every contributing pair, e and f are outer links of different faces,
\(s=1/4\) for each weight, and \(w_g=0\). Thus their zero-channel
coefficients in (20) are both -1/18, and their one-channel coefficients
are both 1/182. Orthogonality and (6) give the complete free cross measure
\[
 \langle r_e^{\rm vec},h(H_0)r_f^{\rm vec}\rangle
 =a_{ef}\left[\frac1{1296}h(9/2)+\frac3{132496}h(13/2)\right].
\tag{22}
\]
No edge-disjoint channel survives in (20).

As \(A_\xi-H_0=-\xi S-e(\xi)I\) tends to zero in operator norm,
its resolvents converge in norm. For bounded continuous h, this implies
convergence of the cross expectations on \(\rho_\xi/\xi^2\) to
(22): first use continuous functions vanishing at infinity and norm
resolvent convergence, then approximate h on a compact interval and
control the discarded tail by the uniformly bounded second spectral
moments. Those moments follow from the \(H^2\) convergence in (19).
Polarization gives the cross statement from the four corresponding
diagonal statements. Hence (22) is the entire fourth-order out-of-band
contribution.

The fourth coefficient of the band mass is obtained without knowing
the third vacuum coefficient: subtract (22) at h=1 from (4). It is
\[
 \langle x_e,z_f\rangle+\langle z_e,x_f\rangle
 =a_{ef}\left(\frac{127}{219024}-\frac1{1296}-\frac3{132496}\right)
 =-\frac{59}{275184}a_{ef}.
\tag{23}
\]
Differentiability of h at 3 and spectral calculus of the finite matrix
(18) give
\(h(V_\xi^*A_\xi V_\xi)=h(3)I+\xi^2h'(3)F+o_L(\xi^2)\).
Combine this with (19), (21), (23), and the exact orthogonal spectral
decomposition into the band and its complement. This proves (16).

In particular the complete dimensionful ground-state time correlation,
with physical \(\kappa>0\) and physical time \(t\ge0\) fixed, is
\[
\boxed{\begin{split}
 \langle v_e,e^{-t(H-\mathcal E)}v_f\rangle
 =a_{ef}\xi^4\biggl[&-\frac{59}{275184}e^{-3\kappa t}
       +\frac{\kappa t}{336}e^{-3\kappa t}\\
       &+\frac1{1296}e^{-9\kappa t/2}
       +\frac3{132496}e^{-13\kappa t/2}\biggr]+O_{L,t,\kappa}(\xi^6).
\end{split}}
\tag{24}
\]
The bounded potential perturbation gives the fixed-time semigroup its
norm-convergent Duhamel series (each order is bounded by
\((2M|\xi|t)^n/n!\)); the vacuum and vectors are analytic in fixed
Sobolev norms, and the central cochain makes the whole expression even.
These facts justify the even remainder in (24), not only a pointwise
little-o limit. For varying physical \(\kappa\), the same proof uses
the explicit parameter \(\tau=\kappa t\) and keeps its dependence;
no estimate uniform in \(\tau\) or L is implied.

At t=0 the bracket is \(127/219024\). Its derivative at t=0 is
exactly zero, because
\[
3\left(-\frac{59}{275184}\right)-\frac1{336}
 +\frac{9}{2\cdot1296}+\frac{39}{2\cdot132496}=0.
\tag{25}
\]
This agrees with the exact identity (14). It exhibits which separated-link
spectral contributions cancel in the first moment: the actual band-mass
correction, the actual band-energy derivative, and both higher spin
channels. The term proportional to t is essential to that cancellation.
Equations (16)--(25) describe the fixed-box fourth coefficient of the
original interacting correlations; they do not exchange a volume limit
with the coupling expansion or assert a continuum spectrum.

## 6. Primary context

The original Hamiltonian framework is J. Kogut and L. Susskind,
*Hamiltonian formulation of Wilson's lattice gauge theories*, Physical
Review D **11** (1975), 395--408,
<https://doi.org/10.1103/PhysRevD.11.395>. Full conventions appear in (1).
For historical linked-cluster calculations in the same spatial dimension,
see A. C. Irving, T. E. Preece and C. J. Hamer, *Cluster expansion approach
to non-abelian lattice gauge theory in (3+1)D (I). SU(2)*, Nuclear Physics B
**270** (1986), 536--552,
<https://doi.org/10.1016/0550-3213(86)90567-5>. This note derives (4)
directly, with no historical novelty assertion or imported coefficient.

```

## Complete source: check_separated_spectral_functional.py

```python
"""Exact rational checks of the derived separated-link spectral functional.

The all-box incidence proof is in the companion independent calculation.
This checker tests the spin-channel subtraction and spectral moment identities;
it does not turn a fixed Taylor coefficient into a full quantum measure.
"""

from fractions import Fraction as F
import json
from pathlib import Path


def main():
    vacuum_zero = F(4, 27)
    vacuum_one = F(4, 39)
    adjacent = F(3, 4) ** 2 * (
        vacuum_zero ** 2 * F(1, 4) + vacuum_one ** 2 * F(3, 4)
    )
    disconnected = F(1, 144)
    connected = adjacent - disconnected
    assert connected == F(127, 219024)
    # Each source link is an outer edge of a different face, so s=1/4,w=0.
    s, w = F(1, 4), F(0)
    out_zero = (4 * s - 2 * w) / 9 - 2 * s / 3
    out_one = (12 * s + 2 * w) / 39 - 2 * s / 7
    assert out_zero == -F(1, 18)
    assert out_one == F(1, 182)
    high_zero = out_zero ** 2 / 4
    high_one = out_one ** 2 * F(3, 4)
    assert high_zero == F(1, 1296)
    assert high_one == F(3, 132496)
    band_mass = connected - high_zero - high_one
    assert band_mass == -F(59, 275184)
    band_energy_derivative = -F(1, 4) * F(1, 21) * F(1, 4)
    assert band_energy_derivative == -F(1, 336)

    def monomial_moment(degree):
        derivative = F(0) if degree == 0 else degree * F(3) ** (degree - 1)
        return (
            band_mass * F(3) ** degree
            + band_energy_derivative * derivative
            + high_zero * F(9, 2) ** degree
            + high_one * F(13, 2) ** degree
        )

    assert monomial_moment(0) == connected
    assert monomial_moment(1) == 0
    # Direct derivatives at tau=0 of the retained dimensionless heat kernel.
    heat_at_zero = band_mass + high_zero + high_one
    heat_derivative_at_zero = (
        -3 * band_mass - band_energy_derivative
        - F(9, 2) * high_zero - F(13, 2) * high_one
    )
    assert heat_at_zero == connected
    assert heat_derivative_at_zero == 0
    assert connected / 256 == F(127, 56070144)
    receipt = {
        "status": "PASS",
        "scope": "exact fourth Taylor-coefficient algebra, not a continuum claim",
        "connected_covariance": str(connected),
        "band_mass": str(band_mass),
        "band_energy_derivative": str(band_energy_derivative),
        "higher_9_over_2_mass": str(high_zero),
        "higher_13_over_2_mass": str(high_one),
        "moments_degree_0_through_6": {
            str(k): str(monomial_moment(k)) for k in range(7)
        },
        "heat_derivative_at_zero": str(heat_derivative_at_zero),
    }
    result = Path(__file__).with_name("SEPARATED_SPECTRAL_FUNCTIONAL_CHECKS.json")
    result.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()

```

## Complete source: wilson_variation/native_magnetic_band_measure.md

```markdown
# The unchanged native magnetic vector and its open-face spectral measure

8 September 2026. This note proves an all-volume spectral-probability limit
for the actual native magnetic leading face vector. The full finite-volume
amplitude, the original coordinate-dependent coefficients, every open boundary,
and the affine map to the first physical excitation coefficient are retained.
The calculation concerns a sequence of finite Taylor-coefficient matrices;
the coupling-dependent spectral transport is a separate calculation.

## 1. Original finite objects and the exact physical coefficient map

Fix an integer \(L\ge2\), put \(m=2L\), and use the original vertices
\(\{-L,\ldots,L\}^3\). A positively directed physical edge
\(e=(n,i)\) exists when both \(n\) and \(n+\mathbf e_i\) lie in this
set. A face \(p=(n;i,j)\), \(i<j\), has oriented edge word
\[
(n,i)^+(n+\mathbf e_i,j)^+(n+\mathbf e_j,i)^-(n,j)^-.
\tag{1.1}
\]
Thus its two plane base coordinates belong to \([-L,L-1]\cap\mathbb Z\),
and its normal base coordinate belongs to \([-L,L]\cap\mathbb Z\).
All \(M_L=3m^2(m+1)\) such faces are included. Distinct faces are adjacent
exactly when they share a physical edge. Write \(\mathsf A_L\) for the
unsigned adjacency matrix, \(d_p\) for its degrees, and
\[
\mathsf Q_L=\operatorname{diag}(d_p)+\mathsf A_L
  :\mathbb C^{\mathsf P_L}\longrightarrow\mathbb C^{\mathsf P_L}.
\tag{1.2}
\]
The inner product is counting measure, conjugate-linear in its first
argument. In particular no orientation sign is inserted in (1.2).

Each lattice edge belongs to at most four faces, and two distinct elementary
faces share at most one edge, so \(d_p\le12\). Directly expanding squares
gives
\[
\begin{split}
\langle x,\mathsf Q_Lx\rangle
 &=\sum_{\{p,q\}\text{ adjacent}}|x_p+x_q|^2,\\
\langle x,(24I-\mathsf Q_L)x\rangle
 &=\sum_{\{p,q\}\text{ adjacent}}|x_p-x_q|^2
   +2\sum_p(12-d_p)|x_p|^2.
\end{split}
\tag{1.3}
\]
Hence \(\operatorname{spec}(\mathsf Q_L)\subset[0,24]\). This proof
uses the unchanged open graph, including its degree-deficient faces.

For the original link variables \(U_e\in SU(2)\), retain
\[
\begin{gathered}
W_{n;ij}(U)=\operatorname{tr}
 \bigl(U_i(n)U_j(n+\mathbf e_i)
 U_i(n+\mathbf e_j)^{-1}U_j(n)^{-1}\bigr),\\
T_a=-i\sigma_a/2,\qquad
X_{e,a}f=\left.\frac{d}{dt}f(\ldots,e^{tT_a}U_e,\ldots)\right|_{t=0},
\qquad E_e=-\sum_{a=1}^3X_{e,a}^2,\\
H=\kappa H_0+b\sum_p(2-W_p)=\kappa K_\xi+2bM_LI,
\quad H_0=\sum_eE_e,\quad K_\xi=H_0-\xi\sum_pW_p,\\
\kappa=\frac{2g_{\rm YM}^2}{a},\qquad
b=\frac{1}{2g_{\rm YM}^2a},\qquad
\xi=\frac{b}{\kappa}=\frac1{4g_{\rm YM}^4},\qquad a>0,\ g_{\rm YM}>0.
\end{gathered}
\tag{1.4}
\]
Here \(a\) without a face subscript is the physical lattice spacing;
the face coefficient vector below is denoted \(\boldsymbol a_L\).
The original Lie metric has \(-\Delta_e^c=4E_e\). No factor in (1.4)
is changed. The gauge-invariant physical space is the invariant closed
subspace of product-Haar \(L^2(SU(2)^N)\). The operator and form domains
are its intersections with \(H^2\) and \(H^1\), respectively.

Define the linear face-to-state map
\[
\mathcal W_L:\mathbb C^{\mathsf P_L}\longrightarrow\mathcal H_{\rm phys},
\qquad \mathcal W_Lx=\sum_px_pW_p.
\tag{1.5}
\]
It is an isometry onto the free energy-three face space: for unequal faces
a link appearing in only one face changes the sign of the integrand under
\(U_e\mapsto-U_e\), proving orthogonality; for equal faces their holonomy
is Haar distributed and the fundamental character has squared Haar norm one.
Every face trace has fundamental Casimir \(3/4\) on its four links, giving
\(H_0\mathcal W_L=3\mathcal W_L\).

The original native translation has
\[
\Gamma=\sum_{e=(n,1)}n_2^2E_e,
\qquad h_1(n)=\exp(-\theta n_2H_c),\quad h_2=h_3=I,
\qquad H_c=i\sigma_3=-2T_3,
\tag{1.6}
\]
with \(\theta=2\pi a^2/D\),
\(D=L_Tq_T+6m_T^2>0\),
\(L_T=\operatorname{Im}\tau_T\),
\(q_T=-\operatorname{Im}\beta_T\), and
\(m_T=\operatorname{Im}\mu_T\). These are the same physical coordinates
and magnetic scale as in magnetic_translation_true_vacuum.md.
In first_physical_excitation_band.md the positive unit vacuum is proved to
satisfy \(\psi_\xi=1+\xi\sum_pW_p/3+O_{H^2,L}(\xi^2)\).
Applying the specified \(\Gamma:H^2\to L^2\), at fixed \(L\), gives
\[
\Gamma\psi_\xi=\xi\mathcal W_L\boldsymbol a_L+O_{L^2,L}(\xi^2),
\quad
\boxed{
a_{12}(n)=\frac{n_2^2+(n_2+1)^2}{4},\qquad
a_{13}(n)=\frac{n_2^2}{2},\qquad a_{23}(n)=0.}
\tag{1.7}
\]
Indeed a 12-face has direction-1 edge bases at heights \(n_2,n_2+1\),
a 13-face has two at height \(n_2\), and a 23-face has none; multiplying
the sum of squared heights by \((3/4)/3\) gives exactly (1.7).
The centered vector \((\Gamma-\langle\psi_\xi,\Gamma\psi_\xi\rangle)
\psi_\xi\) has the same leading coefficient because
\(\langle1,\mathcal W_L\boldsymbol a_L\rangle=0\) and its
centering scalar is \(O_L(\xi^2)\).

The same band source proves the true-vacuum second-order matrix
\[
\mathsf F_L=\frac7{15}I-\frac1{21}\mathsf Q_L.
\tag{1.8}
\]
That derivation retains the whole interaction, the shared-edge spin-zero
and spin-one virtual channels, and the vacuum subtraction. This note
calculates the spectral measure of (1.8) on precisely (1.7).

## 2. The unscaled spectral measure and the complete native amplitude

For a Borel set \(B\subset\mathbb R\), define
\[
\sigma_L(B)=\langle\boldsymbol a_L,
 \mathbf1_B(\mathsf Q_L)\boldsymbol a_L\rangle,
\qquad A_L=\sigma_L(\mathbb R)=\|\boldsymbol a_L\|^2,
\qquad \mu_L=\frac{\sigma_L}{A_L}.
\tag{2.1}
\]
The finite-dimensional spectral theorem defines the indicated orthogonal
projections. No unit-amplitude replacement of the native state occurs:
\(\sigma_L\) is kept, and only its explicitly named probability
\(\mu_L\) is divided by its actual nonzero mass.

Write \(I_L=[-L,L-1]\cap\mathbb Z\), and set
\[
s_r=\sum_{t\in I_L}t^r,
\qquad f(t)=\frac{t^2+(t+1)^2}{4}
 =\frac{t^2}{2}+\frac t2+\frac14.
\tag{2.2}
\]
Both displayed expressions define the same original coefficient. The exact
finite sums needed below are
\[
\begin{gathered}
s_0=2L,\quad s_1=-L,\quad s_2=\frac{L(2L^2+1)}3,
\quad s_3=-L^3,\quad
s_4=\frac{L(6L^4+10L^2-1)}{15},\\
\sum_{t\in I_L}f(t)^2=\frac{L(4L^4+1)}{40},\qquad
\sum_{t\in I_L}\left(\frac t2+\frac14\right)^2
 =\frac{L(4L^2-1)}{24}.
\end{gathered}
\tag{2.3}
\]
Here is an elementary verification of all sums. The odd sums pair \(t\)
with \(-t\) except for \(-L\), giving \(s_1,s_3\). For the even sums,
\(s_{2r}=L^{2r}+2\sum_{t=1}^{L-1}t^{2r}\). The polynomials
\(P_2(z)=z(z+1)(2z+1)/6\) and
\(P_4(z)=z(z+1)(2z+1)(3z^2+3z-1)/30\) obey
\(P_2(0)=P_4(0)=0\) and
\(P_r(z)-P_r(z-1)=z^r\) for \(r=2,4\), by multiplication.
Telescoping proves the two even sums. Expanding the retained polynomial
\(f^2=t^4/4+t^3/2+t^2/2+t/4+1/16\) and the last square in (2.3),
then substituting \(s_0,\ldots,s_4\), proves the remaining identities.

There are \(m(m+1)\) 12-faces at each permitted \(n_2\), and \(m^2\)
13-faces at each height from \(-L\) through \(L\), inclusive. Therefore
\[
\begin{split}
A_L
 &=m(m+1)\sum_{t=-L}^{L-1}
       \left(\frac{t^2+(t+1)^2}{4}\right)^2
   +\frac{m^2}{4}\sum_{t=-L}^{L}t^4\\
 &=\boxed{\frac45L^7+\frac65L^6+\frac23L^5
                  +\frac1{30}L^3+\frac1{20}L^2}.
\end{split}
\tag{2.4}
\]
In particular \(A_L>0\), \(A_L\ge4L^7/5\), and
\(A_L/L^7\longrightarrow4/5\). The boundary heights \(n_2=L\) and
\(n_3=L\) have been included in this mass.

## 3. Exact comparison in the same finite Hilbert space

Introduce a comparison vector solely for estimating (2.1). On the common
base cube \(C_L=I_L^3\), put
\[
g_L(n)=\mathbf1_{C_L}(n)\frac{n_2^2}{2},
\quad
\boldsymbol b_L(n;12)=g_L(n),\quad
\boldsymbol b_L(n;13)=g_L(n),\quad
\boldsymbol b_L(n;23)=0.
\tag{3.1}
\]
This defines an entry on every original face; it is zero on the remaining
faces. Set \(\boldsymbol r_L=\boldsymbol a_L-\boldsymbol b_L\).
Its complete nonzero-entry list is
\[
\begin{array}{c|c}
\text{original face and base}&r_L(n;ij)\\ \hline
n\in C_L,\ ij=12&n_2/2+1/4\\
ij=12,\ n_3=L,\ n_1,n_2\in I_L&f(n_2)\\
ij=13,\ n_2=L,\ n_1,n_3\in I_L&L^2/2.
\end{array}
\tag{3.2}
\]
Every other entry is zero. The three displayed sets are disjoint. No term
in (3.2) is deleted from the native vector or its measure.

Using (2.3) on these exact supports gives
\[
\begin{split}
B_L:=\|\boldsymbol b_L\|^2
 &=\frac{m^2s_4}{2}
   =\frac45L^7+\frac43L^5-\frac2{15}L^3,\\
R_L:=\|\boldsymbol r_L\|^2
 &=m^2\frac{L(4L^2-1)}{24}
   +m\frac{L(4L^4+1)}{40}+\frac{m^2L^4}{4}\\
 &=\frac65L^6+\frac23L^5-\frac16L^3+\frac1{20}L^2,\\
C_L^{\rm cross}:=\langle\boldsymbol b_L,\boldsymbol r_L\rangle
 &=m^2\left(\frac{s_3}{4}+\frac{s_2}{8}\right)
   =-\frac23L^5+\frac16L^3,\\
A_L&=B_L+2C_L^{\rm cross}+R_L.
\end{split}
\tag{3.3}
\]
The negative cross term is retained. These formulas give
\(B_L/A_L\to1\) and \(R_L/A_L\to0\). They follow from a literal
decomposition in \(\mathbb C^{\mathsf P_L}\), not a change of
coordinates, of face sets, or of physical background.

In the order \((12,13,23)\), use the two real plane vectors
\[
v_{24}=\left(\frac23,\frac23,\frac23\right),\qquad
v_{12}=\left(\frac13,\frac13,-\frac23\right),\qquad
(1,1,0)=v_{24}+v_{12}.
\tag{3.4}
\]
Their dot product is zero, and their squared lengths are \(4/3\) and
\(2/3\). Let \(\boldsymbol u_{\lambda,L}(n;\alpha)
=g_L(n)(v_\lambda)_\alpha\) on every original face. All three face
types exist on \(C_L\), so this is a literal orthogonal decomposition:
\[
\boldsymbol b_L=\boldsymbol u_{24,L}+\boldsymbol u_{12,L},\qquad
\langle\boldsymbol u_{24,L},\boldsymbol u_{12,L}\rangle=0,
\qquad
\|\boldsymbol u_{24,L}\|^2=\frac23B_L,\quad
\|\boldsymbol u_{12,L}\|^2=\frac13B_L.
\tag{3.5}
\]
These are not asserted to be finite-open-graph eigenvectors. The next
section bounds their exact eigen-equation errors.

## 4. Every shift and the finite-difference/open-boundary estimates

Independently define the infinite graph on
\(\mathbb Z^3\times\{12,13,23\}\) by the same physical-edge sharing
rule. Its operator on counting-measure
\(\ell^2(\mathbb Z^3;\mathbb C^3)\) is
\(\mathsf Q_\infty=12I+\mathsf A_\infty\). Within plane \(ij\),
the neighbors have bases \(n\pm\mathbf e_i,n\pm\mathbf e_j\).
For the distinct planes, the entire list is
\[
\begin{array}{c|c|c}
\text{source}&\text{target}&\text{target base, }a,b\in\{0,1\}\\ \hline
12&13&n+a\mathbf e_2-b\mathbf e_3\\
12&23&n+a\mathbf e_1-b\mathbf e_3\\
13&23&n+a\mathbf e_1-b\mathbf e_2.
\end{array}
\tag{4.1}
\]
The reverse list has the negative offsets. To prove this directly, two
faces sharing direction \(i\) have their two direction-\(i\) edges at
their respective base and base plus their other plane direction. Equating
these two possible physical-edge bases gives exactly the four offsets
in each row. The inverse traversals in (1.1) change no physical-edge
equality. There are four coplanar neighbors and eight cross-plane
neighbors, all distinct, yielding degree twelve.

Let \(J_L\) extend a face vector by zero to this infinite counting
space. Since the original graph is its induced subgraph,
\[
J_L^*\mathsf Q_\infty J_L=12I+\mathsf A_L,
\qquad
\boxed{\mathsf Q_L=J_L^*\mathsf Q_\infty J_L-\mathsf D_L},
\quad \mathsf D_L=\operatorname{diag}(12-d_p).
\tag{4.2}
\]
Both maps in (4.2) have the displayed original domains, and \(J_L\)
is an isometry. The nonzero boundary matrix \(\mathsf D_L\) is kept.

For the zero-extended scalar \(g_L\) in (3.1) define
\[
\mathcal D_{i,L}=\sum_{n\in\mathbb Z^3}
 |g_L(n+\mathbf e_i)-g_L(n)|^2.
\tag{4.3}
\]
Separation of the three finite coordinate sums gives exactly
\[
\begin{split}
\mathcal D_{1,L}=\mathcal D_{3,L}&=\frac m2s_4,\\
\mathcal D_{2,L}
 &=m^2\left[\frac{L^4+(L-1)^4}{4}
       +\sum_{t=-L}^{L-2}\left(t+\frac12\right)^2\right],\\
\sum_{t=-L}^{L-2}\left(t+\frac12\right)^2
 &=\frac{8L^3-12L^2+10L-3}{12},\\
\mathcal D_L^{\rm sum}
 :=\mathcal D_{1,L}+\mathcal D_{2,L}+\mathcal D_{3,L}
 &=\frac{14}{5}L^6-\frac43L^5+\frac{10}{3}L^4
                         -\frac23L^3-\frac2{15}L^2.
\end{split}
\tag{4.4}
\]
For directions 1 and 3 the only changes are the two boundary planes,
each contributing \(ms_4/4\). In direction 2 the lower and upper jumps
contribute \(L^4/4\) and \((L-1)^4/4\); each internal difference is
\(((t+1)^2-t^2)/2=t+1/2\). Expanding the last finite sum using (2.3)
with its upper endpoint removed proves its displayed polynomial and
then the last line. Thus the jump terms have not been replaced by
interior derivatives.

For a constant plane vector \(v\in\mathbb C^3\) and any eigenpair
\[
(12I+4\mathbf1\mathbf1^T)v=\lambda v,
\tag{4.5}
\]
the residual of \(g_Lv\) in the infinite graph has, in component
\(\alpha\) and at base \(n\), precisely
\[
\bigl((\mathsf Q_\infty-\lambda)(g_Lv)\bigr)_\alpha(n)
 =\sum_{\beta,\delta\in\mathsf T_{\alpha\beta}}
 v_\beta\bigl(g_L(n+\delta)-g_L(n)\bigr).
\tag{4.6}
\]
There are twelve terms, with \(\mathsf T_{\alpha\alpha}\) the four
coplanar shifts and other sets given by (4.1). Indeed the removed
zero-shift matrix is diagonal 16 and off-diagonal 4, precisely the
matrix in (4.5). The two vectors (3.4) satisfy (4.5) at 24 and 12:
their component sums are 2 and 0, respectively.

Translation invariance of counting norm and
\(\|x+y\|^2\le2\|x\|^2+2\|y\|^2\) imply
\[
\sum_n|g_L(n+\mathbf e_i-\mathbf e_j)-g_L(n)|^2
 \le2(\mathcal D_{i,L}+\mathcal D_{j,L}).
\tag{4.7}
\]
Split the change into its two successive coordinate shifts to prove
this, and use translation isometry for each summand. The same bound
holds with either sign or with the entire offset reversed.

Apply Cauchy--Schwarz to the twelve terms in (4.6), sum over \(n,\alpha\),
and collect each fixed target type \(\beta=ij\), with normal direction
\(k\). The four same-plane shifts contribute exactly
\(2(\mathcal D_i+\mathcal D_j)\). The four shifts to one other plane
contribute at most \(3(\mathcal D_i+\mathcal D_k)\) and those to the
remaining plane at most \(3(\mathcal D_j+\mathcal D_k)\): their terms
are a zero shift, two single shifts, and one double shift bounded by
(4.7). Consequently the coefficient for \(|v_\beta|^2\) is at most
\[
12[5(\mathcal D_i+\mathcal D_j)+6\mathcal D_k]
 \le72\mathcal D_L^{\rm sum}.
\]
We have proved the explicit infinite residual estimate
\[
\| (\mathsf Q_\infty-\lambda)(g_Lv)\|^2
 \le72\|v\|^2\mathcal D_L^{\rm sum}.
\tag{4.8}
\]

Here is the complete boundary correction on the original support. Define
\(\beta_L(t)=\mathbf1_{\{t=-L\}}+\mathbf1_{\{t=L-1\}}\) for
\(t\in I_L\). A face \(ij\) of base \(n\in C_L\) and normal
direction \(k\) has
\[
12-d_{n;ij}=\beta_L(n_i)+\beta_L(n_j)+4\mathbf1_{\{n_k=-L\}}.
\tag{4.9}
\]
For proof, each of its four edges has two transverse extension
directions, each with two incident faces except that a transverse
coordinate equal to \(-L\) or \(L\) permits only one. Summing the
three other incident faces over the four edges gives degree twelve,
minus one for either extreme plane base and minus four when the normal
coordinate is an outer boundary. On the common cube the only outer
normal boundary is \(-L\), giving (4.9). On the rest of the original
face set the same formula uses
\(4\mathbf1_{\{n_k\in\{-L,L\}\}}\); our comparison vector is zero
there, while its native residual is already retained in (3.2).

For any \(v\), the exact squared norm of this boundary error is
\[
\mathcal E_L(v):=\|\mathsf D_L(g_Lv)\|^2
 =\sum_{ij}|v_{ij}|^2\sum_{n\in C_L}\frac{n_2^4}{4}
  [\beta_L(n_i)+\beta_L(n_j)+4\mathbf1_{\{n_k=-L\}}]^2.
\tag{4.10}
\]
In each plane type the nonzero summands lie in at most five coordinate
planes of \(m^2\) points each. The bracket is at most 6 and
\(n_2^4/4\le L^4/4\). Counting overlaps more than once is an upper
bound, so
\[
\mathcal E_L(v)\le45m^2L^4\|v\|^2.
\tag{4.11}
\]
Equations (4.2), (4.8), and the triangle inequality, with every quantity
in the same original counting norm, prove
\[
\begin{gathered}
\varepsilon_{\lambda,L}
 :=\| (\mathsf Q_L-\lambda I)\boldsymbol u_{\lambda,L}\|,\\
\boxed{
\varepsilon_{\lambda,L}
 \le\sqrt{72\|v_\lambda\|^2\mathcal D_L^{\rm sum}}
          +\sqrt{\mathcal E_L(v_\lambda)}
 \le\|v_\lambda\|\mathcal K_L,}\qquad
\mathcal K_L=\sqrt{72\mathcal D_L^{\rm sum}}+\sqrt{45m^2L^4},\\
\varepsilon_{24,L}+\varepsilon_{12,L}
 \le\frac{2+\sqrt2}{\sqrt3}\mathcal K_L.
\end{gathered}
\tag{4.12}
\]
Since (4.4) gives \(\mathcal D_L^{\rm sum}=O(L^6)\), all these
residual bounds are \(O(L^3)\); their squared norms are small relative
to \(A_L\), which has order \(L^7\). The explicit formulas, rather
than this order notation, are the finite-volume estimates used below.

## 5. Quantitative spectral probability limit for the actual native vector

For a complex Lipschitz function \(h:[0,24]\to\mathbb C\), write
\(\|h\|_\infty\) and \(\operatorname{Lip}(h)\) for its supremum
norm and Lipschitz constant. Define the explicit finite numbers
\[
\begin{split}
\mathcal N_L
 &=\frac{(\sqrt{A_L}+\sqrt{B_L})\sqrt{R_L}+|B_L-A_L|}{A_L},\\
\mathcal T_L
 &=\frac{\sqrt{B_L}}{A_L}\,
           \frac{2+\sqrt2}{\sqrt3}\mathcal K_L.
\end{split}
\tag{5.1}
\]
All symbols on the right sides were calculated above without asymptotic
replacement. We claim, for every \(L\ge2\),
\[
\boxed{
\left|\int h(q)\,d\mu_L(q)
       -\frac23h(24)-\frac13h(12)\right|
 \le\mathcal N_L\|h\|_\infty
       +\mathcal T_L\operatorname{Lip}(h).}
\tag{5.2}
\]

First, by (3.2), functional calculus, and Cauchy--Schwarz,
\[
\left|\langle\boldsymbol a_L,h(\mathsf Q_L)\boldsymbol a_L\rangle
       -\langle\boldsymbol b_L,h(\mathsf Q_L)\boldsymbol b_L\rangle\right|
 \le\|h\|_\infty(\sqrt{A_L}+\sqrt{B_L})\sqrt{R_L}.
\tag{5.3}
\]
For example expand the difference as
\(\langle\boldsymbol r_L,h(\mathsf Q_L)\boldsymbol a_L\rangle
+\langle\boldsymbol b_L,h(\mathsf Q_L)\boldsymbol r_L\rangle\),
and apply the operator-norm bound \(\|h(\mathsf Q_L)\|\le\|h\|_\infty\).
Second, the finite spectral theorem and the scalar Lipschitz inequality
give, for either \(\lambda=24,12\),
\[
\|[h(\mathsf Q_L)-h(\lambda)I]\boldsymbol u_{\lambda,L}\|^2
 =\int|h(q)-h(\lambda)|^2
       d\langle\boldsymbol u_{\lambda,L},
         \mathbf1_{dq}(\mathsf Q_L)\boldsymbol u_{\lambda,L}\rangle
 \le\operatorname{Lip}(h)^2\varepsilon_{\lambda,L}^2.
\tag{5.4}
\]
Use \(\boldsymbol b_L=\boldsymbol u_{24,L}+\boldsymbol u_{12,L}\)
and their exact orthogonality to obtain
\[
\begin{split}
&\left|\langle\boldsymbol b_L,h(\mathsf Q_L)\boldsymbol b_L\rangle
       -B_L\left[\frac23h(24)+\frac13h(12)\right]\right|\\
&\hspace{15mm}\le\sqrt{B_L}\operatorname{Lip}(h)
   (\varepsilon_{24,L}+\varepsilon_{12,L}).
\end{split}
\tag{5.5}
\]
Indeed the difference equals the inner product of \(\boldsymbol b_L\)
with the sum of the two error vectors in (5.4). This step bounds the
actual spectral cross terms; it does not assume that distinct approximate
eigenvectors have orthogonal spectral projections. Combine (5.3), (5.5),
(4.12), and \(|\frac23h(24)+\frac13h(12)|\le\|h\|_\infty\),
then divide by the actual \(A_L\), proving (5.2).

Equations (2.4), (3.3), and (4.4) show directly
\(\mathcal N_L=O(L^{-1/2})\) and \(\mathcal T_L=O(L^{-1/2})\).
In particular the right side of (5.2) tends to zero for each Lipschitz
\(h\). To pass to all continuous \(h\), partition the compact interval
\([0,24]\) into sufficiently short intervals and use linear interpolation
of its endpoint values. Uniform continuity makes the resulting Lipschitz
function \(h_\eta\) satisfy \(\|h-h_\eta\|_\infty\le\eta\).
Both measures in (5.2) have total mass one, so the substitution error is
at most \(2\eta\). First let \(L\to\infty\), then \(\eta\to0\).
This proves
\[
\boxed{\mu_L\ \Longrightarrow\ \frac23\delta_{24}+\frac13\delta_{12}.}
\tag{5.6}
\]
The unscaled statement is simultaneously retained: (5.3)--(5.5) prove
\[
\begin{split}
\left|\int h\,d\sigma_L
       -A_L\left[\frac23h(24)+\frac13h(12)\right]\right|
 &\le A_L\bigl(\mathcal N_L\|h\|_\infty
                +\mathcal T_L\operatorname{Lip}(h)\bigr),\\
\boxed{L^{-7}\sigma_L\ \Longrightarrow\
              \frac8{15}\delta_{24}+\frac4{15}\delta_{12}.}
\end{split}
\tag{5.7}
\]
The second convergence is of finite measures, whose total masses tend
to \(4/5\); it follows by multiplying (5.6) by \(A_L/L^7\).
The original \(\sigma_L\) itself has diverging total mass \(A_L\),
which remains exactly (2.4).

There is also a direct concentration estimate that does not merely
test fixed functions. Put
\(p(q)=(q-12)(q-24)\). On \([0,24]\),
\(|q-12|\le12\), \(|q-24|\le24\), and \(|p(q)|\le288\)
(the quadratic has its interior extremum \(-36\) at 18 and endpoint
values 288 and 0). By the decomposition (3.2),(3.5),
\[
\|p(\mathsf Q_L)\boldsymbol a_L\|
 \le12\varepsilon_{24,L}+24\varepsilon_{12,L}+288\sqrt{R_L}.
\tag{5.8}
\]
For \(0<\delta\le6\), any point of \([0,24]\) at distance at least
\(\delta\) from both 12 and 24 has
\(|p(q)|\ge\delta(12-\delta)\): below 12 the lower bound is the
larger \(\delta(12+\delta)\), and between the two roots the product
\((q-12)(24-q)\) attains its minimum on the permitted interval at
either endpoint. Spectral integration of (5.8) therefore yields
\[
\boxed{
\mu_L\{q:\min(|q-12|,|q-24|)\ge\delta\}
 \le\frac{[12\varepsilon_{24,L}+24\varepsilon_{12,L}
                    +288\sqrt{R_L}]^2}
             {A_L\delta^2(12-\delta)^2}.}
\tag{5.9}
\]
The residuals on the right may be replaced by their explicit bounds
(4.12). For fixed \(\delta\), the displayed upper bound is \(O(L^{-1})\).
The limit weights follow from (5.2), not from concentration alone.

## 6. Exact pushforward to the band coefficient and original energy units

Let \(\phi(q)=7/15-q/21\). Since (1.8) is exactly the affine functional
calculus of (1.2), their spectral projections obey
\[
\mathbf1_B(\mathsf F_L)=\mathbf1_{\phi^{-1}(B)}(\mathsf Q_L).
\tag{6.1}
\]
One proof is to choose an orthonormal eigenbasis of the real symmetric
\(\mathsf Q_L\); each vector with eigenvalue \(q\) has the same vector
with eigenvalue \(\phi(q)\) for \(\mathsf F_L\). The two indicator
operators therefore agree on a basis. The exact unscaled and probability
measures of \(\mathsf F_L\) on the unchanged \(\boldsymbol a_L\) are
\[
\sigma_L^F=\phi_*\sigma_L,\qquad
\mu_L^F=\phi_*\mu_L,\qquad \sigma_L^F(\mathbb R)=A_L.
\tag{6.2}
\]
In particular
\[
\boxed{\begin{split}
\mu_L^F&\Longrightarrow
 \frac23\delta_{-71/105}+\frac13\delta_{-11/105},\\
L^{-7}\sigma_L^F&\Longrightarrow
 \frac8{15}\delta_{-71/105}+\frac4{15}\delta_{-11/105}.
\end{split}}
\tag{6.3}
\]
For a Lipschitz test function on \([-71/105,7/15]\), (5.2) applies
to its composition with \(\phi\), with Lipschitz constant divided
by 21. Thus (6.3) includes an explicit finite-volume error bound.

The support bound (1.3) permits polynomial test functions, giving
\[
\begin{gathered}
\lim_L\frac{\langle\boldsymbol a_L,\mathsf Q_L\boldsymbol a_L\rangle}{A_L}
 =\frac23\,24+\frac13\,12=20,\\
\lim_L\frac{\|\mathsf Q_L\boldsymbol a_L\|^2}{A_L}
 =\frac23\,24^2+\frac13\,12^2=432,\\
\lim_L\operatorname{Var}_{\mu_L}(q)=432-20^2=32,\\
\lim_L\frac{\langle\boldsymbol a_L,\mathsf F_L\boldsymbol a_L\rangle}{A_L}
 =\frac7{15}-\frac{20}{21}=-\frac{17}{35},\qquad
\lim_L\operatorname{Var}_{\mu_L^F}(F)=\frac{32}{441}.
\end{gathered}
\tag{6.4}
\]
The nonzero limiting variance proves that the native vector's coefficient
measure does not concentrate at the lowest coefficient alone.

For the original energy coefficients, a coefficient \(q\) corresponds to
\[
\kappa\bigl(3+\xi^2\phi(q)\bigr)
 =\frac{6g_{\rm YM}^2}{a}
       +\frac{\phi(q)}{8g_{\rm YM}^6a}.
\tag{6.5}
\]
This identity preserves all energy scales. Its two limiting coefficient
values insert \(-71/105\) and \(-11/105\), respectively, in (6.5).
Equation (6.5) is the Taylor polynomial, not the full interacting energy.
The band source supplies the exact transported finite matrix
\[
V_\xi^*(H-\mathcal E(\xi)I)V_\xi
 =\kappa\left(3I+\xi^2\mathsf F_L+\mathcal R_{L,\xi}\right),
\quad
\|\mathcal R_{L,\xi}\|
 \le\frac73\left(\frac{64M_L}{3}\right)^4|\xi|^4,
\quad |\xi|\le\frac3{128M_L}.
\tag{6.6}
\]
Here \(V_\xi\) is the exact isometry from the free face eigenspace to
the true interacting first cluster, and the left side acts on that free
space using (1.5). Its full vacuum energy \(\mathcal E(\xi)\) includes
the original scalar \(2bM_L\); subtracting the same scalar from both
energies explains its cancellation in (6.6). The norm and coupling
restriction in (6.6) are stated, not replaced by a volume-uniform error.
All nonlinear Wilson terms remain in \(H\) and in its exact spectral
transport; none is estimated by setting a plaquette to its classical
value. The native centered magnetic vector and its projection through
\(V_\xi\) have their own coupling-dependent dressing, treated in the
companion transport calculation.

The leading-vector amplitude also transfers exactly under (1.5):
\[
\|\xi\mathcal W_L\boldsymbol a_L\|^2=\xi^2A_L,
\qquad
\left\| -\frac23\theta^2\xi\mathcal W_L\boldsymbol a_L\right\|^2
 =\frac49\theta^4\xi^2A_L
 =\frac{4\pi^4a^8}{9D^4g_{\rm YM}^8}\,A_L.
\tag{6.7}
\]
The scalar on the right uses the original
\(\theta=2\pi a^2/D\) and \(\xi=1/(4g_{\rm YM}^4)\) without changing
either. The unscaled graph and coefficient measures of these two
specified leading vectors are respectively \(\xi^2\sigma_L\),
\(\xi^2\sigma_L^F\), and \(4\theta^4\xi^2/9\) times those original
\(\sigma_L,\sigma_L^F\). The associated probabilities, when these
scalars are nonzero, are exactly \(\mu_L,\mu_L^F\).
For the actual centered translated state, the source identity is
\(\chi_\theta=-2\theta^2
(\Gamma-\langle\psi_\xi,\Gamma\psi_\xi\rangle)\psi_\xi/3
+O_{H^1,L,\xi}(\theta^4)\). Together with (1.7) this gives
\[
\chi_\theta=-\frac23\theta^2
 [\xi\mathcal W_L\boldsymbol a_L+O_{L^2,L}(\xi^2)]
 +O_{L^2,L,\xi}(\theta^4).
\tag{6.8}
\]
The first remainder is the fixed-volume small-coupling remainder for the
centered generator vector; the second is the fixed-volume, fixed-coupling
small-angle remainder. Their dependencies are retained. Equations
(6.7)--(6.8) specify exactly which leading coefficient the measure
calculation addresses and retain the errors for the actual state.

Thus (6.1)--(6.6) give an exact map from this face-measure limit to the
specified physical band coefficient, while retaining the finite-volume
remainder. Neither (5.6) nor (6.3) takes a fixed positive coupling to
infinite volume, takes the lattice spacing to zero, or constructs the
interacting physical continuum spectral measure.

## 7. Reproducibility and calculation record

The companion check_native_magnetic_band_measure.py uses only the Python
standard library and exact integer/rational arithmetic. It independently
enumerates every original face and every physical-edge star for
\(L=2,3,4,5,6\), constructs the open adjacency, and verifies (1.7),
(2.3)--(2.4), every entry of (3.2), all norms and the negative cross term
in (3.3), the orthogonal weights (3.5), every finite difference (4.4),
the boundary identity (4.9), the exact boundary sum (4.10), and rational
squared versions of the residual bounds. It checks the native graph
moments directly and verifies the rational maps and limiting moments
in (6.3)--(6.4). Polynomial identities are additionally checked by exact
coefficient operations or by their exact finite-sum difference identities;
no floating eigenvalue calculation is used as a proof of the limit.

The checker was executed successfully with
`python agent_work/ym_gap_primary_20260908/wilson_variation/check_native_magnetic_band_measure.py`.
Its verified native amplitudes were \(201,11151/4,18708,333355/4,285129\)
for \(L=2,3,4,5,6\), respectively; the corresponding full face counts
were \(240,756,1728,3300,5616\). All polynomial, physical-edge,
finite-difference, boundary, and residual identities passed.

Task continuity: the existing root logbook and user-input provenance files
were found before writing; this owned calculation had no preexisting
native_magnetic_band_measure.md or checker to overwrite. The three source
notes named in the task were inspected, and all original native coefficients
were retained. The auxiliary common-cube vector was introduced only with
its full residual and cross term. The candidate two-atom probability was
then proved from the finite open graph, rather than assumed from its bulk
symbol. No new agent, remote write, PDF, Lean process, or spectral numerical
diagonalization is part of this bounded calculation.

```

## Complete source: wilson_variation/check_native_magnetic_band_measure.py

```python
"""Exact native open-face coefficients, norms, shifts, and residual checks.

Standard-library arithmetic only. All graph vectors are stored after
multiplication by 12; every reported norm removes exactly that factor.
No floating eigenvalues, external packages, writes, or Lean processes.
"""

from collections import defaultdict
from fractions import Fraction as F
from itertools import combinations, product


def trim(p):
    p = list(map(F, p))
    while len(p) > 1 and p[-1] == 0:
        p.pop()
    return tuple(p)


def add(*ps):
    out = [F(0)] * max(map(len, ps))
    for p in ps:
        for i, x in enumerate(p):
            out[i] += x
    return trim(out)


def scale(p, c):
    return trim([c * x for x in p])


def mul(*ps):
    out = (F(1),)
    for p in ps:
        vals = [F(0)] * (len(out) + len(p) - 1)
        for i, x in enumerate(out):
            for j, y in enumerate(p):
                vals[i + j] += x * y
        out = trim(vals)
    return out


def power(p, n):
    return mul(*([p] * n))


def compose(p, q):
    return add(*(scale(power(q, i), x) for i, x in enumerate(p)))


def value(p, x):
    out = F(0)
    for c in reversed(p):
        out = out * x + c
    return out


def same(p, q):
    assert trim(p) == trim(q), (p, q)


# Exact polynomial identities in L, not numerical fitting.
ell = (F(0), F(1))
one = (F(1),)
minus_one = add(ell, (-1,))
P2 = scale(mul(ell, add(ell, one), add(scale(ell, 2), one)), F(1, 6))
P4 = scale(mul(ell, add(ell, one), add(scale(ell, 2), one),
               add(scale(power(ell, 2), 3), scale(ell, 3), (-1,))), F(1, 30))
for deg, poly in ((2, P2), (4, P4)):
    assert value(poly, 0) == 0
    same(add(poly, scale(compose(poly, minus_one), -1)), power(ell, deg))

s0 = scale(ell, 2)
s1 = scale(ell, -1)
s2 = scale(mul(ell, add(scale(power(ell, 2), 2), one)), F(1, 3))
s3 = scale(power(ell, 3), -1)
s4 = scale(mul(ell, add(scale(power(ell, 4), 6),
                         scale(power(ell, 2), 10), (-1,))), F(1, 15))
same(s2, add(power(ell, 2), scale(compose(P2, minus_one), 2)))
same(s4, add(power(ell, 4), scale(compose(P4, minus_one), 2)))

fsq = scale(mul(ell, add(scale(power(ell, 4), 4), one)), F(1, 40))
dsq = scale(mul(ell, add(scale(power(ell, 2), 4), (-1,))), F(1, 24))
same(fsq, add(scale(s4, F(1, 4)), scale(s3, F(1, 2)),
              scale(s2, F(1, 2)), scale(s1, F(1, 4)), scale(s0, F(1, 16))))
same(dsq, add(scale(s2, F(1, 4)), scale(s1, F(1, 4)), scale(s0, F(1, 16))))

mp = scale(ell, 2)
AA = add(scale(power(ell, 7), F(4, 5)), scale(power(ell, 6), F(6, 5)),
         scale(power(ell, 5), F(2, 3)), scale(power(ell, 3), F(1, 30)),
         scale(power(ell, 2), F(1, 20)))
BB = add(scale(power(ell, 7), F(4, 5)), scale(power(ell, 5), F(4, 3)),
         scale(power(ell, 3), F(-2, 15)))
RR = add(scale(power(ell, 6), F(6, 5)), scale(power(ell, 5), F(2, 3)),
         scale(power(ell, 3), F(-1, 6)), scale(power(ell, 2), F(1, 20)))
CC = add(scale(power(ell, 5), F(-2, 3)), scale(power(ell, 3), F(1, 6)))
same(AA, add(mul(mp, add(mp, one), fsq),
             scale(mul(power(mp, 2), add(s4, power(ell, 4))), F(1, 4))))
same(BB, scale(mul(power(mp, 2), s4), F(1, 2)))
same(RR, add(mul(power(mp, 2), dsq), mul(mp, fsq),
             scale(mul(power(mp, 2), power(ell, 4)), F(1, 4))))
same(CC, mul(power(mp, 2), add(scale(s3, F(1, 4)), scale(s2, F(1, 8)))))
same(AA, add(BB, scale(CC, 2), RR))

interior_diff = scale(add(scale(power(ell, 3), 8),
                          scale(power(ell, 2), -12), scale(ell, 10), (-3,)), F(1, 12))
same(interior_diff,
     add(s2, s1, scale(s0, F(1, 4)),
         scale(power(add(ell, (F(-1, 2),)), 2), -1)))
D2p = mul(power(mp, 2),
          add(scale(add(power(ell, 4), power(minus_one, 4)), F(1, 4)),
              interior_diff))
Dsum = add(scale(power(ell, 6), F(14, 5)), scale(power(ell, 5), F(-4, 3)),
           scale(power(ell, 4), F(10, 3)), scale(power(ell, 3), F(-2, 3)),
           scale(power(ell, 2), F(-2, 15)))
same(Dsum, add(mul(mp, s4), D2p))
assert AA[-1] == BB[-1] == F(4, 5)
assert len(RR) == 7 and len(Dsum) == 7
print("All polynomial identities and finite-sum telescoping identities passed.")


def shifted(n, i, k=1):
    r = list(n)
    r[i] += k
    return tuple(r)


def edges(p):
    n, i, j = p
    return ((n, i), (shifted(n, i), j), (shifted(n, j), i), (n, j))


planes = tuple(combinations(range(3), 2))


def bulk_neighbors(p):
    n, i, j = p
    out = []
    for k in (i, j):
        for sign in (-1, 1):
            out.append((shifted(n, k, sign), i, j))
    for k, l in planes:
        if (i, j) == (k, l):
            continue
        source_transverse = next(iter({i, j} - {k, l}))
        target_transverse = next(iter({k, l} - {i, j}))
        for a, b in product((0, 1), repeat=2):
            base = shifted(shifted(n, source_transverse, a), target_transverse, -b)
            out.append((base, k, l))
    assert len(out) == len(set(out)) == 12
    return out


def dot(x, y):
    return F(sum(x[p] * y[p] for p in x), 144)


def q_apply(x, adj):
    return {p: len(adj[p]) * x[p] + sum(x[q] for q in adj[p]) for p in x}


rows = []
for L in range(2, 7):
    m = 2 * L
    faces = [(n, i, j) for n in product(range(-L, L + 1), repeat=3)
             for i, j in planes if n[i] < L and n[j] < L]
    face_set = set(faces)
    stars = defaultdict(list)
    for p in faces:
        for e in edges(p):
            stars[e].append(p)
    adj = {p: set() for p in faces}
    pairs = set()
    for star in stars.values():
        for p, q in combinations(star, 2):
            pair = frozenset((p, q))
            assert pair not in pairs
            pairs.add(pair)
            adj[p].add(q)
            adj[q].add(p)
    assert len(faces) == 12 * L * L * (2 * L + 1)
    assert len(pairs) == 144 * L**3 - 12 * L

    def in_cube(n):
        return all(-L <= t < L for t in n)

    def g2(n):
        return n[1] ** 2 if in_cube(n) else 0  # Exactly twice g_L.

    a12, b12, r12, u24, u12 = {}, {}, {}, {}, {}
    for p in faces:
        n, i, j = p
        t = n[1]
        alpha = (i, j)
        a12[p] = 3 * (2 * t * t + 2 * t + 1) if alpha == (0, 1) else (
            6 * t * t if alpha == (0, 2) else 0)
        # The original Gamma Casimir map, checked independently by edges.
        assert a12[p] == 3 * sum(base[1] ** 2 for base, direction in edges(p)
                                 if direction == 0)
        b12[p] = 6 * g2(n) if alpha in ((0, 1), (0, 2)) else 0
        r12[p] = a12[p] - b12[p]
        if in_cube(n) and alpha == (0, 1):
            expected = 6 * t + 3
        elif alpha == (0, 1) and n[2] == L:
            expected = 3 * (2 * t * t + 2 * t + 1)
        elif alpha == (0, 2) and n[1] == L:
            expected = 6 * L * L
        else:
            expected = 0
        assert r12[p] == expected
        u24[p] = 4 * g2(n)
        u12[p] = (2 if alpha != (1, 2) else -4) * g2(n)
        assert u24[p] + u12[p] == b12[p]

        assert adj[p] == (set(bulk_neighbors(p)) & face_set)
        normal = 3 - i - j
        beta = lambda t: int(t == -L) + int(t == L - 1)
        deficit = beta(n[i]) + beta(n[j]) + 4 * int(n[normal] in (-L, L))
        assert 12 - len(adj[p]) == deficit
        for q in bulk_neighbors(p):
            assert len(set(edges(p)) & set(edges(q))) == 1

    A, B, R, C = dot(a12, a12), dot(b12, b12), dot(r12, r12), dot(b12, r12)
    assert (A, B, R, C) == tuple(value(poly, L) for poly in (AA, BB, RR, CC))
    assert A == B + 2 * C + R and C < 0
    assert dot(u24, u12) == 0
    assert dot(u24, u24) == F(2, 3) * B
    assert dot(u12, u12) == F(1, 3) * B
    assert A >= F(4, 5) * L**7
    interval = range(-L, L)
    assert tuple(sum(F(t) ** k for t in interval) for k in range(5)) == tuple(
        value(poly, L) for poly in (s0, s1, s2, s3, s4))

    box_nearby = tuple(product(range(-L - 1, L + 1), repeat=3))
    D = [F(sum((g2(shifted(n, i)) - g2(n)) ** 2 for n in box_nearby), 4)
         for i in range(3)]
    assert D[0] == D[2] == F(m, 2) * value(s4, L)
    assert D[1] == value(D2p, L)
    assert sum(D) == value(Dsum, L)
    assert sum(F(2 * t + 1, 2) ** 2 for t in range(-L, L - 1)) == value(interior_diff, L)
    for i, j in combinations(range(3), 2):
        delta = F(sum((g2(shifted(shifted(n, i), j, -1)) - g2(n)) ** 2
                      for n in box_nearby), 4)
        assert delta <= 2 * (D[i] + D[j])

    resnorms = {}
    for eigenvalue, vector, vnorm2 in ((24, u24, F(4, 3)), (12, u12, F(2, 3))):
        def extended_u(p):
            n, i, j = p
            factor = 4 if eigenvalue == 24 else (2 if (i, j) != (1, 2) else -4)
            return factor * g2(n)

        bulk_res = {}
        for n in box_nearby:
            for i, j in planes:
                p = (n, i, j)
                bulk_res[p] = ((12 - eigenvalue) * extended_u(p)
                               + sum(extended_u(q) for q in bulk_neighbors(p)))
        bulk_norm = F(sum(x*x for x in bulk_res.values()), 144)
        assert bulk_norm <= 72 * vnorm2 * sum(D)
        boundary_vec = {p: (12 - len(adj[p])) * vector[p] for p in faces}
        E = dot(boundary_vec, boundary_vec)
        E_formula = F(0)
        for p in faces:
            n, i, j = p
            if not in_cube(n):
                continue
            normal = 3 - i - j
            bracket = beta(n[i]) + beta(n[j]) + 4 * int(n[normal] == -L)
            E_formula += F(bracket * bracket * vector[p] * vector[p], 144)
        assert E == E_formula
        assert E <= 45 * m*m * L**4 * vnorm2
        qvec = q_apply(vector, adj)
        residual = {p: qvec[p] - eigenvalue * vector[p] for p in faces}
        for p in faces:
            assert residual[p] == bulk_res[p] - boundary_vec[p]
        residual_norm = dot(residual, residual)
        assert residual_norm <= 2 * bulk_norm + 2 * E
        assert residual_norm <= 2 * vnorm2 * (72 * sum(D) + 45 * m*m * L**4)
        resnorms[eigenvalue] = residual_norm

    qa = q_apply(a12, adj)
    qform = dot(a12, qa)
    qsecond = dot(qa, qa)
    assert qform == F(sum((a12[p] + a12[q]) ** 2
                         for p, q in (tuple(pair) for pair in pairs)), 144)
    deficit_form = F(sum((a12[p] - a12[q]) ** 2
                         for p, q in (tuple(pair) for pair in pairs))
                     + 2 * sum((12-len(adj[p])) * a12[p] ** 2 for p in faces), 144)
    assert 24 * A - qform == deficit_form >= 0
    assert qsecond * A >= qform * qform
    Fmean = F(7, 15) - qform / (21 * A)
    rows.append((L, len(faces), A, qform/A, Fmean))
    print(f"L={L}: {len(faces)} faces; A={A}; all native entries, exact boundary "
          "and bulk residual identities passed.")

# Exact endpoint pushforward and the limiting first two moments.
v24, v12 = (F(2, 3),)*3, (F(1, 3), F(1, 3), F(-2, 3))
for vv, lam in ((v24, 24), (v12, 12)):
    assert tuple(12 * x + 4 * sum(vv) for x in vv) == tuple(lam * x for x in vv)
assert sum(x*y for x, y in zip(v24, v12)) == 0
phi = lambda q: F(7, 15) - F(q, 21)
assert (phi(24), phi(12)) == (F(-71, 105), F(-11, 105))
weights = ((F(2, 3), 24), (F(1, 3), 12))
qmean = sum(w*q for w, q in weights)
qsecond = sum(w*q*q for w, q in weights)
fmean = sum(w*phi(q) for w, q in weights)
fvar = sum(w*(phi(q)-fmean)**2 for w, q in weights)
assert (qmean, qsecond, qsecond-qmean*qmean, fmean, fvar) == (
    20, 432, 32, F(-17, 35), F(32, 441))
assert (F(4, 5)*F(2, 3), F(4, 5)*F(1, 3)) == (F(8, 15), F(4, 15))
print("Exact affine spectral pushforward, limiting weights, means, and variances passed.")
print("Finite native graph means (exact rational diagnostics, not eigenvalue fits):")
for L, count, A, qmean, fmean in rows:
    print(f"  L={L}: <Q>/A={qmean}; <F>/A={fmean}")
print("PASS: the companion all-L proof retains native amplitude and every open boundary.")

```

## Complete source: wilson_variation/native_magnetic_physical_band_transport.md

```markdown
# Native magnetic state: exact physical band transport and spectral weights

8 September 2026. This proof uses the actual interacting vacuum of the full
open three-dimensional spatial SU(2) box. The angular limit is taken first,
at each fixed box and coupling; the coupling limit is taken afterwards.
All statements about spectral measures retain their unnormalized mass.
Time is Hamiltonian time. The original spatial spacing, magnetic angle,
electric coefficient, and both shared-edge spin channels remain explicit.

## 1. Configuration, domains, and the actual native state

Fix an integer \(L\geq2\). The vertex set is
\(\mathsf V_L=\{-L,\ldots,L\}^3\). Include every positive link
\(e=(n,i)\) whose two endpoints lie in the box and every elementary face
\(p=(n;i,j)\), \(i<j\), whose four vertices lie there. Denote these sets
by \(\mathsf E_L,\mathsf P_L\). Their cardinalities are
\[
 N=3(2L)(2L+1)^2,\qquad M=3(2L)^2(2L+1).
\tag{1.1}
\]
Negative traversal uses the inverse of the same link variable. On the
compact connected configuration manifold \(\mathsf Q_L=SU(2)^N\), use
product Haar probability measure and an inner product conjugate-linear in
its first entry. Define
\[
\begin{split}
 W_{n;i,j}(U)&=\operatorname{tr}\bigl[
 U_i(n)U_j(n+\mathbf e_i)U_i(n+\mathbf e_j)^{-1}U_j(n)^{-1}\bigr],\\
 T_a&=-i\sigma_a/2,\qquad
 X_{e,a}f=\left.\frac{d}{dt}f(\ldots,e^{tT_a}U_e,\ldots)\right|_{t=0},\\
 E_e&=-\sum_{a=1}^3X_{e,a}^2,\qquad H_0=\sum_eE_e,\qquad S=\sum_pW_p,\\
 K_\xi&=H_0-\xi S,\qquad H=\kappa K_\xi+2bM I,\\
 \kappa&=\frac{2g_{\rm YM}^2}{a},\qquad
 b=\frac1{2g_{\rm YM}^2a},\qquad
 \xi=\frac b\kappa=\frac1{4g_{\rm YM}^4}.
\end{split}
\tag{1.2}
\]
Here \(a>0\), \(g_{\rm YM}>0\). In particular the Lie metric
\(c(A,B)=-\operatorname{tr}(AB)/2\) has orthonormal frame \(2T_a\),
so \(-\Delta_e^c=4E_e\). This factor is included in \(\kappa\).
The traces are real on SU(2).

Let \(\Pi\) be the Haar average of the vertex gauge action
\(U_e\mapsto g_{s(e)}U_eg_{t(e)}^{-1}\). Haar invariance proves
\(\Pi^* =\Pi^2=\Pi\); its range \(\mathcal H_{\rm phys}\) is the
physical Hilbert space. Each \(E_e\) is bi-invariant and every \(W_p\)
is gauge invariant, so these operators preserve this subspace. All
subsequent spectral projections are on \(\mathcal H_{\rm phys}\).

The elliptic product Laplacian has operator domain \(H^2\), form domain
\(H^1\), and compact resolvent. We use the intersections with
\(\mathcal H_{\rm phys}\). Multiplication by the bounded smooth real
function \(S\) leaves these domains and self-adjointness unchanged. A
ground minimizer may be taken nonnegative because taking absolute value
does not increase the gradient form; this follows by differentiating
\(\sqrt{|f|^2+\varepsilon^2}\) and passing to the limit. Elliptic
regularity and the strong maximum principle make the minimizer smooth
and strictly positive. For such a unit vector \(\psi_\xi\), with
\(K_\xi\psi_\xi=e(\xi)\psi_\xi\), integration by parts gives
\[
 \langle\psi_\xi F,(H-\mathcal E_\xi)\psi_\xi F\rangle
 =\kappa\sum_{e,a}\int\psi_\xi^2|X_{e,a}F|^2dU,
 \qquad\mathcal E_\xi=\kappa e(\xi)+2bM.
\tag{1.3}
\]
The positive smooth function and its reciprocal are bounded on this
compact manifold. The identity therefore extends to the form domain by
density. A second ground eigenvector divided by \(\psi_\xi\) would
have all derivatives zero and hence be constant. Thus the positive unit
vacuum is unique, and gauge transformations fix it. The full and physical
bottoms coincide. Write the exact physical excitation operator as
\[
 \mathscr A_\xi=H-\mathcal E_\xi I
       =\kappa(K_\xi-e(\xi)I).
\tag{1.4}
\]
This equality subtracts the same \(2bM\) present in both energies.

The native nonwrapping links and their translation are
\[
 h_1(n)=\exp(-\theta n_2H_c),\quad h_2(n)=h_3(n)=I,
 \quad H_c=i\sigma_3=-2T_3,\quad
 (\mathcal T_\theta f)(U)=f((h_e^{-1}U_e)_e).
\tag{1.5}
\]
The original geometric dictionary is \(\theta=2\pi a^2/D\), with
the original positive determinant \(D\). No integer coordinate is wrapped,
translated to a different origin, or rescaled here. Define
\[
 c_{\xi,\theta}=\langle\psi_\xi,\mathcal T_\theta\psi_\xi\rangle,
 \qquad
 \chi_{\xi,\theta}=\Pi\mathcal T_\theta\psi_\xi
                      -c_{\xi,\theta}\psi_\xi.
\tag{1.6}
\]
This is a smooth physical vector orthogonal to the same actual vacuum:
\(\langle\psi_\xi,\Pi\mathcal T_\theta\psi_\xi\rangle
=c_{\xi,\theta}\) since \(\Pi\psi_\xi=\psi_\xi\).

For completeness the exact full-representation projection in (1.6) is
as follows. There is only one nonidentity translated edge at a given
source. Gauge conjugation conjugates its left translation by the gauge
variable at that source. Independent source averages therefore give,
on invariant inputs,
\[
 \Pi\mathcal T_\theta\Pi=\mathcal C_\theta\Pi,
 \qquad \mathcal C_\theta=\prod_{e=(n,1)}C_{e,\theta n_2}.
\tag{1.7}
\]
The operator \(C_{e,s}\) averages left translation by conjugates of
\(e^{sH_c}\). On an edge-spin-\(j\) matrix coefficient Schur's lemma
and its trace give exactly
\[
 c_j(s)=\frac1{2j+1}\sum_{m=-j}^j e^{2ims}.
\tag{1.8}
\]
Indeed the averaged representation matrix commutes with all matrices of
the irreducible representation and its trace is the character. The finite
sum defines it at every angle, including zeros of the alternative sine
denominator. All link-spin sectors and all invariant multiplicities are
retained. This proves that \(\mathcal C_\theta\) is even, self-adjoint,
a contraction, and commutes with every link Casimir, with \(\Pi\), and
with Sobolev powers of \(1+H_0\). Conjugacy under \(i\sigma_1\) sends
\(s\) to \(-s\), which also directly proves evenness and self-adjointness.

Put
\[
 w_{(n,1)}=n_2^2,\qquad w_{(n,2)}=w_{(n,3)}=0,
 \quad \Gamma=\sum_e w_eE_e,
 \quad\gamma_\xi=\langle\psi_\xi,\Gamma\psi_\xi\rangle,
 \quad v_\xi=(\Gamma-\gamma_\xi)\psi_\xi.
\tag{1.9}
\]
In joint Peter--Weyl coordinates, \(\Gamma\) is the nonnegative diagonal
self-adjoint operator with eigenvalues \(\sum_ew_ej_e(j_e+1)\). Its
domain consists precisely of coefficient families square summable after
multiplication by these eigenvalues. It contains \(H^2\); equality is
not needed because some weights vanish. Since \(0\leq w_e\leq L^2\),
the diagonal comparison \(\Gamma\leq L^2H_0\) proves boundedness
\(\Gamma:H^{k+2}\to H^k\). In particular all applications to smooth
vacua, and all products below on such vectors, have their stated domains.

Taylor's formula for the smooth translation flow, averaged over the
compact gauge group, is valid as a map \(H^{k+4}\to H^k\).
The Haar average of an adjoint-vector pair is its scalar inner product
times \(\delta_{ab}/3\), since rotational invariance makes the average
scalar and its trace fixes that scalar. The native generator at an edge
has coefficient \(2n_2T_3\). Distinct translated sources average
independently. Its averaged second derivative is therefore
\(-4\Gamma/3\). Evenness removes the odd derivatives. Consequently
\[
\begin{split}
 \mathcal C_\theta\psi_\xi
  &=\psi_\xi-\frac23\theta^2\Gamma\psi_\xi+O_{H^k,L,\xi}(\theta^4),\\
 \chi_{\xi,\theta}
  &=-\frac23\theta^2v_\xi+O_{H^k,L,\xi}(\theta^4).
\end{split}
\tag{1.10}
\]
This is a Sobolev vector expansion; it does not regard \(\Gamma\) as
a bounded operator on \(L^2\). We will first use (1.10) at fixed \(\xi\).

The vector \(v_\xi\) is nonzero for every \(b>0\). If
\(\Gamma\psi_\xi=\gamma_\xi\psi_\xi\), Haar integration gives
\(0=\gamma_\xi\int\psi_\xi\), so \(\gamma_\xi=0\). Its quadratic
form then implies that \(\psi_\xi\) is independent of every
direction-1 edge with \(n_2\ne0\). Choose \(e=((0,1,0),1)\),
which has four incident faces for \(L\ge2\). Fix all other link
variables at the identity. The kinetic terms and \(\psi_\xi\) are
independent of \(U_e\), whereas the potential in the ground equation
is \(4b(2-\operatorname{tr}U_e)\). Smoothness permits this evaluation
and positivity makes the fixed value of \(\psi_\xi\) nonzero. The
equation is impossible for \(b>0\). This also proves that (1.10) has a
strictly positive leading squared norm at every fixed positive coupling.

## 2. The exact first-band isometry

Here are the spectral isolation and transport facts with their proof.
Peter--Weyl decomposition followed by the bounded gauge projection gives
a complete physical decomposition into link spins and invariant vertex
contractions. A nonempty support graph of such a contraction has no
degree-one vertex: a single nontrivial irreducible representation has no
invariant vector. Thus it contains a cycle. The cubic nearest-neighbor
graph is bipartite, so such a cycle has at least four edges, each costing
at least \(3/4\). If total energy is below \(9/2\), there are at most
five support edges. A four-cycle must then occur. A fifth edge could
neither have a new endpoint without a degree-one vertex nor be a chord,
since the potential chords have endpoints of the same bipartition class.
The support is a four-cycle, which is one elementary square. At its
degree-two vertices the two spins must agree and the invariant contraction
is unique by Schur's lemma. Thus its energy is \(4j(j+1)\). Below
\(9/2\) only \(j=1/2\) occurs. A six-edge rectangular loop realizes
\(9/2\). Single-link Haar integration also gives
\[
 \langle W_p,W_q\rangle=\delta_{pq},\quad
 H_0W_p=3W_p,\quad
 \ker H_0=\mathbb C1,\quad
 \ker(H_0-3)=\mathcal P=\operatorname{span}\{W_p\},
 \quad \operatorname{spec}(H_0)\cap(3,9/2)=\varnothing.
\tag{2.1}
\]
For unequal faces a link occurring in just one kills the integral by
central multiplication by \(-I\). For equal faces their holonomy is
Haar and the fundamental character has norm one: writing
\(U=u_0I+i\sum_au_a\sigma_a\) on the unit three-sphere gives
\(\int(2u_0)^2=1\). The same parity proves \(\int W_p=0\).

Let \(P\) be the projection onto \(\mathcal P\), and define
\[
 R_3=(I-P)\bigl((H_0-3)|_{\operatorname{ran}(I-P)}\bigr)^{-1}(I-P).
\tag{2.2}
\]
It acts by \(-1/3\) on constants; that channel is retained. Set
\[
 r_L=\frac3{64M},\qquad \mathcal C_3=\{z:|z-3|=3/4\},\qquad
 P_\xi=\frac1{2\pi i}\int_{\mathcal C_3}(z-K_\xi)^{-1}\,dz.
\tag{2.3}
\]
The identity \(\|S\|=2M\) follows from its pointwise bound and the
identity configuration with positive-measure neighborhoods. On
\(\mathcal C_3\), the free resolvent has norm at most \(4/3\).
For complex \(|\xi|\le r_L\) the Neumann factor is at most \(1/8\),
and hence
\[
 \|(z-K_\xi)^{-1}\|\le\frac{32}{21},\qquad
 \|P_\xi-P\|\le\frac17.
\tag{2.4}
\]
The latter follows by integrating the resolvent difference:
\((3/4)(4/3)^2(2Mr_L)/(1-1/8)=1/7\). These analytic idempotents
have rank \(M\) by continuous deformation from \(P\). On \(\mathcal P\),
let
\[
 T_\xi=PP_\xi P|_{\mathcal P},\qquad
 V_\xi=P_\xi P T_\xi^{-1/2}:\mathcal P\longrightarrow\operatorname{ran}P_\xi.
\tag{2.5}
\]
The convergent binomial series at \(I\) defines the inverse square root
since \(\|T_\xi-I\|\le1/7\). With
\(U_\xi=T_\xi^{-1/2}PP_\xi\) on \(\operatorname{ran}P_\xi\),
idempotence gives \(U_\xi V_\xi=I\), and equal dimensions give the
reverse identity. For real \(\xi\), \(P_\xi\) is orthogonal and
\(U_\xi=V_\xi^*\), so \(V_\xi\) is an isometry onto the actual
spectral subspace. The full Gram factor is part of this exact coordinate
map. Its range is smooth by elliptic regularity and finite rank.
The contour also makes \(K_\xi P_\xi\) bounded via the integral with
integrand \(z(z-K_\xi)^{-1}\); all intertwining products are thus defined.

For real \(|\xi|\le r_L/2\), min--max moves each ordered physical
eigenvalue by at most \(2M|\xi|\le3/64\). There is one bottom, then
exactly \(M\) eigenvalues near 3, and every other eigenvalue is at least
\(9/2-3/64\). Thus \(P_\xi\) is precisely the first physical band,
and \(P_\xi\psi_\xi=0\) exactly. Define its exact matrix
\[
 B_\xi=U_\xi K_\xi V_\xi,
 \qquad \mathscr A_\xi V_\xi
      =V_\xi\kappa(B_\xi-e(\xi)I).
\tag{2.6}
\]
For every bounded Borel function \(f\), functional calculus gives
\[
 f(\mathscr A_\xi)P_\xi
 =V_\xi f\bigl(\kappa(B_\xi-e(\xi)I)\bigr)V_\xi^*.
\tag{2.7}
\]
Indeed an orthonormal eigenbasis of the finite Hermitian matrix is mapped
by \(V_\xi\) to an orthonormal eigenbasis of its invariant subspace;
both sides act by the same scalar on those vectors and vanish on its
orthogonal complement. This proves the exact observable map as well as
the exact state-space map.

The bottom projection near zero has the analogous isolated contour, so
\(e(\xi)\) and the positively chosen unit \(\psi_\xi\) are analytic
near zero. The equation
\[
 \psi_\xi=(H_0+1)^{-1}[(1+e(\xi)+\xi S)\psi_\xi]
\tag{2.8}
\]
and boundedness of smooth multiplication in each Sobolev space upgrade
analyticity by two derivatives at a time. Thus every fixed Sobolev
Taylor expansion used below is justified at fixed \(L\).

## 3. Every second-order channel and the coefficient energies

For a repeated face and for an unordered adjacent pair with shared edge
\(e\), put
\[
 Y_p=W_p^2-1,\qquad
 Z_{pq,0}=\int W_pW_q\,dU_e,\qquad Z_{pq,1}=W_pW_q-Z_{pq,0}.
\tag{3.1}
\]
An adjacent pair means two distinct faces sharing one physical edge,
including coplanar and hinged pairs. All other unordered distinct pairs
are called edge-disjoint, even when they share a vertex. Reverse one face
traversal if necessary and cyclically write its pair of traces as
\(\operatorname{tr}(U_eA)\operatorname{tr}(U_e^{-1}B)\).
The identity \(\int U_{ij}\overline U_{kl}\,dU
=\delta_{ik}\delta_{jl}/2\) gives
\(Z_{pq,0}=\operatorname{tr}(AB)/2\). The six outer links are distinct.
The shared-edge tensor product has spins 0 and 1, while every outer edge
has spin \(1/2\). Repeated-face character multiplication gives spin 1
on its four edges. Consequently the complete table is
\[
\begin{array}{c|ccccc}
 \text{vector}&1&Y_p&W_pW_q\ (\text{edge-disjoint})&Z_{pq,0}&Z_{pq,1}\\\hline
 H_0\text{ eigenvalue}&0&8&6&9/2&13/2\\
 \text{squared norm}&1&1&1&1/4&3/4.
\end{array}
\tag{3.2}
\]
For the last two norms the Haar projection in (3.1) is orthogonal,
its image is half a norm-one character, and the original product has
squared norm one by integrating the independent outer Haar words first.
The other norms follow from the same character integration.

Vectors belonging to different unordered distinct pairs are orthogonal.
Their odd link parity is exactly \(\partial p\mathbin\triangle\partial q\),
in either shared-edge channel. If different pairs had the same parity,
their symmetric difference would be a nonempty closed mod-two set of at
most four squares. Any square in that set needs another square on each
of its four edges. Distinct elementary squares share at most one edge,
so at least four *other* squares would be necessary, a contradiction.
Integrating a link of unequal parity proves orthogonality. Repeated-face
vectors have even parity everywhere and so are orthogonal to distinct
pairs; distinct \(Y_p\)'s have different link-spin assignments. Constants
are orthogonal to all these nonconstant vectors. All orthogonalities
remain valid after applying \(H_0\), \(R_3\), or \(\Gamma\), since
the displayed vectors have definite joint link spins.

Comparing coefficients in the vacuum equation and its unit norm gives
\[
\begin{split}
 \psi_\xi&=1+\xi A+\xi^2 B^{\rm vac}+O_{H^k,L}(\xi^3),
   \qquad A=S/3,\\
 H_0B^{\rm vac}&=(S^2-M)/3,
   \qquad \int B^{\rm vac}=-M/18,\\
 B^{\rm vac}&=-\frac M{18}+\sum_p\frac{Y_p}{24}
 +\sum_{\{p,q\}\,\text{edge-disjoint}}\frac{W_pW_q}{9}
 +\sum_{\{p,q\}\,\text{adjacent}}
       \left(\frac4{27}Z_{pq,0}+\frac4{39}Z_{pq,1}\right),\\
 e(\xi)&=-\frac M3\xi^2+O_L(\xi^4).
\end{split}
\tag{3.3}
\]
The third line follows by expanding \(S^2-M\) into the repeated-face
terms and twice every distinct unordered pair, and dividing by the
energies in (3.2). The bottom coefficient is
\(-\langle S,A\rangle=-M/3\). The even remainder follows from the
parity proved below.

Let \(\mathscr D=R_3SP:\mathcal P\to\mathcal P^\perp\). For any
\(x=\sum_px_pW_p\), table (3.2) gives its entire value:
\[
\begin{split}
 \mathscr D x={}&-\frac13\sum_px_p
 +\frac15\sum_px_pY_p
 +\frac13\sum_{\{p,q\}\,\text{edge-disjoint}}(x_p+x_q)W_pW_q\\
 &+\sum_{\{p,q\}\,\text{adjacent}}(x_p+x_q)
           \left(\frac23Z_{pq,0}+\frac27Z_{pq,1}\right).
\end{split}
\tag{3.4}
\]
Differentiating \(P_\xi^2=P_\xi\) gives \(PP'_0P=0\).
Differentiating (2.5) therefore gives \(PV'_0=0\). The derivative of
the intertwining equation \(K_\xi V_\xi=V_\xi B_\xi\), projected
onto \(\mathcal P^\perp\), gives \(V'_0=\mathscr D\). Its
second-order projection onto \(\mathcal P\) gives
\[
 B_\xi=3I-\xi^2PSR_3SP+O_L(\xi^3).
\tag{3.5}
\]
The first-order projected term vanishes: the central link cochain
\(z_i(n)=(-1)^{\sum_{j<i}n_j}I\) changes the sign of every face.
It defines a Haar unitary involution \(\mathcal Z\) commuting with all
\(E_e\), gauge transformations, and native translations. It fixes 1
and is \(-I\) on \(\mathcal P\); hence \(PSP=0\).
The same cochain proves
\[
\begin{gathered}
 K_{-\xi}=\mathcal ZK_\xi\mathcal Z,\quad
 \psi_{-\xi}=\mathcal Z\psi_\xi,\quad e(-\xi)=e(\xi),\quad
 P_{-\xi}=\mathcal ZP_\xi\mathcal Z,\\
 T_{-\xi}=T_\xi,\qquad V_{-\xi}=-\mathcal ZV_\xi,
 \qquad B_{-\xi}=B_\xi.
\end{gathered}
\tag{3.6}
\]
Thus the odd matrix coefficients in (3.5) vanish without choosing labels
inside a degenerate eigenspace.

Define the actual open-box face adjacency matrix \(A_L^{\rm face}\) by
shared-edge adjacency, its degrees \(d_p\), and
\[
 Q_L=\operatorname{diag}(d_p)+A_L^{\rm face},\qquad
 F_L=\frac7{15}I-\frac1{21}Q_L.
\tag{3.7}
\]
We identify matrices on \(\ell^2(\mathsf P_L)\) with matrices on
\(\mathcal P\) by the exact unitary
\(\mathcal Jx=\sum_px_pW_p\), justified by (2.1).
The constant channel in \(-PSR_3SP\) contributes \(+1/3\) to every
matrix entry. A repeated face contributes \(-1/5\) to its diagonal.
Each edge-disjoint pair contributes \(-1/3\) to its two diagonals and
two mutual off-diagonals. Each adjacent pair contributes to that same
four-entry pattern
\[
 -\frac{1/4}{9/2-3}-\frac{3/4}{13/2-3}
 =-\frac16-\frac3{14}=-\frac8{21}.
\tag{3.8}
\]
Hence its diagonal is
\(1/3-1/5-(M-1-d_p)/3-8d_p/21
=7/15-M/3-d_p/21\); its off-diagonal is \(-1/21\) for adjacent
faces and zero otherwise. Adding the actual vacuum subtraction \(M/3\)
in (3.3) proves
\[
 B_\xi-e(\xi)I=3I+\xi^2F_L+\mathcal R_\xi,
 \qquad \|\mathcal R_\xi\|\le\frac73 r_L^{-4}|\xi|^4
 \quad (|\xi|\le r_L/2).
\tag{3.9}
\]
Here is also the bound's proof. The binomial series in (2.5) bounds
\(\|T_\xi^{-1/2}\|\le\sqrt{7/6}\); the contour for
\(B_\xi-3I\) gives norm at most
\((7/6)(3/4)^2(32/21)=1\). The bottom contour \(|z|=3/4\) gives
\(|e(\xi)|\le3/4\). Thus the even analytic matrix
\(B_\xi-e(\xi)I-3I\) has norm at most \(7/4\) on \(|\xi|=r_L\).
Cauchy's estimate and a geometric series bound its terms of degree at
least four by \((7/4)\sum_{k\ge2}(|\xi|/r_L)^{2k}
\le(7/3)r_L^{-4}|\xi|^4\). The contour and binomial inequalities are
strict at their singularity thresholds, so analyticity extends to a
neighborhood of that circle and the Cauchy estimate is legitimate.

For every face vector \(x\),
\(\langle x,Q_Lx\rangle=\sum_{\{p,q\}\,\text{adjacent}}|x_p+x_q|^2\).
Every edge has at most four incident faces, so \(d_p\le12\).
Therefore \(0\le Q_L\le24I\) as quadratic forms, by
\(|x_p+x_q|^2\le2|x_p|^2+2|x_q|^2\). In particular
\(\operatorname{spec}(F_L)\subset[-71/105,7/15]\), with each exact
coefficient energy \(7/15-q/21\) corresponding to a spectral value
\(q\) of the same finite \(Q_L\).

## 4. Transport of the actual magnetic variance vector

Define the original face weights
\[
 a_p=\frac14\sum_{e\in\partial p}w_e,
 \qquad \mathbf a=\sum_pa_pW_p=\mathcal J(a_p)_p.
\tag{4.1}
\]
In all three planes their exact values are
\[
 a_{n;1,2}=\frac{n_2^2+(n_2+1)^2}{4},\qquad
 a_{n;1,3}=\frac{n_2^2}{2},\qquad a_{n;2,3}=0.
\tag{4.2}
\]
Since each boundary link of \(W_p\) has Casimir \(3/4\),
\(\Gamma W_p=3a_pW_p\), so \(\Gamma A=\mathbf a\).
The vacuum scalar in (1.9) is
\[
 \gamma_\xi=\frac{\xi^2}{3}\sum_pa_p+O_L(\xi^4),
\tag{4.3}
\]
because \(\Gamma1=0\),
\(\langle A,\Gamma A\rangle=\sum_pa_p/3\), and (3.6) makes the
scalar even. Let
\(\mathbf t=\Gamma B^{\rm vac}-(\sum_pa_p)/3\). Then
\[
 v_\xi=\xi\mathbf a+\xi^2\mathbf t+O_{H^k,L}(\xi^3).
\tag{4.4}
\]
To spell out every coefficient, put \(s_{pq}=a_p+a_q\) for a pair
and let \(w_e\) retain its original value on its shared edge. Its
weighted electric eigenvalues are
\[
\begin{array}{c|cccc}
 \text{vector}&Y_p&W_pW_q\ (\text{edge-disjoint})&Z_{pq,0}&Z_{pq,1}\\\hline
 \Gamma\text{ eigenvalue}&8a_p&3s_{pq}&3s_{pq}-3w_e/2&3s_{pq}+w_e/2.
\end{array}
\tag{4.5}
\]
For the shared edge, \(3s_{pq}\) counts its two fundamental values
as \(3w_e/2\). Replacing these by spin zero subtracts \(3w_e/2\);
replacing them by spin one adds \(w_e/2\). This proves the last two
entries, including direction-2 and direction-3 shared edges where
\(w_e=0\). Inserting (4.5) into (3.3) proves
\[
\begin{split}
 \mathbf t={}&-\frac13\sum_pa_p+\sum_p\frac{a_p}{3}Y_p
 +\sum_{\{p,q\}\,\text{edge-disjoint}}\frac{s_{pq}}3 W_pW_q\\
 &+\sum_{\{p,q\}\,\text{adjacent}}
 \left[\frac{4s_{pq}-2w_e}{9}Z_{pq,0}
       +\frac{12s_{pq}+2w_e}{39}Z_{pq,1}\right].
\end{split}
\tag{4.6}
\]

The exact transported magnetic coordinates and exact remainder are
\[
 y_\xi=V_\xi^*v_\xi=V_\xi^*\Gamma\psi_\xi\in\mathcal P,
 \qquad \rho_\xi=(I-P_\xi)v_\xi\in\mathcal H_{\rm phys},
 \qquad v_\xi=V_\xi y_\xi+\rho_\xi.
\tag{4.7}
\]
The equality dropping the scalar in \(y_\xi\) follows from the exact
identity \(V_\xi^*\psi_\xi=0\); no free-vacuum orthogonality is
substituted. Both summands are orthogonal to \(\psi_\xi\), and the
two summands are mutually orthogonal. The first lies in the actual band,
the second in its orthogonal complement with its ground-state component
exactly zero. These maps are defined on all smooth vectors here, and
\(V_\xi^*\) also extends boundedly to the whole Hilbert space.

Equations (3.4), (4.4), and \(P\mathbf t=0\) give
\[
\begin{split}
 y_\xi&=\xi\mathbf a+O_L(\xi^3),\\
 P_\xi v_\xi&=\xi\mathbf a+\xi^2\mathscr D\mathbf a
                             +O_{H^k,L}(\xi^3),\\
 \rho_\xi&=\xi^2\mathbf r+O_{H^k,L}(\xi^3),
 \qquad \mathbf r=\mathbf t-\mathscr D\mathbf a.
\end{split}
\tag{4.8}
\]
For the first line, \(V_\xi=I+\xi\mathscr D+O(\xi^2)\),
\(\mathscr D\mathbf a\perp\mathcal P\), and \(P\mathbf t=0\)
remove the quadratic term. Alternatively (3.6),
\(v_{-\xi}=\mathcal Z v_\xi\), and \(V_{-\xi}=-\mathcal ZV_\xi\)
give the exact odd identity \(y_{-\xi}=-y_\xi\). Every other
remainder assertion in (4.8) is in the fixed Sobolev norm indicated,
using (2.8) and finite-rank elliptic regularity for \(V_\xi\).

Subtracting the full expressions (3.4) and (4.6) gives
\[
\boxed{
 \mathbf r=\sum_p\frac{2a_p}{15}Y_p
 +\sum_{\{p,q\}\,\text{adjacent}}
   \left[-\frac{2(s_{pq}+w_e)}9Z_{pq,0}
         +\frac{2(3s_{pq}+7w_e)}{273}Z_{pq,1}\right].}
\tag{4.9}
\]
The two constants both equal \(-\sum_pa_p/3\) and cancel. The
edge-disjoint coefficients both equal \(s_{pq}/3\) and cancel.
The repeated coefficient is \(a_p(1/3-1/5)=2a_p/15\).
The adjacent coefficients are
\((4s-2w)/9-2s/3=-2(s+w)/9\) and
\((12s+2w)/39-2s/7=2(3s+7w)/273\).
These calculations prove every retained and cancelled channel.
In particular the exact physical band is not obtained by projecting with
the free \(P\): its constant, repeated-face, edge-disjoint, and both
adjacent-face dressings in (3.4) all enter before the subtraction.

Write the following exact nonnegative finite sums:
\[
\begin{split}
 \mathsf N_L&=\|\mathbf a\|^2=\sum_pa_p^2,\\
 \mathsf R_{8,L}&=\frac4{225}\mathsf N_L,\\
 \mathsf R_{9/2,L}&=\frac1{81}
      \sum_{\{p,q\}\,\text{adjacent}}(s_{pq}+w_e)^2,\\
 \mathsf R_{13/2,L}&=\frac1{24843}
      \sum_{\{p,q\}\,\text{adjacent}}(3s_{pq}+7w_e)^2,\\
 \mathsf R_L&=\mathsf R_{8,L}+\mathsf R_{9/2,L}+\mathsf R_{13/2,L}.
\end{split}
\tag{4.10}
\]
The coefficient \(1/24843\) is
\((3/4)\cdot4/273^2\). Orthogonality and (3.2) prove
\(\|\mathbf r\|^2=\mathsf R_L\). In particular
\(\mathsf R_L\ge4\mathsf N_L/225>0\), since (4.2) has positive
12-face entries. From coupling parity and (4.8),
\[
\begin{split}
 \|v_\xi\|^2&=\xi^2\mathsf N_L+O_L(\xi^4),\qquad
 \|P_\xi v_\xi\|^2=\xi^2\mathsf N_L+O_L(\xi^4),\\
 \|\rho_\xi\|^2&=\xi^4\mathsf R_L+O_L(\xi^6),
 \qquad \|\rho_\xi\|=\xi^2\sqrt{\mathsf R_L}+O_L(\xi^4),\\
 \frac{\|\rho_\xi\|^2}{\|v_\xi\|^2}
   &=\xi^2\frac{\mathsf R_L}{\mathsf N_L}+O_L(\xi^4)
       \quad (\xi\downarrow0).
\end{split}
\tag{4.11}
\]
Indeed \(\rho_{-\xi}=\mathcal Z\rho_\xi\); its squared norm is
even analytic, so its possible fifth coefficient vanishes. The square
root estimate follows because \(\mathsf R_L>0\). The divisions use
\(\mathsf N_L>0\) at this fixed box.

The mass \(\mathsf N_L\) retains the explicit original polynomial:
\[
\boxed{
 \mathsf N_L=\frac{L^2(2L+1)}{60}
       (24L^4+24L^3+8L^2-4L+3).}
\tag{4.12}
\]
To prove it directly, for each \(m=n_2\) there are \(2L(2L+1)\)
12-faces and \(4L^2\) 13-faces. Put \(r_m=m^2+m+1/2\), so the
two coefficients are \(r_m/2\) and \(m^2/2\). Hence
\[
 \mathsf N_L=\frac14\left[
 2L(2L+1)\sum_{m=-L}^{L-1}r_m^2
 +4L^2\sum_{m=-L}^Lm^4\right].
\tag{4.13}
\]
The exact sums are
\(\sum_{m=-L}^{L-1}r_m^2=L(4L^4+1)/10\) and
\(\sum_{m=-L}^Lm^4=L(L+1)(2L+1)(3L^2+3L-1)/15\).
The first polynomial has value \(1/2\) at \(L=1\) and increment
\(2(L^2+L+1/2)^2\); the second has value 2 and increment
\(2(L+1)^4\). These are exactly the endpoint increments of the
respective sums, proving them by induction. Substitution proves (4.12).
The distinct sum needed in (4.3) is
\[
 \sum_pa_p=\frac{L^2(2L+1)(4L^2+2L+1)}3.
\tag{4.14}
\]
Its proof uses the same counts and the sums
\(\sum_{m=-L}^{L-1}r_m=L(2L^2+1)/3\) and
\(\sum_{m=-L}^Lm^2=L(L+1)(2L+1)/3\), each verified by its value
at 1 and its two endpoint increments.

## 5. Finite angles retain further nonlinear channels

The exact map (4.7) extends without a small-angle approximation:
\[
 z_{\xi,\theta}=V_\xi^*\chi_{\xi,\theta}
                =V_\xi^*\mathcal C_\theta\psi_\xi,
 \qquad
 \chi_{\xi,\theta}=V_\xi z_{\xi,\theta}
                     +(I-P_\xi)\chi_{\xi,\theta}.
\tag{5.1}
\]
Both terms are orthogonal to the actual vacuum. These exact expressions,
with (1.7)--(1.8), retain all higher electric representations of that
vacuum. In particular no replacement of \(\psi_\xi\) by its free
constant term is made in the map.

We can also exhibit every channel of its second coupling coefficient at
an arbitrary fixed angle. Set
\[
 \alpha_p=\prod_{e\in\partial p,\ e=(n,1)}\cos(\theta n_2),
 \qquad \beta_p=\prod_{e\in\partial p,\ e=(n,1)}c_1(\theta n_2),
 \qquad u_p(\theta)=\frac{\alpha_p-1}{3}.
\tag{5.2}
\]
Thus \(\alpha_{12}=\cos(n_2\theta)\cos((n_2+1)\theta)\),
\(\alpha_{13}=\cos^2(n_2\theta)\), and \(\alpha_{23}=1\).
For adjacent \(p,q\) sharing \(e\), let
\[
 k_{pq,j}(\theta)=
 \prod_{f\in\partial p\mathbin\triangle\partial q,\ f=(n,1)}
                     \cos(\theta n_2)
 \times
 \begin{cases}c_j(\theta n_2(e)),&e\text{ is direction 1},\\1,&\text{otherwise},\end{cases}
 \qquad j=0,1.
\tag{5.3}
\]
These are the exact multipliers of \(Z_{pq,j}\); (1.8) and their
joint spins prove this assertion. The multiplier of an edge-disjoint
product is \(\alpha_p\alpha_q\), and that of \(Y_p\) is \(\beta_p\).
Every product includes its original source coordinate.

The vacuum overlap has coefficient
\(c_{\xi,\theta}=1+\xi^2\sum_p(\alpha_p-1)/9+O_L(\xi^4)\),
as follows by inserting (3.3), using the mean of \(B^{\rm vac}\),
and \(\langle A,\mathcal C_\theta A\rangle=\sum_p\alpha_p/9\).
Therefore
\[
 z_{\xi,\theta}=\xi\sum_pu_p(\theta)W_p+O_{L,\theta}(\xi^3),
 \qquad
 (I-P_\xi)\chi_{\xi,\theta}
       =\xi^2\mathbf r_\theta+O_{H^k,L,\theta}(\xi^3),
\tag{5.4}
\]
where the complete finite sum is
\[
\begin{split}
 \mathbf r_\theta={}&
 \sum_p\left[\frac{\beta_p-1}{24}-\frac{u_p}{5}\right]Y_p\\
 &+\sum_{\{p,q\}\,\text{edge-disjoint}}
       \frac{(\alpha_p-1)(\alpha_q-1)}9 W_pW_q\\
 &+\sum_{\{p,q\}\,\text{adjacent}}
   \left[\frac4{27}(k_{pq,0}-1)-\frac23(u_p+u_q)\right]Z_{pq,0}\\
 &+\sum_{\{p,q\}\,\text{adjacent}}
   \left[\frac4{39}(k_{pq,1}-1)-\frac27(u_p+u_q)\right]Z_{pq,1}.
\end{split}
\tag{5.5}
\]
To prove it, the second centered coefficient is
\((\mathcal C_\theta-I)B^{\rm vac}
 -[\sum_p(\alpha_p-1)/9]1\). Subtract the entire dressing
\(\mathscr D\sum_pu_pW_p\) from (3.4). Its constant equals the same
\(-\sum_p(\alpha_p-1)/9\) and cancels. The other coefficients are
exactly those displayed. In particular the edge-disjoint coefficient is
\((\alpha_p\alpha_q-1)/9-(\alpha_p+\alpha_q-2)/9\), proving its
displayed product, which need not vanish at a finite angle.

Finally (1.10) applied to each of these finitely many smooth channels,
or the explicit character Taylor expansion, proves
\[
 \sum_pu_p(\theta)W_p=-\frac23\theta^2\mathbf a+O_{H^k,L}(\theta^4),
 \qquad \mathbf r_\theta=-\frac23\theta^2\mathbf r+O_{H^k,L}(\theta^4).
\tag{5.6}
\]
The finite-angle edge-disjoint terms are of order \(\theta^4\) here;
their absence in (4.9) follows from their proved angular order. They are
present in the exact state and in (5.5).

## 6. Full leading first-band spectral measure

For real \(0<\xi\le r_L/2\), define the exact first-band coefficient
matrix and the physical energy map
\[
 C_\xi=\frac{B_\xi-e(\xi)I-3I}{\xi^2},\qquad
 t_\xi(\lambda)=\frac{\lambda/\kappa-3}{\xi^2},\qquad
 s_\xi(c)=\kappa(3+\xi^2c).
\tag{6.1}
\]
These are mutually inverse affine maps between physical excitation
energy and its second coupling coefficient. Their \(\kappa\) is the
same coefficient in (1.2); no rescaled physical Hamiltonian is substituted.
Equation (3.9) gives the explicit norm estimate
\[
 \|C_\xi-F_L\|\le\frac73r_L^{-4}\xi^2.
\tag{6.2}
\]

Let \(E^{Q_L}_q\) be the orthogonal projection onto the eigenspace of
the finite real symmetric \(Q_L\) with eigenvalue \(q\), and define
the exact finite measures
\[
 \mu_L^a=\sum_{q\in\operatorname{spec}Q_L}
          \|E^{Q_L}_q(a_p)_p\|_{\ell^2}^2\,\delta_q,
 \qquad
 \eta_L^a=\left(q\mapsto\frac7{15}-\frac q{21}\right)_*\mu_L^a.
\tag{6.3}
\]
Repeated eigenvalues are handled by the entire eigenspace projection,
so these definitions do not depend on choices of eigenvectors. Their
total mass is \(\mathsf N_L\), not 1, by completeness. Formula (3.7)
and the unitary \(\mathcal J\) prove the exact coefficient-observable
identity
\[
 \int f(c)\,d\eta_L^a(c)
 =\langle\mathbf a,f(F_L)\mathbf a\rangle
 =\sum_q\|E^{Q_L}_q(a_p)_p\|^2f\!\left(\frac7{15}-\frac q{21}\right).
\tag{6.4}
\]

For the actual state define its physical first-band measure by
\[
 \mu^{\rm band}_{\xi,\theta}(J)
 =\langle P_\xi\chi_{\xi,\theta},
             1_J(\mathscr A_\xi)P_\xi\chi_{\xi,\theta}\rangle
 \quad (J\text{ Borel in }\mathbb R).
\tag{6.5}
\]
Equations (2.7) and (5.1) give its exact pushforward, at every angle,
\[
 (t_\xi)_*\mu^{\rm band}_{\xi,\theta}(J)
     =\langle z_{\xi,\theta},1_J(C_\xi)z_{\xi,\theta}\rangle,
 \qquad
 \mu^{\rm band}_{\xi,\theta}
     =(s_\xi)_*\mu_{C_\xi,z_{\xi,\theta}}.
\tag{6.6}
\]
Here \(\mu_{C,z}(J)=\langle z,1_J(C)z\rangle\). This is the exact
map of both the actual vector and all its first-band observables.

For every bounded continuous function \(f:\mathbb R\to\mathbb C\),
the complete leading statement in the requested order of limits is
\[
\boxed{
 \lim_{\xi\downarrow0}\frac1{\xi^2}
 \left[\lim_{\theta\to0}\frac9{4\theta^4}
  \int f\bigl(t_\xi(\lambda)\bigr)
             \,d\mu^{\rm band}_{\xi,\theta}(\lambda)\right]
 =\int f(c)\,d\eta_L^a(c).}
\tag{6.7}
\]
Indeed (1.10) and boundedness of the relevant finite-dimensional
functional calculus give the inner limit as
\(\langle y_\xi,f(C_\xi)y_\xi\rangle\). Dividing by \(\xi^2\),
the vector tends to \(\mathbf a\) by (4.8), and
\(f(C_\xi)\to f(F_L)\) in matrix norm by (6.2). To justify the last
assertion without a differentiability assumption on \(f\), all spectra
are eventually in one compact interval. Approximate the restriction of
the real and imaginary parts of \(f\) uniformly by polynomials. Polynomial
functional calculus is continuous in the matrix entries; spectral
calculus bounds each uniform approximation error by its scalar supremum.
First pass \(\xi\to0\), then let that error tend to zero. This proves
(6.7) for precisely the stated bounded-continuous class. No estimate of
order \(\xi^2\) for an arbitrary continuous \(f\) is asserted.

Equivalently, keeping the actual norm as the denominator gives
\[
 \lim_{\xi\downarrow0}\left[\lim_{\theta\to0}
 \frac{\displaystyle\int f(t_\xi(\lambda))
                     \,d\mu^{\rm band}_{\xi,\theta}(\lambda)}
      {\|\chi_{\xi,\theta}\|^2}\right]
       =\frac1{\mathsf N_L}\int f(c)\,d\eta_L^a(c).
\tag{6.8}
\]
This is an explicitly defined probability comparison derived by division
of (6.7) and the independently retained mass formula; it does not alter
the original state or discard its amplitude.

The physical coefficient locations, with every original scale substituted,
are
\[
 \kappa\left[3+\xi^2\left(\frac7{15}-\frac q{21}\right)\right]
 =\frac{6g_{\rm YM}^2}{a}
  +\frac1{8g_{\rm YM}^6a}\left(\frac7{15}-\frac q{21}\right).
\tag{6.9}
\]
Equation (6.6) is the exact physical pushforward; (6.7) resolves its
leading coefficient measure at every \(q\), including all its weights.
Individual eigenvalues of the actual band differ from the ordered
coefficient predictions by at most
\(\kappa(7/3)r_L^{-4}\xi^4\), by (3.9) and min--max. Within a
degenerate coefficient eigenspace higher orders may split eigenvalues;
the spectral measure formulation retains their aggregate limiting weight
without making an unsupported choice of split eigenvectors.

For fixed \(\kappa>0\), without coefficient resolution one also gets
\[
 \lim_{\xi\downarrow0}\frac1{\xi^2}
 \left[\lim_{\theta\to0}\frac9{4\theta^4}
            \int f(\lambda)\,d\mu^{\rm band}_{\xi,\theta}(\lambda)\right]
 =\mathsf N_L f(3\kappa).
\tag{6.10}
\]
If \(\kappa\) varies with the original \(g_{\rm YM},a\) while
\(\xi\to0\), (6.6)--(6.9) remain the applicable exact pushforward and
coefficient statements; (6.10) specifically requires fixed \(\kappa\).

## 7. Out-of-band order and its leading physical spectral measure

Set \(\chi^{\rm out}_{\xi,\theta}=(I-P_\xi)\chi_{\xi,\theta}\).
It is smooth, orthogonal to the actual vacuum and to the entire actual
first band. At each fixed positive \(\xi\) in the band interval,
(1.10) proves
\[
 \lim_{\theta\to0}\frac9{4\theta^4}
          \|\chi^{\rm out}_{\xi,\theta}\|^2=\|\rho_\xi\|^2,
 \qquad
 \lim_{\theta\to0}\frac9{4\theta^4}
          \|\chi_{\xi,\theta}\|^2=\|v_\xi\|^2.
\tag{7.1}
\]
Therefore the precise nonzero leading out-of-band norm is
\[
\boxed{
 \lim_{\xi\downarrow0}\frac1{\xi^4}
 \left[\lim_{\theta\to0}\frac9{4\theta^4}
               \|\chi^{\rm out}_{\xi,\theta}\|^2\right]=\mathsf R_L>0,}
\tag{7.2}
\]
and its retained fraction is
\[
 \lim_{\theta\to0}
   \frac{\|\chi^{\rm out}_{\xi,\theta}\|^2}{\|\chi_{\xi,\theta}\|^2}
  =\xi^2\frac{\mathsf R_L}{\mathsf N_L}+O_L(\xi^4).
\tag{7.3}
\]
In unsquared norms the ordered leading amplitude is
\((2/3)\theta^2\xi^2\sqrt{\mathsf R_L}\); for the whole state it
is \((2/3)\theta^2\xi\sqrt{\mathsf N_L}\), with \(\xi>0\).
More precisely, first
\(\lim_{\theta\to0}3\|\chi^{\rm out}_{\xi,\theta}\|/(2\theta^2)
=\|\rho_\xi\|\), and then use (4.11). These are ordered limits,
so no unstated uniformity in \(L,\theta,\xi\) is used.

Define \(\mu^{\rm out}_{\xi,\theta}\) by (6.5) with
\(P_\xi\chi\) replaced by \(\chi^{\rm out}\). For fixed \(\kappa\)
and every bounded continuous \(f\), its full leading measure is
\[
\boxed{
 \lim_{\xi\downarrow0}\frac1{\xi^4}
 \left[\lim_{\theta\to0}\frac9{4\theta^4}
     \int f(\lambda)\,d\mu^{\rm out}_{\xi,\theta}(\lambda)\right]
 =\mathsf R_{8,L}f(8\kappa)
  +\mathsf R_{9/2,L}f(9\kappa/2)
  +\mathsf R_{13/2,L}f(13\kappa/2).}
\tag{7.4}
\]
If physical \(\kappa\) varies, replace the test in the integrand by
\(f(\lambda/\kappa)\); the right side then has arguments
\(8,9/2,13/2\). This is its exact dimensionless-to-physical pushforward.

Here is a proof of the functional-calculus limit, including its high-energy
tail. Put \(u_\xi=\rho_\xi/\xi^2\). By (4.8),
\(u_\xi\to\mathbf r\) in \(H^2\), and
\((K_\xi-e(\xi))u_\xi\to H_0\mathbf r\) in Hilbert norm.
Thus these vectors have uniformly bounded norm and uniformly bounded
second spectral moment. For a real spectral cutoff \(R>0\), the
spectral mass at \(|\lambda|>R\) of either vector is bounded by its
second moment divided by \(R^2\). Also \(K_\xi-e(\xi)\) converges
in norm resolvent to \(H_0\): their difference
\(-\xi S-e(\xi)I\) is bounded with norm tending to zero, and the
resolvent identity proves convergence at a nonreal spectral parameter.
The algebra generated by resolvents and their conjugates is uniformly
dense in \(C_0(\mathbb R)\): it separates real points, is closed under
conjugation, and is nonzero at each real point. Uniform approximation
therefore proves norm convergence of \(f_0(K_\xi-e(\xi))\) for
every \(f_0\in C_0(\mathbb R)\). For a general bounded continuous
\(f\), multiply by a continuous compactly supported cutoff equal to 1
on \([-R,R]\). The discarded expectation is at most
\(\|f\|_\infty\) times the just-proved tail mass. First use
\(u_\xi\to\mathbf r\) and the \(C_0\) convergence, and then let
\(R\to\infty\). This proves convergence for the claimed class.
Finally (4.9), orthogonality, and (3.2) give exactly the three masses
and arguments in (7.4). The angular inner limit follows independently
from (1.10) and boundedness of \(f(\mathscr A_\xi)\).

Since the exact band projection commutes with the full Hamiltonian,
the full state measure is the sum
\(\mu^{\rm band}_{\xi,\theta}+\mu^{\rm out}_{\xi,\theta}\),
with no cross term for any Borel set. Equations (6.7) and (7.2) show
that its first-band coefficient limit also holds when the full state
measure is used on the left of (6.7): the absolute contribution of
the omitted component, after the displayed angular and \(\xi^2\)
divisions, is bounded by
\(\|f\|_\infty\|\rho_\xi\|^2/\xi^2=O_L(\xi^2)\).
This remains true although \(t_\xi\) sends its higher energies to
large coefficient values; boundedness of the test function is the
precise hypothesis controlling that contribution.

There is also a direct finite-box two-parameter norm estimate, without
taking a volume limit. On a sufficiently small rectangle of real
\((\xi,\theta)\) around zero,
\[
\begin{split}
 z_{\xi,\theta}
   &=-\frac23\xi\theta^2\mathbf a
      +O_L(|\xi|^3\theta^2+|\xi|\theta^4),\\
 \chi^{\rm out}_{\xi,\theta}
   &=-\frac23\xi^2\theta^2\mathbf r
      +O_{H^k,L}(|\xi|^3\theta^2+\xi^2\theta^4).
\end{split}
\tag{7.5}
\]
In particular its out-of-band norm is \(O_L(\xi^2\theta^2)\).
Here is the joint remainder justification. By (2.8), the vacuum and its
\(\xi\)-derivatives are bounded in each needed higher Sobolev space
on a smaller closed coupling interval. Averaged translation has bounded
derivatives through order four from \(H^{k+4}\) to \(H^k\), uniformly
on a closed angle interval. The expressions in (5.1) therefore have the
corresponding bounded mixed derivatives. They are even in \(\theta\)
and identically zero at \(\theta=0\). The out-of-band expression and
its first \(\xi\)-derivative vanish at \(\xi=0\) for every angle,
by (5.4). Taylor's integral formula in \(\xi\) factors out \(\xi^2\);
Taylor's formula in \(\theta\) then factors out \(\theta^2\), with
a fourth-order angular remainder. The remaining coefficient at
\(\xi=0\) is (5.5), whose second angular coefficient is (5.6).
This proves the second line, including its mixed remainder factors.
The transported coordinate is odd in \(\xi\), by (3.6), so the
same argument factors its coupling remainder as \(\xi^3\) and
proves the first line. All constants here still depend on the fixed
original box; (7.5) does not assert a uniform volume estimate.

The physical amplitude factors in (6.7) and (7.2) are respectively
\[
 \frac49\theta^4\xi^2=\frac{\theta^4}{36g_{\rm YM}^8},
 \qquad
 \frac49\theta^4\xi^4=\frac{\theta^4}{576g_{\rm YM}^{16}},
 \qquad \theta^4=\frac{16\pi^4a^8}{D^4}.
\tag{7.6}
\]
These multiply \(\mathsf N_L\) and \(\mathsf R_L\) in the respective
ordered leading squared norms. None of those factors is absorbed into
the graph vector or the physical energy scale.

## 8. Scope of the coefficient map

Equations (1.7), (2.5), (4.7), (5.1), and (6.6) give exact maps from
the specified continuous magnetic background to the actual physical
state, its first interacting spectral subspace, and all its spectral
observables. The full leading coefficient measure is precisely the
pushforward (6.3), with the original polynomial vector (4.2). The
out-of-band contribution has the explicitly positive coefficient (4.10)
and the three leading physical energies (7.4); all finite-angle nonlinear
channels are retained in (5.5) and in the exact class operator (1.7).

Every asymptotic assertion above fixes \(L\) first. The sufficient
spectral interval is \(0<\xi\le3/(128M)\), and the explicit matrix
remainder constant grows as \(M^4\). No joint continuum convergence,
fixed-positive-coupling infinite-volume convergence, or exchange of these
limits is used. A separate limit of the completely specified finite graph
measure \(\mu_L^a\) can be pushed through the affine map in (6.3);
the exact quantum statement established here is the displayed angular-first,
coupling-second limit at every fixed original box.

The companion exact checker
[check_native_magnetic_physical_band_transport.py](check_native_magnetic_physical_band_transport.py)
constructs the original link and face incidence sets, checks the plane
weights and polynomial mass, independently divides the vacuum channel
coefficients by their electric energies, subtracts every spectral dressing
denominator, and verifies both shared-edge coefficients and their angular
factors using rational arithmetic. It also evaluates all finite-angle
second-order channels at \(\theta=\pi/3\) for \(L=2\), including
the nonzero edge-disjoint terms. The analytic and spectral arguments are
the proofs above; these arithmetic checks supplement them.

```

## Complete source: wilson_variation/check_native_magnetic_physical_band_transport.py

```python
"""Exact finite-incidence and channel checks; no vacuum simulation or Lean.

Uses only the standard library and prints results without creating files.
The analytic spectral theorem is proved in the companion Markdown source.
"""

from collections import defaultdict
from fractions import Fraction as F
from itertools import combinations, product


def add(n, i):
    return tuple(x + (j == i) for j, x in enumerate(n))


def box(L):
    vertices = list(product(range(-L, L + 1), repeat=3))
    edges = [(n, i) for n in vertices for i in range(3) if n[i] < L]
    faces = {}
    for n in vertices:
        for i, j in combinations(range(3), 2):
            if n[i] < L and n[j] < L:
                faces[(n, i, j)] = ((n, i), (add(n, i), j),
                                     (add(n, j), i), (n, j))
    incident = defaultdict(list)
    for p, boundary in faces.items():
        for e in boundary:
            incident[e].append(p)
    w = {e: e[0][1] ** 2 if e[1] == 0 else 0 for e in edges}
    a = {p: F(sum(w[e] for e in boundary), 4)
         for p, boundary in faces.items()}
    adjacent = [(p, q, e) for e, ps in incident.items()
                for p, q in combinations(ps, 2)]
    assert len({frozenset((p, q)) for p, q, _ in adjacent}) == len(adjacent)
    assert len(edges) == 3 * (2 * L) * (2 * L + 1) ** 2
    assert len(faces) == 3 * (2 * L) ** 2 * (2 * L + 1)
    assert len(adjacent) == 144 * L ** 3 - 12 * L
    for (n, i, j), ap in a.items():
        expected = (F(n[1] ** 2 + (n[1] + 1) ** 2, 4)
                    if (i, j) == (0, 1) else
                    F(n[1] ** 2, 2) if (i, j) == (0, 2) else F(0))
        assert ap == expected
    return faces, w, a, adjacent


def multiply(values):
    out = F(1)
    for value in values:
        out *= value
    return out


def cos_pi_over_3(m):
    return (F(1), F(1, 2), F(-1, 2), F(-1), F(-1, 2), F(1, 2))[m % 6]


def char_ratio(j, m):
    if j == 0:
        return F(1)
    if j == F(1, 2):
        return cos_pi_over_3(m)
    assert j == 1
    return (1 + 2 * cos_pi_over_3(2 * m)) / 3


def check_box(L):
    faces, w, a, adjacent = box(L)
    norm_a = sum((ap ** 2 for ap in a.values()), F(0))
    sum_a = sum(a.values(), F(0))
    poly_n = F(L ** 2 * (2 * L + 1), 60) * (
        24 * L ** 4 + 24 * L ** 3 + 8 * L ** 2 - 4 * L + 3)
    poly_s = F(L ** 2 * (2 * L + 1) * (4 * L ** 2 + 2 * L + 1), 3)
    assert norm_a == poly_n
    assert sum_a == poly_s
    r8 = F(0)
    r0 = F(0)
    r1 = F(0)
    # Derive the vacuum second coefficient via its H_0 equation, then
    # subtract the spectral dressing denominators independently.
    for p, boundary in faces.items():
        gamma_y = sum(2 * w[e] for e in boundary)
        assert gamma_y == 8 * a[p]
        vacuum_y = F(1, 3) / 8
        dressing_y = a[p] / (8 - 3)
        residual_y = gamma_y * vacuum_y - dressing_y
        assert residual_y == F(2, 15) * a[p]
        # Character second derivatives on every translated spin-one edge.
        beta_theta2 = sum((-F(4, 3) * w[e] for e in boundary), F(0))
        u_theta2 = -F(2, 3) * a[p]
        angular_residual_y = beta_theta2 / 24 - u_theta2 / 5
        assert angular_residual_y == -F(2, 3) * residual_y
        r8 += residual_y ** 2
    degrees = defaultdict(int)
    off_diagonal_weight = -F(1, 21)
    assert F(1, 3) - (F(1, 4) / F(3, 2) + F(3, 4) / F(7, 2)) == off_diagonal_weight
    for p, q, e in adjacent:
        degrees[p] += 1
        degrees[q] += 1
        boundary_outer = set(faces[p]) ^ set(faces[q])
        assert len(boundary_outer) == 6
        assert set(faces[p]) & set(faces[q]) == {e}
        s = a[p] + a[q]
        gamma0 = sum(F(3, 4) * w[f] for f in boundary_outer)
        gamma1 = gamma0 + 2 * w[e]
        assert gamma0 == 3 * s - F(3, 2) * w[e]
        assert gamma1 == 3 * s + F(1, 2) * w[e]
        residual0 = gamma0 * (F(2, 3) / F(9, 2)) - s / F(3, 2)
        residual1 = gamma1 * (F(2, 3) / F(13, 2)) - s / F(7, 2)
        assert residual0 == -F(2, 9) * (s + w[e])
        assert residual1 == F(2, 273) * (3 * s + 7 * w[e])
        outer_theta2 = sum((-F(1, 2) * w[f] for f in boundary_outer), F(0))
        k0_theta2 = outer_theta2
        k1_theta2 = outer_theta2 - F(4, 3) * w[e]
        u_theta2 = -F(2, 3) * s
        assert F(4, 27) * k0_theta2 - F(2, 3) * u_theta2 == -F(2, 3) * residual0
        assert F(4, 39) * k1_theta2 - F(2, 7) * u_theta2 == -F(2, 3) * residual1
        r0 += F(1, 4) * residual0 ** 2
        r1 += F(3, 4) * residual1 ** 2
    M = len(faces)
    for p in faces:
        d = degrees[p]
        assert d <= 12
        original_diag = F(1, 3) - F(1, 5) - F(M - 1 - d, 3) - F(8 * d, 21)
        assert original_diag + F(M, 3) == F(7, 15) - F(d, 21)
    assert r8 == F(4, 225) * norm_a
    assert r0 == sum((F(1, 81) * (a[p] + a[q] + w[e]) ** 2
                     for p, q, e in adjacent), F(0))
    assert r1 == sum((F(1, 24843) * (3 * (a[p] + a[q]) + 7 * w[e]) ** 2
                     for p, q, e in adjacent), F(0))
    assert r8 > 0 and r0 > 0 and r1 > 0
    return norm_a, r8, r0, r1


def check_finite_angle():
    # At theta=pi/3 every multiplier is rational; evaluate genuine link
    # products before subtracting the first-band dressing.
    faces, w, a, adjacent = box(2)
    alpha = {p: multiply(char_ratio(F(1, 2), e[0][1])
                         for e in b if e[1] == 0) for p, b in faces.items()}
    beta = {p: multiply(char_ratio(1, e[0][1])
                        for e in b if e[1] == 0) for p, b in faces.items()}
    u = {p: (alpha[p] - 1) / 3 for p in faces}
    c2 = sum(((alpha[p] - 1) / 9 for p in faces), F(0))
    assert -c2 == -sum(u.values(), F(0)) / 3
    for p in faces:
        assert (beta[p] - 1) / 24 - u[p] / 5 == (
            F(1, 24) * beta[p] - F(1, 24) - (alpha[p] - 1) / 15)
    adjacent_keys = {frozenset((p, q)) for p, q, _ in adjacent}
    nonzero_disjoint = 0
    for p, q in combinations(faces, 2):
        if frozenset((p, q)) in adjacent_keys:
            continue
        multiplier = multiply(char_ratio(F(1, 2), e[0][1])
                              for e in set(faces[p]) | set(faces[q]) if e[1] == 0)
        assert multiplier == alpha[p] * alpha[q]
        residual = (multiplier - 1) / 9 - (u[p] + u[q]) / 3
        assert residual == (alpha[p] - 1) * (alpha[q] - 1) / 9
        nonzero_disjoint += residual != 0
    assert nonzero_disjoint > 0
    for p, q, e in adjacent:
        outer = set(faces[p]) ^ set(faces[q])
        km_outer = multiply(char_ratio(F(1, 2), f[0][1]) for f in outer if f[1] == 0)
        k0 = km_outer
        k1 = km_outer * (char_ratio(1, e[0][1]) if e[1] == 0 else 1)
        for j, kj, E in [(0, k0, F(9, 2)), (1, k1, F(13, 2))]:
            vacuum_coefficient = F(2, 3) / E
            residual = vacuum_coefficient * (kj - 1) - (u[p] + u[q]) / (E - 3)
            expected = ((F(4, 27) * (k0 - 1) - F(2, 3) * (u[p] + u[q]))
                        if j == 0 else
                        (F(4, 39) * (k1 - 1) - F(2, 7) * (u[p] + u[q])))
            assert residual == expected
    return nonzero_disjoint


if __name__ == "__main__":
    for L in range(2, 6):
        N, R8, R0, R1 = check_box(L)
        print(f"L={L}: ||a||^2={N}; R8={R8}; R9/2={R0}; R13/2={R1}")
    count = check_finite_angle()
    print(f"Finite-angle L=2 check: {count} nonzero edge-disjoint channels retained.")
    print("PASS: exact native incidence, all second-order channels, angular factors, vacuum subtraction, and physical-band coefficients.")

```

## Complete source: ../ym_volume_uniform_astra_20260908/VOLUME_UNIFORM_LOCAL_VACUUM_ESTIMATES.md

```markdown
---
title: "Volume-independent local estimates in the full SU(2) Wilson vacuum"
date: "8 September 2026"
geometry: margin=25mm
header-includes:
  - \usepackage{mathrsfs}
---

# 1. Original Hamiltonian, physical state, and geometric input

Fix an integer \(L\ge2\). The vertices are
\(\mathsf V_L=\{-L,\ldots,L\}^3\). A physical link
\(e=(n,i)\) is oriented from \(n\) to \(n+\mathbf e_i\) whenever
both endpoints are vertices. Its independent variable is \(U_e\in SU(2)\);
an inverse traversal contributes \(U_e^{-1}\). Every contained elementary
face \(p=(n;i,j)\), \(i<j\), is included, with
\[
W_p=\operatorname{tr}\left[
 U_i(n)U_j(n+\mathbf e_i)U_i(n+\mathbf e_j)^{-1}U_j(n)^{-1}
\right].                                                    \tag{1.1}
\]
Write \(\mathsf E_L,\mathsf P_L\) for these complete sets, and
\[
N=3(2L)(2L+1)^2,\qquad M=3(2L)^2(2L+1).
\]
The Hilbert space is \(\mathcal H_L=L^2(SU(2)^{\mathsf E_L},dU)\),
with product Haar probability measure and inner product conjugate-linear
in its first entry. The differential operators and all physical constants are
\[
T_a=-i\sigma_a/2,\quad
X_{e,a}f=\left.\frac{d}{dt}f(\ldots,e^{tT_a}U_e,\ldots)\right|_{t=0},
\quad E_e=-\sum_{a=1}^3X_{e,a}^2,
\]
\[
H=\kappa\sum_{e\in\mathsf E_L}E_e
       +b\sum_{p\in\mathsf P_L}(2-W_p),\qquad
\kappa=\frac{2g_{\rm YM}^2}{a},\quad
b=\frac{1}{2g_{\rm YM}^2a},\quad
\xi=\frac b\kappa=\frac1{4g_{\rm YM}^4},\quad a,g_{\rm YM}>0.       \tag{1.2}
\]
In the original metric \(c(X,Y)=-\operatorname{tr}(XY)/2\), the
orthonormal frame is \(2T_a\), so \(\Delta_e^c=4\Delta_e^T\).
Thus the electric term in (1.2) also equals
\(-g_{\rm YM}^2\sum_e\Delta_e^c/(2a)\). No coefficient or energy
origin is changed. In particular the scalar \(2bM\) remains in \(H\).

The original geometric condition remains
\[
\operatorname{Im}\tau
\left(\operatorname{Im}\beta-
\frac{6(\operatorname{Im}\mu)^2}{\operatorname{Im}\tau}\right)\ne0.
                                                               \tag{1.3}
\]
The input magnetic patch uses
\(L_T=\operatorname{Im}\tau_T,\ q_T=-\operatorname{Im}\beta_T,
m_T=\operatorname{Im}\mu_T,\ D=L_Tq_T+6m_T^2>0\) and
\(\theta=2\pi a^2/D\). Its exact projected small-angle state, proved
in the parent source, is
\[
\chi_\theta=-\frac23\theta^2 v_{w^{\rm nat}}+O_{H^1}(\theta^4),
\qquad w^{\rm nat}_{(n,1)}=n_2^2,\quad
w^{\rm nat}_{(n,2)}=w^{\rm nat}_{(n,3)}=0.                         \tag{1.4}
\]
The angle remainder in (1.4) is a fixed-regulator input, not a bound
claimed uniform here. The result below concerns its actual electric
state with the exact original weights.

The product Laplacian on this compact connected manifold has domain
\(H^2\), form domain \(H^1\), and compact resolvent. Its smooth bounded
potential preserves these domains. A lowest form minimizer can be
chosen nonnegative by the gradient inequality for the modulus, obtained
at its zeros by approximation with \(\sqrt{|f|^2+\epsilon^2}\).
Elliptic regularity and the strong maximum principle make it smooth and
strictly positive. Write it as \(\psi>0\), with
\(\int\psi^2dU=1\), and write its physical energy as \(\mathcal E\).
Integration by parts using \(H\psi=\mathcal E\psi\) gives
\[
\mathfrak q_{H-\mathcal E}[\psi F]
 =\kappa\sum_{e,a}\int\psi^2|X_{e,a}F|^2dU.                    \tag{1.5}
\]
A second ground eigenfunction divided by \(\psi\) would have all
derivatives zero in (1.5), hence be constant. This proves simplicity.
The gauge action \(U_e\mapsto g_{s(e)}U_eg_{t(e)}^{-1}\) preserves
the operator, form, and positive unit vector; consequently \(\psi\)
is gauge invariant. All states below are formed from this same vacuum.

For each link set
\[
r_e=\#\{p:e\in\partial p\},\quad
W_e^{\star}=\sum_{p\ni e}W_p,\quad
t_{ef}=\#\{p:e,f\in\partial p\},\quad
\gamma_e=\langle\psi,E_e\psi\rangle,\quad v_e=(E_e-\gamma_e)\psi.
\]
Here \(2\le r_e\le4\), including boundary links. Define the actual matrices
\[
C_{ef}=\langle v_e,v_f\rangle,\qquad
\mathcal N_{ef}=\langle v_e,(H-\mathcal E)v_f\rangle.             \tag{1.6}
\]
They are real symmetric positive-semidefinite matrices. Smoothness of
\(\psi\) supplies every operator and form domain used in (1.6).

# 2. A local projection and an exact comparison operator

Let \(S\subset\mathsf E_L\) be a nonempty set of links. It need not be
connected. Define
\[
\mathsf J(S)=\{p:\partial p\cap S\ne\varnothing\},\quad
m_S=|\mathsf J(S)|,\quad
W_S=\sum_{p\in\mathsf J(S)}W_p,\quad H_S=\sum_{e\in S}E_e,
\]
\[
H_{\rm ext,S}=\kappa\sum_{e\notin S}E_e
       +b\sum_{p\notin\mathsf J(S)}(2-W_p).                    \tag{2.1}
\]
The last operator acts on the exterior tensor factor only. Its bottom
energy is \(\mathcal E_{\rm ext,S}\); if that factor is empty it is the
zero operator on \(\mathbb C\). The exact decomposition is
\[
H=\kappa H_S+H_{\rm ext,S}+2bm_S-bW_S.                          \tag{2.2}
\]
Every face meeting \(S\), including faces crossing its boundary, is
present in \(W_S\). Every other face is present in \(H_{\rm ext,S}\).
The constant terms total \(2bM\) in both (1.2) and (2.2).

The map
\[
(P_S f)(U_{S^c})=\int f(U_S,U_{S^c})\,dU_S,\qquad Q_S=I-P_S    \tag{2.3}
\]
is understood with its output lifted as a function constant on \(S\).
Fubini proves \(P_S=P_S^*=P_S^2\). Its range is
\(\mathbb C1_S\otimes L^2(SU(2)^{S^c})\), and its kernel consists
of functions of zero conditional Haar integral on \(S\).
It commutes with all link Casimirs and with exterior operators, and
preserves smooth functions and Sobolev domains. Each plaquette in
\(W_S\) contains a link of \(S\) exactly once in the fundamental or
inverse fundamental representation. Integration of that link is zero:
the substitution \(U\mapsto -U\) changes its matrix entries' signs.
Therefore
\[
P_SW_SP_S=0.                                                   \tag{2.4}
\]
This is an operator identity, not a statement that the interacting
vacuum has a Haar marginal. Haar invariance under endpoint left/right
multiplication also proves that \(P_S,Q_S\) intertwine the gauge action.

Take as a trial vector the constant on \(S\) tensored with an exterior
ground vector. Equation (2.4) makes its \(W_S\) expectation zero.
The full variational principle gives
\[
\mathcal E\le\mathcal E_{\rm ext,S}+2bm_S.
\]
Consequently the exterior self-adjoint operator
\[
K_S=H_{\rm ext,S}+2bm_S-\mathcal E\quad\hbox{satisfies }K_S\ge0.
                                                               \tag{2.5}
\]
No gap of \(K_S\) is assumed or needed. Put
\(B_S=\kappa H_S+K_S\). It is a sum of nonnegative operators on
different tensor factors. Their spectral resolutions strongly commute;
the operator domain of their sum is their domain intersection. The
full smooth vacuum belongs to that domain, and its exact equation is
\[
B_S\psi=bW_S\psi.                                             \tag{2.6}
\]
This identity retains the original interaction and exterior vacuum
dependence. It is not a free-vacuum eigen-equation.

The single-link eigenvalues of \(E_e\) are \(j(j+1)\),
\(j=0,\frac12,1,\ldots\), with the constant as its unique zero vector.
Indeed the Pauli matrices give \(-\sum_aT_a^2=3I/4\) on the
fundamental representation, and the spin raising/lowering matrices give
\(j(j+1)\) on each higher representation. Completeness of their
matrix coefficients under product Haar measure gives the joint spectral
decomposition. Thus \(H_S\ge(3/4)Q_S\).
On \(Q_S\mathcal H_L\), \(B_S\ge3\kappa/4\). Define
\[
R_S=Q_S(B_S|_{Q_S\mathcal H_L})^{-1}Q_S.
\]
Joint spectral calculus gives, without a Neumann expansion,
\[
\|R_S\|\le\frac4{3\kappa},\qquad
\|E_eR_S\|\le\frac1\kappa\quad(e\in S).                      \tag{2.7}
\]
For the latter assertion the multiplier is
\(\lambda_e/(\kappa\sum_{f\in S}\lambda_f+k)\le1/\kappa\)
for \(\lambda_f,k\ge0\). This also proves that the displayed composition
has a bounded extension on the full Hilbert space. Applying \(Q_S\)
to (2.6) now gives the exact local-resolvent equation
\[
Q_S\psi=bR_SW_S\psi.                                          \tag{2.8}
\]

# 3. Local electric moments at every positive coupling

**Theorem 3.1.** For every box \(L\ge2\), every \(a,g_{\rm YM}>0\),
every link \(e\), and every nonempty finite link set \(S\),
\[
\|E_e\psi\|\le2r_e\xi,\qquad
0\le\gamma_e\le\frac{16}{3}r_e^2\xi^2,                         \tag{3.1}
\]
\[
\|Q_S\psi\|\le q_S\xi,\qquad
q_S=\frac83\left(\sum_{e\in S}r_e^2\right)^{1/2}
\le\frac{32}{3}\sqrt{|S|}.                                    \tag{3.2}
\]
The constants have no dependence on the number of exterior links or faces.

**Proof.** Use \(S=\{e\}\) in (2.6). Its local interaction satisfies
\(\|W_S\|\le2r_e\). For the joint nonnegative spectral variables
of \(\kappa E_e\) and \(K_S\), their sum is at least the first
variable. Squaring this scalar inequality and integrating against the
spectral measure of \(\psi\) proves
\[
\kappa\|E_e\psi\|\le\|B_S\psi\|
 =b\|W_e^{\star}\psi\|\le2br_e.
\]
Since each nonzero eigenvalue of \(E_e\) is at least \(3/4\),
the spectral inequality \(E_e\le(4/3)E_e^2\) gives the second bound
in (3.1). The commuting projections onto nonconstant individual link
factors obey \(Q_S\le\sum_{e\in S}Q_{\{e\}}\) in their joint
zero/one eigenvalues. Also \(Q_{\{e\}}\le(16/9)E_e^2\).
Taking expectations and using (3.1) gives
\[
\|Q_S\psi\|^2\le\frac{16}{9}\sum_{e\in S}\|E_e\psi\|^2
 \le\frac{64}{9}\xi^2\sum_{e\in S}r_e^2.
\]
This proves (3.2). All estimates used the actual normalized vacuum;
no estimate on its full-box distance from the constant was used. \(\square\)

For later use, let \(F\) be any bounded multiplication operator depending
only on \(S\), with full Haar mean \(\overline F\). With
\(\eta=P_S\psi,\ u=Q_S\psi,\ q=\|u\|\), Fubini gives
\(\langle\eta,F\eta\rangle=\overline F\|\eta\|^2\).
Expanding all four terms of \(\langle\eta+u,F(\eta+u)\rangle\)
and using \(\|\eta\|^2=1-q^2\) therefore gives
\[
\left|\langle\psi,F\psi\rangle-\overline F\right|
 \le2\|F\|q+2\|F\|q^2.                                      \tag{3.3}
\]
This is a proved bound on a marginal expectation. It does not replace
the marginal by Haar measure.

# 4. An edge-star resolvent with an explicit state-vector remainder

Take
\[
S_e=\bigcup_{p\ni e}\partial p,\qquad m_e^{\star}=m_{S_e}.
\]
Each face at \(e\) adds at most three other links, so
\( |S_e|\le1+3r_e\le13\). Each link meets at most four faces,
hence \(m_e^{\star}\le4|S_e|\le52\). Equation (3.2) gives
\(q_{S_e}\le32\sqrt{13}/3<39\). These counts hold also at every
boundary of the open box.

**Theorem 4.1.** Simultaneously for all links and all boxes, on the explicit
interval \(0<\xi\le1/64\),
\[
\left\|E_e\psi-\frac\xi4W_e^{\star}\psi\right\|
 \le4200\xi^2.                                                 \tag{4.1}
\]
This compares two vectors in the same full interacting Hilbert space.

**Proof.** In Section 2 take \(S=S_e\) and abbreviate its operators
as \(P,Q,K,B,R\). Write \(\eta=P\psi,\ u=Q\psi\), with
\(\|u\|\le q_S\xi\). Applying \(P\) to (2.6) and using (2.4)
gives
\[
K\eta=bPW_Su,\qquad \|K\eta\|\le2bm_Sq_S\xi.                 \tag{4.2}
\]
Since \(E_eP=0\), equation (2.8) gives
\[
E_e\psi=bE_eRW_S\eta+bE_eRW_Su.                               \tag{4.3}
\]
Its second term has norm at most \(2m_Sq_S\xi^2\), by (2.7).
For a face not containing \(e\), \(E_eW_p\eta=0\). For a face
containing \(e\), all four boundary links lie in \(S\), and
\[
E_eW_p\eta=\frac34W_p\eta,\qquad H_SW_p\eta=3W_p\eta.
\]
Here the four fundamental Casimirs contribute separately, with exterior
variables untouched. Multiplication by such \(W_p\) commutes with \(K\).
The bounded map \(\zeta\mapsto W_p\zeta\) from the exterior space
to the local four-fundamental sector intertwines \(3\kappa+K\)
with \(B\). Its image is in \(Q\mathcal H_L\). Resolvent intertwining
and (4.3) thus give the exact identity
\[
bE_eRW_S\eta=\frac{3b}{4}
 W_e^{\star}(3\kappa+K)^{-1}\eta.
\]
The exterior inverse exists because \(K\ge0\). Subtracting
\((\xi/4)W_e^{\star}\eta\), while retaining \(K\), gives
\[
-\frac\xi4W_e^{\star}(3\kappa+K)^{-1}K\eta,
\]
whose norm by (4.2) is at most
\(r_em_Sq_S\xi^3/3\). Replacing \(\eta\) by \(\psi\) in the
comparison term has the additional norm cost
\(r_eq_S\xi^2/2\). We have proved the more detailed bound
\[
\left\|E_e\psi-\frac\xi4W_e^{\star}\psi\right\|
\le (2m_S+r_e/2)q_S\xi^2
       +\frac{r_em_Sq_S}{3}\xi^3
\le4134\xi^2+2704\xi^3.                                      \tag{4.4}
\]
For \(\xi\le1/64\) the last coefficient is
\(4134+2704/64=16705/4<4200\). This proves (4.1).
Equations (4.2)--(4.4) exhibit every discarded-in-an-estimate term
as an exact retained term with a bound; none is set to zero. \(\square\)

# 5. Uniform local Wilson and connected electric covariances

For elementary faces \(p,q\), Haar integration gives
\(\int W_pW_qdU=\delta_{pq}\). For unequal faces a link occurs in
only one support; its central sign change annihilates the integral.
For equal faces Haar invariance reduces the integral to
\(\int_{SU(2)}(\operatorname{tr}U)^2dU=1\). In quaternion coordinates
the latter is \(4\int u_0^2=1\), since the four coordinate second
moments on the unit three-sphere equal \(1/4\).

The function \(W_pW_q\) has norm at most \(4\) and uses at most eight
links. Equations (3.2)--(3.3), with
\(q_S\le32\sqrt8/3<31\), prove, for \(0<\xi\le1/64\),
\[
|\langle W_pW_q\rangle_\psi-\delta_{pq}|
 \le248\xi+7688\xi^2\le370\xi.                              \tag{5.1}
\]
This remains valid for faces at any separation; no finite-range assertion
about their true correlations is imposed.

For an individual face choose any one boundary link \(e\) and decompose
\(\psi=P_{\{e\}}\psi+Q_{\{e\}}\psi\). The first-first matrix
element of \(W_p\) vanishes by integration over \(e\). Equation (3.2)
gives \(q\le32\xi/3\), and the other three terms give
\[
|\langle W_p\rangle_\psi|\le4q+2q^2
 \le\left(\frac{128}{3}+\frac{32}{9}\right)\xi<47\xi.
\]
Consequently the connected Wilson moment obeys
\[
|\langle W_pW_q\rangle_\psi
 -\langle W_p\rangle_\psi\langle W_q\rangle_\psi-\delta_{pq}|
 \le410\xi.                                                   \tag{5.2}
\]
Indeed (5.1) and \(47^2\xi^2\le(2209/64)\xi\) give a smaller
constant than \(410\).

**Theorem 5.1.** On the same interval, simultaneously for all boxes and links,
\[
\left|C_{ef}-\frac{\xi^2}{16}t_{ef}\right|\le42500\xi^3.       \tag{5.3}
\]

**Proof.** Set \(u_e=E_e\psi\) and
\(a_e=(\xi/4)W_e^{\star}\psi\). The preceding bounds give
\[
\|u_e\|\le8\xi,\quad \|a_e\|\le2\xi,\quad
\|u_e-a_e\|\le4200\xi^2.
\]
Using the exact difference
\(\langle u_e-a_e,u_f\rangle+\langle a_e,u_f-a_f\rangle\),
its absolute value is at most \(42000\xi^3\). Also
\[
\langle a_e,a_f\rangle
 =\frac{\xi^2}{16}\sum_{p\ni e,q\ni f}\langle W_pW_q\rangle_\psi.
\]
There are at most sixteen ordered pairs in this sum. Its difference
from \(\xi^2t_{ef}/16\) is at most \(370\xi^3\), by (5.1).
Finally (3.1) bounds the exact centering term by
\[
|\gamma_e\gamma_f|\le\frac{65536}{9}\xi^4
 \le\frac{1024}{9}\xi^3<114\xi^3.
\]
The sum \(42000+370+114=42484<42500\) proves (5.3).
No odd Taylor coefficient has been asserted nonzero: this is an
absolute real-coupling remainder bound. The fixed-box evenness theorem
is compatible with (5.3); without an additional uniform analytic
argument it does not improve this bound to order \(\xi^4\). \(\square\)

# 6. Energy entries and a volume-independent weighted numerator estimate

Put \(A=H-\mathcal E\). The product rule, with the original sign
of \(E_f\), gives on the smooth vacuum
\[
AE_f\psi=[H,E_f]\psi
=b\left(\frac34W_f^{\star}\psi-2D_f\psi\right),\qquad
D_f\psi=\sum_{p\ni f,a}(X_{f,a}W_p)X_{f,a}\psi.                \tag{6.1}
\]
The electric sum commutes with \(E_f\). The potential contribution is
\(b[E_f,W_f^{\star}]\), retaining its first-derivative term in full.

For any one occurrence of a link in a simple Wilson loop, cyclically
basing the holonomy at that occurrence writes its derivative as
\(\operatorname{tr}(T_aU)\), or its negative, with a possible adjoint
rotation of the index \(a\). Quaternion coordinates then give
\[
\sum_a|X_{f,a}W_p|^2=1-W_p^2/4\le1.                           \tag{6.2}
\]
Pointwise Cauchy--Schwarz, followed by integration, bounds each
plaquette contraction in \(D_f\psi\) by
\((\sum_a\|X_{f,a}\psi\|^2)^{1/2}=\sqrt{\gamma_f}\).
Thus (3.1) gives
\[
\|D_f\psi\|\le r_f\sqrt{\gamma_f}
 \le\frac4{\sqrt3}r_f^2\xi\le\frac{64}{\sqrt3}\xi<37\xi.     \tag{6.3}
\]

**Theorem 6.1.** For \(0<\xi\le1/64\), all boxes, and all links,
\[
\left|\mathcal N_{ef}-\frac{3\kappa\xi^2}{16}t_{ef}\right|
 \le27000\kappa\xi^3.                                        \tag{6.4}
\]
For every real edge weight \(w\), including weights depending on \(L\)
and \(\xi\),
\[
\left|w^T\mathcal Nw-\frac{3\kappa\xi^2}{16}\|\mathsf Iw\|_2^2\right|
 \le351000\kappa\xi^3\|w\|_2^2,\qquad
 (\mathsf Iw)_p=\sum_{e\in\partial p}w_e.                     \tag{6.5}
\]

**Proof.** Since \(A\psi=0\), centering does not change
\(\mathcal N_{ef}=\langle E_e\psi,AE_f\psi\rangle\).
Insert (6.1). Replacing \(E_e\psi\) by \(a_e\) in the first term
costs at most \(6\cdot4200\kappa\xi^3=25200\kappa\xi^3\),
because \(\|W_f^{\star}\psi\|\le8\). The comparison of its
remaining Wilson products to Haar costs at most \(1110\kappa\xi^3\)
by (5.1). The full derivative term is at most
\(2\kappa\xi(8\xi)(37\xi)=592\kappa\xi^3\).
Their sum is \(26902\kappa\xi^3<27000\kappa\xi^3\), proving (6.4).

To prove the weighted conclusion without extending the entry bound
to an unjustified operator bound, expand the double commutator:
\[
\mathcal N_{ef}
 =\tfrac12\langle\psi,[E_e,[H,E_f]]\psi\rangle
 =\frac b2\sum_{p:e,f\in\partial p}
 \langle\psi,[E_e,[2-W_p,E_f]]\psi\rangle.                     \tag{6.6}
\]
The first identity follows from commutation of \(E_e,E_f\), the
vacuum equation at both endpoints, and reality of the two equal
cross terms. In the second, a face absent from \(f\) has zero inner
commutator. A face containing \(f\) but absent from \(e\) has
coefficients and derivatives commuting with \(E_e\). This proves
exact support on shared faces. A link has at most \(1+3r_e\le13\)
partners, counting itself. The remainder in (6.4) has the same support.
For its real symmetric matrix \(R\),
\[
|w^TRw|\le\sum_{e,f}|R_{ef}|\frac{w_e^2+w_f^2}{2}
 \le13\cdot27000\kappa\xi^3\sum_ew_e^2.
\]
Finally \(t=\mathsf I^T\mathsf I\) by its definition. This proves
(6.5), with no factor of \(M\), \(N\), or \(L\) in its constant. \(\square\)

# 7. Actual states, arbitrary weights, and the entire leading kernel

For real \(w\) write
\(\Gamma_w=\sum_ew_eE_e,\ v_w=(\Gamma_w-\langle\Gamma_w\rangle_\psi)\psi\).
These operators and states preserve the gauge constraint; all products
are taken on smooth \(\psi\). Equations (5.3) and (6.5) give simultaneously
\[
\left|\|v_w\|^2-\frac{\xi^2}{16}\|\mathsf Iw\|_2^2\right|
 \le42500\xi^3\|w\|_1^2,                                    \tag{7.1}
\]
\[
\left|\mathfrak q_A[v_w]-\frac{3\kappa\xi^2}{16}\|\mathsf Iw\|_2^2\right|
 \le351000\kappa\xi^3\|w\|_2^2.                              \tag{7.2}
\]
The \(\ell^1\) norm in (7.1) is not replaced by an \(\ell^2\) norm.
The long-distance covariance entries are retained. Equations (7.1)--(7.2)
are genuine full-vacuum inequalities at fixed nonzero coupling, not
coefficients interpreted outside a finite-box perturbation disk.

On the entire real kernel \(\mathsf Iw=0\), a sharper order statement
follows from the vector calculation. Summing (4.1) gives exactly
\(\Gamma_w\psi=\sum_ew_e(E_e\psi-a_e)\), since
\(\sum_ew_eW_e^{\star}=\sum_p(\mathsf Iw)_pW_p=0\).
Projection perpendicular to \(\psi\) is a contraction, so
\[
\|v_w\|^2\le17640000\xi^4\|w\|_1^2.                          \tag{7.3}
\]
In the sum of (6.1), the same cancellation gives
\(A\Gamma_w\psi=-2b\sum_ew_eD_e\psi\).
Using (6.3) and (4.1), without dividing by a possibly small state norm,
proves
\[
0\le\mathfrak q_A[v_w]\le310800\kappa\xi^4\|w\|_1^2.         \tag{7.4}
\]
The constants are \(4200^2=17640000\) and \(2\cdot4200\cdot37=310800\).
These estimates preserve the already calculated nonzero fourth-order
kernel forms. They do not assert a new lower bound on those forms.

There is also a uniform, quantitative local Rayleigh result. For any single
link \(e\) and
\[
0<\xi\le\frac1{680000},                                      \tag{7.5}
\]
(5.3), \(r_e\ge2\), and \(42500/680000=1/16\) give
\[
C_{ee}\ge\frac{r_e}{32}\xi^2>0.
\]
Equations (5.3) and (6.4) therefore imply
\[
\left|\frac{\mathfrak q_A[v_e]}{\|v_e\|^2}-3\kappa\right|
 \le\frac{4944000}{r_e}\kappa\xi
 \le2472000\kappa\xi.                                       \tag{7.6}
\]
The numerator in this calculation satisfies
\(|\mathcal N_{ee}-3\kappa C_{ee}|\le154500\kappa\xi^3\),
which supplies the constant in (7.6). This is the energy of the actual
smooth nonzero gauge-invariant local trial vector. By the spectral
variational principle its quotient is an upper bound on the physical
finite-box excitation gap, not a lower bound on that gap.
The explicit range (7.5) is equivalently
\(g_{\rm YM}^4\ge170000\), retaining \(\xi=1/(4g_{\rm YM}^4)\).
Neither \(a\) nor \(L\) appears in this range.

# 8. Propagation to the original native magnetic state

For the unchanged \(n_2^2\) weights in (1.4), set
\[
\mathcal A_L=\frac{L^2(2L+1)}{15}
 (24L^4+24L^3+8L^2-4L+3),
\]
\[
S_{1,L}=\frac{2L^2(L+1)(2L+1)^2}{3},\qquad
S_{2,L}=\frac{2L^2(L+1)(2L+1)^2(3L^2+3L-1)}{15}.
\]
The exact identities are
\(\|\mathsf Iw^{\rm nat}\|_2^2=4\mathcal A_L\),
\(\|w^{\rm nat}\|_1=S_{1,L}\), and
\(\|w^{\rm nat}\|_2^2=S_{2,L}\). To check them with all boundary
terms, direction-1 links have \(2L\) first coordinates and \(2L+1\)
third coordinates, so the latter two sums are
\(2L(2L+1)\sum_{t=-L}^Lt^2\) and
\(2L(2L+1)\sum_{t=-L}^Lt^4\).
The exact sums are
\(L(L+1)(2L+1)/3\) and
\(L(L+1)(2L+1)(3L^2+3L-1)/15\), respectively; their formulas follow
by taking the difference under \(L\mapsto L+1\) and checking \(L=0\).
For face sums the \(12\) profile is \(t^2+(t+1)^2\), the \(13\)
profile is \(2t^2\), and the \(23\) profile is zero. Counting their
allowed lower corners gives
\[
\mathcal A_L=2L(2L+1)\sum_{t=-L}^{L-1}(t^2+t+1/2)^2
                  +4L^2\sum_{t=-L}^{L}t^4.
\]
The first sum is \(L(4L^4+1)/10\), checked by the two added endpoint
terms and its value at \(L=1\); substitution gives the displayed polynomial.

Equations (7.1)--(7.2) now yield the explicit new remainders
\[
\left|\|v_{w^{\rm nat}}\|^2-\frac{\xi^2}{4}\mathcal A_L\right|
 \le42500\xi^3 S_{1,L}^2,                                    \tag{8.1}
\]
\[
\left|\mathfrak q_A[v_{w^{\rm nat}}]
          -\frac{3\kappa\xi^2}{4}\mathcal A_L\right|
 \le351000\kappa\xi^3 S_{2,L}.                               \tag{8.2}
\]
All native weights are nonnegative, so on each face
\((\sum w_e)^2\ge\sum w_e^2\); summing faces gives
\(4\mathcal A_L\ge\sum_e r_e(w_e^{\rm nat})^2\ge2S_{2,L}\).
Consequently the relative error in the native energy numerator is at most
\(936000\xi\), independently of \(L\). In particular on
\(0<\xi\le1/1872000\) it is at most one half of that numerator's
positive leading term. This is a proved fixed-coupling extensive energy
estimate, not a volume-shrinking perturbative statement.

By contrast the upper error-to-leading-term ratio furnished by (8.1)
is \(170000\xi S_{1,L}^2/\mathcal A_L\). Its \(L^3\) growth is
visible in the exact polynomials. This bound does not give a uniform
relative error for the native denominator. No step above proves
summability of the separated electric correlations, and the
fourth-order leading kernel is not discarded. The proved local covariance
and weighted numerator estimates therefore do not yet establish the
fixed-coupling minimum over every extensive weight or its continuum limit.
This statement records the scope of the inequalities actually proved;
it is not an assertion that the remaining correlations have no relation
to the native state.

The full physical coefficient conversions are
\[
\xi^2=\frac1{16g_{\rm YM}^8},\quad
\xi^3=\frac1{64g_{\rm YM}^{12}},\quad
\kappa\xi^2=\frac1{8g_{\rm YM}^6a},\quad
\kappa\xi^3=\frac1{32g_{\rm YM}^{10}a}.
\]
Thus, for example, the right side of (8.2) is exactly
\(351000S_{2,L}/(32g_{\rm YM}^{10}a)\).
The actual vacuum energy includes \(2bM=M/(g_{\rm YM}^2a)\)
throughout. The proof does not exchange any spatial, coupling, cusp,
or continuum limits.

# 9. Primary literature, exact dictionaries, and provenance

The local projection method is related to the Feshbach--Schur
reconstruction map, not claimed as a new general projection principle.
Dusson--Sigal--Stamm, *The Feshbach--Schur map and perturbation theory*,
arXiv:2105.02058v1, Theorem 1.2, equation (1.11), and Lemma 2.1 give
the complement inverse and eigenvector reconstruction mechanism
([primary source](https://arxiv.org/abs/2105.02058)). Their finite-rank
perturbation theorem is not used as a volume-uniform hypothesis.
Here \(P=P_S\) has infinite rank when the exterior is nonempty.
For an exact operator dictionary, set
\[
A_S^Q=Q_S(H-\mathcal E)Q_S|_{Q_S\mathcal H_L}
 =B_S|_{Q_S\mathcal H_L}-bQ_SW_SQ_S.
\]
On its domain, when \(2m_S\xi<3/4\), the bound
\(A_S^Q\ge\kappa(3/4-2m_S\xi)>0\) proves its bounded inverse.
The \(Q_S\) block of the full eigen-equation gives exactly
\[
Q_S\psi=b(A_S^Q)^{-1}Q_SW_SP_S\psi.                            \tag{9.1}
\]
The retained block is then
\[
\left[K_S-b^2P_SW_SQ_S(A_S^Q)^{-1}Q_SW_SP_S\right]P_S\psi=0.   \tag{9.2}
\]
Equations (9.1)--(9.2) follow directly by substitution, including the
minus sign and complete exterior operator. Their domains are the
exterior domain of \(K_S\) and its image under the bounded reconstruction
correction. The off-diagonal factors are bounded, so the effective
correction in (9.2) is bounded on the exterior Hilbert space.
Conversely a vector in that domain solving (9.2), inserted into (9.1),
lies in the full domain and solves the original zero-eigenvalue equation.
Applying \(P_S\) to this reconstruction recovers the original exterior
vector; its kernel is therefore zero. This proves the exact bijection
of the two kernels. The estimates in Sections 3--8 instead use (2.8),
whose inverse needs no smallness condition on \(b\); (9.1) explains the
precise relation between the two complement-resolvent presentations.

The canonical corpus also routes Henheik--Teufel--Wessel, *Local stability
of ground states in locally gapped and weakly interacting quantum spin
systems*, arXiv:2106.13780v3, Section 2 and Theorem 7
([primary source](https://arxiv.org/abs/2106.13780)). It permits
infinite-dimensional single-site spaces and unbounded on-site operators.
Its locality constants are existential in the statements read; none is
assigned a numerical value in this note.
The exact model dictionary can be given without changing physical
coordinates. Associate the edge \((n,i)\) to the indexing site
\(x(e)=2n+\mathbf e_i\in\mathbb Z^3\), retaining this map's inverse
on its image: the unique odd coordinate identifies \(i\), and then
\(n=(x-\mathbf e_i)/2\). Attach \(L^2(SU(2))\) and on-site
\(h_{x(e)}=\kappa E_e\) to that site. The on-site gap is
\(3\kappa/4\). Assign a face \(p=(n;i,j)\), \(i<j\), to
its edge \((n,i)\). Its other three indexing sites have \(\ell^1\)
distance \(2\) from \(x(n,i)\). At most two faces are assigned to one
edge, so
\(\Phi_{x(e)}=b\sum_{p\ {\rm assigned\ to}\ e}(2-W_p)\)
has norm at most \(8b\) and range \(2\).
The tensor-permutation unitary defined on elementary tensor functions
by this bijection intertwines the complete Hamiltonian with
\(\sum_xh_x+\sum_x\Phi_x\), including all scalar terms.
The indexing map is not a physical rescaling: the original midpoint is
exactly \(a\,x(e)/2\). The source's small-interaction theorem is not
invoked to supply the explicit constants (3.1)--(8.2); those were proved
above for this precise model.

The local source identities and conventions were read in full in:

- `magnetic_translation_true_vacuum.md`, Sections 1--9, especially
  (1.1), (1.4), (5.3), and (8.1)--(8.5);
- `local_energy_current_true_vacuum.md`, Sections 1--6;
- `wilson_variation/ELECTRIC_COVARIANCE_UNSIGNED_INCIDENCE_20260908.md`,
  Sections 1--8, especially (2.8)--(2.9), (5.7), (6.5), and (7.13);
- `wilson_variation/BULK_PLAQUETTE_EXTENSION.md`, Sections 1--10,
  especially the explicit box-dependent disk and conditional-form maps.

Their common root is `../ym_gap_primary_20260908`.
The complete finite incidence-kernel and second-order coefficient
calculations are preserved there. This note does not repeat those
calculations or promote their \(O_L\) constants to uniform ones.
Its new input to that chain is the independently proved quantitative
local-resolvent control and the resulting estimates above.
The machine-readable lane route records the canonical query results,
primary TeX locators, exact reading coverage, and remaining source reads.

# 10. A uniform score bound and coercivity of the actual conditional operator

The full vacuum equation also controls the conditional density without a
small-coupling expansion. This gives a second volume-independent estimate
useful in the exact elimination construction. It does not presuppose a
spectral gap for the full interacting system.

Use the product Riemannian metric for which the three \(T_a\) fields at
each link are orthonormal; write \(\nabla_e,\Delta_e\) for its link
gradient and Laplacian, and \(\Delta=\sum_e\Delta_e=-\sum_eE_e\).
This is precisely the metric already used in (1.2), not a new physical
metric. In quaternion coordinates \(U=u_0I+i\sum_a u_a\sigma_a\), its
metric is four times the metric of the unit three-sphere: the tangent
vector \(T_a\) at the identity has quaternion Euclidean length \(1/2\),
while its specified Riemannian length is 1. Left multiplication is
orthogonal on quaternions, so this identity holds at every point.
Consequently a link factor is isometric to the round sphere of radius 2.
Its sectional curvature is \(1/4\), Ricci tensor is \(g/2\), and diameter
is \(2\pi\). The curvature coefficient also follows from the second
fundamental form of the radius-2 sphere: its normal derivative has
magnitude \(1/2\), the Gauss equation gives sectional curvature \(1/4\),
and summing the two transverse sectional curvatures gives \(1/2\).
These computations retain the factor four relative to \(c\).

Put \(u=\log\psi\), a globally smooth real function because \(\psi>0\).
Dividing the eigen-equation by the same positive \(\psi\), with its
original unit norm left unchanged, yields the exact nonlinear equation
\[
\Delta u+|\nabla u|^2=\frac{V-\mathcal E}{\kappa},
\qquad V=b\sum_{p\in\mathsf P_L}(2-W_p).                         \tag{10.1}
\]
For each fixed link \(e\) define \(w_e=|\nabla_eu|^2\), and let
\(\nabla_f\nabla_eu\) denote the covariant derivative, in factor \(f\),
of the factor-\(e\) gradient. On the product manifold the partial
Bochner identity is
\[
\Delta w_e
=2\sum_f|\nabla_f\nabla_eu|_{\rm HS}^2
 +2\langle\nabla_eu,\nabla_e\Delta u\rangle+w_e.                  \tag{10.2}
\]
Here is its coordinate derivation. Take orthonormal geodesic frames
in every factor at the point under consideration. Applying each
second derivative in \(\Delta_f\) to the sum of squares of the three
components of \(\nabla_eu\) gives twice their squared first derivatives
plus twice their contraction with the second derivative of the vector.
For \(f\ne e\), the product connection has zero mixed curvature, so that
second derivative commutes with \(\nabla_e\). For \(f=e\), commuting
the covariant derivatives of the differential \(du\) gives
\[
\Delta_e^{\rm rough}\nabla_eu
=\nabla_e\Delta_eu+\operatorname{Ric}_e(\nabla_eu).
\]
This sign can equally be read from the positive sectional-curvature
Gauss formula above. The Ricci contraction in the differentiated norm
is \(2\operatorname{Ric}_e(\nabla_eu,\nabla_eu)=w_e\).
Adding the factor equations proves (10.2).
The scalar smooth Bochner identity, with the same sign of \(\Delta\),
is given in C. Villani, *Optimal Transport: Old and New*, Chapter 14,
equation (14.28), printed p.388 (PDF p.394 in the indexed local edition).
The partial-factor and vacuum substitutions used here are calculated
explicitly, rather than inferred from a dimension-independent constant
not stated there.

Let \(\mathcal D_u=\Delta+2\langle\nabla u,\nabla\,\cdot\,\rangle\).
Differentiating (10.1) and using the symmetry of the full Hessian gives
\[
\mathcal D_u w_e
=2\sum_f|\nabla_f\nabla_eu|_{\rm HS}^2+w_e
 +\frac2\kappa\langle\nabla_eu,\nabla_eV\rangle.                 \tag{10.3}
\]
In detail, the derivative of \(|\nabla u|^2\) in factor \(e\)
is \(2(\nabla^2u\,\nabla u)_e\). Its contraction with \(2\nabla_eu\)
in (10.2) is minus \(4\nabla^2u(\nabla u,\nabla_eu)\).
The drift applied to \(w_e\) is plus that same quantity. This proves
the cancellation with every mixed factor \(f\) included.

**Theorem 10.1.** For all \(L\ge2\), \(a,g_{\rm YM}>0\), and each link,
\[
\|\nabla_e\log\psi\|_\infty\le2r_e\xi,\qquad
\|\nabla_e\log\rho\|_\infty\le4r_e\xi,\qquad \rho=\psi^2.        \tag{10.4}
\]
In particular
\[
0\le\gamma_e\le4r_e^2\xi^2.                                   \tag{10.5}
\]
This improves the constant in the earlier valid bound (3.1).
All estimates (4.1)--(8.2) remain valid with their displayed constants.

**Proof.** Equation (6.2) gives \(|\nabla_eW_p|\le1\) for every
face at \(e\), and all other face derivatives vanish. Thus
\(|\nabla_eV|\le br_e\), without any factor \(M\).
The smooth nonnegative function \(w_e\) attains its maximum on the
compact product. At that point its full gradient vanishes and
\(\Delta w_e\le0\). Equation (10.3) therefore gives
\[
0\ge w_e-2r_e\xi\sqrt{w_e}.
\]
If the maximum is zero the conclusion is immediate. Otherwise dividing
by its positive square root gives \(\sqrt{w_e}\le2r_e\xi\).
This proves the first bound everywhere. Since \(\log\rho=2u\), the
second follows with its exact factor two. Finally integration by parts
gives
\(\gamma_e=\int|\nabla_e\psi|^2dU=\int\rho|\nabla_eu|^2dU\);
its probability integral and (10.4) prove (10.5). \(\square\)

To apply this to the actual conditional operator, fix a nonempty set
\(S\) of eliminated links and write \(r=U_{S^c}\), \(s=U_S\). Define
\[
\rho_{S^c}(r)=\int\rho(s,r)\,ds,\qquad
p_S(s\mid r)=\frac{\rho(s,r)}{\rho_{S^c}(r)},\qquad
\omega_S=8\pi\xi\sum_{e\in S}r_e.                              \tag{10.6}
\]
These are the marginal and conditional density of the same vacuum,
not a postulated Wilson Gibbs density. Holding \(r\) fixed and joining
two \(S\)-configurations one link at a time by minimizing geodesics,
(10.4) and the diameter \(2\pi\) give
\[
\sup_s\log p_S(s\mid r)-\inf_s\log p_S(s\mid r)\le\omega_S.      \tag{10.7}
\]
The denominator in (10.6) cancels from this oscillation. No differentiability
or uniform limit of the exterior marginal is assumed.

The product Haar Poincare inequality on \(S\), with its exact
single-link spectral coefficient, is
\[
\inf_{c\in\mathbb C}\int|F-c|^2ds
\le\frac43\sum_{e\in S}\int|\nabla_eF|^2ds.                     \tag{10.8}
\]
To prove it, expand \(F\) in the complete product matrix-coefficient
basis used in Section 2. Removing the constant leaves at least one
nonzero spin, so its total electric eigenvalue is at least \(3/4\).
Parseval gives (10.8) first for finite sums and then by form closure
for every \(H^1\) function.
For each exterior \(r\), let \(p_{\max},p_{\min}\) be the maximum
and minimum of its smooth positive conditional density on \(S\).
Minimize over \(c\), first bound the density above, apply (10.8), and
then bound it below in the energy integral. This gives the full
comparison calculation
\[
\begin{split}
\operatorname{Var}_{p_S(\cdot\mid r)}(F)
&\le p_{\max}\inf_c\int|F-c|^2ds\\
&\le\frac{4p_{\max}}3\sum_{e\in S}\int|\nabla_eF|^2ds\\
&\le\frac43 e^{\omega_S}
       \sum_{e\in S}\int|\nabla_eF|^2p_S(s\mid r)\,ds .
\end{split}                                                   \tag{10.9}
\]
The minimum characterization of variance is valid for complex functions
as well, with the complex mean as minimizer. This proof records the
entire density ratio; it is the bounded-density perturbation argument,
not a replacement of either measure.

Let \(\mathscr H_\rho=L^2(\rho\,dU)\), and define the exact isometry
\[
J_S:L^2(\rho_{S^c}\,dr)\longrightarrow\mathscr H_\rho,\qquad
(J_SF)(s,r)=F(r).
\]
Its adjoint is
\[
(J_S^*G)(r)=\int G(s,r)p_S(s\mid r)\,ds.
\]
Fubini verifies the inner-product identity for the adjoint and
\(J_S^*J_S=I\). Thus
\(P_S^\rho=J_SJ_S^*\) and \(Q_S^\rho=I-P_S^\rho\) are
orthogonal projections; \(\mathscr K_S^\rho=\ker J_S^*\)
is the conditional-mean-zero space. The multiplication map
\(U_\psi:G\mapsto\psi G\) is a unitary \(\mathscr H_\rho\to\mathcal H_L\).
The exact ground-state transform and its closed form are
\[
\mathscr L_\rho=U_\psi^{-1}(H-\mathcal E)U_\psi
 =-\kappa(\Delta+\langle\nabla\log\rho,\nabla\,\cdot\,\rangle),
\qquad
q_\rho[G]=\kappa\sum_e\int|\nabla_eG|^2\rho\,dU.                 \tag{10.10}
\]
At each fixed box the density and its reciprocal are smooth and bounded
on a compact space. Differentiating the conditional integral shows that
\(P_S^\rho,Q_S^\rho\) preserve \(H^1\): a retained derivative gives the
conditional integral of the input derivative and a bounded smooth
derivative of the conditional kernel; an eliminated derivative of the
output is zero. The constants in this domain-preservation statement
need not be uniform, and are not used for the coercivity bound below.
Applying \(Q_S^\rho\) to smooth \(H^1\) approximants proves that
\(H^1\cap\mathscr K_S^\rho\) is the form closure of its smooth elements
and dense in \(\mathscr K_S^\rho\).

Define \(C_S^\rho\) as the self-adjoint operator of the restricted
closed form \(q_\rho|_{H^1\cap\mathscr K_S^\rho}\). Explicitly its
domain consists of those \(G\) in that form space for which there is
\(h\in\mathscr K_S^\rho\) satisfying
\(q_\rho(F,G)=\langle F,h\rangle_\rho\) for every \(F\) in the form
space, and \(C_S^\rho G=h\). This definition makes no unproved claim
about the domain of a formal operator product.

**Theorem 10.2.** For every positive coupling and every finite box,
\[
C_S^\rho\ge\frac{3\kappa}{4}e^{-\omega_S}I,\qquad
\|(C_S^\rho)^{-1}\|\le\frac4{3\kappa}e^{\omega_S}.              \tag{10.11}
\]
In particular for a single eliminated link \(e\),
\[
C_{\{e\}}^\rho\ge\frac{3\kappa}{4}e^{-8\pi r_e\xi}I
\ge\frac{3\kappa}{4}e^{-32\pi\xi}I.                            \tag{10.12}
\]
These single-link bounds are independent of all exterior volume and
valid for the actual interacting conditional density.

**Proof.** A vector \(G\in\mathscr K_S^\rho\) has zero conditional
mean for almost every \(r\). Apply (10.9) to its conditional slices
and multiply by \(\rho_{S^c}(r)\); integrate in \(r\). Fubini gives
\[
\|G\|_\rho^2\le\frac43 e^{\omega_S}
       \sum_{e\in S}\int|\nabla_eG|^2\rho\,dU
\le\frac4{3\kappa}e^{\omega_S}q_\rho[G].
\]
Smooth approximation extends this inequality to the entire restricted
form domain. The form representation and spectral theorem yield
(10.11); \(r_e\le4\) gives (10.12).
The unitary \(U_\psi\) carries this form onto the full physical
excitation form restricted to \(U_\psi\mathscr K_S^\rho\), so the
constant has not been transferred between different operators without
a domain map. Gauge transformations preserve the density and intertwine
conditional integration by endpoint Haar invariance. Consequently these
projections, forms, and inverses preserve the physical gauge-invariant
subspaces as well. \(\square\)

For comparison with the original parameters, the last bound in (10.12) is
\[
\frac{3g_{\rm YM}^2}{2a}
       \exp\!\left(-\frac{8\pi}{g_{\rm YM}^4}\right).
\]
For larger eliminated sets the bound is also explicit, but its dependence
on \(\sum_{e\in S}r_e\) is retained. No volume-independent extensive-block
bound is inferred by deleting that sum.
Nor does a uniform conditional one-link gap alone tensorize into a
uniform gap for the correlated full density. The proof has established
an inverse for the actual eliminated operator, not a separated-correlation
estimate or the Millennium spectral conclusion.

The indexed Villani PDF has stable unit ID
\nolinkurl{PUBUNIT-3B56736161C0B49850EA7433}, SHA-256
\nolinkurl{3AE2DB61CBFFADFEEF0DE738742F4F3CE81B21874DACB1AD2991A7000434675D}.
Its contents and the complete printed pp.387--389, including equation
(14.28), were read directly; the book is cited, not copied into this
repository. The page reference is to that exact local edition rather
than an assumed page number in every edition.

```

## Complete source: ../ym_volume_uniform_astra_20260908/check_volume_uniform_constants.py

```python
"""Exact arithmetic and bounded incidence checks for the local vacuum proof.

No numerical vacuum or finite-spin replacement is performed. This checks
constants and combinatorics; the operator proof is in the mathematical note.
"""
from fractions import Fraction as F
from itertools import product
import json


def box(L):
    vertices = range(-L, L + 1)
    edges = {(n, i) for n in product(vertices, repeat=3)
             for i in range(3) if n[i] < L}
    faces = {}
    for n in product(vertices, repeat=3):
        for i in range(3):
            for j in range(i + 1, 3):
                if n[i] == L or n[j] == L:
                    continue
                ni, nj = list(n), list(n)
                ni[i] += 1
                nj[j] += 1
                faces[n, i, j] = frozenset([
                    (n, i), (tuple(ni), j), (tuple(nj), i), (n, j)])
    stars = {e: set() for e in edges}
    for p, boundary in faces.items():
        for e in boundary:
            stars[e].add(p)
    return edges, faces, stars


def arithmetic():
    cutoff = F(1, 64)
    assert F(32, 3)**2 * 13 < 39**2
    assert F(32, 3)**2 * 8 < 31**2
    vector = (2*52 + F(4, 2))*39 + F(4*52*39, 3)*cutoff
    assert vector == F(16705, 4) < 4200
    pair = 8*31 + 8*31**2*cutoff
    assert pair < 370
    one = F(128, 3) + F(2048, 9)*cutoff
    assert one < 47
    assert 370 + 47**2*cutoff < 410
    centered = F(65536, 9)*cutoff
    assert centered < 114
    covariance = 10*4200 + 370 + centered
    assert covariance < 42500
    assert F(64**2, 3) < 37**2
    energy = 6*4200 + 3*370 + 2*8*37
    assert energy == 26902 < 27000
    assert 13*27000 == 351000
    assert 4200**2 == 17640000
    assert 2*4200*37 == 310800
    assert F(42500, 680000) == F(1, 16)
    assert (27000 + 3*42500)*32 == 4944000
    assert F(351000*8, 3) == 936000
    assert F(936000, 1872000) == F(1, 2)
    # Radius-2 SU(2): Ric=(3-1)/2^2; the maximum-principle
    # gradient factor is inverse Ric. Density and diameter retain
    # their separate factors two and 2*pi.
    ricci = F(2, 4)
    assert 1/ricci == 2
    assert 2 * (1/ricci) * 2 == 8  # coefficient of pi*r_e*xi
    assert 8 * 4 == 32
    assert F(3, 4) * 2 == F(3, 2)  # physical kappa=2g^2/a
    return dict(vector_constant_exact=str(vector), vector_constant=4200,
                covariance_constant=42500, energy_entry_constant=27000,
                energy_form_constant=351000, cutoff=str(cutoff),
                local_nonzero_cutoff="1/680000")


def incidence(L):
    edges, faces, stars = box(L)
    assert len(edges) == 3*(2*L)*(2*L+1)**2
    assert len(faces) == 3*(2*L)**2*(2*L+1)
    max_links = max_faces = 0
    for e, star in stars.items():
        assert 2 <= len(star) <= 4
        local = set().union(*(faces[p] for p in star))
        touching = set().union(*(stars[f] for f in local))
        assert len(local) <= 1+3*len(star) <= 13
        assert len(touching) <= 4*len(local) <= 52
        max_links = max(max_links, len(local))
        max_faces = max(max_faces, len(touching))
    w = {e: e[0][1]**2 if e[1] == 0 else 0 for e in edges}
    s1 = sum(w.values())
    s2 = sum(v*v for v in w.values())
    iw2 = sum(sum(w[e] for e in boundary)**2 for boundary in faces.values())
    exact_a = F(L**2*(2*L+1), 15)*(24*L**4+24*L**3+8*L**2-4*L+3)
    assert s1 == F(2*L**2*(L+1)*(2*L+1)**2, 3)
    assert s2 == F(2*L**2*(L+1)*(2*L+1)**2*(3*L**2+3*L-1), 15)
    assert iw2 == 4*exact_a and iw2 >= 2*s2
    # The literature indexing map is bijective, with its stated inverse.
    labels = {}
    for n, i in edges:
        label = tuple(2*n[j] + (j == i) for j in range(3))
        odd = [j for j in range(3) if label[j] % 2]
        assert odd == [i]
        assert tuple((label[j] - (j == i))//2 for j in range(3)) == n
        assert label not in labels
        labels[label] = (n, i)
    assigned = {e: 0 for e in edges}
    for (n, i, j), boundary in faces.items():
        anchor = (n, i)
        assigned[anchor] += 1
        origin = tuple(2*n[k] + (k == i) for k in range(3))
        for q, k in boundary:
            dest = tuple(2*q[l] + (l == k) for l in range(3))
            assert sum(abs(x-y) for x, y in zip(origin, dest)) <= 2
    assert max(assigned.values()) <= 2
    return dict(L=L, links=len(edges), faces=len(faces),
                max_star_links=max_links, max_touching_faces=max_faces,
                native_l1=s1, native_l2_squared=s2, native_incidence_squared=iw2)


if __name__ == "__main__":
    print(json.dumps(dict(status="passed", arithmetic=arithmetic(),
                          boxes=[incidence(L) for L in (2, 3, 4, 5)],
                          scope="Exact constants/incidence only; analytical proof is in the note."),
                     indent=2))

```

## Complete source: ../ym_quantum_coarse_graining_astra_20260908/extensive_quantum_blocking.md

```markdown
# Extensive true-vacuum quantum blocking in the full spatial Wilson box

Exact path-product maps, associative memory, and uniform loop spectral weight. 8 September 2026.

## Original objects and the finite interacting operator

Let $L\geq2$ be an integer. The vertex set is $\mathsf V_L=\{-L,-L+1,\ldots,L\}^3$. For each $i\in\{1,2,3\}$, the physical edge $e=(n,i)$ goes from $n$ to $n+\mathbf e_i$ when both vertices are present. Its variable is $U_i(n)\in\operatorname{SU}(2)$. Inverse traversal uses $U_i(n)^{-1}$. Every such edge belongs to $\mathsf E_L$. Every elementary face $p=(n;i,j)$, $i<j$, with four vertices in the box belongs to $\mathsf P_L$; its ordered holonomy and trace are 

$$
\qquad\text{(1)}
 U_p=U_i(n)U_j(n+\mathbf e_i)U_i(n+\mathbf e_j)^{-1}U_j(n)^{-1},
 \qquad W_p=\operatorname{tr}U_p.
$$

 The counts are $N=3(2L)(2L+1)^2$ and $M=3(2L)^2(2L+1)$: fix a direction or a face plane and count its initial and transverse coordinates. The configuration space is $\mathcal Q=\operatorname{SU}(2)^{\mathsf E_L}$ with product Haar probability measure $\lambda$. Put 

$$
\begin{gathered}
 T_a=-i\sigma_a/2,\qquad
 X_{e,a}f=\left.\frac{d}{dt}f(\ldots,e^{tT_a}U_e,\ldots)\right|_{t=0},
 \qquad E_e=-\sum_{a=1}^3X_{e,a}^2,\qquad\text{(2)}\\
 H=\kappa\sum_{e\in\mathsf E_L}E_e+b\sum_{p\in\mathsf P_L}(2-W_p),\qquad
 \kappa=\frac{2g^2}{a},\quad b=\frac{1}{2g^2a},\quad
 \xi=\frac b\kappa=\frac1{4g^4},\quad a,g>0.\qquad\text{(3)}
\end{gathered}
$$

 Here $a$ in $a,g>0$ denotes spatial spacing; the color index in (2) is summed only when indicated. Haar integration by parts makes $X_{e,a}$ skew-adjoint. The Pauli identities give $-2\operatorname{tr}(T_aT_b)=\delta_{ab}$ and $-\sum_aT_a^2=3I/4$. The original metric $c(A,B)=-\operatorname{tr}(AB)/2$ has orthonormal basis $2T_a$; hence $X^c=2X$, $\Delta^c=4\Delta^T$, and the same kinetic term is $-(\kappa/4)\sum_e\Delta_e^c$. All faces, including boundary faces and faces in every plane, remain in (3). In particular the exact scalar term $2bM=M/(g^2a)$ is part of $H$.

Gauge transformations are $(h\cdot U)_e=h_{s(e)}^{-1}U_eh_{t(e)}$. The form of $H$ on $H^1(\mathcal Q)$ is 

$$
q_H(u,v)=\kappa\sum_{e,a}\int\overline{X_{e,a}u}X_{e,a}v\,\mathrm d\lambda
        +b\sum_p\int(2-W_p)\overline uv\,\mathrm d\lambda.
$$

 It is closed, since the smooth potential is bounded between $0$ and $4bM$. Its associated self-adjoint operator has domain $H^2$ by elliptic regularity; smooth functions are operator and form cores. Compact Sobolev embedding gives compact resolvent. Taking the modulus of a minimizing vector does not increase its form: apply the chain rule first to $(|u|^2+\epsilon^2)^{1/2}$ and then let $\epsilon$ decrease to zero. The resulting nonnegative lowest eigenfunction is smooth by elliptic regularity and strictly positive by the elliptic strong maximum principle. Write it as $\psi>0$, with $H\psi=E_0\psi$ and $\int\psi^2\,\mathrm d\lambda=1$. This fixes the state norm; none of the physical coefficients is changed.

Set $\rho=\psi^2$, $\mu=\rho\lambda$, and $\mathscr H=L^2(\mu)$. Multiplication $\mathcal Uu=\psi u$ is a unitary $\mathscr H\to L^2(\lambda)$, with inverse division by $\psi$. The product rule and $H\psi=E_0\psi$ give 

$$
\begin{aligned}
 \mathscr L&=\mathcal U^{-1}(H-E_0)\mathcal U
 =-\kappa\sum_{e,a}\bigl[X_{e,a}^2+(X_{e,a}\log\rho)X_{e,a}\bigr],
 \qquad\text{(4)}\\
 q(u,v)&=\kappa\sum_{e,a}\int\overline{X_{e,a}u}X_{e,a}v\,\mathrm d\mu,
 \qquad D(q)=\mathscr V=H^1(\mathcal Q).\qquad\text{(5)}
\end{aligned}
$$

 Integration by parts proves the form identity. Multiplication and division by the smooth positive $\psi$ preserve every integer Sobolev space, so the form and operator domains are respectively $H^1,H^2$. If $q(u,u)=0$, all its derivatives vanish and connectedness makes $u$ constant. This proves uniqueness of $\psi$, and its gauge invariance follows because gauge transformations preserve $H$, positivity and norm. It also proves that the finite first nonzero eigenvalue $\delta$ of $\mathscr L$ is strictly positive. No uniform lower bound for $\delta$ is used in the uniform estimates below. Inner products are conjugate-linear in their first arguments.

## A uniform single-link estimate for the actual vacuum

This section supplies estimates independent of $L$, with every $b>0$ allowed. Define the constants 

$$
\qquad\text{(6)}
 D=16b,\quad d=D/\kappa=16\xi=4/g^4,\quad
 t_0=\frac{2\log12}{\kappa},\quad
 R=3e^{Dt_0}=3\,12^{2d},\quad \alpha=R^{-2},
$$

 and 

$$
\qquad\text{(7)}
 G=R\exp\!\left(\frac d{1+d}\right)
       \left(1+\frac{2d}{1+d}\right)\sqrt{\frac{1+d}{2}},
 \qquad C_*=\frac32+2G.
$$

 Here $D$ has units of energy and $t_0$ of inverse energy. The constants $d,R,\alpha,G,C_*$ are dimensionless and depend on the original coupling $g$, but not on the number of links, the blocking length, or $a$ separately.

### Lemma 2.1.

For the single-link heat operator $P_t=e^{-t\kappa E}$, its kernel at $t=t_0$ lies between $1/2$ and $3/2$. For every real smooth $f$, 

$$
\qquad\text{(8)}
 2\kappa t\sum_a|X_aP_tf|^2
 \leq P_t(f^2)-(P_tf)^2,\qquad
 \|\nabla P_tf\|_\infty\leq\frac{\|f\|_\infty}{\sqrt{2\kappa t}}.
$$

### Proof.

The spin-$j$ representation has dimension $2j+1$ and Casimir $j(j+1)$ in (2). One can verify the latter by the eigenvalues $m=-j,\ldots,j$ of $iT_3$ and the raising/lowering coefficients $\sqrt{(j\mp m)(j\pm m+1)}$; their quadratic sum is $j(j+1)$. Peter--Weyl completeness therefore gives the heat kernel $p_t(U)=\sum_{j\geq0}(2j+1)e^{-\kappa tj(j+1)}\chi_j(U)$. This series is absolutely uniformly convergent for $t>0$, since $|\chi_j|\leq2j+1$. Writing $k=2j$, using $j(j+1)=k(k+2)/4\geq k/2$ and $(k+1)^2\leq4^k$ for $k\geq1$, gives 

$$
|p_{t_0}-1|\leq\sum_{k\geq1}4^k e^{-\kappa t_0k/2}
 =\sum_{k\geq1}3^{-k}=\frac12.
$$

 For the gradient assertion, the bi-invariant Casimir commutes with each $X_a$: the commutator of its sum of squares with $X_b$ contracts antisymmetric Lie structure constants with $X_aX_c+X_cX_a$ and is zero. Thus $X_aP_s=P_sX_a$ on smooth functions, and Jensen's inequality gives $\Gamma(P_sf)\leq P_s\Gamma(f)$ for $\Gamma(f)=\sum_a|X_af|^2$. Differentiate $P_s[(P_{t-s}f)^2]$ and use the product rule: 

$$
P_t(f^2)-(P_tf)^2=2\kappa\int_0^tP_s\Gamma(P_{t-s}f)\,\mathrm ds
 \geq2\kappa t\Gamma(P_tf).
$$

 The last inequality applies the preceding gradient contraction with input $P_{t-s}f$. The supremum estimate follows because $P_t(f^2)\leq\|f\|_\infty^2$. This is the exact single-group version of the reverse Poincare inequality [\[2, Eq. (1.7)\]](https://doi.org/10.4171/RMI/470), with the time and generator coefficient displayed explicitly.

### Theorem 2.2.

Fix one physical link $e$ and write all other variables as $y$. For all $u,u'\in\operatorname{SU}(2)$ and $y$, 

$$
\qquad\text{(9)}
 R^{-1}\leq\frac{\psi(u,y)}{\psi(u',y)}\leq R,\qquad
 \alpha\leq\frac{\rho(u,y)}{\int\rho(v,y)\,\mathrm dv}\leq\alpha^{-1}.
$$

 Moreover, 

$$
\qquad\text{(10)}
 \left(\sum_a|X_{e,a}\log\psi|^2\right)^{1/2}\leq G,
 \qquad |\nabla_e\log\rho|\leq2G.
$$

 All bounds are uniform in $e$ and $L$ at the fixed positive $a,g$.

### Proof.

Let $V_e=b\sum_{p\ni e}(2-W_p)$ and let $H_{\neg e}$ contain all other kinetic terms and all faces not incident to $e$. There are at most four incident faces in the full three-dimensional box, including the boundary cases with fewer faces. Therefore $0\leq V_e\leq D$, and the exact operator is 

$$
H=A_e+V_e,\qquad A_e=\kappa E_e+H_{\neg e},\qquad
 T_t=e^{-tA_e}=P_t^{(e)}\otimes e^{-tH_{\neg e}}.
$$

 The two factors of $T_t$ commute because $H_{\neg e}$ is independent of $u$. They have positive kernels. The parabolic comparison principle with the bounded multiplication $0\leq V_e\leq D$ gives, for $f\geq0$, 

$$
\qquad\text{(11)}
 e^{-Dt}T_tf\leq e^{-tH}f\leq T_tf.
$$

 For example $T_tf$ is a supersolution for $\partial_t+A_e+V_e$, while $e^{-Dt}T_tf$ is a subsolution; their initial data agree. The maximum principle gives (11). This proves the comparison for this compact group product directly; no Euclidean configuration-space identification is needed.

Apply it to $\psi$. At $t_0$, positivity of the other-link kernel and Lemma 2.1 imply 

$$
\frac{(T_{t_0}\psi)(u,y)}{(T_{t_0}\psi)(u',y)}\leq3.
$$

 Since $e^{-tH}\psi=e^{-tE_0}\psi$, comparison at both $u,u'$ gives $\psi(u,y)/\psi(u',y)\leq3e^{Dt_0}=R$. Interchanging $u,u'$ proves both sides. Squaring and averaging the denominator over $u'$ proves the conditional density bounds. The extensive energy $E_0$ cancels from this ratio exactly.

Here is a derivative proof that does not differentiate an unknown vacuum estimate. If a positive function $F(u,y)$ satisfies the first ratio bound, so does $f_t(u)=(e^{-tH_{\neg e}}F(u,\cdot))(y)$ at each fixed $y$, by positivity. Hence $\|f_t\|_\infty\leq R\min f_t\leq RP_t f_t(u)$. Lemma 2.1 yields 

$$
|\nabla_e T_t\psi|\leq\frac{R}{\sqrt{2\kappa t}}T_t\psi.
$$

 The function $(e^{-tH_{\neg e}}(V_e\psi))(u,y)$ is nonnegative and bounded above by $D(e^{-tH_{\neg e}}\psi)(u,y)$. Its supremum in $u$ is consequently at most $DR\min_u(e^{-tH_{\neg e}}\psi)(u,y)$. The same heat estimate gives 

$$
|\nabla_e T_t(V_e\psi)|\leq\frac{DR}{\sqrt{2\kappa t}}T_t\psi.
$$

 The exact Duhamel identity on the smooth eigenvector is 

$$
\qquad\text{(12)}
 \psi=e^{E_0t}T_t\psi-\int_0^t e^{E_0\tau}T_\tau(V_e\psi)\,\mathrm d\tau.
$$

 It follows either by differentiating $e^{E_0t}T_t\psi$ and using $A_e\psi=(E_0-V_e)\psi$, or by the bounded-potential Duhamel formula. Comparison gives $e^{E_0\tau}T_\tau\psi\leq e^{D\tau}\psi$. The two gradient estimates, whose $\tau^{-1/2}$ singularity is integrable, justify differentiation of (12) and give 

$$
\frac{|\nabla_e\psi|}{\psi}
 \leq R\left[\frac{e^{Dt}}{\sqrt{2\kappa t}}
       +D\int_0^t\frac{e^{D\tau}}{\sqrt{2\kappa\tau}}\,\mathrm d\tau\right]
 \leq\frac{Re^{Dt}(1+2Dt)}{\sqrt{2\kappa t}}.
$$

 Choose the actual time $t=(\kappa+D)^{-1}$. This last expression is exactly $G$ in (7). Finally $X\log\rho=2X\log\psi$. No gap bound, perturbation disk, or correlation factorization was used.

## A specified extensive spatial blocking sequence

Let $m\geq1$ divide $2L$, and put $q_m=2L/m$. Retain as skeleton links those direction-$i$ fine edges whose two transverse coordinates lie in $-L+m\{0,1,\ldots,q_m\}$. Every longitudinal fine edge on each such line is included. Denote this subset by $R_m$ and its complement by $S_m$. Its exact count is 

$$
\qquad\text{(13)}
 |R_m|=3(2L)(q_m+1)^2,\qquad
 |S_m|=3(2L)\bigl[(2L+1)^2-(q_m+1)^2\bigr].
$$

 Thus a fixed $m>1$ eliminates an extensive number of links as the box increases. If $m\mid n\mid2L$, then $R_n\subset R_m$. In particular $m=1,2,4,\ldots,2^k$ gives a repeated blocking sequence whenever $2^k\mid2L$. The Hamiltonian still has all $N$ link and $M$ face terms.

The coarse vertices are the points $x\in[-L,L]^3$ whose coordinates all lie in $-L+m\mathbb Z$. A coarse direction-$i$ edge $\gamma=(x,i)$ is the ordered path of $m$ fine edges from $x$ to $x+m\mathbf e_i$. The number of coarse edges is 

$$
N_m=3q_m(q_m+1)^2,\qquad |R_m|=mN_m.
$$

 The chains have disjoint physical-edge supports and meet only at coarse vertices. Write their variables as $u_{\gamma,1},\ldots,u_{\gamma,m}$ in positive order, and define 

$$
\qquad\text{(14)}
 z_\gamma=u_{\gamma,1}\cdots u_{\gamma,m},\qquad
 \pi_m:\mathcal Q\longrightarrow\mathcal Q_m:=\operatorname{SU}(2)^{N_m}.
$$

 No original coordinate was replaced by a unit coarse spacing: the physical coarse spacing is $ma$, while the original coordinates remain $x$.

For every chain put $v_{\gamma,k}=u_{\gamma,k}$ for $k<m$. Let $y$ comprise all $v$ and all untouched variables on $S_m$. The coordinate map $U\mapsto(y,z)$ is a global smooth bijection. Its inverse uses 

$$
u_{\gamma,m}=(v_{\gamma,1}\cdots v_{\gamma,m-1})^{-1}z_\gamma,
$$

 and keeps every other variable. Integrating $u_{\gamma,m}$ last, left invariance of Haar proves the exact measure identity 

$$
\qquad\text{(15)}
 \,\mathrm d\lambda(U)=\,\mathrm d\lambda_y(y)\,\mathrm d\lambda_m(z).
$$

 This proves the map and its measure factor, rather than postulating independent coarse links in the interacting vacuum.

The complete kinetic operator in these coordinates is as follows. Define the prefix and the real orthogonal matrix $O_{\gamma,k}$ by 

$$
p_{\gamma,k}=v_{\gamma,1}\cdots v_{\gamma,k-1},\qquad
 p_{\gamma,k}T_a p_{\gamma,k}^{-1}
   =\sum_b O_{\gamma,k;ba}T_b.
$$

 Orthogonality follows by applying $-2\operatorname{tr}(AB)$ to both conjugated factors; its determinant is $1$ by connectedness. Let $D_{\gamma,b}$ be left multiplication differentiation on $z_\gamma$, with the same $T_b$. For $k<m$ the transformed fine vector field is 

$$
X_{\gamma,k,a}=X_{v_{\gamma,k},a}
            +\sum_bO_{\gamma,k;ba}D_{\gamma,b};
$$

 for $k=m$ it is $\sum_bO_{\gamma,m;ba}D_{\gamma,b}$. The prefix $p_{\gamma,k}$ does not involve $v_{\gamma,k}$, and no $O$ depends on $z$. The full sum of squares is consequently 

$$
\begin{aligned}
\qquad\text{(16)}
 \sum_{e,a}X_{e,a}^2
 ={}&\sum_{e\in S_m,a}X_{e,a}^2
 +\sum_{\gamma}\left[\sum_{k<m,a}X_{v_{\gamma,k},a}^2
                      +m\sum_bD_{\gamma,b}^2\right]\\
 &+2\sum_{\gamma,k<m,a,b}O_{\gamma,k;ba}
                    X_{v_{\gamma,k},a}D_{\gamma,b}.
\end{aligned}
$$

 Each square before expansion is the square of the displayed original field, so this formula includes all mixed derivatives with their signs and coefficients. Every original $W_p$ in (3) is evaluated at the explicit inverse coordinate map. It is not replaced by a coarse face trace or truncated to selected words.

Gauge transformations on a chain cancel at its internal vertices and give $z_\gamma\mapsto h_x^{-1}z_\gamma h_{x+m\mathbf e_i}$. The marginal density on $R_m$ is invariant under the internal gauge transformations, by gauge invariance of $\rho$ and Haar substitution on $S_m$. A non-coarse skeleton vertex is bivalent in the skeleton. For a fixed chain with endpoints fixed, set successively $h_{x+k\mathbf e_i}=(u_1\cdots u_k)^{-1}$, $k<m$. This sends its first $m-1$ links to the identity and its last to $z_\gamma$. Different chain interiors are disjoint, so these choices are simultaneous. It follows that this skeleton marginal is a function of $z$ alone. This statement concerns the marginal; the full conditional distribution of $y$ given $z$ need not factorize.

## The actual coarse density, domains, and conditional coupling

Let $\widetilde\rho_m(y,z)=\rho(U(y,z))$ and define 

$$
\begin{gathered}
 r_m(z)=\int\widetilde\rho_m(y,z)\,\mathrm d\lambda_y,
 \quad \mu_m=r_m\lambda_m,\quad
 p_m(y\mid z)=\widetilde\rho_m(y,z)/r_m(z),\qquad\text{(17)}\\
 \mathscr K_m=L^2(\mu_m),\quad J_m f=f\circ\pi_m,\quad
 P_m=J_mJ_m^*,\quad Q_m=I-P_m,\\
 (J_m^*u)(z)=\int p_m(y\mid z)u(U(y,z))\,\mathrm d\lambda_y.\qquad\text{(18)}
\end{gathered}
$$

 Smoothness and strict positivity follow from compact integration. Fubini proves the adjoint formula and $J_m^*J_m=I$; Jensen proves that $J_m^*$ is a contraction. Thus $P_m$ is the true-vacuum orthogonal projection. All these maps intertwine the stated fine and coarse gauge actions. The restriction of the conditional projection onto skeleton functions, on the fine invariant Hilbert space, equals this path projection: its output is internally gauge invariant, hence depends only on $z$, as proved in the preceding section.

For each chain and color set, in the original coordinates, 

$$
\qquad\text{(19)}
 Y_{\gamma,b}=\frac1m\sum_{k=1}^m\sum_a
                   O_{\gamma,k;ba}X_{\gamma,k,a}.
$$

 Then $Y_{\gamma,b}J_mf=J_mD_{\gamma,b}f$. Indeed each summand differentiates $z_\gamma$ in the direction $\operatorname{Ad}_{p_{\gamma,k}}T_a$, and orthogonality of $O$ gives one copy of $D_{\gamma,b}$ per $k$. Also $Y_{\gamma,b}$ has zero Haar divergence: every coefficient $O_{\gamma,k;ba}$ is independent of its own differentiated fine edge. Consequently integration by parts against a coarse smooth test function gives the exact derivative identities 

$$
\begin{aligned}
 D_{\gamma,b}\log r_m&=J_m^*(Y_{\gamma,b}\log\rho),\qquad\text{(20)}\\
 D_{\gamma,b}J_m^*u
   &=J_m^*(Y_{\gamma,b}u)+J_m^*(\beta_{\gamma,b}u),\qquad\text{(21)}\\
 \beta_{\gamma,b}&=Y_{\gamma,b}\log\rho
                       -J_mD_{\gamma,b}\log r_m,\qquad J_m^*\beta_{\gamma,b}=0.
 \qquad\text{(22)}
\end{aligned}
$$

 For example integrate $Y_{\gamma,b}(J_m\varphi\,\rho)$ over the full configuration space; its integral is zero. The resulting identity is $\int(D_{\gamma,b}\varphi)r_m=-\int\varphi J_m^*(Y_{\gamma,b}\log\rho)r_m$, which proves (20). Apply the same calculation to $u\rho$ to prove (21). This also avoids differentiating fibre coordinates while holding an incompatible fine coordinate fixed.

Theorem 2.2, the average in (19), and conditional Jensen give 

$$
\qquad\text{(23)}
 |Y_\gamma\log\rho|\leq2G,\qquad
 |D_\gamma\log r_m|\leq2G,\qquad |\beta_\gamma|\leq4G.
$$

 Here each absolute value is the Euclidean norm of its three color components. The first inequality uses the average of $m$ rotated vectors, each with norm at most $2G$; it does not assume independence.

### Proposition 4.1.

The exact lifted form and its generator are 

$$
\begin{aligned}
 a_m(f,g)&=q(J_mf,J_mg)
    =\kappa m\sum_{\gamma,b}\int\overline{D_{\gamma,b}f}D_{\gamma,b}g\,\mathrm d\mu_m,
       &D(a_m)&=\mathscr V_m=H^1(\mathcal Q_m),\qquad\text{(24)}\\
 A_m&=-\kappa m\,r_m^{-1}\sum_{\gamma,b}D_{\gamma,b}(r_mD_{\gamma,b}),
       &D(A_m)&=H^2(\mathcal Q_m).\qquad\text{(25)}
\end{aligned}
$$

 The maps $J_m,J_m^*$ preserve all integer Sobolev spaces, and $P_m,Q_m$ preserve $\mathscr V$. On $\mathscr V_m$ the full eliminated coupling is 

$$
\qquad\text{(26)}
 B_mf=-\kappa m\sum_{\gamma,b}\beta_{\gamma,b}J_mD_{\gamma,b}f,
 \quad J_m^*B_mf=0,\quad \mathscr LJ_mf=J_mA_mf+B_mf\quad(f\in H^2).
$$

 In particular the retained kinetic coefficient is exactly $\kappa m$.

### Proof.

The fine derivative of $J_mf$ on edge $(\gamma,k)$ is the orthogonal rotation $O_{\gamma,k}^TD_\gamma f$; on $S_m$ it is zero. Summing the squared derivatives over the $m$ edges proves (24). The smooth positive weight gives closedness and the $H^2$ elliptic domain of (25). The compact smooth coordinate bijection (15) preserves each integer Sobolev class with finite norm bounds, since its derivatives and inverse derivatives are bounded. The fibre integral with smooth positive kernel $p_m$ has bounded derivatives of every finite order. This proves the Sobolev mapping claims.

There is also a useful explicit first-order estimate. Define 

$$
\eta_m=\kappa m\left\|\sum_{\gamma,b}\beta_{\gamma,b}^2\right\|_\infty
             \leq16\kappa mN_mG^2.
$$

 Orthogonality of the rotations and Cauchy--Schwarz in the $k$ sum give the pointwise inequality 

$$
m\sum_{\gamma,b}|Y_{\gamma,b}u|^2
 \leq\sum_{e\in R_m,a}|X_{e,a}u|^2.
$$

 Conditional Jensen and (21) consequently give 

$$
\qquad\text{(27)}
 a_m(J_m^*u,J_m^*u)\leq2q(u,u)+2\eta_m\|u\|_\mu^2.
$$

 This extends by smooth approximation. The same derivative identities show that $J_mf\in H^1$ implies $f\in H^1$, so the retained form space has exactly the claimed domain. On a lifted smooth $f$, (16) gives $\sum_{e,a}X_{e,a}^2J_mf=mJ_m\sum_{\gamma,b}D_{\gamma,b}^2f$. The drift in (4) is $-\kappa m\sum_{\gamma,b}(Y_{\gamma,b}\log\rho)J_mD_{\gamma,b}f$. Subtract (25), and use (22); this proves (26) for smooth $f$. Density gives the stated $H^2$ identity and the bounded map $B_m:\mathscr V_m\to Q_m\mathscr H$, with 

$$
\qquad\text{(28)}
 \|B_mf\|_\mu^2\leq\eta_m a_m(f,f).
$$

The full correlation tensor of the induced first-order terms is 

$$
\qquad\text{(29)}
 I_{\gamma b,\eta c}(z)=J_m^*(\beta_{\gamma,b}\beta_{\eta,c})(z),\quad
 \|B_mf\|^2=(\kappa m)^2\int
 \sum_{\gamma,b,\eta,c}I_{\gamma b,\eta c}
              \overline{D_{\gamma,b}f}D_{\eta,c}f\,\mathrm d\mu_m.
$$

 Every off-diagonal index is retained. This is the conditional covariance of the vectors $Y_{\gamma,b}\log\rho$. It is positive semidefinite because its quadratic form is a conditional expectation of a squared absolute value. Positivity does not assert that its different entries vanish or that it is uniformly diagonal-dominant.

There is an exact Haar-space description of the instantaneous marginal operator. Multiplication $f\mapsto\sqrt{r_m}f$ is a unitary $\mathscr K_m\to L^2(\lambda_m)$. Direct product differentiation gives 

$$
\qquad\text{(30)}
 \sqrt{r_m}A_m r_m^{-1/2}
 =-\kappa m\sum_{\gamma,b}D_{\gamma,b}^2
       +\kappa m\frac{\sum_{\gamma,b}D_{\gamma,b}^2\sqrt{r_m}}{\sqrt{r_m}}.
$$

 The last scalar function equals $\kappa m\sum_{\gamma,b}[D_{\gamma,b}^2\log r_m/2
 +(D_{\gamma,b}\log r_m)^2/4]$. It depends on the entire induced density. No equality with a sum of one-plaquette Wilson terms is asserted. Moreover (30) is only the instantaneous compression; the next section gives the rest of the physical operator relation.

## Exact memory, resolvent reconstruction, and physical norms

Set $\mathscr H_{Q_m}=Q_m\mathscr H$ and $\mathscr V_{Q_m}=\mathscr V\cap\mathscr H_{Q_m}$. The restriction $c_m(h,k)=q(h,k)$ on $\mathscr V_{Q_m}$ is closed and densely defined. Closedness uses the $L^2$-closed subspace, and density follows by applying $Q_m$ to smooth approximants, using (27). Define its self-adjoint operator $C_m$ by 

$$
\begin{aligned}
\qquad\text{(31)}
 D(C_m)=\{h\in\mathscr V_{Q_m}:&\ \exists v\in\mathscr H_{Q_m}\ \text{such that}
 \ c_m(k,h)=\langle k,v\rangle\ \forall k\in\mathscr V_{Q_m}\},
 \qquad C_mh=v.
\end{aligned}
$$

 For smooth $h\in\mathscr H_{Q_m}$ this is $Q_m\mathscr Lh$. Every such $h$ is orthogonal to $1=J_m1$, so $C_m\geq\delta I>0$. For form-domain arguments no formal compression domain is substituted for (31).

For $f,g\in\mathscr V_m$ and $h,k\in\mathscr V_{Q_m}$, integration by parts on a smooth core, followed by continuity, gives 

$$
\qquad\text{(32)}
 q(J_mf+h,J_mg+k)=a_m(f,g)+\langle B_mf,k\rangle
                         +\langle h,B_mg\rangle+c_m(h,k).
$$

 For smooth $h\in\mathscr H_{Q_m}$ the adjoint coupling is 

$$
\qquad\text{(33)}
 B_m^*h=\kappa m\,r_m^{-1}\sum_{\gamma,b}
           D_{\gamma,b}\bigl(r_mJ_m^*(\beta_{\gamma,b}h)\bigr).
$$

 To prove the sign, integrate the negative derivative in (26) against $h$ using Haar integration by parts in $z$. Differentiating the conditional integral by (21) expands each derivative in (33) into terms with $Yh$, $Y\beta$, $\beta^2h$ and $(D\log r_m)\beta h$. All coefficients are smooth and bounded in a fixed box, so $B_m^*:\mathscr V_{Q_m}\to\mathscr K_m$ is bounded. Without that regularity the adjoint is the bounded dual map $\mathscr H_{Q_m}\to\mathscr V_m^*$.

For $z>0$ define on $\mathscr V_m$ the sesquilinear form 

$$
\qquad\text{(34)}
 s_{m,z}(f,g)=a_m(f,g)+z\langle f,g\rangle
             -\langle B_mf,(C_m+z)^{-1}B_mg\rangle.
$$

 The use of $z$ as a positive spectral shift here is distinct from the tuple $z_\gamma$ of coarse link variables. The argument of a resolvent always denotes the scalar shift.

### Theorem 5.1.

The form $s_{m,z}$ is closed with domain $\mathscr V_m$, and its associated operator $S_{m,z}$ satisfies $S_{m,z}\geq zI$. Its exact full resolvent and reconstruction maps are 

$$
\begin{aligned}
 J_m^*(\mathscr L+z)^{-1}J_m&=S_{m,z}^{-1},\qquad\text{(35)}\\
 (\mathscr L+z)^{-1}J_mg
 &=\bigl[J_m-(C_m+z)^{-1}B_m\bigr]S_{m,z}^{-1}g.\qquad\text{(36)}
\end{aligned}
$$

 Every product in these formulas is defined by the displayed form domains.

### Proof.

Completing the square in (32) gives 

$$
\begin{aligned}
\qquad\text{(37)}
 q(J_mf+h,J_mf+h)+z(\|f\|^2+\|h\|^2)
 =s_{m,z}(f,f)+\|(C_m+z)^{1/2}[h+(C_m+z)^{-1}B_mf]\|^2.
\end{aligned}
$$

 Its unique minimizing $h$ is $-(C_m+z)^{-1}B_mf$, which lies in $D(C_m)\subset\mathscr V_{Q_m}$. Nonnegativity of $q$ proves $s_{m,z}(f,f)\geq z\|f\|^2$. Apply (27) to $u=J_mf+h$. It gives 

$$
a_m(f,f)+\kappa\|f\|^2\leq2q(u,u)+(2\eta_m+\kappa)\|u\|^2
 \leq K_{m,z}\,[q(u,u)+z\|u\|^2],
$$

 where $K_{m,z}=\max\{2,(2\eta_m+\kappa)/z\}$ in the form norm with reference energy $\kappa$. This constant is dimensionless. Taking the minimizing $h$ proves a lower form-norm bound. The upper bound $s_{m,z}(f,f)\leq a_m(f,f)+z\|f\|^2$ follows by choosing $h=0$. Their equivalence proves closedness. For $v=(\mathscr L+z)^{-1}J_mg$, its form-domain decomposition $v=J_mf+h$ is legitimate. Testing the weak resolvent equation against $k\in\mathscr V_{Q_m}$ gives $h=-(C_m+z)^{-1}B_mf$; testing against $J_mf'$ gives $s_{m,z}(f',f)=\langle f',g\rangle$. This proves both identities.

The notation in (34) is a closed-form implementation of the Feshbach--Schur map. The general method and reconstruction are established in [\[1, Theorem 1.2, Eqs. (1.10)--(1.16)\]](https://doi.org/10.4171/ECR/18-1/5). That theorem's bounded effective operator assumption is not silently applied to our infinite-rank projection; the coercivity and domain proof above supplies the needed extension for this particular operator.

For smooth initial $f_0$, define $K_m(t)=J_m^*e^{-t\mathscr L}J_m$, $f(t)=K_m(t)f_0$. The full evolution and (32) give 

$$
\begin{aligned}
 f'(t)&=-A_m f(t)+\int_0^t B_m^*e^{-(t-s)C_m}B_m f(s)\,\mathrm ds,
       &f(0)&=f_0,\qquad\text{(38)}\\
 K_m(t)&=J_m^*e^{-t\mathscr L}J_m,\qquad
 \int_0^\infty e^{-zt}K_m(t)\,\mathrm dt=S_{m,z}^{-1}.\qquad\text{(39)}
\end{aligned}
$$

 Here is the domain justification and the sign calculation. Smooth initial data lie in all powers of the compact elliptic $\mathscr L$. Spectral calculus and elliptic regularity keep $v(t)=e^{-t\mathscr L}J_mf_0$, $f(t)=J_m^*v(t)$ and $h(t)=Q_mv(t)$ smooth, continuously in the required Sobolev norms. They satisfy $f'=-A_mf-B_m^*h$, $h'=-B_mf-C_mh$, $h(0)=0$. Variation of constants gives $h(t)=-\int_0^te^{-(t-s)C_m}B_mf(s)\,\mathrm ds$. Since $\sup_{x\geq0}\sqrt{x}e^{-\tau x}=(2e\tau)^{-1/2}$, $e^{-\tau C_m}$ maps $\mathscr H_{Q_m}$ to its form space with norm at most $\sqrt\kappa+(2e\tau)^{-1/2}$ when the squared form norm is $c_m(h,h)+\kappa\|h\|^2$. The singularity is integrable; the bounded form-space map (33) makes (38) a Bochner integral in $\mathscr K_m$. The positive sign follows from the two negative cross terms. The Laplace identity follows by the spectral theorem and Theorem 5.1. This explicitly realizes projection memory of the kind introduced in [\[4\]](https://doi.org/10.1143/PTP.33.423), with this Euclidean generator.

For every smooth $f$, orthogonality of the two components of $\mathscr LJ_mf$ gives the full second moment 

$$
\qquad\text{(40)}
 \|\mathscr LJ_mf\|^2=\|A_mf\|^2+\|B_mf\|^2.
$$

 Thus $K_m(t)$ is replaced by $e^{-tA_m}$ for all $t$ only when $B_m$ vanishes: compare their scalar second derivatives at $t=0$ on a smooth core. Conversely $B_m=0$ makes (32) a direct-sum form and proves that replacement exactly. We do not make that replacement.

The dependence on energy also records the actual reconstructed norm. For fixed $0\ne f\in\mathscr V_m$ with $\mu_m(f)=0$ and scalar $z\geq0$, put 

$$
\qquad\text{(41)}
 w_z=(C_m+z)^{-1}B_mf,\quad
 u_z=\psi(J_mf-w_z),\quad d_f=\|f\|^2.
$$

 The $z=0$ case exists because $C_m\geq\delta>0$ in every fixed box. The vector is in the original form domain, is orthogonal to $\psi$, and is gauge invariant when $f$ is. Its exact norm and energy are 

$$
\begin{aligned}
 \|u_z\|_\lambda^2&=d_f+\|w_z\|_\mu^2
                  =\partial_z s_{m,z}(f,f),\qquad\text{(42)}\\
 \mathfrak q_{H-E_0}[u_z]
 &=a_m(f,f)-\langle B_mf,w_z\rangle-z\|w_z\|^2
   =s_{m,z}(f,f)-z\partial_zs_{m,z}(f,f).\qquad\text{(43)}
\end{aligned}
$$

 To verify these, orthogonality gives the norm; differentiation of the bounded resolvent gives $\partial_z(C_m+z)^{-1}=-(C_m+z)^{-2}$. Testing $(C_m+z)w_z=B_mf$ against $w_z$ gives $c_m(w_z,w_z)=\langle B_mf,w_z\rangle-z\|w_z\|^2$; insert it in (32). Nonnegativity of $q$ proves the numerator is nonnegative. For $B_mf\ne0$ the quotient in (43) divided by (42) is strictly below $a_m(f,f)/d_f$. These are energies of actual full-system vectors; no artificial effective vacuum norm has replaced their eliminated components.

## Associativity of repeated blocking with all prior memory

Let $m\mid n\mid2L$. A coarse $n$-edge is the ordered concatenation of $n/m$ coarse $m$-edges along its line. Let $\pi_{m,n}$ take these products and discard the other $m$-coarse edges. Literal ordered multiplication gives 

$$
\qquad\text{(44)}
 \pi_n=\pi_{m,n}\circ\pi_m,\quad J_n=J_m I_{m,n},\quad
 \mu_n=(\pi_{m,n})_*\mu_m,\quad
 J_n^*=I_{m,n}^*J_m^*.
$$

 Here $I_{m,n}f=f\circ\pi_{m,n}$ is an isometry $\mathscr K_n\to\mathscr K_m$; its adjoint is conditional integration using $r_m$, not Haar integration in place of that weight. Fubini proves each equality, including the adjoint identity. In the full Hilbert space $P_nP_m=P_mP_n=P_n$. All maps preserve the relevant Sobolev spaces by the same compact path-product coordinate construction. Coefficient composition in the instantaneous forms is exactly $\kappa m(n/m)=\kappa n$.

Let $\widehat Q=I-I_{m,n}I_{m,n}^*$ on $\mathscr K_m$. On $\widehat Q\mathscr K_m\cap\mathscr V_m$, let $t_{22,z}$ be the restriction of the already completed form $s_{m,z}$. Define its other block forms by 

$$
\begin{aligned}
 t_{11,z}(f,g)&=s_{m,z}(I_{m,n}f,I_{m,n}g),\\
 t_{21,z}(h,f)&=s_{m,z}(h,I_{m,n}f),\\
 t_{12,z}(f,h)&=s_{m,z}(I_{m,n}f,h).
\end{aligned}
$$

 The operator $T_{22,z}$ associated to $t_{22,z}$ is positive with lower bound $z$. Its inverse also acts from its form dual to its form space, by the coercive weak equation. In that sense the next eliminated component is $h_f=-T_{22,z}^{-1}t_{21,z}(\cdot,f)$, and the next form is 

$$
\qquad\text{(45)}
 s_{n,z}(f,g)=t_{11,z}(f,g)
       -t_{12,z}\bigl(f,T_{22,z}^{-1}t_{21,z}(\cdot,g)\bigr).
$$

 This notation means substitution of the unique weak solution, so does not require multiplying unspecified unbounded compressions.

### Theorem 6.1.

Equation (45) equals the direct fine-to-$n$ form (34). In particular 

$$
\qquad\text{(46)}
 S_{n,z}^{-1}=I_{m,n}^*S_{m,z}^{-1}I_{m,n}
            =J_n^*(\mathscr L+z)^{-1}J_n.
$$

 No memory generated at an earlier level is lost in the next level.

### Proof.

For prescribed $f\in\mathscr V_n$, every $u\in\mathscr V$ with $J_n^*u=f$ has a unique orthogonal decomposition $u=J_n f+J_mh+k$, where $h\in\widehat Q\mathscr K_m\cap\mathscr V_m$ and $k\in\mathscr H_{Q_m}\cap\mathscr V$; obtain it by the nested projections in (44). Put $v_h=J_m(I_{m,n}f+h)$ to keep both arguments of the sesquilinear form explicit. The exact variational identity (37) gives 

$$
\begin{aligned}
 s_{n,z}(f,f)
 &=\inf_{J_n^*u=f}[q(u,u)+z\|u\|^2]\\
 &=\inf_h\inf_k[q(v_h+k,v_h+k)+z\|v_h+k\|^2]\\
 &=\inf_h s_{m,z}(I_{m,n}f+h,I_{m,n}f+h).
\end{aligned}
$$

 The infima have unique minimizers by coercivity and the closed form-space constraints. The weak equation for the last minimizer is precisely the $T_{22,z}$ equation above. Expanding the last form and polarizing proves (45). Alternatively compress (35) by $I_{m,n}$ and use (44); this proves (46) directly and confirms the same unique closed form. Both arguments include all intermediate eliminated components.

To display the generated terms explicitly, write $\mathcal M_{m,z}(f,g)=\langle B_mf,(C_m+z)^{-1}B_mg\rangle$. Then each of $t_{11,z},t_{12,z},t_{21,z},t_{22,z}$ is the corresponding block of $a_m+z\langle\cdot,\cdot\rangle-\mathcal M_{m,z}$. In particular the two off-diagonal blocks contain the corresponding off-diagonal terms of $-\mathcal M_{m,z}$, and $T_{22,z}$ contains its entire diagonal term. Setting these terms to zero would change (45). The exact recursion is independent of the order of the specified nested eliminations; it does not reinitialize the dynamics at each marginal $A_m$.

## A large-block Wilson channel with uniform norm and spectral bounds

Let $C$ be a closed coarse edge word using each coarse physical edge at most once. Its fine path then uses each of its fine physical edges once; let $r$ be its number of coarse edges and $\ell=mr$ its number of fine edges. For example, every elementary coarse face has $r=4$, fine perimeter $\ell=4m$, and physical side length $ma$. Keep its original ordered word, with inverses on the negative traversals, and set 

$$
\begin{gathered}
 W_C(z)=\operatorname{tr}\prod_{(\gamma,\epsilon)\in C}z_\gamma^\epsilon,\quad
 \overline W_C=\mu_m(W_C),\quad r_C=\mu_m(W_C^2),\\
 f_C=W_C-\overline W_C,\quad u_C=\psi J_mf_C,\quad
 d_C=\|u_C\|_\lambda^2=r_C-(\overline W_C)^2.\qquad\text{(47)}
\end{gathered}
$$

 SU(2) traces are real. The fine and coarse gauge actions both fix the closed trace, so $u_C$ is a physical invariant vector, orthogonal to $\psi$. The subtraction is the actual interacting mean.

### Lemma 7.1.

For every such loop, at arbitrary positive coupling, 

$$
\qquad\text{(48)}
 \alpha\leq d_C\leq4,\qquad
 \alpha\leq r_C\leq4-3\alpha.
$$

 The exact unnormalized excitation energy and bounds are 

$$
\qquad\text{(49)}
 \mathfrak q_{H-E_0}[u_C]
   =\kappa\ell\left(1-\frac{r_C}{4}\right),\qquad
 \frac34\alpha\kappa\ell\leq\mathfrak q_{H-E_0}[u_C]\leq\kappa\ell.
$$

 Consequently 

$$
\qquad\text{(50)}
 \frac{3\alpha}{16}\kappa\ell\leq
 \frac{\mathfrak q_{H-E_0}[u_C]}{d_C}
 =\kappa\ell\frac{1-r_C/4}{r_C-(\overline W_C)^2}
 \leq\frac{\kappa\ell}{\alpha}.
$$

### Proof.

Fix any one fine edge used by the loop and condition on all other fine variables. The ordered holonomy is $A u^{\pm1}B$ for fixed group matrices $A,B$, so its Haar distribution is Haar by invariance and inversion. Writing $U=u_0I+i\sum_a u_a\sigma_a$ identifies Haar measure with the uniform measure on the unit sphere in $\mathbb R^4$. Its coordinate second moments are $1/4$ by sign and permutation symmetry and $\sum_{a=0}^3u_a^2=1$. Thus $\int W_C\,\mathrm du=0$, $\int W_C^2\,\mathrm du=1$, and $\int(1-W_C^2/4)\,\mathrm du=3/4$. The conditional density is bounded below by $\alpha$ from Theorem 2.2. Integrating the two nonnegative functions $W_C^2$ and $4-W_C^2$ proves the two bounds on $r_C$. For every real constant $c$, conditional integration gives $\int(W_C-c)^2p(u\mid y)\,\mathrm du\geq\alpha\int(W_C-c)^2\,\mathrm du
=\alpha(1+c^2)\geq\alpha$. Taking $c$ to be that conditional mean proves conditional variance at least $\alpha$. The law of total variance, obtained by expanding around the conditional mean and integrating the cross term to zero, proves $d_C\geq\alpha$. Since $|W_C|\leq2$, $d_C\leq4$.

For a positive occurrence, a based form of the derivative is $\operatorname{tr}(T_aA_C)$ with $A_C\in\operatorname{SU}(2)$ having trace $W_C$; for a negative occurrence it is $-\operatorname{tr}(T_aA_C')$. This follows from $X_a u^{-1}=-u^{-1}T_a$ and cyclic trace invariance. The Pauli expression above gives $\sum_a|\operatorname{tr}(T_aA_C)|^2=1-W_C^2/4$. There are exactly $\ell$ used fine edges. Insert this identity in (5); centering leaves derivatives unchanged. The exact energy and its lower and upper bounds follow. Divide using $\alpha\leq d_C\leq4$ to obtain (50).

These bounds are for the same density used by the block projection. For an additional consistency check, that coarse density itself has a single-coarse-link conditional lower bound $\alpha$, independent of $m$. Indeed change only the last fine edge of a specified chain, holding all $y$ and all other coarse links fixed in (15). Theorem 2.2 bounds the ratio of the two full densities by $R^2$. Integrating the same $y$ on both sides bounds the ratio $r_m(z_\gamma,z_{\ne\gamma})/r_m(z'_\gamma,z_{\ne\gamma})$ by $R^2$. Averaging over $z'_\gamma$ proves the assertion. This exact argument does not equate single-link conditional bounds with independence or a global Poincare inequality.

### Theorem 7.2.

Define the actual full-Hamiltonian probability measure 

$$
\qquad\text{(51)}
 \nu_C(B)=d_C^{-1}\langle u_C,\mathbf1_B(H-E_0)u_C\rangle.
$$

 It has no atom at zero. Its full first and second moments satisfy 

$$
\begin{gathered}
 \int\omega\,\mathrm d\nu_C=\kappa\ell\frac{1-r_C/4}{d_C},\\
 \int\omega^2\,\mathrm d\nu_C
 =\frac{\|A_mf_C\|^2+\|B_mf_C\|^2}{d_C}
 \leq\frac{C_*^2}{\alpha}\kappa^2\ell^2.\qquad\text{(52)}\\
 \Omega_C=\frac{3\alpha}{32}\kappa\ell,\qquad
 c_H=\frac{9\alpha^3}{1024C_*^2}>0,\qquad
 \boxed{\nu_C([\Omega_C,\infty))\geq c_H.}\qquad\text{(53)}
\end{gathered}
$$

 In particular $c_H$ is independent of the increasing blocking length $m$ and of total box volume. The full compressed resolvent, including its memory, obeys at the scalar shift $z=\kappa\ell$ 

$$
\qquad\text{(54)}
 \frac{z\langle f_C,S_{m,z}^{-1}f_C\rangle}{d_C}
 \leq1-c_H\frac{3\alpha/32}{1+3\alpha/32}.
$$

### Proof.

The state is smooth and orthogonal to the unique vacuum. Spectral calculus and (49) prove the first moment and the absence of a zero atom. Every used edge has fundamental Casimir $3/4$, including inverse occurrences, so $-\sum_{e,a}X_{e,a}^2W_C=3\ell W_C/4$. Combining (4) with (10) and $|\nabla_e W_C|\leq1$ gives the pointwise bound 

$$
|\mathscr LJ_mf_C|=|\mathscr LJ_mW_C|
 \leq\kappa\ell\left(\frac32+2G\right)=\kappa\ell C_*.
$$

 The second-moment bound follows by integration, $d_C\geq\alpha$, and (40). In particular the term $\|B_mf_C\|^2$ has not been deleted from this spectral measure.

Put $A=3\alpha/16$. The first moment is at least $A\kappa\ell$ by (50). With $\Omega_C=A\kappa\ell/2$, its part on $[\Omega_C,\infty)$ is at least $A\kappa\ell/2$, since the integral over $[0,\Omega_C)$ is at most $\Omega_C$. Cauchy--Schwarz against $\nu_C$ gives 

$$
(A\kappa\ell/2)^2
 \leq\left(\int\omega^2\,\mathrm d\nu_C\right)\nu_C([\Omega_C,\infty)).
$$

 Use (52); the resulting constant is precisely $c_H$. Finally (35) gives $z\langle f_C,S_{m,z}^{-1}f_C\rangle/d_C
=\int z/(\omega+z)\,\mathrm d\nu_C$. On $[\Omega_C,\infty)$ its integrand is at most $z/(\Omega_C+z)$, and elsewhere it is at most $1$. Insert (53) and $z=\kappa\ell$ to obtain (54).

The same channel can be dressed by the complete eliminated resolvent with a quantitative bound that continues to hold for growing $m$. Define 

$$
\qquad\text{(55)}
 \tau_* =\frac{8G}{\sqrt{\alpha c_H}},\qquad
 z_C=\tau\kappa\ell,\quad\tau\geq\tau_*.
$$

 For $f=f_C$ use the full $u_{z_C}$ of (41), with all fine eliminated degrees of freedom in $C_m$.

### Corollary 7.3.

This is a nonzero physical vector with exact norm and energy (42)--(43). Quantitatively, 

$$
\begin{gathered}
 d_C\leq\|u_{z_C}\|^2\leq d_C+\alpha c_H/4,\\
 \frac{\|\mathbf1_{[\Omega_C,\infty)}(H-E_0)u_{z_C}\|^2}
      {\|u_{z_C}\|^2}\geq\frac{c_H}{4+c_H},\qquad\text{(56)}\\
 \frac{\Omega_Cc_H}{4+c_H}
 \leq\frac{\mathfrak q_{H-E_0}[u_{z_C}]}{\|u_{z_C}\|^2}
 \leq\kappa\ell\frac{1-r_C/4}{d_C}.
\end{gathered}
$$

### Proof.

By (23), each used coarse edge contributes at most $4G\kappa m$ to the pointwise absolute value of $B_mf_C$; there are $r$ such edges and $|D_\gamma W_C|\leq1$. Thus $\|B_mf_C\|\leq4G\kappa\ell$. Since $C_m\geq0$, its shifted inverse has norm at most $1/z_C$. Consequently 

$$
\|w_{z_C}\|\leq4G/\tau\leq\tfrac12\sqrt{\alpha c_H}
                              \leq\tfrac12\sqrt{d_Cc_H}.
$$

 Orthogonality gives the norm bound. Multiplication by $\psi$ is unitary, and an orthogonal spectral projection is contractive. Hence the triangle inequality and (53) give 

$$
\|\mathbf1_{[\Omega_C,\infty)}(H-E_0)u_{z_C}\|
 \geq\sqrt{d_Cc_H}-\|w_{z_C}\|
 \geq\tfrac12\sqrt{d_Cc_H}.
$$

 Divide its square by $d_C+\|w_{z_C}\|^2\leq d_C(1+c_H/4)$. Integrating $\omega\geq\Omega_C$ over this weight proves the lower energy bound; (43) proves the upper bound. The large positive shift here is explicitly fixed in (55); this argument does not assert the same lower bound for the separately defined $z=0$ minimizing vector.

## Original scales and the exact scope of the spectral conclusion

For an elementary coarse face $\ell=4m$. The actual state has 

$$
\begin{aligned}
 \|u_C\|^2&=r_C-(\overline W_C)^2\in[\alpha,4],\qquad\text{(58)}\\
 \mathfrak q_{H-E_0}[u_C]
 &=\frac{8g^2m}{a}\left(1-\frac{r_C}{4}\right)
       \in\left[\frac{6\alpha g^2m}{a},\frac{8g^2m}{a}\right],\qquad\text{(59)}\\
 \frac{\mathfrak q_{H-E_0}[u_C]}{\|u_C\|^2}
 &\in\left[\frac{3\alpha g^2m}{2a},\frac{8g^2m}{a\alpha}\right],
 \qquad \Omega_C=\frac{3\alpha g^2m}{4a}.\qquad\text{(60)}
\end{aligned}
$$

 Here $\alpha=1/(9\,12^{16/g^4})$, and $G,C_*,c_H$ are the explicit functions (7), (53) of $d=4/g^4$. The physical length is $ma$, so $g^2m/a=g^2(ma)/a^2$ as an exact rewriting with no coordinate change. The expectation of the unsubtracted Hamiltonian is 

$$
\langle u_C,Hu_C\rangle
 =E_0(r_C-(\overline W_C)^2)
       +\frac{8g^2m}{a}(1-r_C/4).
$$

 The same scalar $E_0\|u_{z_C}\|^2$ is added to the dressed excitation energy. Also $0\leq E_0\leq2bM$ follows from $H\geq0$ and the constant unit Haar trial vector, whose plaquette means vanish. The original $2bM$ term has not been omitted from $H$.

The exact instantaneous kinetic term has the two metric expressions 

$$
-\kappa m\Delta^T=-(\kappa m/4)\Delta^c,\qquad \kappa m=2g^2m/a.
$$

 If its coefficient is written solely as $2g_m^2/(ma)$, algebra forces $g_m^2=m^2g^2$. This is only the coefficient dictionary for this marginal kinetic form. It does not make (30) and the energy-dependent memory into the original one-plaquette Hamiltonian at a claimed running coupling.

The map from the spatial coarse observable to the quantum theory is exactly $f\mapsto\psi J_mf$, followed by (51); the retained resolvent is (35), and sequential eliminations obey (45). Theorems 7.2 and Corollary 7.3 are statements about that full quantum spectral measure, with no omission of generated interactions. For fixed $g>0$, these particular large-loop channels retain a positive fraction of weight at energies proportional to $g^2m/a$, including the specified fully dressed channels. Thus they cannot place their entire probability measure into arbitrarily low energy by increasing $m$ at fixed $a,g$.

This assertion does not give a lower bound on the support of the whole measure: some weight can lie below $\Omega_C$. Nor does a lower bound on the quotient of this family bound the infimum over all physical states. At variable $g=g(a)$ the constants $\alpha$ and $c_H$ have the explicit coupling dependence above and can tend to zero. The calculation therefore proves neither a continuum mass gap nor a four-dimensional mass-gap counterexample. It supplies an exact extensive block map and an all-positive-coupling, volume-independent quantitative channel result; it does not presume an answer for the remaining states or for the joint spatial continuum limit.

## Primary-source map and reproducibility

The general Feshbach--Schur construction is attributed to its established literature. The locally retained source of Dusson, Sigal and Stamm was read at Theorem 1.2, its reconstruction map, and Eqs. (1.10)--(1.16). Their operator $H-\lambda$ corresponds here to $\mathscr L+z$, with $\lambda=-z$, their complementary inverse to $(C_m+z)^{-1}$, and their reconstruction to (36). Their effective interaction has the negative sign in (34). The infinite-rank form argument and the conditional coefficients are proved in this paper.

Bakry and Ledoux's reverse Poincare estimate is their Eq. (1.7), with $d(t)=2t$ at curvature bound zero, on pp. 686--687. Our single-edge Markov generator is $\kappa\Delta^T$ and its carré du champ is $\kappa\sum_a(X_af)^2$, giving precisely (8). Its full compact-group proof was included. Simon's locally retained Theorem 1.1 uses the Euclidean generator $-\Delta/2$ and its Brownian-bridge formula. It is a primary reference for positive potential weights, not a theorem identifying Euclidean space with this compact configuration product; the compact parabolic comparison needed here was proved in (11). Mori's projection-memory method provides the historical comparison: its projection is Eq. (2.13) and its exact memory equations are Eqs. (3.1)--(3.10), pp. 430--431. Our evolution uses $-\mathscr L$ on functions with the vacuum inner product; Mori's evolution uses a Liouville operator on dynamical variables. Equation (38) derives the corresponding Euclidean block identity here, including its signs and domains.

The companion exact checker verifies the entire open-box skeleton and path counts on several finite boxes, chain disjointness, nested product paths, every retained loop orientation, exact Pauli rotations and the mixed derivative tensor in explicit noncommuting samples, and exact rational Schur associativity and spectral constants. These finite checks diagnose algebra; they do not stand in for the all-box proofs above or compute a substitute vacuum. No Lean run or large parallel job is used.

## References 

### \[1\]

G. Dusson, I. M. Sigal, and B. Stamm, *The Feshbach--Schur map and perturbation theory*, in *Partial Differential Equations, Spectral Theory, and Mathematical Physics*, EMS Series of Congress Reports (2021), pp. 65--88. [doi:10.4171/ECR/18-1/5](https://doi.org/10.4171/ECR/18-1/5); [arXiv:2105.02058v1](https://arxiv.org/abs/2105.02058v1), Theorem 1.2 and Eqs. (1.10)--(1.16).

### \[2\]

D. Bakry and M. Ledoux, *A logarithmic Sobolev form of the Li--Yau parabolic inequality*, Revista Matemática Iberoamericana **22** (2006), no. 2, 683--702. [doi:10.4171/RMI/470](https://doi.org/10.4171/RMI/470), Eq. (1.7) and its proof, pp. 686--687.

### \[3\]

B. Simon, *A Feynman--Kac Formula for Unbounded Semigroups*, [arXiv:math-ph/9907022v1](https://arxiv.org/abs/math-ph/9907022v1) (1999), Theorem 1.1 and Eqs. (1.1)--(1.3).

### \[4\]

H. Mori, *Transport, Collective Motion, and Brownian Motion*, Progress of Theoretical Physics **33** (1965), 423--455. [doi:10.1143/PTP.33.423](https://doi.org/10.1143/PTP.33.423).

### \[5\]

J. Kogut and L. Susskind, *Hamiltonian formulation of Wilson's lattice gauge theories*, Physical Review D **11** (1975), 395--408. [doi:10.1103/PhysRevD.11.395](https://doi.org/10.1103/PhysRevD.11.395).

### \[6\]

F. Peter and H. Weyl, *Die Vollständigkeit der primitiven Darstellungen einer geschlossenen kontinuierlichen Gruppe*, Mathematische Annalen **97** (1927), 737--755. [doi:10.1007/BF01447892](https://doi.org/10.1007/BF01447892).

```

## Complete source: ../ym_quantum_coarse_graining_astra_20260908/check_extensive_blocking.py

```python
"""Exact finite diagnostics for the accompanying all-box analytic proofs.

No vacuum approximation, Monte Carlo sample or Lean invocation is used.
Only files in this script's directory are written.
"""
from __future__ import annotations

import hashlib
import itertools
import json
from pathlib import Path
import sympy as s

ROOT = Path(__file__).resolve().parent
assertions = 0


def check(condition, label):
    global assertions
    if not condition:
        raise AssertionError(label)
    assertions += 1


def mat_equal(a, b, label):
    for x in a - b:
        check(s.simplify(x) == 0, label)


def step(v, i, amount=1):
    w = list(v)
    w[i] += amount
    return tuple(w)


def graph(L):
    vertices = list(itertools.product(range(-L, L + 1), repeat=3))
    edges = {(v, i) for v in vertices for i in range(3) if v[i] < L}
    faces = {}
    for v in vertices:
        for i, j in itertools.combinations(range(3), 2):
            if v[i] < L and v[j] < L:
                faces[v, i, j] = [((v, i), 1), ((step(v, i), j), 1),
                                   ((step(v, j), i), -1), ((v, j), -1)]
    return edges, faces


def chains(L, m):
    grid = range(-L, L + 1, m)
    return {(v, i): [(step(v, i, k), i) for k in range(m)]
            for v in itertools.product(grid, repeat=3)
            for i in range(3) if v[i] < L}


box_receipts = []
for L in (2, 3, 4, 5, 6):
    edges, faces = graph(L)
    check(len(edges) == 3 * (2 * L) * (2 * L + 1) ** 2, 'full edge count')
    check(len(faces) == 3 * (2 * L) ** 2 * (2 * L + 1), 'full face count')
    stars = {e: 0 for e in edges}
    for word in faces.values():
        for e, _ in word:
            stars[e] += 1
    check(max(stars.values()) == 4, 'all incident face bound is attained')
    check(min(stars.values()) >= 2, 'boundary links retain incident faces')
    divisors = [m for m in range(1, 2 * L + 1) if (2 * L) % m == 0]
    levels = {}
    for m in divisors:
        q = (2 * L) // m
        paths = chains(L, m)
        flattened = [e for path in paths.values() for e in path]
        retained = set(flattened)
        check(len(flattened) == len(retained), 'coarse paths edge-disjoint')
        check(retained <= edges, 'every retained edge in original box')
        check(len(paths) == 3 * q * (q + 1) ** 2, 'coarse-edge count')
        check(len(retained) == 3 * (2 * L) * (q + 1) ** 2, 'skeleton count')
        check(len(edges - retained) == 3 * (2 * L) *
              ((2 * L + 1) ** 2 - (q + 1) ** 2), 'eliminated count')
        for e in edges:
            transverse_test = all((e[0][j] + L) % m == 0
                                  for j in range(3) if j != e[1])
            check((e in retained) == transverse_test, 'literal skeleton rule')
        coarse_face_count = 0
        for v in itertools.product(range(-L, L + 1, m), repeat=3):
            for i, j in itertools.combinations(range(3), 2):
                if v[i] == L or v[j] == L:
                    continue
                coarse_face_count += 1
                # Keep all four orientations and the order of inverse paths.
                cw = [((v, i), 1), ((step(v, i, m), j), 1),
                      ((step(v, j, m), i), -1), ((v, j), -1)]
                fine_word = []
                for ce, sign in cw:
                    fine_word.extend((e, sign) for e in
                                     (paths[ce] if sign == 1 else paths[ce][::-1]))
                check(len(fine_word) == 4 * m, 'actual fine perimeter')
                check(len({e for e, _ in fine_word}) == 4 * m, 'simple fine loop')
                current = v
                for (n, axis), sign in fine_word:
                    initial = n if sign == 1 else step(n, axis)
                    terminal = step(n, axis) if sign == 1 else n
                    check(current == initial, 'oriented path continuity')
                    current = terminal
                check(current == v, 'oriented coarse loop closes')
        check(coarse_face_count == 3 * q ** 2 * (q + 1), 'coarse face count')
        levels[m] = (paths, retained)
        box_receipts.append({'L': L, 'm': m, 'fine_edges': len(edges),
                             'retained_fine_edges': len(retained),
                             'eliminated_fine_edges': len(edges-retained),
                             'coarse_edges': len(paths),
                             'coarse_faces': coarse_face_count})
    for m in divisors:
        for n in divisors:
            if n % m:
                continue
            check(levels[n][1] <= levels[m][1], 'nested skeleton')
            for (v, i), path in levels[n][0].items():
                composed = [e for k in range(n // m)
                            for e in levels[m][0][step(v, i, k * m), i]]
                check(composed == path, 'ordered product tower')

# Exact Pauli and noncommuting path-product differential tensor.
I2 = s.eye(2)
pauli = [s.Matrix([[0, 1], [1, 0]]),
         s.Matrix([[0, -s.I], [s.I, 0]]),
         s.Matrix([[1, 0], [0, -1]])]
T = [-s.I * p / 2 for p in pauli]
mat_equal(-sum((t*t for t in T), s.zeros(2)), 3*I2/4, 'fundamental Casimir')
for a in range(3):
    for b in range(3):
        check(-2*s.trace(T[a]*T[b]) == (1 if a == b else 0), 'original metric')

sample = [s.Rational(3, 5)*I2+s.I*s.Rational(4, 5)*pauli[0],
          s.Rational(5, 13)*I2+s.I*s.Rational(12, 13)*pauli[1],
          s.Rational(7, 25)*I2+s.I*s.Rational(24, 25)*pauli[2]]
for u in sample:
    mat_equal(u*u.conjugate().T, I2, 'SU2 exact sample')
    check(s.det(u) == 1, 'sample determinant')
check(sample[0]*sample[1] != sample[1]*sample[0], 'noncommuting sample')
z = sample[0]*sample[1]*sample[2]
prefix = I2
rotations = []
for k, u in enumerate(sample):
    O = s.Matrix(3, 3, lambda b, a: -2*s.trace(T[b]*prefix*T[a]*prefix.inv()))
    rotations.append(O)
    mat_equal(O*O.T, s.eye(3), 'adjoint color rotation')
    check(s.det(O) == 1, 'proper color rotation')
    suffix = I2
    for after in sample[k+1:]:
        suffix = suffix*after
    for a in range(3):
        tangent = prefix*T[a]*u*suffix
        predicted = sum((O[b, a]*T[b]*z for b in range(3)), s.zeros(2))
        mat_equal(tangent, predicted, 'fine-to-coarse tangent')
    prefix = prefix*u
M = s.zeros(9)
M[:3, :3] = s.eye(3)
M[3:6, 3:6] = s.eye(3)
for k, O in enumerate(rotations):
    M[6:9, 3*k:3*k+3] = O
tensor = M*M.T
expected = s.diag(s.eye(3), s.eye(3), 3*s.eye(3))
expected[:3, 6:9] = rotations[0].T
expected[6:9, :3] = rotations[0]
expected[3:6, 6:9] = rotations[1].T
expected[6:9, 3:6] = rotations[1]
mat_equal(tensor, expected, 'complete mixed kinetic tensor')
check(s.det(tensor) == 1, 'kinetic coordinate map nondegenerate')
Y = s.zeros(3, 9)
for k, O in enumerate(rotations):
    Y[:, 3*k:3*k+3] = O/3
mat_equal(Y*Y.T, s.eye(3)/3, 'horizontal derivative coefficient 1/m')

# Exact rational Schur recursion with a nonzero intermediate memory block.
zeta = s.symbols('zeta', positive=True)
base = s.Matrix([[5, 1, 2, 0], [1, 6, 1, 1],
                 [2, 1, 7, 2], [0, 1, 2, 8]])
for k in range(1, 5):
    check(base[:k, :k].det() > 0, 'positive exact block matrix')
full = base+zeta*s.eye(4)
stage1 = full[:2, :2]-full[:2, 2:]*full[2:, 2:].inv()*full[2:, :2]
stage2 = stage1[0, 0]-stage1[0, 1]*stage1[1, 0]/stage1[1, 1]
direct = full[0, 0]-(full[:1, 1:]*full[1:, 1:].inv()*full[1:, :1])[0]
check(s.factor(stage2-direct) == 0, 'Schur associativity as rational function')
check(s.factor(full.inv()[0, 0]-1/direct) == 0, 'compressed inverse')
B = base[1:, :1]
C = base[1:, 1:]
w = (C+zeta*s.eye(3)).inv()*B
norm = 1+(w.T*w)[0]
check(s.factor(s.diff(direct, zeta)-norm) == 0, 'Schur derivative is dressed norm')
v = s.Matrix([1, -w[0], -w[1], -w[2]])
energy = (v.T*base*v)[0]
check(s.factor(energy-(direct-zeta*s.diff(direct, zeta))) == 0,
      'energy includes all eliminated terms')

alpha, Cstar, kappa, ell, G = s.symbols('alpha Cstar kappa ell G', positive=True)
A = 3*alpha/16
cH = 9*alpha**3/(1024*Cstar**2)
second_upper = Cstar**2*kappa**2*ell**2/alpha
check(s.simplify((A*kappa*ell/2)**2/second_upper-cH) == 0,
      'exact retained high-energy weight constant')
tau = 8*G/s.sqrt(alpha*cH)
check(s.simplify(4*G/tau-s.sqrt(alpha*cH)/2) == 0, 'dressing norm constant')
check(s.simplify((cH/4)/(1+cH/4)-cH/(4+cH)) == 0, 'dressed weight fraction')
g, spacing, m = s.symbols('g spacing m', positive=True)
check(s.simplify((3*alpha/32)*(2*g**2/spacing)*(4*m)
                 -3*alpha*g**2*m/(4*spacing)) == 0, 'physical threshold')
check(s.simplify((3*alpha/16)*(2*g**2/spacing)*(4*m)
                 -3*alpha*g**2*m/(2*spacing)) == 0, 'physical quotient lower bound')

sources = {}
for name in ['extensive_quantum_blocking.tex', 'check_extensive_blocking.py']:
    sources[name] = hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
receipt = {'status': 'passed', 'exact_assertions': assertions,
           'boxes_and_blocks': box_receipts, 'source_sha256': sources,
           'scope': 'Exact finite incidence, noncommuting SU2 tangent/tensor, '
                    'rational Schur recursion and spectral coefficient diagnostics; '
                    'the analytic all-volume proofs are in the manuscript. '
                    'No interacting vacuum is numerically replaced.'}
(ROOT/'EXACT_CHECKS.json').write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'status': 'passed', 'exact_assertions': assertions,
                  'box_block_cases': len(box_receipts)}, indent=2))

```

## Complete source: ../ym_spatial_continuum_astra_20260908/spatial_continuum.md

```markdown
---
title: "The retained cusp, spatial refinement, and the spectral measure of the actual magnetic vacuum translation"
date: "8 September 2026"
geometry: margin=1in
fontsize: 11pt
---

## 1. Objects and scope of the calculation

We calculate two simultaneous sequences in the original full spatial SU(2) theory. The first retains an arbitrary fixed positive coupling. For that sequence we prove an explicit vanishing bound for the actual, unmodified, centered magnetic state. The second retains a strictly positive, explicitly varying coupling at every regulator. For the second sequence we prove convergence of the entire excitation spectral probability after recording its energy dilation, escape of that probability from every bounded physical energy interval, convergence of configuration measures under exact refinement maps, and a failure of strong continuity for the resulting unscaled temporal correlations. The estimates use the actual vacuum at every regulator. In particular, a constant function is used as a comparison vector in inequalities, never as a replacement vacuum.

These results do not construct a four-dimensional interacting continuum counterexample. The fixed-coupling spectral probability, after division by the actual nonzero squared norm, is not determined by the vanishing bound. The second sequence provides a proved obstruction to the specific small-interaction-relative-to-the-total-electric-operator route, with an exact map to its limiting configuration measure. All constants in the Hamiltonian, including the scalar Wilson constant, remain displayed.

For an integer \(L\ge2\), the spatial vertices are \(\{-L,\ldots,L\}^3\). We retain every positive edge whose two endpoints lie in the box and every elementary face. Let
\[
 N_L=3(2L)(2L+1)^2,
 \qquad M_L=3(2L)^2(2L+1)=12L^2(2L+1).
\]
The configuration space is \(Q_L=SU(2)^{N_L}\), with product Haar probability \(\lambda_L\). Reverse traversal means the inverse of the same link. A face is traversed as
\[
 U_p=U_i(n)U_j(n+e_i)U_i(n+e_j)^{-1}U_j(n)^{-1},
 \qquad W_p=\operatorname{tr}U_p,\quad i<j.
\]
With \(T_a=-i\sigma_a/2\), let \(X_{e,a}\) be differentiation under left multiplication by \(\exp(tT_a)\), and set
\[
 E_e=-\sum_{a=1}^3X_{e,a}^2,\quad H_0=\sum_eE_e,
 \quad \mathcal W=\sum_pW_p,
\]
\[
 H_{L,a,g}=\kappa H_0+b\sum_p(2-W_p)
 =\kappa(H_0-\xi\mathcal W)+2bM_L I,
\quad \kappa=\frac{2g^2}{a},\quad b=\frac1{2g^2a},\quad
 \xi=\frac1{4g^4}.
\tag{1}
\]
The physical Lie metric is \(c(X,Y)=-\operatorname{tr}(XY)/2\), so \(\Delta^c=4\Delta^T\). Equation (1) is therefore also the Hamiltonian with electric part \(-g^2(2a)^{-1}\sum_e\Delta_e^c\). The positive real numbers \(a,g\) have not been absorbed into any new metric.

The vertex group acts by \(U_e\mapsto g_{s(e)}U_eg_{t(e)}^{-1}\). Its Haar average \(\Pi_L\) is an orthogonal projection because Haar measure is invariant under inversion and multiplication. The operator \(H\) commutes with it: left and right multiplication preserve each link Laplacian, and each face word is conjugated at its base vertex. Its range is denoted \(\mathcal H_L^{\mathrm{inv}}\).

The operator \(H_0\) is the product compact-group Laplacian, with operator domain \(H^2(Q_L)\) and form domain \(H^1(Q_L)\). The potential is smooth, bounded and real, with \(0\le b\sum_p(2-W_p)\le4bM_L\). Hence \(H\) has the same domains and compact resolvent. A ground minimizer can be made nonnegative by the gradient inequality for its absolute value; the smooth approximants \((|f|^2+\varepsilon^2)^{1/2}\) justify that inequality at zeros. Elliptic regularity and the strong maximum principle give a smooth strictly positive ground vector \(\psi\), with \(\int\psi^2d\lambda_L=1\). For smooth \(F\), the product rule and Haar integration by parts give
\[
 \langle\psi F,(H-E)\psi F\rangle
 =\kappa\sum_{e,a}\int\psi^2|X_{e,a}F|^2d\lambda_L.
\tag{2}
\]
If another ground vector existed, its quotient by \(\psi\) would have every derivative zero by (2), and thus would be constant on connected \(Q_L\). This proves simplicity. Gauge transformations preserve positivity and the chosen norm, so \(\Pi_L\psi=\psi\). All quotients by \(\psi\) below are valid on the finite compact manifold, where \(\psi\) has a positive minimum.

## 2. Original cusp and the complete physical dictionary

The canonical cusp supplies holomorphic functions \(\mu(t_c),h(t_c),b_{\mathrm{per}}(t_c)\), with the exact period identity
\[
 Z(s)=s\begin{pmatrix}0&1\\-1&0\end{pmatrix}
 +\begin{pmatrix}6\mu&h\\b_{\mathrm{per}}-h&\mu\end{pmatrix},
 \qquad t_c=e^{2\pi i s}.
\]
The notation \(b_{\mathrm{per}}\) records the canonical period function called \(b\) in the cusp source; it is distinct from the Hamiltonian coefficient in (1). On \(s=iT\), write
\[
 \mu_T=\alpha_T+im_T,\quad h_T=\eta_T+iH_T,
 \quad b_{\mathrm{per},T}=\zeta_T+iB_T^{\mathrm{per}},
\]
\[
 L_T=T+H_T,\quad q_T=L_T-B_T^{\mathrm{per}},\quad
 c_T=\zeta_T-\eta_T,\quad D_T=L_Tq_T+6m_T^2>0.
\]
In original real coordinate order \((x_1,x_2,x_3,x_4)=(\operatorname{Re}z_1,\operatorname{Im}z_1,\operatorname{Re}z_2,\operatorname{Im}z_2)\), the exact matrix is
\[
 P_T=\begin{pmatrix}
 6\alpha_T&\eta_T&1&0\\6m_T&L_T&0&0\\
 c_T&\alpha_T&0&1\\-q_T&m_T&0&0
 \end{pmatrix},\qquad \det P_T=-D_T.
\tag{3}
\]
Every bounded period correction remains in this matrix. Holomorphy gives convergence of its bounded entries with errors \(O(e^{-2\pi T})\). In particular, with
\[
 A_T=\begin{pmatrix}6\alpha_T&\eta_T\\c_T&\alpha_T\end{pmatrix},
 \quad B_T=\begin{pmatrix}6m_T&L_T\\-q_T&m_T\end{pmatrix}
 =TJ+C_T,\quad J=\begin{pmatrix}0&1\\-1&0\end{pmatrix},
\]
there is a finite \(C=\sup_{T\ge T_0}\|C_T\|\), after restricting to the specified cusp ray. Thus
\[
 D_T\ge(T-C)^2\quad(T>C),\qquad D_T=T^2+O(T).
\tag{4}
\]
For the first inequality, \(|B_Tv|\ge(T-C)|v|\) bounds both singular values from below; their product is the positive determinant \(D_T\). The second follows by multiplying the retained expressions for \(L_T,q_T,m_T\).

For a cover integer \(M_{\mathrm{cov}}\), set \(S_M=\operatorname{diag}(1,1,M_{\mathrm{cov}},M_{\mathrm{cov}})\). The torus covering is induced by
\[
 P_TS_M\mathbb Z^4\subset P_T\mathbb Z^4.
\]
It has fibre degree \(M_{\mathrm{cov}}^2\), determinant \(-M_{\mathrm{cov}}^2D_T\), metric \(G=(P_TS_M)^{\mathsf T}P_TS_M\), and positive volume density \(M_{\mathrm{cov}}^2D_T\). In the recorded permutation \((x_1,x_3;x_2,x_4)\), its period matrix and inverse are
\[
 Q=\begin{pmatrix}A_T&M_{\mathrm{cov}}I_2\\B_T&0\end{pmatrix},
 \quad Q^{-1}=\begin{pmatrix}0&B_T^{-1}\\
 M_{\mathrm{cov}}^{-1}I_2&-M_{\mathrm{cov}}^{-1}A_TB_T^{-1}\end{pmatrix},
 \quad B_T^{-1}=D_T^{-1}\begin{pmatrix}m_T&-L_T\\q_T&6m_T\end{pmatrix}.
\tag{5}
\]
Multiplication verifies both inverse identities. The permutation in (5) has determinant \(-1\); it records coordinates and does not alter the determinant of (3). Formula (5) retains the complete inverse metric as \(Q^{-1}Q^{-\mathsf T}\).

The original marked monodromy is
\[
 M_0=I+R_0,\qquad
 R_0=\begin{pmatrix}0&0&0&0\\0&0&0&0\\0&1&0&0\\-1&0&0&0\end{pmatrix}.
\]
Indeed it sends \(\widehat\gamma\) to \(\widehat\gamma-\widehat\delta\), \(\widehat u\) to \(\widehat u+\widehat w\), and fixes \(\widehat w,\widehat\delta\). Direct multiplication gives
\[
 R_0^2=0,\qquad S_M^{-1}M_0^{M_{\mathrm{cov}}}S_M=M_0.
\tag{6}
\]
Thus the degree-\(M_{\mathrm{cov}}^2\) fibre cover descends after the base change \(t_c=v^{M_{\mathrm{cov}}}\). The proof is that continuation around \(v=0\) acts on the original lattice by \(M_0^{M_{\mathrm{cov}}}\), which (6) carries to an integral automorphism in the cover basis. No cover of the entire original base or completed compact threefold is required here.

A nonzero covered period, in (5)'s order, is \((A_Tn+M_{\mathrm{cov}}z,B_Tn)\), for \(n,z\in\mathbb Z^2\). If \(n\ne0\), its length is at least \(T-C\); if \(n=0\), its length is at least \(M_{\mathrm{cov}}\). Therefore
\[
 \operatorname{sys}\ge\min(T-C,M_{\mathrm{cov}}).
\tag{7}
\]
When this bound exceeds \(4R\), the radius-\(R\) Euclidean ball is mapped isometrically to the torus: for two points in that ball and a nonzero period \(\lambda\), \(|x-y+\lambda|\ge|\lambda|-2R>2R\ge|x-y|\).

The physical time and spatial coordinates used for the Hamiltonian are
\[
 (y_0,y_1,y_2,y_3)=(x_3,x_2,x_4,x_1).
\tag{8}
\]
This permutation has determinant \(+1\) and preserves the exact Euclidean metric. The physical magnetic plane is \((y_1,y_2)\). From (5),
\[
 u_1=D_T^{-1}(m_Ty_1-L_Ty_2),\quad
 u_2=D_T^{-1}(q_Ty_1+6m_Ty_2),\quad
 du_1\wedge du_2=D_T^{-1}dy_1\wedge dy_2.
\]
The original bundle connection \(d+2\pi u_1H_cdu_2\), with \(H_c=i\sigma_3=-2T_3\), therefore has the local expression
\[
 A_{\mathrm{orig}}=\frac{2\pi H_c}{D_T^2}
 (m_Ty_1-L_Ty_2)(q_Tdy_1+6m_Tdy_2).
\]
Put
\[
 f_T(y)=\frac{2\pi}{D_T^2}
 \left(\frac{m_Tq_T}{2}y_1^2-L_Tq_Ty_1y_2-3m_TL_Ty_2^2\right).
\]
Differentiation, with all signs retained, proves
\[
 A_{\mathrm{orig}}=\frac{2\pi}{D_T}H_cy_1dy_2+H_cdf_T.
\]
The two gauge maps \(\exp(-H_cf_T)\) and \(\exp(-2\pi H_cy_1y_2/D_T)\), under \(A^h=h^{-1}Ah+h^{-1}dh\), give exactly
\[
 A_1=-\frac{2\pi}{D_T}H_cy_2dy_1,\qquad
 F_{12}=\frac{2\pi}{D_T}H_c.
\tag{9}
\]
The original transitions are \(\exp(-2\pi k_1u_2H_c)\); on a nonwrapping embedded ball they are represented by the displayed local frames. The flat reference is chosen as the identity transport in the final frame. Subsequent frame changes act on the reference and magnetic transport simultaneously. For any such pair \(M_e,R_e\), their relative transport \(h_e=M_eR_e^{-1}\) changes by conjugation at the source, proving covariance of the translated state under changes of vertex frames.

The inverse transport of (9) on the edge from \(an\) to \(a(n+e_i)\) is
\[
 h_1(n)=\exp(-\theta n_2H_c),\quad h_2(n)=h_3(n)=I,
 \qquad \theta=\frac{2\pi a^2}{D_T}.
\tag{10}
\]
Integration is exact because the coefficients commute along the edge. The face word is \(\exp(\theta H_c)\) in the 12 plane and identity in the other two planes.

For general connections, the map to the period coordinates is the usual exact pullback: \(\widetilde A_i=\sum_\alpha(P_TS_M)_{\alpha i}A_\alpha(P_TS_My)\), and \(\widetilde F\) is its exterior-square pullback. The chain rule preserves \(dA\), and bilinearity preserves every term of \(A\wedge A\). Its action is
\[
 \frac{M_{\mathrm{cov}}^2D_T}{2g^2}
 \int_{[0,1)^4}\sum_{i<j,\,k<l}
 \bigl[(G^{-1})_{ik}(G^{-1})_{jl}-(G^{-1})_{il}(G^{-1})_{jk}\bigr]
 c(\widetilde F_{ij},\widetilde F_{kl})\,d^4y.
\tag{11}
\]
This follows by the Jacobian formula for volume and the Gram determinant for two covectors. It includes all mixed terms. Pullback carries the parallel-transport differential equation to the identical equation on each path; uniqueness gives the holonomy map, including for noncommuting fields. On the embedded balls in (7), this pullback is a local isometry and preserves the full action of every compactly supported connection, extended by zero through a collar. Thus no nonlinear interaction is lost in passing to a physical cubical patch.

### 2.1 A simultaneous geometric exhaustion in unchanged physical units

Let \(j=2^r\), for integers \(r\) sufficiently large, and set
\[
 T_j=j^2,\quad t_{c,j}=e^{-2\pi j^2},\quad
 M_{\mathrm{cov},j}=j,\quad v_j=e^{-2\pi j},
\]
\[
 a_j=\frac1{100j},\quad L_j=j^2,\quad
 \ell_j=2a_jL_j=\frac j{50},\quad
 D_j=L_{j^2}q_{j^2}+6m_{j^2}^2,\quad
 \theta_j=\frac{2\pi}{10^4j^2D_j}.
\tag{12}
\]
Here subscripts on \(L_{j^2},q_{j^2},m_{j^2}\) denote the cusp functions, whereas \(L_j=j^2\) on the preceding line is the integer half-width of the spatial graph. In particular \(D_j\) is never replaced by \(j^4\). The exact identity \(v_j^j=t_{c,j}\) and (6) prove monodromy compatibility. The fibre degree is \(j^2\) and the base-change degree is \(j\).

The four-dimensional box \(|y_\mu|\le j/100\), with time coordinate (8), has radius \(R_j=j/50\). For \(j^2-C\ge j\), (7) gives \(\operatorname{sys}\ge j>8R_j\). Hence the spatial box at \(y_0=0\), the growing time interval, and a collar all embed in the actual covered cusp. The mesh tends to zero while the physical box tends to all of \(\mathbb R^3\), and the time interval tends to \(\mathbb R\).

The fixed physical reference length is the length \(\ell_*\) of the original real period vector \(e_1\) in (3). Its value in the original Euclidean metric is exactly 1. We use its reciprocal \(E_*=\ell_*^{-1}\) as a reference inverse length for energies. Neither \(\ell_*\), the metric, nor time (8) varies with \(j\). Thus \(a_j/\ell_*=1/(100j)\), the reference momentum \(p_*=2\pi/\ell_*\) stays fixed, and the finite energy interval \([0,\Omega E_*]\) means the same physical interval at every regulator. These are reference units, not an assertion that the quantum theory has a particle of mass \(E_*\).

The exact reciprocal-vector approximation can also retain this momentum. For a physical covector \(p\), choose each integer component of \(k_j\) by rounding \((P_{j^2}S_j)^{\mathsf T}p/(2\pi)\). Then
\[
 p_j=2\pi(P_{j^2}S_j)^{-\mathsf T}k_j,\qquad
 |p_j-p|\le\pi\sum_{i=1}^4|(P_{j^2}S_j)^{-\mathsf T}e_i|.
\]
Formula (5) bounds the right side by a constant times \(j^{-2}+j^{-1}\), with the original \(A_T,B_T\) retained. This proves that fixed physical spatial or temporal momenta are geometrically resolvable. It is not a dispersion relation for the interacting Hamiltonian.

The magnetic field itself supplies another exact physical length and inverse length,
\[
 \ell_{B,j}=\sqrt{\frac{D_j}{2\pi}},\qquad
 E_{B,j}=\ell_{B,j}^{-1}=\sqrt{\frac{2\pi}{D_j}}.
\]
They are defined by the retained curvature norm in (9), so
\[
 \frac{a_j}{\ell_{B,j}}=\sqrt{\theta_j},\qquad
 \frac{\ell_j}{\ell_{B,j}}=\frac{j\sqrt{2\pi}}{50\sqrt{D_j}}
 \sim\frac{\sqrt{2\pi}}{50j},\qquad
 E_{B,j}\sim\frac{\sqrt{2\pi}}{j^2}.
\]
Thus the box exhausts physical space while remaining small relative to the growing magnetic length. The flux through its full magnetic square is exactly \(2\pi\ell_j^2/D_j\), which tends to zero. These equations identify the geometric soft scale without equating it to a quantum excitation energy. Every finite cover with its pullback metric preserves the local value \(2\pi/D_j\) of the curvature, since its differential is a local isometry. Consequently no choice of cover degree can hold this original nonzero magnetic scale fixed while \(T_j\to\infty\). A varying unit of length would have the additional metric and energy effects calculated in (61); it cannot be silently used to keep this field scale constant.

## 3. Exact spectral measure and a bound at every positive coupling

Let \((T_hF)(U)=F((h_e^{-1}U_e)_e)\). Haar invariance makes this a unitary operator; its electric commutator is zero by bi-invariance. Set
\[
 c_\theta=\langle\psi,T_h\psi\rangle,
 \quad \chi_\theta=\Pi_LT_h\psi-c_\theta\psi,
 \quad d_\theta=\|\chi_\theta\|^2.
\tag{13}
\]
The positive overlap is real, and \(\chi_\theta\) is invariant and orthogonal to \(\psi\). The full magnetic translation has at most one nonidentity translated edge at each source vertex. Conjugating it by gauge transformations therefore gives an independent conjugacy average on each such link. On invariant inputs,
\[
 \Pi_LT_h\Pi_L=K_\theta\Pi_L,\qquad
 K_\theta=\prod_{e=(n,1)}C_{e,\theta n_2}.
\tag{14}
\]
Here \(C_{e,s}\) averages the left translations by the conjugacy class of \(\exp(sH_c)\). Schur's lemma applied to spin \(q\) gives the real multiplier
\[
 c_q(s)=\frac1{2q+1}\sum_{m=-q}^q e^{2ims}
 =\frac{\sin((2q+1)s)}{(2q+1)\sin s},\qquad q\in\tfrac12\mathbb Z_{\ge0}.
\tag{15}
\]
The finite sum defines the value when \(\sin s=0\). Inversion preserves the conjugacy class, so each \(C\) and their commuting product are self-adjoint contractions. They preserve constants and Haar integrals, and commute with every \(E_e\) and with \(\Pi_L\). Equations (13)-(14) thus give the exact state \(\chi_\theta=(K_\theta-c_\theta)\psi\), with no angular expansion.

Write \(h_{L,\xi}=H_0-\xi\mathcal W\), let \(e_{L,\xi}\) be its ground energy, and define \(A_{L,\xi}=h_{L,\xi}-e_{L,\xi}\). Then
\[
 E=\kappa e_{L,\xi}+2bM_L,\qquad H-E=\kappa A_{L,\xi}.
\tag{16}
\]
The same \(\psi\), \(\chi_\theta\), and \(d_\theta\) appear on both sides. For \(d_\theta>0\), the two spectral probabilities are
\[
 \rho_{L,\xi,\theta}(B)=d_\theta^{-1}
 \langle\chi_\theta,\mathbf1_B(A_{L,\xi})\chi_\theta\rangle,
\]
\[
 \nu_{L,a,g,\theta}(B)=d_\theta^{-1}
 \langle\chi_\theta,\mathbf1_B(H-E)\chi_\theta\rangle
 =\rho_{L,\xi,\theta}(\kappa^{-1}B).
\tag{17}
\]
This is the exact pushforward by \(\lambda\mapsto\kappa\lambda\). It follows first for spectral intervals from the spectral resolution of a scalar multiple, then for all Borel sets by countable additivity. The finite measure before division is \(d_\theta\nu\); the state and its amplitude have not been changed. In particular
\[
 \langle\chi_\theta,e^{-t(H-E)}\chi_\theta\rangle
 =d_\theta\int e^{-t\kappa\lambda}d\rho(\lambda).
\tag{18}
\]

### 3.1 An all-angle operator inequality

Put \(\Gamma=\sum_{e=(n,1)}n_2^2E_e\) and \(J_\theta=K_\theta-I\). On a joint spin block, (15) and \(1-\cos x\le x^2/2\) give
\[
 |1-c_q(s)|=1-c_q(s)
 \le\frac{2s^2}{2q+1}\sum_{m=-q}^qm^2
 =\frac23s^2q(q+1).
\]
The last finite-sum formula follows by pairing the weights and summing consecutive squares, also for half-integral \(q\). For real numbers \(|z_i|\le1\), telescoping the product gives \(|1-\prod_i z_i|\le\sum_i|1-z_i|\). Therefore, on every joint spin block,
\[
 |1-k(\theta)|\le\frac23\theta^2\sum_{e=(n,1)}n_2^2q_e(q_e+1).
\]
Parseval's identity and completeness of the joint matrix coefficients prove, for every \(F\in D(H_0)\),
\[
 \|J_\theta F\|\le\frac23\theta^2\|\Gamma F\|
 \le\frac23\theta^2L^2\|H_0F\|.
\tag{19}
\]
The second inequality follows on the same joint blocks from \(0\le\Gamma\le L^2H_0\); these are simultaneously diagonal positive operators. This is a graph-domain estimate, not a bounded-operator Taylor expansion.

The constant trial vector has zero electric energy and \(\int W_p=0\), so \(0\le E/\kappa\le2\xi M_L\). The eigen-equation, with \(0\le\sum_p(2-W_p)\le4M_L\), consequently gives
\[
 \|H_0\psi\|
 =\|[E/\kappa-\xi\sum_p(2-W_p)]\psi\|
 \le4\xi M_L.
\tag{20}
\]
Centering is an orthogonal projection off \(\psi\), so (19)-(20) imply the all-coupling estimate
\[
 \boxed{\quad\|\chi_\theta\|\le\frac83\theta^2L^2\xi M_L.\quad}
\tag{21}
\]
This estimate concerns the full interacting vacuum and is valid without any restriction on \(\xi M_L\).

For the fixed-coupling version of (12), set \(g_j=g_0>0\), hence \(\xi_0=1/(4g_0^4)\), \(\kappa_j=200g_0^2j\), and \(b_j=50j/g_0^2\). Once \(j^2\ge2C\), (4) yields \(D_j\ge j^4/4\). Since \(M_{L_j}\le36j^6\), direct substitution in (21) gives
\[
 \boxed{\quad\|\chi_j\|\le
 \frac{6144\pi^2\xi_0}{10^8}\,j^{-2},\qquad
 d_j\le\left(\frac{6144\pi^2\xi_0}{10^8}\right)^2j^{-4}.\quad}
\tag{22}
\]
In deriving this bound, the exact angle satisfies \(\theta_j^2L_j^2=4\pi^2/(10^8D_j^2)\); the determinant estimate is applied only afterwards. Thus every unscaled excitation spectral measure \(d_j\nu_j\) converges to the zero measure in total mass. Division by \(d_j\) in (17) prevents this fact from deciding \(\nu_j\).

For completeness, the uncentered projected vectors also converge to their respective vacua. Indeed \(|c_j-1|\le\|J_{\theta_j}\psi_j\|\), and (19)-(20) give exactly the same right side as (22). If \(F_j=K_{\theta_j}\psi_j\), then for each multiplication observable \(f\) with \(\|f\|_\infty\le1\),
\[
 \left|\int f(F_j^2-\psi_j^2)d\lambda_j\right|
 \le\|F_j-\psi_j\|(\|F_j\|+\|\psi_j\|)
 \le2\|J_{\theta_j}\psi_j\|.
\tag{23}
\]
Here \(F_j^2d\lambda_j\) is the actual finite measure of mass \(\|F_j\|^2\), which tends to 1; no mass convention has been changed.

## 4. A volume-explicit estimate for the whole excitation measure

We now prove a relative estimate that remains useful as both the angle and the volume vary. Its constants do not divide by an unspecified small angular remainder.

### 4.1 The exact first physical electric eigenvalue

On one link, spin \(q\) has \(E_e\) eigenvalue \(q(q+1)\); for the fundamental representation this is \(3/4\), obtained directly from \(-\sum_aT_a^2=3I/4\). At a vertex, a gauge invariant tensor involving exactly one nontrivial incident representation is impossible: that irreducible representation has no fixed vector. Hence the support graph of nonzero edge spins in any nonconstant gauge invariant joint-spin block has no vertex of degree one. Any nonempty finite graph with this property contains a cycle, as follows by following edges without immediately reversing and stopping at the first repeated vertex. The open cubical graph is simple and bipartite and has no triangular cycles, so a cycle has at least four edges. Consequently its electric sum is at least \(4(3/4)=3\). Equality is attained by the fundamental trace around any elementary square, whose four links have spin \(1/2\).

Peter--Weyl decomposition and vertex averaging preserve each finite joint-spin block and give a complete invariant basis. The preceding argument therefore proves the form inequality
\[
 H_0\big|_{\mathcal H_L^{\mathrm{inv}}\ominus\mathbb C1}\ge3I.
\tag{24}
\]
The constant is an exact physical-sector gap for the comparison operator \(H_0\), not an assumed gap for \(H\).

For distinct elementary faces, integrating a link occurring in just one trace gives zero, since multiplication of that link by \(-I\) changes the sign. Two distinct elementary squares have distinct four-edge supports. A single face product is Haar, and the trace has second moment 1: in the unit-quaternion model the scalar coordinate has second moment \(1/4\). Hence
\[
 \int W_p=0,\quad\langle W_p,W_q\rangle=\delta_{pq},
 \quad H_0W_p=3W_p,\quad\|\mathcal W\|_2=\sqrt{M_L},
 \quad\|\mathcal W\|_\infty=2M_L.
\tag{25}
\]
The last equality is attained at the identity configuration and holds for the essential supremum by continuity and positive Haar measure of neighborhoods.

The upper endpoint \(4bM_L\) of the full potential is attained as well. Define central links \(z_i(n)=(-1)^{\sum_{k<i}n_k}I\). On a face \(i<j\), shifting in direction \(i\) changes the sign of \(z_j\), while shifting in direction \(j\) does not change \(z_i\). The product of the four central signs is therefore \(-I\). Every face trace is \(-2\), so the potential equals \(4bM_L\). Continuity again identifies this maximum with the multiplication-operator norm. This proves the norm assertion used in (39) without dropping any face.

Since \(h_{L,\xi}=H_0-\xi\mathcal W\), its ground eigenvalue satisfies \(-2\xi M_L\le e\le0\). The min-max principle and (24)-(25) give the first eigenvalue above its ground at least \(3-2\xi M_L\), before subtraction of \(e\). Since \(e\le0\),
\[
 \boxed{\quad A_{L,\xi}\big|_{\psi^\perp\cap\mathcal H_L^{\mathrm{inv}}}
 \ge(3-2\xi M_L)I.\quad}
\tag{26}
\]
This lower bound is useful when its right side is positive. It is valid for the entire invariant excitation space, independently of the chosen magnetic state.

### 4.2 A controlled comparison with the actual vacuum

Write \(\psi=s1+\zeta\), with \(s=\int\psi>0\), \(\int\zeta=0\), and \(s^2+\|\zeta\|^2=1\). Let \(Q\) be the projection off the constant function. Put \(\varepsilon=\xi M_L\), and suppose for the bounds in this subsection that \(0<\varepsilon\le1/2\). The exact eigen-equation projected by \(Q\) is
\[
 (H_0-e)\zeta=\xi s\mathcal W+\xi Q\mathcal W\zeta.
\]
By (24), \(\|(H_0-e)^{-1}Q\|\le1/(3-e)\). Applying (25), rearranging, and using \(s\le1,e\le0\) proves
\[
 \|\zeta\|\le\frac{\xi\sqrt{M_L}}{3-2\varepsilon}
 \le\frac{\xi\sqrt{M_L}}2.
\tag{27}
\]
Set \(A=\mathcal W/3\) and retain the exact remainder \(r=\psi-1-\xi A\). The same equation gives
\[
 H_0r=\xi(s-1)\mathcal W+e\zeta+\xi Q\mathcal W\zeta.
\]
Since \(1-s=\|\zeta\|^2/(1+s)\le\|\zeta\|^2\), \(|e|\le2\varepsilon\), and \(\xi\le1\), equation (27) yields
\[
 \boxed{\quad\|H_0r\|\le
 \frac{\xi^3M_L^{3/2}}4+2\xi^2M_L^{3/2}
 \le\frac94\xi^2M_L^{3/2}.\quad}
\tag{28}
\]
No convergence of a perturbation series, no unknown Sobolev constant, and no approximation of the true probability density are used in (27)-(28).

Define the explicit finite vector
\[
 V_\theta=J_\theta A=\frac13\sum_p(\alpha_p(\theta)-1)W_p.
\tag{29}
\]
The coefficients follow from (14)-(15) on the fundamental representation of the two direction-1 edges of each face:
\[
 \alpha_{n;12}=\cos(n_2\theta)\cos((n_2+1)\theta),\quad
 \alpha_{n;13}=\cos^2(n_2\theta),\quad\alpha_{n;23}=1.
\tag{30}
\]
The two translated edges of such a face have distinct source vertices, which justifies the product of the two averages in this particular background. Thus
\[
 \|V_\theta\|^2=\mathcal D_L(\theta)/9,\quad
 H_0V_\theta=3V_\theta,\quad\int V_\theta=0,
\]
\[
 \mathcal D_L(\theta)=2L(2L+1)\sum_{m=-L}^{L-1}
 [1-\cos(m\theta)\cos((m+1)\theta)]^2
 +4L^2\sum_{m=-L}^{L}\sin^4(m\theta).
\tag{31}
\]

The actual centered state is nonzero for every \(b>0\) and \(\theta\notin2\pi\mathbb Z\), without a small-coupling restriction. To prove this, suppose \(\chi_\theta=0\). Haar integration in \(K_\theta\psi=c_\theta\psi\) gives \(c_\theta=1\), since \(\int\psi>0\) and \(K_\theta\) preserves that integral. Unitarity then gives \(\|T_h\psi-\psi\|^2=2-2c_\theta=0\). Apply \(T_h\) to the exact eigen-equation, use its electric commutation, and subtract the original equation. The result is \(b(T_h\mathcal W-\mathcal W)\psi=0\). Strict positivity and smoothness imply \(T_h\mathcal W=\mathcal W\) pointwise. Its gauge average, (30), and the orthogonality (25) imply \(\alpha_p=1\) for every face. A 12 face based at \(n_2=0\) exists and has \(\alpha_p=\cos\theta\), so \(\theta\in2\pi\mathbb Z\). Conversely, at these angles every link (10) is identity and \(\chi_\theta=0\). This proves the exact zero set and, in particular, legitimizes (17) on both sequences (12) for all sufficiently large indices.

We need a lower estimate with a completely displayed domain. Let \(r_m=m^2+m+1/2\). The elementary inequality
\[
 0\le t^2/2-(1-\cos t)\le t^4/24
\]
follows from \(|\sin(t/2)|\le|t/2|\) and the Taylor integral remainder. Applying it to \(x+y\) and \(x-y\) gives, for \(u=1-\cos x\cos y\), \(q=(x^2+y^2)/2\),
\[
 0\le u\le q,\quad 0\le q-u\le q^2/3,
 \quad0\le q^2-u^2\le2q^3/3.
\]
The same last estimate holds for \(u=\sin^2x,q=x^2\). Substitution into (31) gives
\[
 \mathcal D_L(\theta)\ge\mathcal A_L\theta^4-16L^9\theta^6,
\]
\[
 \mathcal A_L=
 \frac{L^2(2L+1)}{15}(24L^4+24L^3+8L^2-4L+3)
 \ge\frac{16}{5}L^7.
\tag{32}
\]
For the exact polynomial, expand \(r_m^2\), sum, and use
\[
 \sum_{m=-L}^{L-1}r_m^2=\frac{L(4L^4+1)}{10},\qquad
 \sum_{m=-L}^Lm^4=\frac{L(L+1)(2L+1)(3L^2+3L-1)}{15}.
\]
Each identity is verified at \(L=1\); subtracting its value at \(L\) from that at \(L+1\) gives exactly the two new endpoint summands, proving it for every integer. The error coefficient is bounded by
\((2/3)[2L(2L+1)(2L)L^6+4L^2(2L+1)L^6]\le16L^9\), because \(r_m\le L^2\). Expansion of \(\mathcal A_L\) gives \((16/5)L^7+(24/5)L^6+(8/3)L^5+(2/15)L^3+(1/5)L^2\), proving its lower bound.

Consequently, whenever \(0<\theta^2L^2\le1/10\),
\[
 \|V_\theta\|\ge\frac13\theta^2L^{7/2}>0.
\tag{33}
\]
Combining (19),(28),(33), and \(M_L\le36L^3\) gives
\[
 B_\theta:=\|J_\theta\psi-\xi V_\theta\|
 \le\frac32\theta^2L^2\xi^2M_L^{3/2},
 \qquad\frac{B_\theta}{\xi\|V_\theta\|}\le27\varepsilon.
\tag{34}
\]
Since \(J_\theta\) preserves Haar integrals and annihilates 1,
\[
 c_\theta-1=\langle\zeta,J_\theta\psi\rangle.
\]
Thus (13) and (34) give
\[
 \|\chi_\theta-\xi V_\theta\|
 \le B_\theta+\|\zeta\|(\xi\|V_\theta\|+B_\theta).
\]
For \(\varepsilon\le1/2\), (27) implies \(\|\zeta\|\le\varepsilon/2\le1/4\). We have proved the explicit relative estimate
\[
 \boxed{\quad
 \|\chi_\theta-\xi V_\theta\|\le
 40\varepsilon\,\xi\|V_\theta\|,
 \qquad 0<\varepsilon\le\tfrac12,
 \quad0<\theta^2L^2\le\tfrac1{10}.
 \quad}
\tag{35}
\]
The constant follows from \((1+1/4)27+1/2=137/4<40\). In particular, when \(40\varepsilon<1\), the actual state is nonzero and
\[
 (1-40\varepsilon)^2\frac{\xi^2\mathcal D_L(\theta)}9
 \le d_\theta\le
 (1+40\varepsilon)^2\frac{\xi^2\mathcal D_L(\theta)}9.
\tag{36}
\]
This is a simultaneous bound, not an iterated fixed-volume coefficient.

### 4.3 Concentration of the full excitation probability

For \(\delta>0\), let \(P_\delta\) be the spectral projection of \(A_{L,\xi}\) on \(\{\lambda:|\lambda-3|>\delta\}\). From (25),(29),
\[
 \|(A_{L,\xi}-3)V_\theta\|
 =\|(-\xi\mathcal W-e)V_\theta\|
 \le4\varepsilon\|V_\theta\|.
\]
The spectral theorem gives \(\|P_\delta V_\theta\|\le(4\varepsilon/\delta)\|V_\theta\|\). Equation (35) bounds its actual-state counterpart by
\[
 \|P_\delta\chi_\theta\|
 \le(40+4/\delta)\varepsilon\xi\|V_\theta\|.
\]
When \(\varepsilon\le1/100\), (36) makes \(\|\chi_\theta\|\ge(1-40\varepsilon)\xi\|V_\theta\|\ge\tfrac12\xi\|V_\theta\|\). Hence
\[
 \boxed{\quad
 \rho_{L,\xi,\theta}(\{\lambda:|\lambda-3|>\delta\})
 \le(80+8/\delta)^2\varepsilon^2.
 \quad}
\tag{37}
\]
This estimate treats all spectral channels of the interacting operator. It imposes no cutoff on edge spins and discards none of the off-diagonal Wilson matrix elements.

## 5. Explicit joint sequence and its physical spectral consequences

Keep all geometric data (12), and define the second coupling sequence by
\[
 M_j:=M_{L_j}=12j^4(2j^2+1),\qquad
 \xi_j=\frac1{j^2M_j},\qquad
 g_j^4=\frac{j^2M_j}{4},\qquad
 g_j^2=\frac j2\sqrt{M_j}.
\tag{38}
\]
Every \(g_j\) is strictly positive and finite. Its actual Hamiltonian coefficients are
\[
 \kappa_j=100j^2\sqrt{M_j},\qquad
 b_j=\frac{100}{\sqrt{M_j}},\qquad
 2b_jM_j=200\sqrt{M_j},\qquad
 \xi_jM_j=j^{-2}.
\tag{39}
\]
In particular the complete magnetic potential still has norm \(4b_jM_j=400\sqrt{M_j}\), which diverges. It was not removed from the physical operator; the norm of its nonscalar part relative to \(\kappa_j\) is \(2/j^2\).

The angular condition of (35) holds for all sufficiently large \(j\), because
\[
 \theta_j^2L_j^2=\frac{4\pi^2}{10^8D_j^2}\longrightarrow0.
\]
For \(j\ge10\) satisfying that condition, (36)-(37) apply to the actual \(\psi_j\) and \(\chi_j\). They prove
\[
 \rho_j\Longrightarrow\delta_3,\qquad
 \rho_j(|\lambda-3|>\delta)\le(80+8/\delta)^2j^{-4}.
\tag{40}
\]
For a bounded continuous test function, continuity near 3 and the tail bound in (40) prove weak convergence by splitting its integral into \(|\lambda-3|\le\delta\) and its complement. The same estimate proves tightness of these probabilities in the recorded variable \(\lambda=\omega/\kappa_j\).

The physical probabilities have a different computed behavior. Equations (17),(26),(39) give
\[
 \operatorname{supp}\nu_j\subset
 [\kappa_j(3-2/j^2),\infty),\qquad
 \kappa_j\sim100\sqrt{24}\,j^5.
\tag{41}
\]
For every fixed finite physical \(\Omega\), therefore,
\[
 \boxed{\quad \nu_j([0,\Omega])=0\quad\hbox{for all sufficiently large }j.\quad}
\tag{42}
\]
No subsequence of \(\nu_j\) is tight on \([0,\infty)\): every compact subset is bounded and eventually has zero mass. The measures converge vaguely to zero against continuous compactly supported functions, while each retains total mass 1. This is spectral escape, not a zero-energy limit.

The original state amplitude has a simultaneous limit as well. Equations (31)-(32), with \(L_j=j^2\), \(D_j=j^4+O(j^2)\), and (12), give
\[
 j^{10}\mathcal D_{L_j}(\theta_j)
 \longrightarrow\frac{16}{5}\left(\frac{2\pi}{10^4}\right)^4.
\]
Indeed the degree-seven term of \(\mathcal A_{j^2}\) times \(\theta_j^4\) has this limit, and the error in (32), after multiplication by \(j^{10}\), is bounded by \(16j^{28}\theta_j^6=O(j^{-8})\). Since \(j^8\xi_j\to1/24\), the relative bounds (36) prove the genuine joint limit
\[
 \boxed{\quad
 j^{26}d_j\longrightarrow
 \frac1{1620}\left(\frac{2\pi}{10^4}\right)^4.
 \quad}
\tag{43}
\]
The raw measure remains \(d_j\nu_j\). Equations (41)-(43) display both its vanishing amplitude and its energy escape without exchanging the two limits.

The physical time scale in (18) is also explicit. For every fixed \(t>0\),
\[
 0\le d_j^{-1}\langle\chi_j,e^{-t(H_j-E_j)}\chi_j\rangle
 \le e^{-t\kappa_j(3-2/j^2)}\longrightarrow0.
\tag{44}
\]
At the varying physical time \(t_j=s/\kappa_j\), with \(s\ge0\) fixed, (18),(40) instead give
\[
 d_j^{-1}\langle\chi_j,e^{-(s/\kappa_j)(H_j-E_j)}\chi_j\rangle
 \longrightarrow e^{-3s}.
\tag{45}
\]
The test function \(e^{-s\lambda}\) is bounded and continuous, so (45) follows directly from the full spectral convergence. Time \(s\) is the explicitly dilated time; \(t_j\) tends to zero in the physical coordinate (8). Holding \(\kappa_j\) at a fixed positive \(\kappa_*\) while keeping the coupling (38) would require
\[
 a_j=\frac{2g_j^2}{\kappa_*}=\frac{j\sqrt{M_j}}{\kappa_*},
\]
which diverges. Conversely, holding \(\kappa_*\) with \(a_j\downarrow0\) forces \(g_j^2=\kappa_*a_j/2\) and
\[
 \xi_jM_j=\frac{M_j}{\kappa_*^2a_j^2}\longrightarrow\infty.
\tag{46}
\]
Thus the controlled sequence (38) cannot be corrected into a fixed electric energy scale by retaining its coupling and also refining the mesh.

A broader precise obstruction follows directly from (26). On any sequence with \(a_j\downarrow0\) and \(0<\xi_jM_j\le\eta<3/2\), the original dictionary gives
\[
 \kappa_j=\frac1{a_j\sqrt{\xi_j}}
 \ge\frac{\sqrt{M_j}}{a_j\sqrt\eta},
\quad \operatorname{gap}(H_j)\ge
 \frac{(3-2\eta)\sqrt{M_j}}{a_j\sqrt\eta}\longrightarrow\infty.
\tag{47}
\]
Every vacuum-orthogonal invariant spectral probability then escapes bounded physical energies, not only the magnetic one. This statement has the displayed coupling-volume domain. A fixed positive coupling on the growing box has \(\xi_jM_j\to\infty\) and is outside that domain. Equation (47) makes no assertion of spectral escape there.

## 6. Exact refinement maps, measures, and their limits

### 6.1 Configuration, gauge, field and electric-operator maps

Because \(j\) is dyadic, every edge of the graph in (12) at \(j\) is the concatenation of two fine edges at \(2j\); the old physical box is contained in the new one. Define
\[
 p_{j,2j}:Q_{L_{2j}}\longrightarrow Q_{L_j},\qquad
 (p_{j,2j}U)_{(n,i)}=U_i(2n)U_i(2n+e_i).
\tag{48}
\]
It ignores all other fine links. Concatenations for distinct coarse edges use disjoint fine edges. The map is continuous and surjective: assign the first link in each pair the desired coarse value and the second identity, then assign unused links identity. This gives a continuous section in the fixed frames. Fine vertex gauge transformations cancel at the intermediate vertex, leaving exactly the coarse endpoint action. Thus (48) induces a map of gauge quotients as well. Associativity proves \(p_{j,4j}=p_{j,2j}p_{2j,4j}\).

For each pair, the variable change
\[
 (U^{(1)},U^{(2)})\longleftrightarrow
 (W=U^{(1)}U^{(2)},Z=U^{(1)}),\qquad
 U^{(2)}=Z^{-1}W
\tag{49}
\]
is a diffeomorphism preserving product Haar measure. To prove the measure assertion, integrate first over \(U^{(2)}\) at fixed \(Z\) and use left invariance. Applying (49) to each disjoint pair proves
\[
 (p_{j,2j})_*\lambda_{2j}=\lambda_j.
\tag{50}
\]
Thus pullback is an exact Haar-Hilbert-space isometry and an algebra homomorphism, preserving complex conjugation and the sup norm. Inverse parallel transport along two consecutive segments multiplies in the order in (48), so every smooth connection's link assignment obeys this same map, with its full non-Abelian path ordering.

For smooth \(f\) on the coarse configuration, each of the two fine edge Casimirs differentiating \(f(U^{(1)}U^{(2)})\) gives the coarse Casimir. For the first edge this is direct left differentiation. For the second, differentiation is conjugated by \(U^{(1)}\); the orthogonality of its adjoint action preserves the sum of three squares. All unused-edge derivatives annihilate the pullback. Consequently
\[
 H_{0,2j}p_{j,2j}^*f=2p_{j,2j}^*H_{0,j}f.
\tag{51}
\]
For the full Hamiltonians the exact defect, with \(V_j=b_j\sum_p(2-W_p)\), is
\[
 H_{2j}p^*f-p^*H_jf
 =(2\kappa_{2j}-\kappa_j)p^*H_{0,j}f
 +(V_{2j}-p^*V_j)p^*f.
\tag{52}
\]
The fine potential and the coarse face word in the second term are both retained; (52) is not set to zero. Smooth cylinders are within both operator domains, so it is an equality of Hilbert-space vectors on the displayed domain.

The changing cusp determinant also appears in the background map. On a coarse direction-1 edge, the product of the two fine background links equals
\[
 \exp\left(-\frac{2\pi a_j^2}{D_{2j}}n_2H_c\right).
\]
The original coarse background instead has \(D_j\) in the denominator. Their exact relative factor is
\[
 \exp\left[-2\pi a_j^2n_2
 \left(\frac1{D_{2j}}-\frac1{D_j}\right)H_c\right].
\tag{53}
\]
Even for a fixed determinant, arbitrary quantum links cannot be translated and then blocked by merely multiplying the background translations. For two fine links the actual translated product is
\[
 (h_1^{-1}U_1)(h_2^{-1}U_2)
 =h_1^{-1}(U_1h_2^{-1}U_1^{-1})(U_1U_2).
\tag{54}
\]
The effective left insertion is therefore \(h_1^{-1}\operatorname{Ad}_{U_1}(h_2^{-1})\), with its exact dependence on the integrated link. Formula (54) is the morphism between the two presentations; no independence of that conjugation is assumed.

### 6.2 The exact vacuum and translated-state measure maps

Let \(d\mu_{2j}=\psi_{2j}^2d\lambda_{2j}\). In the coordinates (49), collect all split-link \(Z\)'s and all unused links into \(Z_{\mathrm{all}}\). Write \(\Phi(W,Z_{\mathrm{all}})\) for the inverse change of variables. The exact marginal density is
\[
 r_j^{(2j)}(W)=\int
 \psi_{2j}(\Phi(W,Z_{\mathrm{all}}))^2dZ_{\mathrm{all}},
 \qquad (p_{j,2j})_*\mu_{2j}=r_j^{(2j)}d\lambda_j.
\tag{55}
\]
This is positive and smooth on the compact coarse configuration, by differentiation under the finite compact integral. It is gauge invariant by (48) and invariance of \(\mu_{2j}\). Equation (55) does not identify \(r_j^{(2j)}\) with \(\psi_j^2\).

For the exact centered state write \(f_{2j}=\chi_{2j}/\psi_{2j}\), retaining its amplitude. Its pushed-forward finite measure is
\[
 (p_{j,2j})_*(|\chi_{2j}|^2d\lambda_{2j})
 =r_j^{(2j)}(W)
 \left[\frac{\int |f_{2j}(\Phi)|^2\psi_{2j}(\Phi)^2dZ_{\mathrm{all}}}
 {r_j^{(2j)}(W)}\right]d\lambda_j(W).
\tag{56}
\]
The conditional mean
\[
 \bar f_j(W)=\frac{\int f_{2j}(\Phi)\psi_{2j}(\Phi)^2dZ_{\mathrm{all}}}
 {r_j^{(2j)}(W)}
\]
defines the orthogonal projection of \(f_{2j}\) onto coarse observables in \(L^2(\mu_{2j})\). Indeed subtracting its pullback has zero inner product with every coarse function, directly by Fubini. Its exact norm decomposition is
\[
 \|\chi_{2j}\|^2
 =\int |\bar f_j|^2r_j^{(2j)}d\lambda_j
 +\int|f_{2j}-p^*\bar f_j|^2d\mu_{2j}.
\tag{57}
\]
The second term is retained. Equations (54)-(57) give explicit maps of quantum link variables, measures and gauge-invariant states through refinement, including the interaction-dependent conditional law. They do not require a proposed continuum vacuum.

### 6.3 Actual configuration compactness at fixed coupling

Let \(\mathcal Q_\infty\) be the inverse limit of the countable compact spaces \(Q_{L_j}\) under (48). It is a closed subset of their compact metrizable product, since each equality \(p_{j,2j}U_{2j}=U_j\) is closed; hence it is compact and metrizable. Surjectivity of the coordinate maps follows by successively using the section after (48). Cylindrical continuous functions form a unital self-adjoint algebra separating its points; the Stone--Weierstrass theorem makes them uniformly dense in \(C(\mathcal Q_\infty)\).

For either actual sequence of vacua, and any fixed coarse index \(k\), the pushforwards \((p_{k,j})_*\mu_j\), \(j\ge k\), are probability measures on compact \(Q_{L_k}\). Their weak sequential compactness follows by taking a countable uniformly dense set of continuous functions, choosing a diagonal subsequence of their bounded integrals, and extending the limiting positive functional by uniform continuity; the Riesz representation theorem supplies the limiting probability. Diagonalize once more over the countably many \(k\). The resulting probabilities \(\mu_k^\infty\) are consistent, since
\[
 (p_{k,l})_* (p_{l,j})_*\mu_j=(p_{k,j})_*\mu_j
\]
at every finite regulator, and continuous pullback permits passage to the weak limit. They define a positive functional on the cylindrical algebra; the same density and Riesz argument give a unique probability \(\mu^\infty\) on \(\mathcal Q_\infty\) with these marginals. Gauge invariance passes to this limit. This proves actual subsequential configuration compactness for the fixed-coupling vacua. It is a compact topology of holonomies on the displayed dyadic path family, not a claimed topology of distributional curvature or convergence of Hamiltonians.

Equation (23) shows that the uncentered projected magnetic finite measures have exactly the same subsequential limits as their corresponding vacua on these cylinders. Their centered finite measures have total mass tending to zero by (22). These are proved convergence statements at fixed positive coupling, while the probability obtained from the centered state after division by \(d_j\) still has no energy-tightness estimate from them.

### 6.4 The explicit configuration limit of (38)

For the controlled sequence, (27) gives
\[
 \|\psi_j-1\|^2=2(1-s_j)\le2\|\zeta_j\|^2,
 \quad\|\psi_j-1\|\le\frac{\sqrt2}{2}\xi_j\sqrt{M_j}.
\]
For the total variation convention
\(\|\mu-\lambda\|_{\mathrm{var}}=\sup_{\|f\|_\infty\le1}|\mu(f)-\lambda(f)|\), Cauchy--Schwarz therefore proves
\[
 \|\mu_j-\lambda_j\|_{\mathrm{var}}
 \le\int|\psi_j^2-1|d\lambda_j
 \le2\|\psi_j-1\|
 \le\sqrt2\xi_j\sqrt{M_j}=\frac{\sqrt2}{j^2\sqrt{M_j}}.
\tag{58}
\]
Pushforward cannot increase this norm, because composition preserves the bound on a test function. Equations (50),(58) give, for every fixed \(k\),
\[
 \|(p_{k,j})_*\mu_j-\lambda_k\|_{\mathrm{var}}
 \le\frac{\sqrt2}{j^2\sqrt{M_j}}\longrightarrow0.
\tag{59}
\]
Thus the whole sequence, not only a subsequence, converges on all cylinders to the projective Haar probability. Existence and uniqueness follow from the construction in the preceding subsection and the exact consistency (50). This is the restriction of the projective Haar generalized-connection construction to the present countable cubical path family. The measure is a computed limit of the actual interacting vacua in (38); no equality between a finite \(\psi_j\) and the constant vector is asserted.

## 7. The computed temporal obstruction and an exact change of scales

Take a fixed elementary square of one coarse graph, and let \(W\) be its trace as a cylinder observable on every refinement. Haar integration on that graph gives \(\lambda(W)=0\) and \(\lambda(W^2)=1\), by the four-edge argument in (25). Equation (59) proves
\[
 \mu_j(W)\longrightarrow0,\qquad
 v_j:=\|(W-\mu_j(W))\psi_j\|^2\longrightarrow1.
\]
Let
\[
 C_j(t)=\langle(W-\mu_j(W))\psi_j,
 e^{-t(H_j-E_j)}(W-\mu_j(W))\psi_j\rangle.
\]
The vector is invariant and orthogonal to the actual vacuum. Applying (26),(39) to it proves
\[
 0\le C_j(t)\le v_j e^{-t\kappa_j(3-2/j^2)}.
\]
Hence the pointwise limiting function satisfies
\[
 C(0)=1,\qquad C(t)=0\quad(t>0).
\tag{60}
\]
There is no Hilbert-space vector \(v\) of squared norm 1 and nonnegative self-adjoint operator \(A\) whose strongly continuous semigroup has \(C(t)=\langle v,e^{-tA}v\rangle\). In fact spectral calculus and dominated convergence give \(\|e^{-tA}v-v\|^2=\int|e^{-t\omega}-1|^2d\langle v,\mathbf1_{d\omega}(A)v\rangle\to0\), forcing \(C(t)\to1\) as \(t\downarrow0\). This contradicts (60). Thus the direct configuration limit in (59), with these fixed physical Wilson observables and unscaled time, does not reconstruct such an evolution.

This is a specific dynamical obstruction in addition to spectral escape. It does not forbid other coupling trajectories or differently constructed observables. The exact comparison between them is (17), (46), (52), and (54)-(57), rather than a declaration that different presentations have no relation.

For an actual uniform spatial dilation \(x'=sx\) of the same finite graph, retaining its link variables and \(g\), the pulled connection is \(A'(x')=s^{-1}A(x'/s)\); its curvature is \(s^{-2}F(x'/s)\), including the commutator, since both differentiated and bracket terms acquire \(s^{-2}\). The dilated metric volume is \(s^4dx\), so the four-dimensional action (11) is unchanged. The lattice dictionary gives
\[
 a'=sa,\quad\kappa'=\kappa/s,\quad b'=b/s,
 \quad H'=H/s,\quad E'=E/s,\quad
 \nu'(B)=\nu(sB).
\tag{61}
\]
These are identities on the same finite configuration Hilbert space. If the time coordinate is also dilated by \(s\), then \(t'(H'-E')=t(H-E)\). Thus changes of coordinate scale have an exact spectral dictionary; none of (40)-(45) is a spectral disproof obtained by concealing such a dilation. In (12), the original physical metric and \(\ell_*\) stay fixed throughout.

## 8. Relation to temporal transfer and continuum literature

The retained finite-spatial-regulator temporal Wilson coefficients are
\[
 b_t(\epsilon)=\frac{a}{2g^2\epsilon},\quad
 b_s(\epsilon)=\frac{\epsilon}{2g^2a},\quad
 Z(b_t)=\frac{I_1(2b_t)}{b_t}.
\]
The exact temporal-link integral is
\[
 \mathcal T_\epsilon^{\mathrm{raw}}
 =[e^{-2b_t}Z(b_t)]^{N_L}
 M_\epsilon K_\epsilon M_\epsilon\Pi_L,
 \quad M_\epsilon=e^{-\epsilon V/2},
\]
where the single-edge multiplier of \(K_\epsilon\) is \(I_{2q+1}(2b_t)/I_1(2b_t)\).

The companion temporal-transfer proof, retained in the sources directory, proves its strong power limit to \(e^{-tH}\Pi_L\), with the scalar energy shift \(N_L[2b_t-\log Z(b_t)]/\epsilon\) retained. Its correlation-ratio identity applies directly to (18) and to \(C_j(t)\): at each fixed \(j\), the raw scalar cancels exactly between numerator and vacuum denominator. Thus all spectral statements here are statements about the actual temporal-limit Hamiltonian of that full finite Wilson system. No uniform-in-\(j\) error bound for replacing \(H_j\) by a simultaneous finite-time-step transfer is used or asserted.

The literature comparison is tied to the proved maps above:

- K. Osterwalder and E. Seiler, *Gauge field theories on a lattice*, Annals of Physics **110** (1978), 440-471, [doi:10.1016/0003-4916(78)90039-8](https://doi.org/10.1016/0003-4916(78)90039-8), establish transfer positivity and strongly coupled infinite-volume lattice results. Their lattice transfer framework supports comparison with the finite temporal operator just displayed; it does not identify a single-time Wilson density with the Hamiltonian density \(\psi_j^2\) in (55).

- A. Ashtekar and J. Lewandowski, *Projective techniques and functional integration for gauge theories*, Journal of Mathematical Physics **36** (1995), 2170-2191, [doi:10.1063/1.531037](https://doi.org/10.1063/1.531037), [arXiv:gr-qc/9411046](https://arxiv.org/abs/gr-qc/9411046), Theorem 2 and Sections 2.3, 3.3, give the compact projective-measure framework. The precise hypotheses here are continuous surjective maps (48), their composition identity, and consistent limiting probabilities proved after (57). The finite vacuum measures are not presumed consistent. Our countable cubical construction is proved directly, and (59)-(60) calculate both its limiting measure and its temporal limitation. Their source TeX is retained under `sources/Ashtekar_Lewandowski_1994`.

- S. Chatterjee, *Yang-Mills for probabilists*, in *Probability and Analysis in Interacting Physical Systems*, Springer Proceedings in Mathematics and Statistics **283** (2019), 1-16, [doi:10.1007/978-3-030-15338-0_1](https://doi.org/10.1007/978-3-030-15338-0_1), [arXiv:1803.01950](https://arxiv.org/abs/1803.01950), Sections 3 and 6-7, distinguishes finite Wilson measures and the scaling of loop observables needed for a continuum limit. His lattice action \(S_\Lambda=\sum_p\operatorname{Re}\operatorname{Tr}(I-U_p)\) is exactly \(\sum_p(2-W_p)\) for SU(2). Therefore his coefficient \(\beta\) equals \(b_t\) on our temporal faces and \(b_s\) on spatial faces of the anisotropic finite integral; it is not the Hamiltonian \(b=b_s/\epsilon\). This coefficient dictionary is exact and prevents substituting a fixed isotropic Wilson parameter for (38)-(39). Source TeX is retained under `sources/Chatterjee_2018`.

The local primary corpus `Tong_Gauge_Theory_20260904/gt.txt` was also consulted for the lattice Hamiltonian and continuum discussion; it supplies context rather than a vacuum estimate used in any proof here. Every spectral estimate in Sections 3-7 is proved above with the original finite operator and original coefficients.

A current primary construction can be compared by an exact density map. S. Chatterjee, *A scaling limit of SU(2) lattice Yang-Mills-Higgs theory*, [arXiv:2401.10507v2](https://arxiv.org/abs/2401.10507v2), Theorem 3.2, treats the unitary-gauge stereographic field \(\sqrt2\sigma_3(\tau(U_e))/g_H\). With \(\alpha\to\infty\), \(g_H\to0\), \(\alpha g_H=c\epsilon\), and \(g_H=O(\epsilon^{50d})\), its specified spatially dilated distributional fields converge to three independent Proca fields of mass \(c/\sqrt2\). Its equation (5.2) gives \(\|I-U\|_{\mathrm{HS}}^2=4-2\operatorname{Re}\operatorname{tr}U\). Therefore, on any one fixed finite graph, its gauge-fixed density (3.3) is related to the pure isotropic Wilson probability with coefficient \(\beta=1/g_H^2\) by the exact Radon-Nikodym derivative
\[
 \frac{d\mu_H}{d\mu_W}(U)
 =\frac{\exp[-(\alpha^2/2)\sum_e(2-\operatorname{tr}U_e)]}
 {\mu_W(\exp[-(\alpha^2/2)\sum_e(2-\operatorname{tr}U_e)])}.
\]
This follows simply by dividing the two positive densities and integrating to determine the denominator. The numerator is nonconstant for \(\alpha>0\), since varying one link with all others fixed changes its trace. It retains the added Higgs-induced interaction explicitly. The correspondence does not remove that term or provide the missing pure-vacuum estimate in (17). The retained source TeX records the theorem's boundary conditions, observable map and full hypotheses.

## 9. What has and has not been calculated

The fixed-coupling diagonal (12) has an exact nonlinear geometric map, a measure/state refinement map retaining the internal quantum conjugation, subsequential compactness of the actual configuration measures on the specified path family, and the explicit bound (22) on the unmodified centered magnetic vector. Those results do not establish a nonzero low-energy limit for the spectral probability (17).

The explicit positive-coupling diagonal (38) has the stronger joint estimates (36)-(43), including the entire spectral probability and its amplitude, the projective configuration limit (59), and the dynamical obstruction (60). It fails to produce finite physical excitation energies: (42) is exactly zero spectral weight on every fixed bounded physical interval for all sufficiently large regulators. The wider obstruction (47) proves the same for all invariant excitations in its stated coupling-volume domain. The fixed-coupling continuation and weak-coupling spatial construction lie outside that domain; no assertion that they are impossible follows from this calculation.

The remaining unresolved mathematical target is a construction and a spectral estimate for the actual interacting spatial continuum at a trajectory outside the proved escape regime. No missing covariance or convergence estimate is installed as an assumption or called a theorem here. The obtained calculations, with their exact errors and maps, are the substantive continuation from the previously available finite coefficient.

```

## Complete source: ../ym_spatial_continuum_astra_20260908/check_spatial_continuum.py

```python
"""Exact algebra diagnostics; analytic estimates are proved in spatial_continuum.md."""
from pathlib import Path
import json
import sympy as s

count=0
def check(value):
    global count
    assert bool(value)
    count+=1

m,l,q,ac,bc,cc,dc,M=s.symbols('m l q ac bc cc dc M',real=True,nonzero=True)
D=l*q+6*m*m
B=s.Matrix([[6*m,l],[-q,m]])
Bi=s.Matrix([[m,-l],[q,6*m]])/D
check(s.simplify(B*Bi)==s.eye(2))
check(s.simplify(Bi*B)==s.eye(2))
A=s.Matrix([[ac,bc],[cc,dc]])
Q=A.row_join(M*s.eye(2)).col_join(B.row_join(s.zeros(2)))
Qi=s.zeros(2).row_join(Bi).col_join((s.eye(2)/M).row_join(-A*Bi/M))
check(s.simplify(Q*Qi)==s.eye(4))
check(s.simplify(Q.det()-M*M*D)==0)
P=s.Matrix([[ac,bc,M,0],[6*m,l,0,0],[cc,dc,0,M],[-q,m,0,0]])
check(s.simplify(P.det()+M*M*D)==0)
R=s.Matrix([[0,0,0,0],[0,0,0,0],[0,1,0,0],[-1,0,0,0]])
S=s.diag(1,1,M,M)
check(R*R==s.zeros(4))
check(s.simplify(S.inv()*(s.eye(4)+M*R)*S)==s.eye(4)+R)
y1,y2=s.symbols('y1 y2',real=True)
f=2*s.pi/D**2*(m*q*y1*y1/2-l*q*y1*y2-3*m*l*y2*y2)
check(s.simplify(s.diff(f,y1)-2*s.pi*(m*y1-l*y2)*q/D**2)==0)
check(s.simplify(s.diff(f,y2)+2*s.pi*y1/D-2*s.pi*(m*y1-l*y2)*6*m/D**2)==0)
perm=s.zeros(4)
for row,col in enumerate([2,1,3,0]): perm[row,col]=1
check(perm.det()==1)
for L in range(2,13):
    r=lambda k:s.Rational(1,2)+k+k*k
    sum1=sum(r(k)**2 for k in range(-L,L))
    sum2=sum(k**4 for k in range(-L,L+1))
    check(sum1==s.Rational(L*(4*L**4+1),10))
    check(sum2==s.Rational(L*(L+1)*(2*L+1)*(3*L*L+3*L-1),15))
    AL=s.Rational(L*L*(2*L+1)*(24*L**4+24*L**3+8*L*L-4*L+3),15)
    check(AL==2*L*(2*L+1)*sum1+4*L*L*sum2)
    check(AL>=s.Rational(16,5)*L**7)
    EL=s.Rational(2,3)*(2*L*(2*L+1)*sum(r(k)**3 for k in range(-L,L))+4*L*L*sum(k**6 for k in range(-L,L+1)))
    check(EL<=16*L**9)
    check(AL-s.Rational(16,10)*L**7>=L**7)
    faces=12*L*L*(2*L+1)
    check(faces<=36*L**3)
for twice_spin in range(0,31):
    spin=s.Rational(twice_spin,2)
    weights=[-spin+k for k in range(twice_spin+1)]
    check(sum(w*w for w in weights)==(twice_spin+1)*spin*(spin+1)/3)
j=s.symbols('j',positive=True)
faces=12*j**4*(2*j*j+1)
xi=1/(j*j*faces)
g2=j*s.sqrt(faces)/2
a=1/(100*j)
kappa=2*g2/a
b=1/(2*g2*a)
check(s.simplify(1/(4*g2*g2)-xi)==0)
check(s.simplify(kappa-100*j*j*s.sqrt(faces))==0)
check(s.simplify(b-100/s.sqrt(faces))==0)
check(s.simplify(b/kappa-xi)==0)
check(s.simplify(xi*faces-1/j**2)==0)
check(s.limit(j**8*xi,j,s.oo)==s.Rational(1,24))
check(s.limit(kappa/j**5,j,s.oo)==100*s.sqrt(24))
check(s.Rational(16,5)/9/24**2==s.Rational(1,1620))
check(s.Rational(8,3)*4*36*16==6144)
check(s.Rational(5,4)*27+s.Rational(1,2)<40)
I=s.eye(2)
sigma1=s.Matrix([[0,1],[1,0]])
sigma3=s.diag(1,-1)
h1=s.Rational(3,5)*I+s.Rational(4,5)*s.I*sigma3
h2=s.Rational(5,13)*I+s.Rational(12,13)*s.I*sigma3
u1=s.Rational(8,17)*I+s.Rational(15,17)*s.I*sigma1
u2=s.Rational(20,29)*I+s.Rational(21,29)*s.I*sigma3
for v in [h1,h2,u1,u2]:
    check(v.det()==1)
    check(s.simplify(v.conjugate().T*v)==I)
actual=h1.inv()*u1*h2.inv()*u2
retained=h1.inv()*(u1*h2.inv()*u1.inv())*(u1*u2)
check(s.simplify(actual-retained)==s.zeros(2))
check(s.simplify(actual-(h1*h2).inv()*u1*u2)!=s.zeros(2))
report={'exact_assertions':count,'status':'passed','scope':'Finite symbolic algebra and constants only; operator, compactness, and spectral proofs are in the manuscript.'}
out=Path(__file__).resolve().parent/'CHECK_RESULTS.json'
out.write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))

```

