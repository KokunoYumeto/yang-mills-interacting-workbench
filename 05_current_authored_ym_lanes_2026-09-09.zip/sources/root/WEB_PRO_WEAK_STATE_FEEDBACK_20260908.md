# Current weak-coupling state calculation and the next native question

8 September 2026. This is a research handoff, not a claimed interacting
four-dimensional mass-gap counterexample. Read the complete companion
proofs in the current canonical TeX/Bib Markdown packet before reusing
their statements. The new topic is the weak-coupling physical draft.

The exact unchanged open-box operator is

\[
H_g=(2g^2/a)\sum_eE_e+(1/(2g^2a))\sum_p(2-\operatorname{tr}U_p),
\quad E_e=-\sum_\alpha X_{e,\alpha}^2,
\quad T_\alpha=-i\sigma_\alpha/2.
\]

The full tree/chord quotient retains Haar probability measure and residual
simultaneous SU(2). At fixed box L and spacing a the actual physical gap
has limit

\[
\lim_{g\downarrow0}\Delta_L(g,a)
 =\frac{4\sqrt2}{a}\sin\frac{\pi}{4L+2}.
\]

This is proved by a full-form localization/min--max argument for the
nonlinear operator, not by declaring its Hessian to be its spectrum.
The accompanying state proof establishes strong actual-vacuum convergence
under the exact logarithm, Haar-density and dilation isometry, and
operator-norm convergence of fixed finite physical spectral projections.

For one transverse mode of frequency sigma, a bounded physical observable
with the explicit local-coordinate expression exp(i theta |z|^2) has
limiting raw centered excitation measure

\[
\sum_{n=1}^{\infty}\frac{(3/2)_n}{n!}
\frac{\beta^{2n}}{(1+\beta^2)^{n+3/2}}\,
\delta_{2n\sigma/a},\qquad \beta=4\theta/\sigma.
\]

All weights and their total mass are retained. At beta=1 the first raw
weight is 3/(8 sqrt(2)) and the total centered mass is 1-2^(-3/2).
The full proof defines the global smooth observable with a chart cutoff
and retains its physical gauge projection. Its time correlation is

\[
[1+\beta^2(1-e^{-2\sigma t/a})]^{-3/2}
 -(1+\beta^2)^{-3/2}.
\]

There is also an exact limitation of one candidate diagonal. With
L_j=j^2, a_j=1/(100j), beta=1, and a sufficiently small positive g_j
chosen by the proved fixed-box theorem, the actual raw measure converges
to (1-2^(-3/2)) delta_0. This is not positive limiting spectral weight
on every (0,epsilon). Retaining a nonzero vacuum-orthogonal limiting
vector with those correlations would add a zero-energy sector. Do not
present that particular diagonal as the target interacting continuum.

## Bounded demanding next calculation

The fixed-box electric derivative-state map has now also been proved in
*Full-vacuum potential moments and the electric-state graph limit*.
The exact original inequality |grad W|²<=16W gives
b M_(k+1)<=E M_k+4 kappa k² M_(k-1), hence every potential moment
M_k=O_L(g^(2k)). This controls weighted tails and proves actual strong
g² Gamma_w psi convergence, not merely vacuum convergence. Its centered
limiting raw measure has weights (3/32) J_nn² at 2sigma_n/a and
(3/16) J_nm² at (sigma_n+sigma_m)/a for n<m, with every matrix
defined in the full proof. The total mass is (3/32)tr(J²).
For the original native weights, the comparison finite-energy fraction
is at most min(1,54(aE_*)²/L [1+(2L+1)aE_*/2]³). This tends to zero
on the original L=j²,a=1/(100j) diagonal. No uniform finite-g remainder
is assumed, and this does not settle the two specified coupling paths.

Work on the actual original native magnetic state, not a replacement by
one common color rotation or a chosen oscillator eigenvector. Start from
its exact central link-convolution/Gauss projection and the current
tree-row translation map. The original parameter is

\[
\vartheta_j=2\pi a_j^2/D_j,
\quad D_j=L_{j^2}q_{j^2}+6m_{j^2}^2,
\quad a_j=1/(100j),\quad L_j=j^2.
\]

Derive a volume-explicit estimate for its actual centered raw norm and
its spectral mass in a fixed finite physical energy interval on the
path g_j^2=kappa_*/(200j), kappa_*>0. Retain the original D_j, all
independent local color integrations, full nonlinear Wilson words,
Haar/kinetic tensor, vacuum subtraction and every error term. The fixed-L
strong-convergence theorem is an available input, but its constants are
not uniform in L and must not be promoted to such a bound by assumption.
Do not infer a vanishing or nonvanishing spectral probability by dividing
an upper bound on a vanishing raw norm. Supply an actual quantitative
estimate or a proved obstruction for this stated path, with complete
definitions and calculations. This is the state/observable continuation
needed next, not a request to rederive the finite fourth coefficient.

## Sources to read in full

- The original finite-box SU(2) Hamiltonian at small positive coupling.
- Actual weak-coupling vacuum, observable and spectral maps.
- Current native tangent-map manuscript, when present in the source bundle.
- Current spatial-continuum manuscript, particularly its exact weak-coupling
  energy/electric-moment bounds and its proved pure-gauge cylinder limit.

The human literature is cited in those manuscripts. The target remains
the nontrivial interacting theory specified by Jaffe and Witten, not a
free limit, a classical Hessian, a spectral atom at zero, or a different
Hamiltonian with a favorable gap calculation.
## 8 September 2026 update: current exact boundary

The spatial-continuum sidebar has now completed a 65-page continuation. Its
Sections 17--18 prove the fixed-(L,a) actual weighted-electric graph map and
the complete raw pair measure, with exact covariance mass bounds
\(4L^7/99\le C_L\le99L^7/4\). On \(L=j^2\), \(a=1/(100j)\), the comparison
probability below any fixed physical energy is \(O_\Omega(j^{-5})\). A
strictly positive dyadic coupling \(g_j=2^{-k_j}\) is selected from the
proved fixed-box limits; the corrected cusp transport then gives actual gaps
\(\le(100\sqrt2\pi+1)/j\) while the actual native-state probability tends
to zero on every bounded physical-energy interval. This is a rigorous
obstruction for that selected state sequence, not the desired nonzero
low-energy interacting continuum.

The separate NS-to-YM audit gives the exact Cartan map
\(A_i=\lambda u_iT\), \(A_0=0\), with invariant spatial curvature
\(\lambda^2|\nabla\times u|^2\). The full Yang--Mills current retains viscosity,
transport, pressure and forcing and is generally nonzero. The Fabel/Jacobi
\(-1/4\) direction has an explicit material covector with metric powers
\(64z^6/121\) and \(337/(64z^6)\), but no map yet exists from this coordinate
blow-up to a gauge-invariant vacuum-orthogonal quantum state with vanishing
raw Rayleigh quotient. Please use these exact facts as the current handoff;
do not infer an NS or Yang--Mills endpoint from the coordinate bridge.
