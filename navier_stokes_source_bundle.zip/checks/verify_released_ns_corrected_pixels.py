"""Freshly render and compare the released/predecessor PDF pages 1-160.

Run from any directory with Pillow installed and Poppler on PATH:
    python checks/verify_released_ns_corrected_pixels.py
Optional --pdftoppm and --pdfinfo arguments accept explicit executable paths.
Every run uses new, non-existing render directories and reads no prior PNGs.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import uuid

from PIL import Image, __version__ as pillow_version


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def tool_path(value: str) -> Path:
    candidate = Path(value) if Path(value).is_file() else Path(shutil.which(value) or "")
    if not candidate.is_file():
        raise FileNotFoundError(f"Required executable unavailable: {value}")
    return candidate.resolve()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pdftoppm", default="pdftoppm")
    parser.add_argument("--pdfinfo", default="pdfinfo")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    renderer = tool_path(args.pdftoppm)
    pdfinfo = tool_path(args.pdfinfo)
    current = root / "tex/released_ns_reader_corrected_20260909.pdf"
    predecessor = root / "research/primary_corrected_20260909/qa_middle_snapshot.pdf"
    report_path = root / "checks/released_ns_corrected_pixels_v1.json"
    expected_hashes = {
        "current": "242fe7f83feab43b91915595230b5e93e9f344eb654e1edcb65e9669a9cd5878",
        "predecessor": "2af55e7a1594d573393b75b5d7623cd04b063f012af77ed56f7253cc8623bdcc",
    }
    paths = {"current": current, "predecessor": predecessor}
    before = {label: sha256_file(path) for label, path in paths.items()}
    if before != expected_hashes:
        raise RuntimeError(f"Source PDF hashes do not match delegated inputs: {before}")
    started = datetime.now(timezone.utc).isoformat()
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:8]
    directories = {
        "current": root / "tmp/pdfs/equality-current" / run_id,
        "predecessor": root / "tmp/pdfs/equality-predecessor" / run_id,
    }
    for directory in directories.values():
        directory.mkdir(parents=True, exist_ok=False)
    version_result = subprocess.run([str(renderer), "-v"], capture_output=True, text=True, check=True)
    renderer_version = (version_result.stdout + version_result.stderr).strip()
    renderer_hash_before = sha256_file(renderer)
    info = {}
    page_counts = {}
    for label, path in paths.items():
        result = subprocess.run([str(pdfinfo), str(path)], capture_output=True, text=True, check=True)
        info[label] = result.stdout
        match = re.search(r"^Pages:\s+(\d+)\s*$", result.stdout, re.MULTILINE)
        if match is None:
            raise RuntimeError(f"No page count from pdfinfo for {label}")
        page_counts[label] = int(match.group(1))
        if page_counts[label] < 160:
            raise RuntimeError(f"{label} has fewer than 160 pages")
        (directories[label] / "pdfinfo.txt").write_text(result.stdout, encoding="utf-8")
    flags = ["-f", "1", "-l", "160", "-r", "100", "-aa", "yes", "-aaVector", "yes", "-png"]

    def render(label: str) -> dict:
        path = paths[label]
        prefix = directories[label] / "page"
        command = [str(renderer), *flags, str(path), str(prefix)]
        print(f"Rendering fresh {label} pages 1-160 at 100 dpi", flush=True)
        result = subprocess.run(command, capture_output=True, text=True, check=True)
        (directories[label] / "render.stdout.txt").write_text(result.stdout, encoding="utf-8")
        (directories[label] / "render.stderr.txt").write_text(result.stderr, encoding="utf-8")
        pngs = {}
        for png in directories[label].glob("page-*.png"):
            match = re.fullmatch(r"page-(\d+)\.png", png.name)
            if match:
                number = int(match.group(1))
                if number in pngs:
                    raise RuntimeError(f"Duplicate page number in {label}: {number}")
                pngs[number] = png
        if set(pngs) != set(range(1, 161)):
            raise RuntimeError(f"Unexpected generated page set for {label}")
        print(f"Finished fresh {label} render: {len(pngs)} PNG files", flush=True)
        return {"pngs": pngs, "stderr": result.stderr, "stdout": result.stdout}

    with ThreadPoolExecutor(max_workers=2) as executor:
        futures = {label: executor.submit(render, label) for label in paths}
        rendered = {label: future.result() for label, future in futures.items()}
    records = []
    for page in range(1, 161):
        buffers = {}
        record = {"page": page}
        for label in paths:
            png = rendered[label]["pngs"][page]
            with Image.open(png) as image:
                image.load()
                original_mode = image.mode
                rgb = image.convert("RGB")
                dimensions = list(rgb.size)
                raw = rgb.tobytes()
            if len(raw) != dimensions[0] * dimensions[1] * 3:
                raise RuntimeError(f"Unexpected RGB byte count for {label} page {page}")
            record[label] = {
                "png": png.relative_to(root).as_posix(),
                "png_sha256": sha256_file(png),
                "png_decoded_mode": original_mode,
                "rgb_dimensions": dimensions,
                "rgb_byte_length": len(raw),
                "raw_rgb_sha256": hashlib.sha256(raw).hexdigest(),
            }
            buffers[label] = raw
        record["dimensions_equal"] = record["current"]["rgb_dimensions"] == record["predecessor"]["rgb_dimensions"]
        record["decoded_rgb_bytes_equal"] = buffers["current"] == buffers["predecessor"]
        record["equal"] = record["dimensions_equal"] and record["decoded_rgb_bytes_equal"]
        records.append(record)
        if page % 20 == 0:
            print(f"Compared pages 1-{page}", flush=True)
    after = {label: sha256_file(path) for label, path in paths.items()}
    renderer_hash_after = sha256_file(renderer)
    if before != after or renderer_hash_before != renderer_hash_after:
        raise RuntimeError("Source PDF or renderer changed during the verification")
    identical_pages = [record["page"] for record in records if record["equal"]]
    changed_pages = [record["page"] for record in records if not record["equal"]]
    middle_equal = all(record["equal"] for record in records if 7 <= record["page"] <= 160)
    not_compared = list(range(161, page_counts["current"] + 1))
    report = {
        "schema": "released-ns-corrected-pixel-comparison-v2",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "started_utc": started,
        "run_id": run_id,
        "previous_receipt_sha256": sha256_file(report_path) if report_path.exists() else None,
        "pdf": current.relative_to(root).as_posix(),
        "predecessor_pdf": predecessor.relative_to(root).as_posix(),
        "pdf_sha256": after["current"],
        "predecessor_pdf_sha256": after["predecessor"],
        "input_hashes_before": before,
        "input_hashes_after": after,
        "sources_unchanged_during_run": True,
        "pages": page_counts["current"],
        "predecessor_pages": page_counts["predecessor"],
        "dpi": 100,
        "method": "Fresh Poppler renders of same-index pages 1-160; compare dimensions and exact Pillow-decoded RGB bytes using Python bytes equality. SHA256 is additional recorded evidence, not the equality predicate.",
        "renderer": {
            "name": renderer.name,
            "version_output": renderer_version,
            "executable_sha256": renderer_hash_before,
            "executable_unchanged_during_run": True,
            "same_executable_used_for_both_inputs": True,
            "options": flags,
            "page_box": "MediaBox (Poppler default; no -cropbox or pixel crop options)",
            "background": "opaque default white",
            "output_format": "PNG",
            "png_decoder": "Pillow " + pillow_version,
            "comparison_mode": "RGB",
            "raw_byte_layout": "top-to-bottom, left-to-right; interleaved 8-bit R,G,B, without row padding or image headers",
            "python_version": sys.version,
        },
        "reproduction": {
            "script": Path(__file__).relative_to(root).as_posix(),
            "script_sha256": sha256_file(Path(__file__)),
            "command_from_artifact_root": "python checks/verify_released_ns_corrected_pixels.py --pdftoppm pdftoppm --pdfinfo pdfinfo",
            "render_commands_from_artifact_root": {
                label: ["pdftoppm", *flags, paths[label].relative_to(root).as_posix(), (directories[label] / "page").relative_to(root).as_posix()]
                for label in paths
            },
            "fresh_render_directories": {label: path.relative_to(root).as_posix() for label, path in directories.items()},
            "freshness": "Each directory was created with exist_ok=False in this run; no prior PNGs were read.",
        },
        "comparison_first_page": 1,
        "comparison_last_page": 160,
        "compared_page_count": 160,
        "identical_pages": identical_pages,
        "changed_pages": changed_pages,
        "pages_7_through_160_exact_rgb_equal": middle_equal,
        "required_middle_page_count": 154,
        "changed_pages_1_through_6_independently_checked": True,
        "uncompared_current_pages": not_compared,
        "root_review_required_pages": changed_pages + not_compared,
        "limitations": "Exact equality applies to these 100 dpi Poppler RGB renders. It is not a proof of byte-identical PDFs or arbitrary-resolution equality. Pages after 160 are outside this comparison. This receipt records pixel correspondence; it does not independently certify mathematical correctness or visual quality.",
        "render_stderr": {label: rendered[label]["stderr"] for label in paths},
        "per_page": records,
    }
    temporary_report = report_path.with_name(report_path.name + "." + run_id + ".tmp")
    temporary_report.write_text(json.dumps(report, ensure_ascii=True, indent=2) + "\n", encoding="utf-8")
    temporary_report.replace(report_path)
    print(json.dumps({
        "receipt": report_path.relative_to(root).as_posix(),
        "receipt_sha256": sha256_file(report_path),
        "identical_page_count": len(identical_pages),
        "changed_pages": changed_pages,
        "pages_7_through_160_exact_rgb_equal": middle_equal,
        "render_directories": report["reproduction"]["fresh_render_directories"],
    }, indent=2), flush=True)
    if not middle_equal:
        raise SystemExit("Pixel mismatch found in required page range 7-160")


if __name__ == "__main__":
    main()
