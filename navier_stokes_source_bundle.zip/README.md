# Navier–Stokes construction: corrected reader and reproducible sources

Read the [complete reader](tex/released_ns_reader_corrected_20260909.pdf). This corrected
edition contains 13 complete mathematical proof bodies, selected
directly from the reader's exact build receipt. The original component,
localization, profile assembly, stage-input assembly, summation and realization,
and terminal-trace bodies accompany the complete radial-stress, stage-cycle,
and global analytic closure audits. The full source inventory and original
digests are listed in the manifest. Complete TeX sources, derivation notes,
mathematical reviews, and finite-check programs accompany the reader. These
audits record the actual scope of the construction and its corrections.
Independent whole-construction analytic validation remains in progress.

The external [source paper](https://cdn.openai.com/pdf/32d9f210-8b73-45e0-91bc-82a30aef8a9a/navier-stokes.pdf) concerns the classical three-dimensional
Navier–Stokes equations with zero initial velocity, smooth compactly supported
force, bounded kinetic energy, and the source's claimed terminal singularity.
The component/profile/stage derivations use the 165-page capture, SHA-256
`8c8a94ad9ac824c8b605b9827cadf7beaca48bd10b380de3cfc872a2c37afa81`. The summation audit uses the distinct 166-page capture, SHA-256
`0e779481c4da40bd28d1e642e1d8ca57447d129610df28dfa5a11e9af8ae228f`. The finite source-revision comparison is fully recorded in
[its public receipt](checks/source_revision_audit.json); source byte identity
is false, and finite text/glyph comparisons do not certify proof correctness.

The [formal repository](https://github.com/openai/NavierStokesAndEuler/tree/8937a8f4cbc7abaab5e9e97d1cc7f5d2319d9538)
is pinned to `8937a8f4cbc7abaab5e9e97d1cc7f5d2319d9538` and toolchain `leanprover/lean4:v4.34.0-rc2`.
The recorded 26 statement comparisons are static source comparisons. Import
compilation and the fresh endpoint/comparator checks remain incomplete; this
package contains no Lean kernel certificate and makes no prize or priority claim.

## Rebuild and replay

Install Python and the pinned packages with `python -m pip install -r requirements.txt`.
Run `python scripts/replay_checks.py` with assertions enabled. Its nine programs
assert 144 named mathematical result groups and 12 separate structural probes.
The stage-input program also asserts three full term-list lower bounds. The
base/heat program reports two additional exact rational evaluations and one
numerical evaluation; these are not counted as passed universal identities.
Matrix components and grouped inequalities are not counted a second time.

The profile assembly adapter preserves its ten mathematical and five structural
checks. It rehashes four exact historical TeX inputs under `historical_edition/`
against the unchanged expected digests from the earlier assembly receipt.
Those inputs comprise the three original component bodies and the historical
reader. The source PDF remains external and is recorded as unavailable for
rehashing. Historical matches establish identity with those historical inputs;
the corrected current bodies have their own separate build digests. No expected
historical digest has been replaced to obtain a passing check. Every portability
transformation and the original checker digest are recorded in the manifest.

Run `python scripts/replay_additional_checks.py` for the additional programs in
the explicit corrected-edition source manifest. Each program has its own
receipt-field checks and evidence scope. Those results remain separate from
the original nine-program counts; the additional manifest may contain no
replays when no further program has been selected.

Install a LaTeX distribution providing the packages listed in the reader's
preamble, then run `python scripts/build_reader.py`. This runs three pdflatex
passes in `rebuild/`, preserves the supplied PDF, and checks exact page-by-page
extracted text equality against it. PDF metadata can produce different binary
hashes despite identical page content. The self-contained TeX has no external
proof-body inputs. Python, SymPy, pypdf, and LaTeX are external runtime dependencies;
no network, Lean, Lake, or Elan invocation occurs during the replays.

## Evidence and provenance

`released_ns_primary_corrected_20260909.json` embeds every included UTF-8 source and receipt with its exact
SHA-256, and lists the frozen reader PDF's digest. The ZIP member hashes are
checked against that manifest. This JSON records our reconstruction and checks;
it is not the original external discovery transcript. Bibliographic attribution
follows the cited source. Task instructions, private conversation logs, account
names, local machine paths, and credentials are excluded.

Written analytic arguments, finite algebra, structural text probes, numerical
supplements, visual QA, source-hash comparisons, and kernel acceptance are
separate evidence classes. The receipts report the actual scope of each.
