"""Execute explicitly listed corrected-edition checks with their stated scope."""
from pathlib import Path
import hashlib, json, os, subprocess, sys
ROOT=Path(__file__).resolve().parents[1]
if not __debug__ or sys.flags.optimize or os.environ.get('PYTHONOPTIMIZE'):
    raise SystemExit('Replay requires Python assertions: remove -O/PYTHONOPTIMIZE.')
manifest=json.loads((ROOT/'checks/corrected_additional_source_manifest.json').read_text(encoding='utf-8'))
items=[]
for spec in manifest.get('replays',[]):
    script=ROOT/spec['script']
    receipt_path=ROOT/spec['receipt']
    if not script.resolve().is_relative_to(ROOT) or not receipt_path.resolve().is_relative_to(ROOT):
        raise ValueError('Additional replay leaves its package')
    if receipt_path.exists():
        receipt_path.unlink()
    result=subprocess.run([sys.executable,str(script)]+spec.get('arguments',[]),cwd=ROOT,
                          capture_output=True,text=True)
    if result.returncode:
        raise RuntimeError(spec['script']+': '+result.stdout+result.stderr)
    data=json.loads(receipt_path.read_text(encoding='utf-8'))
    for pointer, expected in spec['expect'].items():
        if not pointer.startswith('/'):
            raise ValueError('Expected receipt fields use JSON pointers beginning with /')
        actual=data
        for key in pointer[1:].split('/'):
            key=key.replace('~1','/').replace('~0','~')
            actual=actual[int(key)] if isinstance(actual,list) else actual[key]
        assert type(actual)==type(expected) and actual==expected,(spec['id'],pointer,actual,expected)
    items.append({'id':spec['id'],'script':spec['script'],'receipt':spec['receipt'],
                  'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),
                  'receipt_sha256':hashlib.sha256(receipt_path.read_bytes()).hexdigest(),
                  'returncode':0,'expected_receipt_fields_matched':spec['expect'],
                  'scope':spec['scope']})
report={'schema_version':1,'program_count':len(items),'programs':items,
        'all_requested_programs_passed':True,
        'counting_policy':'Additional programs retain their individual receipt fields and evidence scope; their checks are not added to the original nine-program counts.',
        'complete_independent_analytical_validation':False,'lean_kernel_certificate':False,
        'prize_claim':False,'priority_claim':False}
(ROOT/'checks/released_ns_additional_replay_corrected_20260909.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'additional_program_count':len(items),'all_requested_programs_passed':True}))
