"""Compile the self-contained reader into rebuild/, preserving the shipped PDF."""
from pathlib import Path
import argparse, hashlib, json, os, re, shutil, subprocess, sys
from pypdf import PdfReader
if not __debug__ or sys.flags.optimize or os.environ.get('PYTHONOPTIMIZE'):
    raise SystemExit('Build validation requires Python assertions: remove -O/PYTHONOPTIMIZE.')
root=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser()
parser.add_argument('--output',type=Path,default=root/'rebuild')
args=parser.parse_args()
target=args.output.resolve()
target.mkdir(parents=True,exist_ok=True)
tex=root/'tex/released_ns_reader_corrected_20260909.tex'
exe=shutil.which('pdflatex')
if not exe: raise SystemExit('Install pdflatex and the packages listed in the TeX preamble.')
shutil.copyfile(tex,target/tex.name)
for run in range(3):
    proc=subprocess.run([exe,'-interaction=nonstopmode','-halt-on-error',tex.name],cwd=target,capture_output=True,text=True)
    (target/f'build-pass-{run+1}.txt').write_text(proc.stdout+proc.stderr,encoding='utf-8')
    if proc.returncode: raise SystemExit('LaTeX failed; inspect the local build-pass log.')
log=(target/tex.with_suffix('.log').name).read_text(encoding='utf-8',errors='replace')
diagnostics=[line for line in log.splitlines() if any(x in line for x in ('Overfull','Undefined control sequence','undefined references','multiply-defined labels','LaTeX Warning:'))]
assert not diagnostics,diagnostics
original=PdfReader(root/'tex/released_ns_reader_corrected_20260909.pdf')
rebuilt=PdfReader(target/tex.with_suffix('.pdf').name)
original_text=[page.extract_text() for page in original.pages]
rebuilt_text=[page.extract_text() for page in rebuilt.pages]
assert original_text==rebuilt_text,'Rebuilt page count or page text differs from the shipped frozen PDF'
report={'schema_version':1,'passes':3,'passed':True,'pages':len(rebuilt.pages),'diagnostics':diagnostics,
        'source_tex_sha256':hashlib.sha256(tex.read_bytes()).hexdigest(),
        'frozen_pdf_sha256':hashlib.sha256((root/'tex/released_ns_reader_corrected_20260909.pdf').read_bytes()).hexdigest(),
        'pagewise_extracted_text_equal':True,
        'method':'Three pdflatex passes; exact page-by-page pypdf text equality with the frozen PDF. PDF binary metadata may differ.',
        'complete_independent_analytical_validation':False,'lean_kernel_certificate':False,'prize_claim':False}
(root/'checks/released_ns_reader_corrected_20260909_portable_build.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))
