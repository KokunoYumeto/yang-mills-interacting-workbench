"""Replay the included finite checks, retaining separate evidence classes."""
from pathlib import Path
import hashlib, json, os, subprocess, sys
ROOT = Path(__file__).resolve().parents[1]
REPLAYS = [('profiles', 'proof_sources/profiles/exact_checks.py', 'exact_checks.json', 14, 0), ('base_heat', 'proof_sources/base_heat/verify_identities.py', 'identity_check_results.json', 7, 0), ('oscillations', 'proof_sources/oscillations/exact_checks.py', 'exact_checks_results.json', 28, 0), ('mean_corrections', 'proof_sources/mean_corrections/verify_exact.py', 'exact_checks.json', 26, 0), ('stage9', 'proof_sources/stage9/exact_checks.py', 'exact_checks.json', 15, 7), ('profile_assembly', 'proof_sources/profile_assembly_audit/check_assembly.py', 'exact_assembly_checks.json', 10, 5), ('stage_inputs', 'proof_sources/stage_inputs_audit/check_exponents.py', 'exponent_checks.json', 7, 0), ('maps_covariance', 'proof_sources/stage_inputs_audit/maps_covariance/exact_checks.py', 'exact_checks.json', 19, 0), ('radial_fiveeq', 'proof_sources/stage_inputs_audit/radial_fiveeq/exact_checks.py', 'exact_checks.json', 18, 0)]
if not __debug__ or sys.flags.optimize or os.environ.get('PYTHONOPTIMIZE'):
    raise SystemExit('Replay requires Python assertions: remove -O/PYTHONOPTIMIZE.')
items = []
for ident, path, receipt_name, math_count, structural_count in REPLAYS:
    script = ROOT/path
    args = [sys.executable, str(script)]
    if ident in ('profiles', 'oscillations'):
        args += ['--source-pdf', str(ROOT/'source_captures/source_165.pdf')]
    result = subprocess.run(args, cwd=ROOT, capture_output=True, text=True)
    if result.returncode:
        # Child diagnostics are useful locally; public receipts use relative names.
        raise RuntimeError(path + ': ' + result.stdout + result.stderr)
    receipt_path = script.with_name(receipt_name)
    data = json.loads(receipt_path.read_text(encoding='utf-8'))
    if ident == 'profiles':
        assert data['count'] == math_count and len(data['certificates']) == math_count
        assert all(x['result'] == '0' for x in data['certificates'] if x['kind'] == 'exact rational identity')
    elif ident == 'base_heat':
        assert sum(v == 'exact zero' for v in data.values()) == math_count
    elif ident == 'oscillations':
        assert data['count'] == math_count and len(data['checks']) == math_count
        assert all(x['status'] == 'exact zero' for x in data['checks'])
    elif ident == 'mean_corrections':
        assert data['all_passed'] and data['check_count'] == math_count
    elif ident == 'stage9':
        assert len(data['exact_calculations']) == math_count and all(data['exact_calculations'].values())
        assert len(data['structural_checks']) == structural_count and all(data['structural_checks'].values())
    elif ident == 'profile_assembly':
        assert len(data['mathematical_checks']) == math_count and all(data['mathematical_checks'].values())
        assert len(data['structural_checks']) == structural_count and all(data['structural_checks'].values())
        assert data['all_included_source_hashes_match']
    elif ident == 'stage_inputs':
        assert data['all_passed'] and len(data['checks']) == math_count
    elif ident == 'maps_covariance':
        assert data['all_passed'] and data['total'] == data['passed'] == math_count
    elif ident == 'radial_fiveeq':
        assert data['all_passed'] and len(data['checks']) == math_count and all(data['checks'].values())
    item = {'id': ident, 'script': path, 'receipt': receipt_path.relative_to(ROOT).as_posix(),
            'returncode': result.returncode, 'named_mathematical_result_groups': math_count,
            'structural_probes': structural_count,
            'script_sha256': hashlib.sha256(script.read_bytes()).hexdigest(),
            'receipt_sha256': hashlib.sha256(receipt_path.read_bytes()).hexdigest()}
    if ident in ('profiles', 'oscillations'):
        item['source_capture_rehashed_this_run'] = data['source_capture_rehashed_this_run']
    if ident == 'profile_assembly':
        item['historical_input_rehash'] = data['source_hash_checks']
    items.append(item)
report = {'schema_version': 1, 'method': 'Fresh local execution with assertions enabled; SymPy exact algebra and Python Fraction arithmetic.',
          'programs': items, 'program_count': len(items), 'all_included_programs_passed': True,
          'named_mathematical_result_groups': sum(x['named_mathematical_result_groups'] for x in items),
          'structural_probes': sum(x['structural_probes'] for x in items),
          'stage_input_term_list_lower_bound_assertions': 3,
          'base_heat_supplements': {'unasserted_exact_rational_evaluations': 2, 'numerical_evaluations': 1,
                                   'scope': 'Reported evaluations, not additional passed universal identities.'},
          'counting_convention': 'Named result groups; matrix components, five-row instance rows, and grouped inequalities are not counted again.',
          'source_pdf_policy': 'Original source captures are external. Missing captures are recorded as not rehashed, never as a successful hash comparison.',
          'complete_independent_analytical_validation': False, 'lean_kernel_certificate': False, 'prize_claim': False}
(ROOT/'checks').mkdir(exist_ok=True)
(ROOT/'checks/released_ns_portable_replay_corrected_20260909.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'all_included_programs_passed': True,'programs':len(items),'mathematical_result_groups':report['named_mathematical_result_groups'],'structural_probes':report['structural_probes']}))
