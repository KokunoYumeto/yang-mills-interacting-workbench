# Exact maps and original-amplitude covariance audit

## Deliverables

- `maps_fragment.tex`: preamble-free full coordinate/evaluation/covering/support-separation proof.
- `covariance_check/covariance_fragment.tex`: preamble-free full covariance, positive-amplitude threshold, signed inverse and assembly proof.
- `standalone.tex`: independent wrapper containing those two fragments; no custom macros required.
- `exact_checks.py` and `exact_checks.json`: 19 passing exact symbolic identity checks. They certify only their listed identities, not analytic estimates or a global theorem.

## Required source qualifications

1. **Common torus neighborhood.** In the source paragraph beginning “Near a fixed z,t with q>0,” shrink U so q(U) is contained in (q0/2,2q0). Then q/Q in [1/2,2] implies Q in (q0/4,4q0), hence the active integer band differences are at most four. Only then does the proved uniform floor bound imply Δ≤Δmax. Finiteness of an arbitrary set of bands does not by itself imply that uniform bound. The original common-torus map H=Jg^{i0}Y and all constants are unchanged.

2. **Physical signed-inverse domain.** The source introduction “For a physical auxiliary-independent stress σ(r,z,t)” to the assembled inverse is too broad if read without the preceding local mean-class condition. Exact replacement: “For a real, auxiliary-independent physical stress supported in the prescribed active shell whose band representatives Qβ^{2A}σ satisfy the local Mα bounds and smooth zero extension used above, use the assembled maps below.” The sum of squares is one on the active partition domain. Outside it both the admissible σ and waves vanish. A smooth nonzero stress supported outside the shell is an explicit counterexample to the unrestricted reading. Arbitrary nonvanishing data at the shell edge also need not cancel division by the original aσ.

3. **Inverse estimate wording.** The source's “finite Neumann series estimate” is imprecise for the exact inverse. The supplied proof uses the direct lower norm bound |(I+H0^{-1}E)z|≥(1−||H0^{-1}E||)|z| and the exact inverse-difference identity. This is a proof repair, not a change to the original H or amplitudes.

## Exact retained results

The q map is a smooth bijection from (q>0, |η|<1) to (z real, t<1), with Jacobian q^D L>0 in the original (z,t)/(q,η) order. It extends smoothly one-sided to t=1,z≠0 and has no q>0 point above (z,t)=(0,1). This coordinate result retains the base range 0<h<1/2; the auxiliary construction retains 0<h<1/100. The original q_t,q_z,η_t,η_z,X_t,X_z and fixed-Q chart maps are explicitly proved.

The evaluation pullback intertwines physical derivatives with the original extended radial and time operators. The normalized operators retain Dr=∂R+Mi dr R^{dr−1}Li, Dz=ε∂Z, and t*=−ε∂T+ciNi. The frame derivative has [Dr,Dθ]=−R^{-1}Dθ; the unscaled coordinate derivations commute. No axis smoothness of r^{dr} is assumed. The support annulus supplies an actual zero neighborhood at each q>0.

The integer torus map has exactly 14^i preimages per point and preserves normalized Haar measure. All lifts, derivative factors, descent maps, common-torus paths, and path derivatives are given explicitly. The support proof constructs the finite-degree graph coloring, rational centers, positive distance margin, and an r0 satisfying both injectivity and separation inequalities; all cross-label derivative products therefore vanish before and after evaluation.

The auxiliary mean and physical evaluation are related by E F=P F+E(F−JPF), with PJ=EJ=I. The explicit field exp(2πin·Y)−exp(2πin·γ(r,t)) lies in ker E but has nonzero mean. Thus auxiliary averaging cannot be recovered from the evaluated field alone; the covariance identity is an identity of the extended construction with physical scale factors retained.

For original columns Hσ=hσ(−AcN−σu*K+eσ), the determinant has its exact perturbation formula and negative sign beyond a fixed threshold. The original aσ=sqrt((H^{-1}T0,*)σ)>0 remain unchanged. The signed right inverse is LΣ=√ε Σσ [(H^{-1}(Σ/ε))σ/(2aσ)]bσ, and B(W0,LΣ)=Σ exactly for all signed inputs in its admissible class. Its full nonlinear remainder is (4ε)^{-1}H[((H^{-1}Σ)+)^2/y+,((H^{-1}Σ)−)^2/y−]^T. Every derivative weight is proved through the unchanged positive amplitudes, yielding L:Mα→Wα−1/2. Physical assembly retains each Qβ factor.

## Boundary of this audit

The q/evaluation/common-cover/support results are proved here. The covariance calculation identifies its exact previously constructed profile cone/edge factors and homogeneous pulse estimates; it proves their covariance consequences and the inverse rather than asserting their underlying global construction anew. The parent separately integrates profile, pulse, radial-stress, and finite-stage derivations. No global Navier–Stokes theorem or completion of the research goal is asserted. No Lean process, source mutation outside the assigned directory, or publication was performed by this audit.
