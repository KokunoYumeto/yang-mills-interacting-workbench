# Signed covariance and original positive-amplitude audit

Date: 2026-09-08. Source: `research/released_ns/oscillations/oscillations_body.tex`, especially lines 303–415 and 472–487. This audit preserves the original amplitudes \(a_\sigma>0\), the original cylindrical component order \((r\theta,rz)\), and all scale, angular, and measure factors. Source files were not edited. No Lean process or publication was used.

The covariance matrix, positivity mechanism, exact signed differential inverse, shell weights, and displayed increment exponents are correct. The physical assembly statement at source line 403 needs its domain stated: the physical stress must have admissible local mean-class representatives with the prescribed active-shell support and edge vanishing. An arbitrary auxiliary-independent physical stress is too broad a domain. The precise counterexample and corrected wording appear below.

## 1. Original objects and input provenance

The source uses

\[
A=\tfrac12+h,\quad Q=2^{-\ell},\quad \varepsilon=Q^h,
\quad S_*=\ell^2,\quad 0<h<1/100,\quad \kappa_s=10^{-5}.
\]

The normalized angular average has measure \(d\theta/(2\pi)\); the auxiliary torus has normalized Haar measure. For real extended vector fields,

\[
\mathcal C(w)=\langle\langle w_rw_{\tan}\rangle_\theta\rangle_Y,
\qquad
\mathcal B(w,v)=\langle\langle w_rv_{\tan}+v_rw_{\tan}\rangle_\theta\rangle_Y,
\quad w_{\tan}=(w_\theta,w_z).
\]

Every entry of these maps is a product followed by the two specified linear integrations. Expanding each product gives

\[
\mathcal C(w+v)=\mathcal C(w)+\mathcal B(w,v)+\mathcal C(v),
\qquad D\mathcal C(w)[v]=\mathcal B(w,v).
\]

In particular, the derivative contains both cross terms and therefore contains a factor of two on a scalar multiple of one wave.

The following inputs are explicitly present outside the assigned interval:

* Source lines 55–90 construct disjoint auxiliary preimages for every pair of simultaneously active distinct labels, including the two signs, and prove preservation of normalized Haar measure under the covering maps. This is the support and measure input used below.
* Source lines 121–143 define the original frozen vectors \(N,K\), the original negative \(c_0\), and the uniform strict target-direction cone margin. Source lines 673–695 identify the profile endpoint-direction and profile-weight construction imported from the profiles lane. This audit does not independently construct those profile factors.
* Source lines 233–256 and 278–292 supply the two-sided Gaussian bounds for \(P\), the positive radial homogeneous amplitude \(x\), and their derivative bounds. The calculation below gives the complete covariance consequence of these inputs.
* Source lines 94–108 define the shell weight, derivative variables, and coefficient spaces, with all derivative bounds required pointwise. Source lines 417–453 give the exact curl remainder used in the final increment calculation.

In the original tangential component order,

\[
N=(N_\theta,N_z),\qquad K=(-N_z,N_\theta),\qquad |N|=1.
\]

Thus \(N\cdot K=0\), \(|K|=1\), and

\[
\det[N\mid K]=N_\theta^2+N_z^2=1.
\]

Consequently, expressing the covariance columns in the ordered basis \((N,K)\) preserves the determinant sign in the original \((\theta,z)\) order. It is a coordinate expression of the same columns, not a replacement or renormalization of them.

The coefficient derivatives used throughout are, for a five-component multi-index \(I\),

\[
D^I=\partial_R^{I_1}\partial_Z^{I_2}\partial_T^{I_3}
\partial_{H_1}^{I_4}\partial_{H_2}^{I_5},
\]

where \((H_1,H_2)\) are coordinates on the common auxiliary torus; the covariance matrix \(H\) defined below is a different object. Every label, band scale, and discrete harmonic is fixed under these derivatives. For the original radial shell variable \(X\), define

\[
\zeta=\exp\left(-a_a/\log^2(X/X_a)-a_b/\log^2(X_b/X)\right),
\qquad \delta=\min\{1,\log(X/X_a),\log(X_b/X)\},
\]

on \(X_a<X<X_b\), with \(a_a,a_b>0\) the original constants, and extend \(\zeta\) by zero. The mean class \(\mathcal M_\alpha\) consists of compatible angular-independent coefficients with smooth zero extension outside this shell and, for every \(I\),

\[
|D^If|\le C_I\varepsilon^\alpha S_*^{b_I}\zeta\delta^{-d_I}.
\]

It has no auxiliary-rectangle or pulse-envelope requirement and may depend on the auxiliary torus. Its auxiliary-independent subclass is denoted \(\mathcal M_\alpha^{\rm independent}\). The wave class \(\mathcal W_\alpha\) consists of the nonzero-harmonic coefficients \(w_{\gamma,m}\) in finite labelled sums \(w_{\gamma,m}e^{ikm\Phi_\gamma}\), with the source's prescribed closed slow, transverse-rectangle, and shell supports, satisfying

\[
|D^Iw_{\gamma,m}|\le C_I\varepsilon^\alpha S_*^{b_I}
\sqrt\zeta\delta^{-d_I}P(v).
\]

The actual cutoff coefficients additionally have compact pulse support and smooth zero extension at that support. Equal label-harmonic contributions are collected before testing these bounds. The finite constants and nonnegative exponents \(C_I,b_I,d_I\) may depend on the derivative order and the fixed finite collection under consideration, but are uniform in the band. Compatibility means equality after the specified torus covering pullbacks on chart overlaps. These are coefficient estimates with the exponential factored out; every coefficient derivative is required to satisfy the stated pointwise envelope bound. No conclusion below differentiates a bare inequality for \(P\).

## 2. Exact column integral and its constants

For each sign of one slow box, retain

\[
b_\sigma=\chi_g(\xi_g)\psi(v)t_\sigma^h\cos(k\Phi_\sigma),
\qquad H=[\mathcal C(b_+)\mid\mathcal C(b_-)].
\]

The integer \(kp\) is nonzero. For every non-angular phase offset \(c\),

\[
\frac1{2\pi}\int_0^{2\pi}\cos^2(kp\theta+c)\,d\theta
=\frac12+
\left[\frac{\sin(2kp\theta+2c)}{8\pi kp}\right]_0^{2\pi}
=\frac12.
\]

The rectangle map is

\[
(\xi_g,\eta_g)\longmapsto c_\gamma+\xi_gv_r+\eta_gv_t,
\quad v_r=(1,-b_g),\quad v_t=(b_g,1),\quad b_g=\sqrt2-1.
\]

Its absolute Jacobian is \(1+b_g^2\); \(\eta_g=c_iv-r_0\) gives \(d\eta_g=c_i\,dv\). Haar preservation means no additional covering degree multiplies or divides the integral. The homogeneous amplitude is independent of \(\xi_g\). Writing its radial component as \(x\), direct substitution therefore gives

\[
H_\sigma=D_gc_i\int_0^{L_s}\psi(v)^2x(v)t_{\sigma,\tan}^h(v)\,dv,
\]
\[
h_\sigma=D_gc_i\int_0^{L_s}\psi(v)^2x(v)^2\,dv,
\qquad
D_g=\frac{1+b_g^2}{2}\int_{\mathbb R}\chi_g(\xi)^2\,d\xi>0,
\qquad L_s=\frac{2r_0}{c_i}.
\]

All four original factors—the angular half, rectangle Jacobian, transverse integral, and \(c_i\,dv\)—are retained.

Write the proved pulse bounds with positive uniform constants as

\[
c_xP(v)\le x(v)\le C_xP(v),\qquad
e^{-C_P(v-L_s/2)^2/L_s}\le P(v)
\le e^{-c_P(v-L_s/2)^2/L_s}.
\]

Put \(d=v-L_s/2\). On the central interval \(|d|\le\sqrt{L_s}\), the cutoff equals one when \(L_s\ge25\), since the source cutoff is one for \(|d|<L_s/5\). Thus

\[
I_0:=\int_0^{L_s}\psi^2x^2\,dv
\ge 2c_x^2e^{-2C_P}\sqrt{L_s}=:C_{0,-}\sqrt{L_s}.
\]

Using \(0\le\psi\le1\) and integrating the upper Gaussian over the whole real line gives

\[
I_0\le C_x^2\sqrt{\frac{\pi}{2c_P}}\sqrt{L_s}
=:C_{0,+}\sqrt{L_s}.
\]

The first absolute moment is bounded by

\[
I_1:=\int_0^{L_s}\frac{|d|}{L_s}\psi^2x^2\,dv
\le\frac{C_x^2}{L_s}\int_{\mathbb R}|d|e^{-2c_Pd^2/L_s}\,dd
=\frac{C_x^2}{2c_P}.
\]

The source floor estimate is

\[
\frac{1}{T_gS_*}<c_i\le\frac1{S_*},\qquad T_g=4+\sqrt2.
\]

Hence \(L_s\ge2r_0S_*\), so \(S_*\ge25/(2r_0)\) suffices for the central-interval bound. Also

\[
c_i\sqrt{L_s}=\sqrt{2r_0c_i}.
\]

Therefore the positive original \(h_\sigma\) obey

\[
h_-^{\rm bd}S_*^{-1/2}\le h_\sigma\le h_+^{\rm bd}S_*^{-1/2},
\]
\[
h_-^{\rm bd}=D_gC_{0,-}\sqrt{2r_0/T_g}>0,
\qquad h_+^{\rm bd}=D_gC_{0,+}\sqrt{2r_0}.
\]

The strict floor inequality also implies this non-strict lower bound. The symbols \(h_-^{\rm bd},h_+^{\rm bd}\) denote bounds, not a replacement for the two different original numbers \(h_+,h_-\).

## 3. Column directions and the exact determinant

The original frozen constants satisfy \(c_0<0\), \(u_*>0\), and

\[
A_c=-c_0\sqrt{1+u_*^2}>0.
\]

The homogeneous polarization satisfies the uniform error bound stated in source line 334 relative to

\[
f(s)=-sK+c_0\sqrt{1+s^2}N,
\qquad s(v)=\sigma(u_*/2+u_*v/L_s).
\]

Here

\[
f'(s)=-K+c_0\frac{s}{\sqrt{1+s^2}}N,
\qquad |f'(s)|\le\sqrt{1+c_0^2},
\qquad |s(v)-\sigma u_*|=u_*|d|/L_s.
\]

The mean-value integral for \(f(s(v))-f(\sigma u_*)\), followed by the probability measure \(\psi^2x^2\,dv/I_0\), bounds its average by

\[
\sqrt{1+c_0^2}\,u_*\frac{I_1}{I_0}
\le \sqrt{1+c_0^2}\,u_*\frac{C_x^2}{2c_PC_{0,-}\sqrt{L_s}}.
\]

Adding the source's uniform \(O(S_*^{-1})\) polarization error gives the asserted uniform \(O(S_*^{-1/2})\) column error without discarding any sign:

\[
H_\sigma=h_\sigma(-A_cN-\sigma u_*K+e_\sigma),
\qquad |e_\sigma|\le C_eS_*^{-1/2}.
\]

Set \(e_{\sigma,N}=e_\sigma\cdot N\), \(e_{\sigma,K}=e_\sigma\cdot K\). In \((N,K)\) coordinates the full, perturbed original matrix is

\[
H=\begin{pmatrix}
(-A_c+e_{+,N})h_+&(-A_c+e_{-,N})h_-\\
(-u_*+e_{+,K})h_+&(u_*+e_{-,K})h_-
\end{pmatrix}.
\]

Its exact determinant is

\[
\det H=h_+h_-\Delta,
\]
\[
\begin{aligned}
\Delta={}&(-A_c+e_{+,N})(u_*+e_{-,K})
-(-A_c+e_{-,N})(-u_*+e_{+,K})\\
={}&-2A_cu_*+A_c(e_{+,K}-e_{-,K})
+u_*(e_{+,N}+e_{-,N})\\
&\hspace{1cm}+e_{+,N}e_{-,K}-e_{-,N}e_{+,K}.
\end{aligned}
\]

For a target \(T=T_NN+T_KK\), the exact inverse is

\[
(H^{-1}T)_+=\frac{(u_*+e_{-,K})T_N+(A_c-e_{-,N})T_K}{h_+\Delta},
\]
\[
(H^{-1}T)_-=\frac{(u_*-e_{+,K})T_N+(-A_c+e_{+,N})T_K}{h_-\Delta}.
\]

At zero error these formulas become exactly

\[
h_+(H_{\rm ref}^{-1}T)_+=\tfrac12(-T_N/A_c-T_K/u_*),
\quad
h_-(H_{\rm ref}^{-1}T)_-=\tfrac12(-T_N/A_c+T_K/u_*).
\]

In particular, \(\det H_{\rm ref}=-2A_cu_*h_+h_-\), with the same sign in the original tangential coordinates.

## 4. A uniform threshold that proves positivity of the original amplitudes

The strict compact direction gap in source lines 141–143 supplies a number \(\mu<1\). With the original choice

\[
\frac{u_*}{\sqrt{1+u_*^2}}>\mu,
\]

the unfrozen direction ratio has a strict margin below \(u_*/\sqrt{1+u_*^2}\). Uniform continuity of the extended normalized target direction, and the fixed mesh diameter \(O(S_*^{-3})\), preserves a strictly smaller margin for the frozen box basis. Hence one fixed \(\eta_c>0\) satisfies on every enlarged box after the stated initial band threshold

\[
T_N<0,\qquad |T_K|/u_*\le(1-\eta_c)(-T_N)/A_c,
\qquad T=T_{0,*}.
\]

No division by \(T\) at a zero edge is used: the compact direction is extended first, and the inequalities for nonzero \(T\) are applied in the open shell.

To make the perturbation threshold fully quantitative, let \(A_{\min}\le A_c\le A_{\max}\) be the positive uniform bounds from source line 135 and define

\[
H_0=\begin{pmatrix}-A_c&-A_c\\-u_*&u_*\end{pmatrix},
\qquad \mathcal E=[e_+\mid e_-]_{(N,K)},
\qquad D_h=\operatorname{diag}(h_+,h_-).
\]

These identities retain \(H=(H_0+\mathcal E)D_h\) and the original \(H\); they only factor its two already defined scalar column weights. Direct multiplication gives

\[
H_0H_0^T=\operatorname{diag}(2A_c^2,2u_*^2),
\qquad
\|H_0^{-1}\|\le M:=\frac1{\sqrt2\min(A_{\min},u_*)}.
\]

Choose \(C_E\) with \(\|\mathcal E\|\le C_ES_*^{-1/2}\); for example \(C_E=\sqrt2C_e\) is valid in the Euclidean operator norm. For every vector \(z\),

\[
|(I+H_0^{-1}\mathcal E)z|\ge(1-MC_ES_*^{-1/2})|z|.
\]

Thus \(MC_ES_*^{-1/2}\le1/2\) proves invertibility and

\[
\|(H_0+\mathcal E)^{-1}\|\le 2M.
\]

This proves the needed estimate directly, with no unproved appeal to a “finite Neumann series.” Along the real path \(I+tH_0^{-1}\mathcal E\), \(0\le t\le1\), the same lower norm bound prevents a zero determinant, so its determinant remains positive. Both singular values are at least \(1/2\). Consequently

\[
\Delta<0,\qquad |\Delta|\ge \frac{|\det H_0|}{4}=\frac{A_cu_*}{2},
\]
\[
|\det H|\ge\frac{A_{\min}u_*}{2}(h_-^{\rm bd})^2S_*^{-1},
\qquad
\|H^{-1}\|\le\frac{2M}{h_-^{\rm bd}}\sqrt{S_*}.
\]

For coefficient positivity retain \(y=H^{-1}T_{0,*}\) and introduce only the comparison coordinates \(c=D_hy\), \(c^{\rm ref}=H_0^{-1}T_{0,*}\). Put \(p=-T_N/A_c>0\), \(q=T_K/u_*\). Then \(|q|\le(1-\eta_c)p\), and

\[
c_+^{\rm ref}=\tfrac12(p-q),\quad c_-^{\rm ref}=\tfrac12(p+q),
\quad c_\sigma^{\rm ref}\ge\tfrac{\eta_c}{2}p.
\]

Moreover

\[
|T_{0,*}|^2=A_c^2p^2+u_*^2q^2
\le [A_{\max}^2+(1-\eta_c)^2u_*^2]p^2.
\]

Hence, with

\[
m_0=\frac{\eta_c}{2\sqrt{A_{\max}^2+(1-\eta_c)^2u_*^2}}>0,
\]

we have \(c_\sigma^{\rm ref}\ge m_0|T_{0,*}|\). The exact inverse difference identity gives

\[
c-c^{\rm ref}=-(H_0+\mathcal E)^{-1}\mathcal E H_0^{-1}T_{0,*},
\quad |c-c^{\rm ref}|\le 2M^2C_ES_*^{-1/2}|T_{0,*}|.
\]

Therefore one fixed threshold

\[
\sqrt{S_*}\ge
\max\left\{2MC_E,\frac{4M^2C_E}{m_0}\right\}
\]

in addition to the already described pulse and cone thresholds proves

\[
\frac{m_0}{2h_+^{\rm bd}}\sqrt{S_*}|T_{0,*}|
\le y_\sigma
\le\frac{2M}{h_-^{\rm bd}}\sqrt{S_*}|T_{0,*}|.
\]

The original amplitudes are exactly

\[
a_\sigma=\sqrt{y_\sigma}>0
\]

on the open shell. They have not been divided by their size, replaced with unit vectors, or signed to absorb a correction. At each shell edge the target and extended amplitudes are zero. The threshold uses only fixed value bounds and direction margins, not the later derivative order or signed correction.

## 5. Derivatives and smooth zero extension with the original shell weight

Retain the source weight

\[
\zeta(X)=\exp\left(-\frac{a_a}{\log^2(X/X_a)}-
\frac{a_b}{\log^2(X_b/X)}\right),
\quad \delta=\min\{1,\log(X/X_a),\log(X_b/X)\},
\]

with its original positive constants. The profile-specific source choice is \(a_a=t_1^2\), \(a_b=4\); the argument applies to precisely those constants. The profile bounds used here are

\[
|T_{0,*}|\ge c_T\zeta,
\qquad |D^IT_{0,*}|\le C_I\zeta\delta^{-d_I}.
\]

The source's chart/profile map has bounded derivatives on the dyadic shell and a positive bounded chart multiplier, so those physical profile bounds have the displayed chart form. All differentiations here keep the label and \(Q,\varepsilon,S_*,c_i,L_s\) fixed. They therefore do not differentiate a discrete frequency or a moving endpoint.

Each derivative of \(H\) is polynomially bounded in \(S_*\) by differentiation of the fixed finite pulse integral. To see that this gives every derivative of its inverse with no new smallness condition, differentiate \(HH^{-1}=I\). For a nonzero multi-index \(I\),

\[
D^IH^{-1}=-H^{-1}\sum_{0<J\le I}\binom IJ(D^JH)(D^{I-J}H^{-1}).
\]

Induction on \(|I|\), the already established value bound on \(H^{-1}\), and the finite sum prove a polynomial bound at every fixed order. Applying the finite Leibniz expansion to \(H^{-1}T_{0,*}\) gives

\[
y_\sigma\ge c\sqrt{S_*}\zeta,
\qquad |D^Iy_\sigma|\le C_IS_*^{b_I}\zeta\delta^{-d_I}.
\]

For completeness, for either exponent \(\nu=1/2\) or \(\nu=-1/2\), the exact multivariate chain-rule formula on the open shell is

\[
D^I(y_\sigma^\nu)=I!\sum_{\substack{(k_J)_{0<J\le I}\\
\sum_J k_JJ=I}}
(\nu)_{\underline n}\,y_\sigma^{\nu-n}
\prod_{0<J\le I}\frac1{k_J!}
\left(\frac{D^Jy_\sigma}{J!}\right)^{k_J},
\qquad n=\sum_Jk_J,
\]

where \((\nu)_{\underline n}=\nu(\nu-1)\cdots(\nu-n+1)\) and the empty product for \(I=0\) is one. This formula follows by applying the one-variable Taylor expansion to \(y(x+h)-y(x)\) and extracting the \(h^I\) coefficient; only degrees at most \(|I|\) can contribute. It therefore has finitely many terms at each fixed order.

For \(\nu=1/2\) and \(|I|>0\), \(n\ge1\); the factor \(y^{1/2-n}\) has a negative exponent and is bounded by the established lower bound on \(y\). The product of the \(n\) derivative factors contributes \(\zeta^n\), while that inverse power contributes \(\zeta^{1/2-n}\). The result is exactly \(\sqrt\zeta\). For \(I=0\), the upper value bound on \(y\) supplies the same weight, with permitted inverse-distance powers. Thus

\[
|D^Ia_\sigma|\le C_IS_*^{b'_I}\sqrt\zeta\,\delta^{-d'_I}.
\]

For \(\nu=-1/2\), the same calculation, including \(I=0\), gives

\[
|D^I(a_\sigma^{-1})|=|D^I(y_\sigma^{-1/2})|
\le C_IS_*^{b''_I}\zeta^{-1/2}\delta^{-d''_I}.
\]

The inverse amplitude itself is not claimed to extend smoothly; the product with an admissible target will extend.

The flatness statement is rigorous: at either edge, \(\sqrt\zeta\,\delta^{-N}\) tends to zero faster than every positive power of the edge distance, because its logarithm has a negative term of order \(-c/\delta^2\), which dominates every \(N\log(1/\delta)\). The same holds for all the displayed derivatives. In local smooth coordinates consisting of edge distance and tangential variables, the zero-extended value is continuous. Its difference quotient normal to the edge tends to zero by the faster-than-linear value bound; its tangential derivative equals zero on the edge. Repeating this argument for each already identified derivative proves by induction that the zero extension is smooth and all its jets vanish. Smooth chart changes preserve this statement. This proves the shell extension claimed for \(a_\sigma\) and for the signed coefficients below.

## 6. Exact signed differential inverse, including its full quadratic remainder

The input is exactly the source's real, angular- and auxiliary-independent two-vector \(\Sigma(R,Z,T)\) in \(\mathcal M_\alpha\), with

\[
|D^I\Sigma|\le C_I\varepsilon^\alpha S_*^{b_I}\zeta\delta^{-d_I}.
\]

Its values may have arbitrary signs and arbitrary size within that class. Keep the already constructed original \(a_\sigma>0\) fixed and define

\[
d_\Sigma=H^{-1}(\Sigma/\varepsilon),\qquad
\delta a_\sigma=\frac{(d_\Sigma)_\sigma}{2a_\sigma},\qquad
\mathcal L\Sigma=\sqrt\varepsilon\sum_{\sigma=\pm}\delta a_\sigma b_\sigma.
\]

The inverse-matrix derivative bounds and Leibniz rule give

\[
|D^Id_\Sigma|\le C_I\varepsilon^{\alpha-1}S_*^{b_I}\zeta\delta^{-d_I}.
\]

Multiplication with the proved \(a_\sigma^{-1}\) estimates gives

\[
|D^I\delta a_\sigma|\le C_I\varepsilon^{\alpha-1}S_*^{b'_I}
\sqrt\zeta\delta^{-d'_I}.
\]

The inverse power of the original amplitude cancels exactly one half-power of the target shell weight. Multiplying by \(\sqrt\varepsilon\) and the original pulse coefficient, whose derivatives have polynomial factors times \(P(v)\), proves

\[
\mathcal L:\mathcal M_\alpha^{\rm independent}\longrightarrow
\mathcal W_{\alpha-1/2},
\]

with the prescribed smooth shell extension, transverse support, pulse cutoff, and later slow cutoff. Both maps in this statement refer to the fixed source chart and labels. Auxiliary independence is required to take \(\delta a_\sigma\) outside the torus integral; angular independence is required for the same angular calculation.

Because the two sign supports are disjoint,

\[
\mathcal C(W_0)=\varepsilon\sum_\sigma a_\sigma^2H_\sigma
=\varepsilon H(y_+,y_-)^T=\varepsilon T_{0,*},
\]
\[
\mathcal B(W_0,\mathcal L\Sigma)
=\varepsilon\sum_\sigma2a_\sigma\delta a_\sigma H_\sigma
=\varepsilon H d_\Sigma=\Sigma.
\]

At shell edges both sides have their proved zero extension, so the identity persists there. The map is linear because \(H,a_\sigma,b_\sigma\) are fixed before \(\Sigma\) is chosen. No positivity or smallness of \(\Sigma\) was used in any equality.

The precise nonlinear remainder can also be written without an unspecified symbol. Set \(z=H^{-1}\Sigma\). Then

\[
\mathcal C(\mathcal L\Sigma)
=\frac1{4\varepsilon}H
\begin{pmatrix}z_+^2/y_+\\z_-^2/y_-\end{pmatrix}.
\]

Thus

\[
\mathcal C(W_0+\mathcal L\Sigma)
=\varepsilon T_{0,*}+\Sigma+
\frac1{4\varepsilon}H
\begin{pmatrix}(H^{-1}\Sigma)_+^2/y_+\\(H^{-1}\Sigma)_-^2/y_-\end{pmatrix}.
\]

The remainder has \(\varepsilon\) exponent \(2\alpha-1\); the product of the two wave weights is \(\zeta P^2\), and \(0\le P\le1\). After averaging it therefore belongs to \(\mathcal M_{2\alpha-1}\) with all derivatives, by the finite Leibniz rule. The exact signed inverse is an inverse of the derivative at the fixed original wave; it does not remove this nonzero quadratic term.

## 7. Physical assembly, chart maps, and the missing domain qualification

The original chart relation is

\[
T_{0,*}=(Q/q)^{A+1/2}T_0.
\]

Keeping every physical scaling factor gives

\[
\begin{aligned}
Q^{-2A}\varepsilon T_{0,*}
&=Q^{-2A+h}(Q/q)^{A+1/2}T_0\\
&=Q^{-A+h+1/2}q^{-A-1/2}T_0\\
&=q^{-A-1/2}T_0,
\end{aligned}
\]

because \(-A+h+1/2=0\). No equality of distinct \(Q_\beta\) is used.

For a physical stress with admissible local representatives, retain the assembled fields exactly as in the source:

\[
W_{0,\mathrm{phys}}^{\rm as}
=\sum_\beta Q_\beta^{-A}\eta_\beta W_{0,\beta},
\]
\[
\mathcal L_{\mathrm{phys}}^{\rm as}\sigma
=\sum_\beta Q_\beta^{-A}\eta_\beta
\mathcal L_\beta(Q_\beta^{2A}\sigma).
\]

At a fixed physical slow point there are finitely many active labels with uniform bounded overlap. Products from distinct active labels vanish by the already proved common-torus support disjointness. The slow \(\eta_\beta\) and \(Q_\beta\) factors are independent of both averaging variables. Therefore the exact contribution of one label is

\[
Q_\beta^{-2A}\eta_\beta^2
\mathcal B(W_{0,\beta},\mathcal L_\beta(Q_\beta^{2A}\sigma))
=Q_\beta^{-2A}\eta_\beta^2Q_\beta^{2A}\sigma
=\eta_\beta^2\sigma.
\]

On the region covered by the squared partition, \(\sum_\beta\eta_\beta^2=1\). Outside the active shell an admissible stress is zero, as are the extended wave fields. These two facts establish the global identity on its proper domain:

\[
\mathcal B(W_{0,\mathrm{phys}}^{\rm as},
\mathcal L_{\mathrm{phys}}^{\rm as}\sigma)=\sigma.
\]

In a reference chart, the exact representative maps are

\[
W_0^{\rm as}=Q^AW_{0,\mathrm{phys}}^{\rm as},
\quad
\mathcal L^{\rm as}\Sigma
=Q^A\mathcal L_{\mathrm{phys}}^{\rm as}(Q^{-2A}\Sigma).
\]

Bilinearity gives

\[
\mathcal B(W_0^{\rm as},\mathcal L^{\rm as}\Sigma)
=Q^{2A}(Q^{-2A}\Sigma)=\Sigma.
\]

For overlapping bands the chart maps are exactly

\[
R_\beta=(Q/Q_\beta)^{1/2}R,\quad
Z_\beta=(Q/Q_\beta)^DZ,\quad
T_\beta=(Q/Q_\beta)T,
\quad \varepsilon_\beta=(Q_\beta/Q)^h\varepsilon.
\]

Their constants and inverses are uniformly bounded on the allowed band range, as are \(S_\beta/S_*\) and covering multiplicities. The shell variable \(X\) and its weights describe the same physical point. Each fixed derivative of these affine scale changes introduces bounded factors, and derivatives of the fixed mesh cutoffs add polynomial powers of \(S_*\). Finite sums and prior collection of equal label-harmonic contributions therefore preserve every stated coefficient exponent.

**Necessary qualification at source line 403.**

The phrase “For a physical auxiliary-independent stress sigma(r,z,t)” must retain the preceding local input class and support. Taken literally for every such physical stress, it is false. Choose any nonzero smooth two-vector stress with compact support in an open set outside the closed active shell. It is auxiliary-independent. Every assembled wave in the displayed formulas vanishes there, so its bilinear covariance is zero there, while the chosen stress is nonzero. Thus the asserted right-inverse identity cannot hold on that enlarged domain. Furthermore an arbitrary nonvanishing stress approaching a shell edge need not cancel \(1/a_\sigma\) and need not give any smooth extension.

A precise source replacement is:

> For a real, auxiliary-independent physical stress supported in the prescribed active shell whose band representatives \(Q_\beta^{2A}\sigma\) satisfy the local \(\mathcal M_\alpha\) bounds and smooth zero extension used above, use the assembled maps below.

This repairs the domain while retaining all original formulas. The stated local inverse at line 383 and actual increment at line 474 already include the mean-class restriction. No additional sign or smallness requirement should be inserted.

## 8. Actual divergence-free covariance increment and every exponent

Retain the source hypotheses and fields:

\[
U=W_0^{\rm as}+E,\qquad U\in\mathcal W_{1/2},\quad E\in\mathcal W_\rho,
\qquad \Sigma\in\mathcal M_\alpha^{\rm independent}.
\]

The exact curl construction applied to the original \(\mathcal L^{\rm as}\Sigma\) produces

\[
V=\mathcal L^{\rm as}\Sigma+R,
\qquad R\in\mathcal W_{\alpha-\kappa_s},
\]

since the input exponent is \(\alpha-1/2\) and the curl correction gains \(1/2-\kappa_s\). With \(L=\mathcal L^{\rm as}\Sigma\) only as a temporary notation for this unchanged field, expansion of all products gives

\[
\begin{aligned}
\mathcal C(U+V)-\mathcal C(U)
&=\mathcal B(U,V)+\mathcal C(V)\\
&=\mathcal B(W_0^{\rm as}+E,L)+\mathcal B(U,R)+\mathcal C(V)\\
&=\Sigma+\mathcal B(E,L)+\mathcal B(U,R)+\mathcal C(V).
\end{aligned}
\]

The first remainder includes precisely the interaction of the already present error with the uncurled signed inverse. The second retains its interactions with both \(W_0^{\rm as}\) and \(E\), because \(U\) is not replaced. The third retains all three quadratic pieces

\[
\mathcal C(V)=\mathcal C(L)+\mathcal B(L,R)+\mathcal C(R).
\]

Leibniz differentiation and the product weight \(\sqrt\zeta P\sqrt\zeta P=\zeta P^2\le\zeta\) give

\[
\mathcal B(E,L)\in\mathcal M_{\rho+\alpha-1/2},
\quad
\mathcal B(U,R)\in\mathcal M_{\alpha+1/2-\kappa_s}.
\]

The three quadratic pieces have exponents, respectively,

\[
2\alpha-1,\qquad 2\alpha-\tfrac12-\kappa_s,
\qquad 2\alpha-2\kappa_s.
\]

Because \(0<\varepsilon\le1\) and \(\kappa_s<1/2\), the latter two exponents are at least \(2\alpha-1\); hence their estimates imply the same weaker class \(\mathcal M_{2\alpha-1}\). Equivalently, \(R\in\mathcal W_{\alpha-\kappa_s}\) implies \(R\in\mathcal W_{\alpha-1/2}\), so \(V\) is in the latter class. This proves exactly the source's third displayed exponent without suppressing a quadratic term.

The original tangential radial-divergence components are \((D_r+2/R)T_\theta\) and \((D_r+1/R)T_z\). On the fixed positive radial interval the frame multipliers and all their derivatives are bounded. The established coefficient derivative map is \(D_r:\mathcal M_\beta\to\mathcal M_{\beta-\kappa_s}\). Consequently the three respective exponents after this conservative radial-divergence estimate are

\[
\rho+\alpha-\tfrac12-\kappa_s,
\qquad \alpha+\tfrac12-2\kappa_s,
\qquad 2\alpha-1-\kappa_s.
\]

For these particular fully averaged remainders one can also observe that they are auxiliary-independent; then the torus component of \(D_r\) annihilates them and the ordinary chart derivative need not lose \(\kappa_s\). The source's weaker estimate remains valid and is the one recorded for stage comparison. The local calculation itself imposes no extra inequality involving \(\alpha\) and \(\rho\); a later residual-improvement claim has to substitute its actual exponents into these proved expressions.

## 9. Audit disposition

The exact determinant, orientation, reference coefficients, signed inverse, covariance factors, physical chart factors, and all three remainder exponents have been checked. The positivity argument can be made fully explicit by the single value threshold in Section 4, and all fixed derivative orders follow without increasing that threshold. Division by the original positive amplitudes is valid on the prescribed weighted domain and gives smooth zero-extended signed corrections.

The substantive omission is the overly broad physical input wording at line 403; Section 7 provides both its counterexample and the exact corrected domain. The phrase “finite Neumann series estimate” at line 353 is imprecise; Section 4 supplies a direct norm proof and exact inverse-difference identity. The background endpoint factors and pulse evolution remain identifiable imported construction inputs, with their precise source locations recorded in Section 1; this covariance audit does not certify those separate constructions or the later numerical choice of iteration exponents.

