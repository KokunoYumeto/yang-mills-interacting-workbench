"""Exact symbolic replay for the explicitly written map and covariance identities.

This checks identities only; the accompanying TeX proves domains, bounds,
support separation, smooth extension and the finite covering assertions.
"""

import json
from pathlib import Path
import sympy as s

checks = []


def check(name, value):
    if isinstance(value, s.MatrixBase):
        ok = all(s.simplify(x) == 0 for x in value)
    else:
        ok = s.simplify(value) == 0
    checks.append({"identity": name, "passed": bool(ok)})
    if not ok:
        raise AssertionError((name, value))


h, q, eta, X, R = s.symbols("h q eta X R", real=True)
D = s.Rational(1, 2) - h
A = s.Rational(1, 2) + h
d = 1 - eta**2
L = 1 - 2*h*eta**2

# The source exponents are retained; a positive formal q is needed for powers.
q = s.symbols("q", positive=True)
z = q**D*eta
t = 1-q*d
Jphys = s.Matrix([[s.diff(z, q), s.diff(z, eta)],
                  [s.diff(t, q), s.diff(t, eta)]])
check("physical coordinate Jacobian orientation", Jphys.det()-q**D*L)
InvExpected = s.Matrix([[2*eta*q**(1-D)/L, -1/L],
                       [d/(q**D*L), D*eta/(q*L)]])
check("q eta inverse coordinate derivatives", Jphys*InvExpected-s.eye(2))

sQ = s.symbols("s_Q", positive=True)
Jchart = s.Matrix([[D*sQ**(D-1)*eta, sQ**D],
                   [d, -2*sQ*eta]])
InvChart = s.Matrix([[2*eta*sQ**(1-D)/L, 1/L],
                     [d/(sQ**D*L), -D*eta/(sQ*L)]])
check("chart inverse signs and exponents", Jchart*InvChart-s.eye(2))
check("chart Jacobian orientation", Jchart.det()+sQ**D*L)

bg = s.sqrt(2)-1
vr = s.Matrix([1, -bg])
vt = s.Matrix([bg, 1])
Jg = s.Matrix([[3, 1], [1, 5]])
check("radial eigenvector", Jg*vr-(4-s.sqrt(2))*vr)
check("time eigenvector", Jg*vt-(4+s.sqrt(2))*vt)
check("eigenvector orthogonality", vr.dot(vt))
check("cover determinant", Jg.det()-14)
check("rectangle Jacobian", s.Matrix.hstack(vr, vt).det()-(1+bg**2))
lt = vt.T/(1+bg**2)
check("pulse path transverse projector", (s.eye(2)-vt*lt)*vt)
check("pulse path preserves radial coordinate", lt*vr)

ac, u, hp, hm, TN, TK = s.symbols("A_c u_star h_plus h_minus T_N T_K", nonzero=True)
H0 = s.Matrix([[-ac, -ac], [-u, u]])
Hm = H0*s.diag(hp, hm)
coeff = s.Matrix([(-TN/ac-TK/u)/(2*hp),
                  (-TN/ac+TK/u)/(2*hm)])
check("reference column determinant orientation", Hm.det()+2*ac*u*hp*hm)
check("positive reference coefficients solve original target", Hm*coeff-s.Matrix([TN,TK]))

eps, ap, am = s.symbols("epsilon a_plus a_minus", positive=True)
sig0, sig1 = s.symbols("Sigma_0 Sigma_1", real=True)
S = s.Matrix([sig0,sig1])
ds = Hm.inv()*S/eps
da = s.Matrix([ds[0]/(2*ap),ds[1]/(2*am)])
check("signed differential inverse retains factor two", eps*Hm*s.diag(2*ap,2*am)*da-S)
quadratic = eps*Hm*s.Matrix([da[0]**2,da[1]**2])
hs = Hm.inv()*S
check("exact quadratic covariance remainder", quadratic-Hm*s.Matrix([hs[0]**2/ap**2,hs[1]**2/am**2])/(4*eps))

check("physical covariance Q exponent cancellation", -2*A+h+A+s.Rational(1,2))
check("time scaling exponent", 2*A+s.Rational(1,2)-A-(1+h))
check("viscous scaling exponent", 2*A+s.Rational(1,2)-A-1-h)
check("axial chart scaling exponent", s.Rational(1,2)-D-h)

report = {
    "scope": "Exact finite-dimensional and coordinate identities only; no global Navier-Stokes theorem asserted.",
    "checks": checks,
    "total": len(checks),
    "passed": sum(x["passed"] for x in checks),
    "all_passed": all(x["passed"] for x in checks),
}
out = Path(__file__).with_name("exact_checks.json")
out.write_text(json.dumps(report, indent=2)+"\n", encoding="utf-8")
print(json.dumps({"total": report["total"], "passed": report["passed"], "all_passed": report["all_passed"]}))
