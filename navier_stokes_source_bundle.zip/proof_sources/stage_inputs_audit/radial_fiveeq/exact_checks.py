"""Exact finite algebra checks; analytic claims are proved in the TeX body."""
import json
from pathlib import Path
import sympy as s

a, m0, m1, m2, t0, t1, t2, b1, b2, z = s.symbols(
    "a m0 m1 m2 t0 t1 t2 b1 b2 z"
)
C = b1*(z-t0)*(z-t2)/((t1-t0)*(t1-t2)) + b2*(z-t0)*(z-t1)/((t2-t0)*(t2-t1))
checks = {
    "angular_zero_moment": s.factor(C.subs(z,t0)) == 0,
    "angular_pressure_value": s.factor(C.subs(z,t1)-b1) == 0,
    "angular_axial_flux_value": s.factor(C.subs(z,t2)-b2) == 0,
}
B = s.Matrix([[m0,m0*t0,m0*t0**2],
              [2*a*m1,2*a*m1*t1,2*a*m1*t1**2],
              [-a*m2,-a*m2*t2,-a*m2*t2**2]])
checks["signed_angular_determinant"] = s.factor(
    B.det()+2*a*a*m0*m1*m2*(t1-t0)*(t2-t0)*(t2-t1)
) == 0
ta,tb,jtheta,mua,mub=s.symbols("ta tb jtheta mua mub")
s1=-jtheta/(a*mua*(ta-tb))
s0=-tb*s1
checks["axial_zero_moment"] = s.factor(mub*(s0+tb*s1)) == 0
checks["axial_target"] = s.factor(a*mua*(s0+ta*s1)+jtheta) == 0
checks["signed_axial_determinant"] = s.factor(
    s.Matrix([[mub,mub*tb],[a*mua,a*mua*ta]]).det()
    -a*mub*mua*(ta-tb)
) == 0
h,eta,mstar,lam=s.symbols("h eta mstar lam")
A=s.Rational(1,2)+h
D=s.Rational(1,2)-h
checks["exact_radial_profile"] = s.factor(
    (-2*D*eta*(mstar*eta)-(1-eta**2)*mstar)/(1-2*h*eta**2)
    +mstar
) == 0
checks["chart_swirl_power"] = s.expand(-A+(1+2*lam)/2-(lam-h)) == 0
checks["pressure_scaling"] = s.expand((2*A+s.Rational(1,2))-s.Rational(1,2)-2*A)==0
checks["axial_pressure_moment_scaling"] = s.expand((2*A+s.Rational(1,2))-s.Rational(3,2)-(2*A-1))==0
J=s.Matrix([[3,1],[1,5]])
vr=s.Matrix([1,1-s.sqrt(2)])
vt=s.Matrix([s.sqrt(2)-1,1])
checks["radial_eigenvector"]=all(s.expand(v)==0 for v in J*vr-(4-s.sqrt(2))*vr)
checks["temporal_eigenvector"]=all(s.expand(v)==0 for v in J*vt-(4+s.sqrt(2))*vt)
u,v,d,gam,G,V,b,Binc,beta=s.symbols("u v d gam G V b Binc beta")
checks["radial_quadratic_difference"]=s.expand((beta+Binc)**2-beta**2-2*beta*Binc-Binc**2)==0
checks["mixed_quadratic_difference"]=s.expand((beta+Binc)*(gam+d)-beta*gam-beta*d-gam*Binc-Binc*d)==0
checks["swirl_quadratic_difference"]=s.expand((v+u)**2-v**2-2*v*u-u**2)==0
kap=s.Rational(1,100000)
checks["initial_defect_exact_exponent"]=(1-kap)+s.Rational(9,10)-2*kap==s.Rational(189997,100000)
checks["initial_defect_above_C0"]=(1-kap)+s.Rational(9,10)-2*kap>s.Rational(6,5)
checks={key:bool(value) for key,value in checks.items()}
out={"all_passed":all(checks.values()),"checks":checks}
Path(__file__).with_name("exact_checks.json").write_text(json.dumps(out,indent=2)+"\n",encoding="utf-8")
print(json.dumps(out,indent=2))
assert out["all_passed"]
