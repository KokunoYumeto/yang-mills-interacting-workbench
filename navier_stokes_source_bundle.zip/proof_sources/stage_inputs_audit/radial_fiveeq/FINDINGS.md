# Complete radial/five-equation audit results

The inclusion fragment is radial_fiveeq_body.tex. It requires amsmath, amssymb, amsthm, and a proposition environment; it defines no custom macros and has no preamble. standalone.tex is the separate wrapper. The proof preserves the source's fixed 0<h<1/100, positive fixed lambda, original D_r,D_z,t_*, dyadic Q, physical q, closed parameter endpoint, and proper reserved shell.

## Exact results ready for integration

1. RF8–RF14 prove the full torus obstruction K_e, exact sequence, unique compact inverse on its kernel, and D_e T_e=1-A_e, A_e²=A_e. Haar cancellation gives only the scalar average of K_e.
2. RF15 gives a real smooth all-orders-flat source whose Haar average is zero at every radius but whose full K_e is nonzero. Exact elimination of the retained flat projector remainder is impossible in general.
3. RF16–RF22 prove weighted primitive bounds by fixed-shift integrals, exact irrational small-divisor estimates, and every-order flatness of A_e after Haar cancellation. Derivative order changes the integration-by-parts count and constants, not the chosen physical domain or construction parameters.
4. RF24–RF27 retain the radial pressure remainder and actual axial remnant a=-A_1 gamma_d. The resulting velocity is exactly divergence-free, its weighted moment remains exactly zero, and every later product must use the actual increment including a.
5. RF40a–RF40g derive the intermediate power-law amplitude and exact interval I_mean=I4, track all earlier compact edits and their exact moment-restoration map, and compute the cumulative axial moment. RF40–RF42 prove that every positive-order velocity and the derivative-of-Borel-cutoff radial term vanish on the entire mean interval.
6. RF43 is exactly
   \[
   b=-\epsilon\mathfrak m/R,\qquad
   V=a(\eta)(q/Q)^{\lambda-h}R^{-1-2\lambda},\qquad G=0,
   \]
   where
   \[
   \mathfrak m=eX_R\left(4+\int_0^{T_d}k(v)e^v\,dv\right)>0,
   \quad a_0=2^{\lambda-1/2}c_{\rm patch}>0.
   \]
   This holds on every gap crossed by the mean Stokes potential as well as on the bumps.
7. RF31–RF39 give all physical/q-profile/Q-chart target factors, signed determinants and explicit inverse coefficients. The inverse exists for every fixed positive lambda, every target size, and all fixed derivative orders. It imposes no further small-q threshold.
8. At lambda=0, the zero axial moment forces the axial block's flux moment to vanish; a nonzero J_theta target is then impossible for every compact smooth correction. This is an actual rank failure outside the original positive-parameter domain.
9. RF44–RF49 retain all terms and prove exact formulas for the remaining three defects after cancellation of the base-linear terms. At initial target order H0=1-kappa_s, the defect exponent is 1.9-3*kappa_s=1.89997>1.2. This does not substitute for the parent's separate stage-zero residual estimates.

## Omissions closed relative to the earlier bounded ledger

The earlier mean-corrections ledger delegated actual summed-base preservation and local bounds to other source lanes. The new fragment proves the connecting calculation, including exact propagation from restored cumulative moments, vanishing of every positive-order cutoff term, and the full-potential support. No replacement background or perturbed determinant is used.

The flat radial remnant is not an omission to repair by setting it to zero: RF15 proves why it must remain. A state or recomputation that omits it needs to be corrected by using RF25–RF27 in the actual velocity.

## Validation and boundaries

- exact_checks.py uses SymPy exact algebra. All 18 assertions pass, including both signed determinants, every interpolated target, q/Q powers, radial identity, eigenvectors, nonlinear products, and the initial exponent. Receipt: exact_checks.json.
- standalone.tex compiles successfully to a 12-page PDF without overfull or underfull boxes or mathematical LaTeX errors.
- patch_source_check.md independently records exact base source provenance with line references, including earlier profile/cone/heat restorations and finite-parameter thresholds.
- These computations concern the specified radial and five-equation maps. They make no separate claim to establish the initial wave covariance, all of Section 9, or a Navier–Stokes endpoint.
- No Lean/Lake/Elan process, publication, or edit outside this lane was performed.
