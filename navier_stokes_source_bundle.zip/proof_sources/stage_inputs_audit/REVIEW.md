# Stage-input integration review

The complete integration-ready proof is `stage_inputs_body.tex`; the standalone document is `stage_inputs.tex`. Every body label and reference has the prefix `si:`. The only custom theorem environment is `siproposition`, declared in the body. There are no external TeX inputs, appendix commands, or counter resets in the integration body. Required standard packages are amsmath, amssymb, amsthm; the standalone wrapper also loads mathtools, geometry, hyperref and longtable.

Final integration body SHA-256: `18f4b5b95d1ff062c2df75afdb3084091759b87ced9b374f04a6abfcf8a4eb15`.

Final standalone TeX SHA-256: `c8290423de621cc920d38c31d179b7bcd992b4467c8c859e42b42658308b0e3b`.

The original source identity remains the frozen 165-page PDF, SHA-256 `8c8a94ad9ac824c8b605b9827cadf7beaca48bd10b380de3cfc872a2c37afa81`. The current primary 76-page edition and its snapshot were not edited in this subtree. No Lean, remote publication, or external messages were used.

## Exact mathematical integration points

1. **Common domain and differential maps.** The proof gives the global q inverse on t<1 and its precise one-sided q>0 terminal boundary, every original q/X/eta derivative, physical evaluation as a differential algebra map, the full finite coverings, exact Haar preservation and descent, and original Dr/Dz/t_* intertwining. A common neighborhood must be chosen with q(U) contained in (q0/2,2q0); then all active band scales lie in (q0/4,4q0), giving the fixed covering-offset bound. An arbitrary finite collection of bands would not imply that uniform bound. The full support coloring, rational centers, enlarged-rectangle separation and exact lifted pulse path are proved. The evaluation/mean relation is given by an exact projection identity and an explicit kernel counterexample.

2. **Actual pulse estimates.** `pulse_data.tex` contains the complete constrained-plane equations, pressure elimination, phase comparison, propagator and all-fixed-derivative induction, and the positive homogeneous pulse proof from the live oscillatory derivation. It is included in the single standalone body, so the covariance calculation does not rely solely on a dependency ledger. The background expansion is checked against the actual diagonal potential cutoff, with its radial cutoff derivative retained.

3. **Original positive-amplitude signed inverse.** The covariance proof retains the angular factor 1/2, rectangle Jacobian 1+b_g^2, transverse integral and c_i dv measure. It proves an explicit determinant/adjugate bound and positivity threshold, including edge directions. Every signed correction divides only by the fixed original 2a_sigma. The exact derivative identity includes both cross terms; the quadratic covariance increment and every complete-curl remainder remain present. The physical signed-stress domain must be real, auxiliary independent, supported in the active shell, and have all Q_beta^(2A) representatives in the stated M_alpha domain with all derivative edge bounds and smooth zero extension. Mere auxiliary independence is insufficient. Exact corrected wording is supplied in the covariance fragment.

4. **Full radial obstruction.** The exact sequence uses the torus-valued characteristic moment K_e. It proves D_e T_e=1-A_e, K_e A_e=K_e, A_e^2=A_e and T_e D_e=1, and gives a nonzero flat source with zero Haar mean but nonzero K_e. The fixed-shift U=R^(d_r) formulas prove the primitive's all-derivative weighted estimates; repeated integration by parts gives every flat order on the same domain. The actual temporal axial increment is gamma_d-A_1 gamma_d. Its flat part remains in the actual field and all products.

5. **Exact source mean interval.** The proof traces I_mean=I4=X_w exp((T_w-8,T_w-3)) through the leading schedule and exact moment repairs; the preceding positive-order patch is I3, with a positive logarithmic gap. The full potential interval between the first and last mean bump lies within I4. The leading cumulative axial moment is m eta with m=e X_R(4+integral_0^Td k(v)e^v dv)>0. Therefore V_0=-m, and every positive-order velocity and cutoff-potential term vanishes on I4. The actual summed chart fields there satisfy exactly b=-epsilon m/R, V=a(eta)(q/Q)^(lambda-h)R^(-1-2lambda), G=0. The five-row inverse is constructed with explicit scaled bumps and exact profile-to-chart target powers. No target-size or stage-dependent invertibility condition occurs.

6. **Stage zero.** SI1 proves Sigma-Sigma^(0) in M_3 from the exact stress scale. SI2--SI4 retain the full a=t+r and the exact longitudinal divergence identity, giving the primary W_(1-3kappa) nonzero residual. SI5--SI6 prove the full initial mean residual and the stronger Haar bound M_(3/2-kappa), hence M_1.49. SI7--SI8 give the complete temporal differences; -cN B occurs at order H+1 in its radial source and is not assigned the stronger slow-field time order. Haar averages can change quadratically, although their retained order persists. SI9 includes the complete radial-source contribution in J_z after the five-row update. SI10 proves B0=.7/C0=1.2 and W_.5/W_.68/M_.9/M_1.9, with both moments exactly zero.

7. **Fixed threshold and source closure.** SI11 makes one parameter/geometry threshold choice. The all-harmonic propagator formula, finite derivative induction, fixed linear inverses, original-amplitude division, and locally finite operations introduce no later threshold restrictions. SI12 is the actual forward source class, with original supports, every derivative bound, envelope, full radial edge weights and finite harmonic set. Closure is proved operation by operation, including exact path support, radial integration at fixed q, all products of complete curls, and the flat ideal. Cutoff/projector tails remain in the additive flat residual.

## Concrete source wording repairs

- Common torus: explicitly narrow the neighborhood by q(U) contained in (q0/2,2q0).
- Physical signed covariance assembly: state its shell-supported M_alpha domain and smooth edge extension.
- The covariance matrix paragraph's phrase “finite Neumann series estimate” should refer to the actual inverse estimate. The included proof supplies a finite-dimensional determinant/adjugate estimate; an exact inverse is not a finite Neumann polynomial.
- Temporal initialization: replace “unchanged auxiliary averages” with the precise assertion that the existing averaged order is retained after the explicitly displayed quadratic changes.
- Keep the temporal radial time term -cN B distinct from the later torus-independent five-equation radial time term.

The parent coordinator was sent the first two exact wording corrections and reported applying them to live oscillator Markdown/TeX while preserving the old reader. This subtree does not claim to have made those outside edits.

## Validation and reproducibility

- `python assemble.py` produces both single-file TeX outputs and a hash receipt from the owned fragments.
- `pdflatex -interaction=nonstopmode -halt-on-error stage_inputs.tex` was run to stable references: 44 pages, no actual warnings, undefined references, overfull boxes or underfull boxes.
- `python check_exponents.py` passes seven exact Fraction comparisons and all explicitly listed term bounds. Its initial overstrong checker bound for the temporal radial remainder was corrected to min(H+1,2H); the mathematical text had already retained only the valid M_H bound.
- The maps/covariance child passed 19 exact symbolic checks. The radial/five-equation child passed 18 exact symbolic checks. These are arithmetic/algebra checks, not substitutes for the written analytic proofs.
- `python render_review.py` rendered all 44 pages and checked text bounds. All-page contact sheets and full pages 25, 26, 39, 40, 41, 43 and 44 were inspected. Equations and tables are legible; no clipping, overlap or margin overflow was found. The short final page contains the concluding exact decomposition, without a missing mathematical continuation.

The claim established here is the exact finite-state assembly and its source-class preservation on a fixed domain. The global Navier--Stokes theorem, infinite-stage realization and localization remain the parent construction's separate work.

## Current live correction and validation — 9 September 2026

The preceding 44-page validation records the earlier source state. The current live pulse source and its two assembled copies now retain the actual-shear remainder at the representative, prove the actual homogeneous-pulse production bound with explicit integer thresholds and every polarization error, use the full polynomial coefficient-product estimate for the radial transport term, and prove both directions of the moving-plane coordinate equation. The exact ambient map is the oblique projection onto the constrained plane along the actual tangential direction; its identity action is used only on that plane. The actual equation, damping, carrier, signs, original background and covariance integral remain the original objects.

The stage-input assembler was rerun from the corrected fragment. Current `stage_inputs_body.tex` has SHA-256 `61aa4684591b964321b00304d58ca7e8e2bbf538cfc930bc8a6be219755bd7e3`; current `stage_inputs.tex` has SHA-256 `41462256f825435865958bd9c4d4fcfe07ef22d5fbe34cca2a7fe34f34ec5edd`. The final PDF is 47 pages. Repeated compilation reached stable references with no actual warning, undefined control, or overfull box. Every page was rendered and checked geometrically; all four contact sheets and full pages 12, 13, 17 and 18 containing the repairs were inspected. No clipping, overlap or broken formula was found. The refreshed `qa_receipt.json` identifies this exact PDF and validation state.

The exact preimages of all six affected live copies, postimage hashes, and unchanged protected-edition checks are in `../global_analytic_closure_review/LIVE_CORRECTION_RECEIPT.json`; the current complete mathematical audit and independent correction reviews are recorded there as separate proof and review artifacts. The earlier published reader and release packages were not edited. This update extends the prior review only for the stated local correction and regenerated output; it does not enlarge the mathematical scope of the finite-state assembly.
