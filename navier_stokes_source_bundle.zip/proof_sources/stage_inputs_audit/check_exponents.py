"""Exact arithmetic checks for the explicitly proved stage-zero inequalities."""
from fractions import Fraction as F
from pathlib import Path
import json

k = F(1, 100000)
H = 1-k
temporal_radial_remainder = [H+1, H+2-k, 2*H+2-k,
    H+2, H+2, 2*H+2, 2*H, H+2-2*k]
temporal_mean_changes = [H+1, H+1-2*k, H+1-k, H+1,
    2*H+1-k, 2*H+1]
slow_radial_remainder = [H+2, H+2-k, H+F(29,10)-k,
    2*H+2-k, H+2, H+2, H+F(29,10), H+F(29,10),
    2*H+2, H+F(9,10), 2*H, H+2-2*k]
assert min(temporal_radial_remainder) >= min(H+1, 2*H)
assert min(temporal_mean_changes) >= H+1-2*k
assert min(slow_radial_remainder) >= H+F(9,10)-2*k
checks = {
    "wave_residual": (1-3*k, F(7,10)),
    "tangential_mean_residual": (F(149,100), F(6,5)),
    "three_defects": (H+F(9,10)-2*k, F(6,5)),
    "primary_curl_difference": (1-k, F(68,100)),
    "mean_tangential_and_pressure": (H, F(9,10)),
    "mean_radial": (H+1, F(19,10)),
    "averaged_primary_residual": (F(3,2)-k, F(149,100)),
}
for name, (proved, retained) in checks.items():
    assert proved > retained, name
receipt = {
    "method": "Python Fraction exact rational arithmetic, only displayed exponent inequalities",
    "kappa": str(k), "H": str(H),
    "checks": {name: {"proved": str(a), "retained": str(b),
        "strict_margin": str(a-b)} for name,(a,b) in checks.items()},
    "temporal_radial_remainder": list(map(str, temporal_radial_remainder)),
    "temporal_mean_changes": list(map(str, temporal_mean_changes)),
    "slow_radial_remainder": list(map(str, slow_radial_remainder)),
    "all_passed": True,
    "scope": "Arithmetic validation only; analytic proofs are in stage_inputs.tex.",
}
Path(__file__).with_name("exponent_checks.json").write_text(
    json.dumps(receipt, indent=2)+"\n", encoding="utf-8")
print(json.dumps({"all_passed": True, "strict_comparisons": len(checks)}))
