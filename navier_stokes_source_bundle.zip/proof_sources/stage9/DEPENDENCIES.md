# Stage 9 dependency scan of released_ns component audits

Scanned component audit folders under `research/released_ns` on 2026-09-08. Source manuscript identity is SHA-256 `8c8a94ad9ac824c8b605b9827cadf7beaca48bd10b380de3cfc872a2c37afa81`; source URL is https://cdn.openai.com/pdf/32d9f210-8b73-45e0-91bc-82a30aef8a9a/navier-stokes.pdf.

## Profiles (Sections 4 and Appendix B)

Use these files:

- `profiles/core_exact.md`: retains `0<h<1/100` for the construction (coordinate lemma proved on `0<h<1/2`), exact `(q,eta,X)` Jacobian, Cartesian axis extension, incompressibility, pressure identity, stress primitives, and five moment coordinates `(M,I,J,S,C_p)`.
- `profiles/axis_exact.md`: imported holomorphic pressure datum `Pi_0`; exact axis root/positivity alternatives; weighted Banach coefficient space, radial resolvents and nonlinear contraction; common analytic domain.
- `profiles/continuation_exact.md`: reference continuation to `X_i=110`, activation/flat factorization, cone crossing, continuation and five-moment repair, parameter order (fix finite `N`, then physical scale/bands/stages).
- `profiles/profiles_body.tex`: direct inclusion body; `exact_checks.py`/`exact_checks.json` contain 14 supplementary checks. `README.md` is the result/dependency ledger.

Stage 9 must import (and identify as imports) existence of the Appendix-A outer profile/pressure datum and Appendix-C initial variance loop. Profiles does not certify those constructions or Theorem 4.6 globally.

## Base and heat (Section 5 and Appendix A)

Use `base_heat/derivation.tex` and `base_heat/read_scope_ledger.md`; `README.md` states build commands, while `verify_identities.py`/`identity_check_results.json` supply seven exact-zero identities, two rational quadratic maxima, and one explicitly numerical pulse evaluation. Required interfaces are:

- fixed radial coefficient induction and Proposition 5.5-type bounds: for truncation `N`, one valid physical loss is `K_m=2A+1/2+m` and residual `O(q^{2h(N+1)-K_m})`; stage-independent derivative losses;
- divergence-preserving potential cutoffs (curl the cut potential, retaining the `nabla chi x A` term), locally finite Borel tail and flat residual at each fixed physical derivative order;
- all positive-order velocity/pressure corrections supported below a common `X_+`, stresses below `X_b`, and exact leading heat exterior with zero augmented residual beyond support;
- Appendix-A outer schedule and moment closure, exact heat ODE, and endpoint stress factors: flat powers `-3` for angular factor, `+3` for integrated factor, ratio power `+6`; endpoint angular coefficient `16 rho_o E_pow(X_b) H(2d/X_b) g(0)/sqrt(2X_b)`; precursor bound is `C_pre e^26/lambda`.

Base audit imports leading-axis gluing, final leading profile/moment data, wave realization, and global endpoint; it does not establish these.

## Oscillations (Sections 6-7 and Appendix C)

Use `oscillations/01_auxiliary_geometry.md`, `02_pulse_equation.md`, `03_covariance_curl_and_tails.md`, `04_admissible_cone.md`, and inclusion body `oscillations_body.tex`; `READ_SCOPE.md` records boundaries; `exact_checks.py`/`exact_checks_results.json` contain 28 exact algebra checks; the SHA-256 rehash is separately classified. Interfaces needed by Stage 9:

- classes `W_alpha` (waves) and `M_alpha` (means), dyadic chart maps, `kappa_s=10^-5`, derivative losses: `D_r` at most `-kappa_s`, `D_z` and slow `t` gain one, fast `cN` preserves exponent;
- primary total wave in `W_{1/2}`, actual-wave difference in `W_{0.68}`; mean tangential fields in `M_{0.9}`, radial mean in `M_{1.9}`;
- exact stress-covariance right inverse and retained nonlinear quadratic remainder, old-wave interaction, curl term, and Gaussian cutoff terms; fixed-stage tails are flat in `q` at every physical derivative;
- Appendix-C loop/modulation and five-moment restoration preserve axis data, exterior heat, reserved intervals and cone margins.

Oscillations explicitly leaves the complete Section-9 normalized residual expansion, infinite summation, compactification and endpoint theorem to the root programme. Fixed-stage flat tails cannot replace this proof.

## Mean corrections (Section 8)

Use `mean_corrections/AUDIT.md`, `DEPENDENCIES.md`, and inclusion body `mean_corrections_body.tex`; `verify_exact.py`/`exact_checks.json` contain 26 checks. Interfaces needed by Stage 9:

- exact radial operator `D_e=D_r+e/R` has full torus obstruction `K_e f(w)=integral R^e f(R,w+M R^{d_r}v_r)dR`; zero Haar moment is necessary for the mean but is not sufficient for compact inversion;
- split inverse/projector `T_e`, `A_e` satisfies `D_e T_e=1-A_e`, `K_e A_e=K_e`, `A_e^2=A_e`, and `T_e` is exact on `ker K_e`; the retained projector is the flat remainder used in Section 9;
- exact five-dimensional inverse requires the summed-base law `G_q=0`, `V_q=a(eta)x^{-1-2lambda}`, with fixed positive `lambda`, and produces potential/stress bounds; classes used by Stage 9 are `v,gamma in M_0.9`, `beta in M_1.9`, targets in `S_alpha (alpha>=0.9)`;
- derivative and product estimates preserve shell weights `zeta delta^{-C}` and explicit `epsilon` powers.

Mean audit imports the actual base law/profile shell, global iteration, and endpoint. It warns that the full torus obstruction must not be silently replaced by its Haar average.

## Stage 9 imported boundary

The stage9 body now proves the complete finite correction cycle, exponent budget, fixed common domain, Cartesian derivative conversion, and single-stage realization. Its imports are the actual profile/background data and the earlier proved pulse, covariance, radial, temporal, and five-equation maps listed above. The summation specializes the proof in base_heat/derivation.tex to g_j=hj/10, with stage-independent cutoff derivative loss L_m=ell_{m+1}+m+1. The weighted mean identities are MC16–MC17 in mean_corrections_body.tex, including the entire derivative epsilon partial_Z(J_z+c_rho P). Defect correction uses MC28–MC30 with the complete R_g reproduced and symbolically checked. The phase/curl interface retains n_Phi=grad_*Phi and ikm n_Phi dot a=-((D_r+1/R)a_r+D_z a_z): exponent alpha+1/2-kappa_s belongs to n_Phi dot a, while multiplication by ikm gives alpha-kappa_s. Root propagated that precision repair to the oscillations body. Terminal force extension, whole-space comparison, energy, viscosity maps and periodization belong to Section 10, outside this assignment. These component-local results are not promoted to a theorem-complete claim.
