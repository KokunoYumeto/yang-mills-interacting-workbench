# STATUS — Section 9 reconstruction

## Delivered

The stage9_body.tex inclusion body reconstructs the finite correction state, initialization, four-step cycle, fixed common domain, Cartesian derivative conversion, and single-stage realization from printed pp.100–116. The exact requested constants and every class budget are retained.

## Mathematical repairs

- The phase covector is the full grad_* Phi, with its three exact components and the original squared-length denominator.
- The principal curl amplitude follows from the exact vector triple-product identity. The complete amplitude a=t+r is not asserted transverse; its exact divergence identity supplies the nonlinear wave gain.
- The wave error B+0.4 is distinguished from the mean covariance order C=B+1/2. The complete signed self-interaction and both angular/auxiliary means are retained.
- The temporal inverse zero-average subspace is distinguished from the radial full-obstruction projector.
- Every radial defect term is displayed, including the positive R^{-1}(2vu+u^2) term; the exact five-row cancellation is calculated.
- Logarithmic factors remain powers with stage-dependent degrees.
- The diagonal construction retains the cutoff curl term and compares the actual residual with one fixed finite stage. It never sums an infinite family of flat residuals.
- The exact exterior prefactor 2^A c_infty, centrifugal pressure, full half-line heat derivative bound, and endpoint derivative compatibility are calculated.

## Validation

The source text was read from output/navier_stokes_research_2026-09-08/lanes/web_bundle_audit/coordination/claimed_proof/openai_navier_stokes.txt, pp.100–116.

The exact_checks.py script contains 15 exact rational/symbolic calculations and seven separate structural probes. Stage-zero exponents and all margins use Fraction arithmetic. The full radial-source difference is independently checked symbolically with the signed azimuthal square term. Structural probes are not mathematical proofs. All pass.

Standalone pdflatex compilation succeeds (12 pages). The narrow default article layout reports overfull display boxes; the root reader owns integrated layout and visual QA.

## Boundary

This body proves the Section 9 composition of earlier maps and records its exact inputs in DEPENDENCIES.md. No new assumption replaces a correction calculation. Complete theorem status remains unclaimed pending the root cross-component and formal checks. No Lean process ran and no source project was edited.
