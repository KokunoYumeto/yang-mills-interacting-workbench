"""Exact finite algebra checks and separate structural TeX probes.

These computations supplement the written proofs. They do not verify analytic
existence, infinite-dimensional bounds, or the complete Navier--Stokes theorem.
"""
import json
import re
from fractions import Fraction as F
from pathlib import Path
import sympy as s

root = Path(__file__).resolve().parent
tex = (root / "stage9_body.tex").read_text(encoding="utf-8")
kappa = F(1, 100000)
gain = F(1, 10)
sigma0 = F(1, 5)
B0 = F(1, 2) + sigma0
C0 = B0 + F(1, 2)
H0cycle = C0 - 2 * kappa

# Each omitted j-dependence has slope 0, 1/10 or 2/10, all nonnegative,
# so evaluating the lower bounds at j=0 proves them for every integer j>=0.
step1 = [F(1,2)-3*kappa, F(1,2)-kappa, B0-kappa, F(2,5)]
step2 = [F(1,2)-4*kappa, F(2,5)-kappa, F(1,2)-2*kappa, B0-3*kappa]
margins = {
    "step1_wave_minimum": min(step1),
    "step2_wave_minimum": min(step2),
    "old_remainder_covariance_gain": F(18,100)-2*kappa,
    "self_covariance_gain_minimum": sigma0-3*kappa,
    "temporal_wave_gain": H0cycle-B0,
    "mean_cycle_gain": min(F(17,100), 1-4*kappa),
    "defect_cycle_gain": F(9,10)-4*kappa,
    "signed_increment_above_W_068": B0-kappa-F(68,100),
    "mean_increment_above_M_09": H0cycle-F(9,10),
    "radial_increment_above_M_19": H0cycle+1-F(19,10),
    "stage_j_increment_above_j_tenth": F(3,5)-kappa,
}
exact = {
    "stage_zero_exponents": B0 == F(7,10) and C0 == F(6,5),
    "cycle_wave_gain": min(step1+step2) > gain,
    "cycle_temporal_wave_gain": margins["temporal_wave_gain"] > gain,
    "cycle_mean_gain": margins["mean_cycle_gain"] > gain,
    "cycle_defect_gain": margins["defect_cycle_gain"] > gain,
    "average_covariance_slack": min(margins["old_remainder_covariance_gain"],
        margins["self_covariance_gain_minimum"]) > F(17,100),
    "retained_cumulative_class_slack": all(margins[n]>0 for n in (
        "signed_increment_above_W_068", "mean_increment_above_M_09",
        "radial_increment_above_M_19", "stage_j_increment_above_j_tenth")),
}
# Complete R_g term list at minimal H. All coefficient slopes in H are >=1.
H=H0cycle
Rg_exponents=[H+2,H+2-kappa,H+F(29,10)-kappa,2*H+2-kappa,
              H+2,H+2,H+F(29,10),H+F(29,10),2*H+2,
              H+F(9,10),2*H,H+2-2*kappa,H+2-kappa,H+4,H+2]
exact["all_radial_defect_terms"] = all(e>=H+F(9,10)-2*kappa for e in Rg_exponents)

n=s.Matrix(s.symbols("n1:4")); t=s.Matrix(s.symbols("t1:4"))
triple = n.cross(n.cross(t)) - (n*(n.dot(t)) - t*(n.dot(n)))
exact["full_covector_triple_product"] = all(s.expand(c)==0 for c in triple)

# Cylindrical div(curl A), with the retained 1/r terms and orientation.
r,theta,z=s.symbols("r theta z", positive=True)
Ar,At,Az=[s.Function(nm)(r,theta,z) for nm in ("Ar","At","Az")]
curl=s.Matrix([s.diff(Az,theta)/r-s.diff(At,z),
               s.diff(Ar,z)-s.diff(Az,r),
               s.diff(At,r)+At/r-s.diff(Ar,theta)/r])
divcurl=s.diff(curl[0],r)+curl[0]/r+s.diff(curl[1],theta)/r+s.diff(curl[2],z)
exact["cylindrical_div_curl"] = s.expand(divcurl)==0

# sigma=-r^{-e}I and I'=r^e(F-b M) gives the exact target divergence.
e=s.symbols("e", integer=True, positive=True)
I=s.Function("I")(r); f,b,M=s.symbols("F b M")
stress=-r**(-e)*I
stress_identity=(s.diff(stress,r)+e*stress/r).subs(s.diff(I,r),r**e*(f-b*M))
exact["weighted_stress_right_inverse"] = s.expand(stress_identity+f-b*M)==0

beta,Br,v,u,G,V,gamma,d,bbase=s.symbols("beta Br v u G V gamma d bbase")
exact["radial_square_increment"] = s.expand((bbase+beta+Br)**2-(bbase+beta)**2
    -(2*bbase*Br+2*beta*Br+Br**2))==0
exact["azimuthal_square_increment"] = s.expand((V+v+u)**2-(V+v)**2
    -(2*V*u+2*v*u+u**2))==0
exact["axial_radial_product_increment"] = s.expand(
    (bbase+beta+Br)*(G+gamma+d)-(bbase+beta)*(G+gamma)
    -(bbase*d+G*Br+beta*d+gamma*Br+Br*d))==0

# Independent full radial balance difference, including the positive
# azimuthal square term. Use slow-coordinate derivations t_*=-epsilon d/dT
# and D_z=epsilon d/dZ. This is an identity of differential polynomials.
T,epsilon=s.symbols("T epsilon")
bf,Vf,Gf,betaf,vf,gammaf,uf,df,Brf=[
    s.Function(nm)(r,z,T) for nm in
    ("b","V","G","beta","v","gamma","u","d","Br")]
def radial_flux(f):
    return s.diff(f,r)+f/r
def axial(f):
    return epsilon*s.diff(f,z)
def vector_radial_laplacian(f):
    return s.diff(f,r,2)+s.diff(f,r)/r+epsilon**2*s.diff(f,z,2)-f/r**2
def gr(beta_value,v_value,gamma_value):
    return (epsilon*s.diff(beta_value,T)
        -radial_flux(2*bf*beta_value+beta_value**2)
        -axial(bf*gamma_value+Gf*beta_value+beta_value*gamma_value)
        +(2*Vf*v_value+v_value**2)/r
        +epsilon*vector_radial_laplacian(beta_value))
actual_difference=gr(betaf+Brf,vf+uf,gammaf+df)-gr(betaf,vf,gammaf)
retained_remainder=(epsilon*s.diff(Brf,T)
    -radial_flux(2*bf*Brf+2*betaf*Brf+Brf**2)
    -axial(bf*df+Gf*Brf+betaf*df+gammaf*Brf+Brf*df)
    +(2*vf*uf+uf**2)/r+epsilon*vector_radial_laplacian(Brf))
exact["full_radial_defect_difference"] = s.expand(
    actual_difference-2*Vf*uf/r-retained_remainder)==0

# This group only detects accidental omissions/typesetting regressions.
structural = {
    "required_equation_markers": all(r"\tag{"+x+"}" in tex for x in
        ("9.1","9.2","9.3","9.12","9.13","9.14","9.16","9.17","9.18","9.20","9.21","9.23")),
    "no_bare_spacing_commands": re.search(r"(?<!\\)\b(?:qquad|quad)\b",tex) is None,
    "no_unit_covector_replacement": r"n_\Phi=\nabla_*\Phi/|\nabla_*\Phi|" not in tex,
    "no_false_full_transversality": r"a\cdot n_\Phi=0" not in tex,
    "logarithmic_factors_are_powers": r"(1+|\log q|)P_{j,m}" not in tex,
    "cutoff_curl_retained": r"\nabla q\times A_j" in tex,
    "single_stage_tail": r"g_{J+1}/2-L_{m+2}>N+K_{m+2}+2" in tex,
}
result={
    "scope":"Exact rational and symbolic finite calculations; structural probes are not mathematical proofs.",
    "parameters":{"kappa_s":str(kappa),"sigma_0":str(sigma0),"B_0":str(B0),"C_0":str(C0)},
    "exact_margins":{k:str(v) for k,v in margins.items()},
    "exact_calculations":exact,
    "structural_checks":structural,
    "all_pass":all(exact.values()) and all(structural.values()),
}
(root/"exact_checks.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
print(json.dumps(result,indent=2))
raise SystemExit(0 if result["all_pass"] else 1)
