# Independent mathematical review of the actual pulse correction

Review date: 9 September 2026. This public copy retains the complete mathematical review, all original and updated input hashes, and the final-source verification. Only private operational continuity paragraphs were omitted. The original independent review has SHA-256 `4a8be66b6bc40a370a670e891ce75d0ae5f30d5728d532fd79455505bdb67e7e`.

The requested formulas pass the direct algebraic and quantitative checks. In particular, the pressure coefficient is **positive** \(i/(km)\); the force–pressure map in (AS20) has the stated signs and a genuine two-sided inverse; the two-dimensional equation has a complete converse; and the constants in (AS28), (AS31)–(AS37), and (AS40) suffice as written. The two repairs identified in the initially inspected reconstruction are mathematically necessary and appear in the corrected source recorded in Section 11: actual production retains \(-(g-g_0)\cdot T\), and derivatives of the entire radial transport product retain a polynomial factor in \(S_*\). No additional error was found in the requested formulas. The proof below also gives the exact ambient matrix \(BB^\ell\), which makes the domain of its identity action explicit.

## 1. Inputs, hashes, and exact scope

The following SHA-256 hashes identify the bytes read. Hash letters are uppercase; case has no mathematical significance.

| Input, relative to the programme root unless explicitly stated | SHA-256 | Reading scope |
|---|---|---|
| `lanes/web_bundle_audit/actual_shear_energy_morphism.md` | `59D4D312A3960CA91878C9F0D743D9F91EF2F951584F503C863CBF1979AF4669` | Complete file, (AS1)–(AS40) |
| `research/global_analytic_closure_review/base_pulse/pulse_check.md` | `C535365CA94C6C4F6FB86290CFCE3D04E3F811FC7034934880EC4C2305B46393` | Complete file |
| Workspace `research/released_ns/oscillations/02_pulse_equation.md` | `CE8E503EA0AB17EE0732678E51E70DDFBA7D1D555D7881225BCB8B2BF78D644D` | Complete file |
| Workspace `research/released_ns/oscillations/01_auxiliary_geometry.md` | `C3304B492B9FC08F905DC7A09CE145D7CD06062DF4D3D718629B9F547B5ED0DF` | Exact affine pulse-coordinate and common-torus formulas, with surrounding derivations |

The programme root is the workspace directory output/navier_stokes_research_2026-09-08. Entries marked “Workspace” are relative to the workspace root; all other source entries are relative to the programme root.

This is a direct review of the local finite-dimensional identities and of the precise inequalities built from the constructed phase/background estimates. The underlying Borel construction and the complete infinite Navier–Stokes realization are outside this assigned review. They are not established by the word “passes” above. No assertion that another audit passed was used as proof of a sign, inverse, coordinate identity, or threshold here. The phase bounds, background bounds, and compact positive constants are identified where used; every consequence claimed here is calculated below. There are no deferred proof obligations in this review.

## 2. Original objects and retained shear difference

Keep the original label fixed under differentiation, with
\[
0<h<1/100,\quad A=1/2+h,\quad D=1/2-h,\quad Q=2^{-\ell},
\quad\varepsilon=Q^h,\quad S_*=\ell^2,
\quad R=r/\sqrt Q,\quad Z=z/Q^D,\quad T=(1-t)/Q.
\tag{R1}
\]
The fixed enlarged chart annulus has \(R\ge R_->0\), and \(p_0=(R_0,Z_0,T_0)\) is the fixed representative. The exact leading fields in the input are
\[
V^{(0)}=s_Q^{-A}E_0(X,\eta),\quad
G^{(0)}=s_Q^{-A}U_0(X,\eta),\quad
s_Q=q/Q,\quad X=R^2/(2s_Q),\quad
Z=s_Q^D\eta,\quad T=s_Q(1-\eta^2).
\tag{R2}
\]
The actual fields are retained as \(V=V^{(0)}+\delta V\) and \(G=G^{(0)}+\delta G\). Define
\[
F=V/R,\quad F^{(0)}=V^{(0)}/R,\quad F_0=F^{(0)}(p_0),
\quad g=(RF_R,G_R),\quad g^{(0)}=(RF_R^{(0)},G_R^{(0)}),
\quad g_0=g^{(0)}(p_0).
\tag{R3}
\]
Then, by differentiating the actual quotient \(V/R\),
\[
g-g^{(0)}=(\partial_R\delta V-\delta V/R,\partial_R\delta G),
\quad\Delta g:=g-g_0=(g-g^{(0)})+g^{(0)}(p)-g^{(0)}(p_0).
\tag{R4}
\]
In particular \(\Delta g(p_0)=g(p_0)-g^{(0)}(p_0)\); fixing a representative does not set this Borel difference to zero.

The given Borel estimates have constants \(C_{V,I},C_{G,I}\ge0\) such that
\[
|\partial^I\delta V|\le C_{V,I}\varepsilon^2,
\qquad |\partial^I\delta G|\le C_{G,I}\varepsilon^2.
\tag{R5}
\]
For \(I=(i_R,i_Z,i_T)\), the derivative identity
\[
\partial_R^j(R^{-1})=(-1)^j j!R^{-j-1}
\]
and the full product rule give
\[
\partial^I(g-g^{(0)})_\theta
=\partial^{I+e_R}\delta V-
\sum_{j=0}^{i_R}\binom{i_R}{j}(-1)^j j!R^{-j-1}
\partial^{I-je_R}\delta V,
\quad
\partial^I(g-g^{(0)})_z=\partial^{I+e_R}\delta G.
\tag{R6}
\]
Thus (AS8) bounds each entry exactly as stated. At order zero this gives
\[
C_B=\left[(C_{V,e_R}+R_-^{-1}C_{V,0})^2+C_{G,e_R}^2\right]^{1/2},
\qquad |g-g^{(0)}|\le C_B\varepsilon^2.
\tag{R7}
\]
Along the stipulated segment from \(p_0\) to \(p\), the fundamental theorem of calculus gives
\[
g^{(0)}(p)-g^{(0)}(p_0)
=\int_0^1D_pg^{(0)}(p_0+u(p-p_0))(p-p_0)\,du.
\]
Consequently \(\|D_pg^{(0)}\|\le L_g\) and \(|p-p_0|\le C_{\rm box}S_*^{-3}\) give
\[
|\Delta g|\le C_B2^{-2h\ell}+L_gC_{\rm box}\ell^{-6}.
\tag{R8}
\]
Positive-order derivatives of \(g^{(0)}(p)-g^{(0)}(p_0)\) are the actual derivatives of \(g^{(0)}(p)\); no \(O(\varepsilon^2)\) bound for those derivatives follows from (R8).

For completeness, the retained four-coordinate jet map in (AS11) is also exact. Writing \(j=(v,v_R,w,w_R)\), its full coordinate map is
\[
\mathcal J_Rj=(v_R-v/R,w_R,v,w),\qquad
\mathcal J_R^{-1}(a,b,v,w)=(v,a+v/R,w,b).
\tag{R9}
\]
Their two compositions are identities by substitution in each of the four entries. The shear map alone has kernel \(\{(v,v/R,w,0):v,w\in\mathbb C\}\) and right inverse \((a,b)\mapsto(0,a,0,b)\). Thus the two extra jet coordinates have been retained in a genuine bijection.

## 3. Full constrained equation and pressure elimination in both directions

All vectors below are in coordinate order \((r,\theta,z)\); two-component tangent vectors are embedded with radial entry zero. Let \(v\) range over the original pulse interval. Its actual normal \(n(v)\in\mathbb R^3\setminus\{0\}\) is \(C^1\), and \(n'=\partial_vn\). For complex amplitudes the constraint is the complex-linear condition \(n^Tt=0\). Since \(n\) is real, \(n^Tn=|n|^2>0\). Retain the original \(k=\lceil\varepsilon^{-1/2}\rceil\ge1\), \(m\in\mathbb Z\setminus\{0\}\), and
\[
d=\varepsilon k^2|n|^2,
\quad\mathcal K=
\begin{pmatrix}0&-2F&0\\2F+g_\theta&0&0\\g_z&0&0\end{pmatrix},
\quad\Pi_n=I-\frac{nn^T}{|n|^2}.
\tag{R10}
\]
The full equation and its constraint are
\[
t'+\mathcal Kt+m^2dt+ikm n\pi=-f,\qquad n^Tt=0.
\tag{R11}
\]
Here \(t\) is \(C^1\), and \(f,\pi\) are continuous, as are the coefficients; the original smooth data have this regularity.

Differentiating the constraint gives \(n^Tt'=-n'^Tt\). Multiplication of (R11) by \(n^T\) therefore yields
\[
ikm|n|^2\pi=-n^T\mathcal Kt+n'^Tt-n^Tf.
\]
Since \(1/i=-i\), solving this equation gives the unique pressure
\[
\boxed{\pi=\frac{i}{km}\frac{n^T\mathcal Kt-n'^Tt+n^Tf}{|n|^2}.}
\tag{R12}
\]
Multiplying (R12) by \(ikmn\) gives
\[
ikmn\pi=-\frac{n(n^T\mathcal Kt-n'^Tt+n^Tf)}{|n|^2}.
\tag{R13}
\]
Substitution in (R11), with each forcing component kept, gives
\[
t'=\mathcal At-m^2dt-\Pi_nf,
\quad\mathcal A=-\mathcal K+
\frac{n(n^T\mathcal K-n'^T)}{|n|^2}.
\tag{R14}
\]
This proves the full-to-projected implication and the pressure sign.

For the converse, direct left multiplication gives
\[
n^T\mathcal A=-n'^T,\qquad n^T\Pi_n=0.
\tag{R15}
\]
For any solution of (R14), its scalar normal component \(c(v)=n(v)^Tt(v)\) therefore satisfies
\[
c'=n'^Tt+n^Tt'=-m^2dc.
\tag{R16}
\]
For an initial time \(v_0\), differentiating
\(c(v)\exp(m^2\int_{v_0}^vd(u)\,du)\) shows it is constant. Hence
\[
c(v)=c(v_0)\exp\!\left(-m^2\int_{v_0}^vd(u)\,du\right).
\tag{R17}
\]
An initially zero constraint persists exactly. Define \(\pi\) by (R12). Adding \(\mathcal Kt+m^2dt\) to (R14), and then adding (R13), cancels the two normal matrix terms and leaves
\[
-\Pi_nf-\frac{nn^Tf}{|n|^2}=-f.
\]
This proves (R11), including normal forcing. Thus constrained solutions of the full equation correspond bijectively to solutions of the projected equation with constrained initial data, with the unique pressure reconstructed by (R12). Without constrained initial data, (R17) describes a nonzero normal component; it is not legitimate to identify that larger projected solution space with the constrained one.

## 4. Exact actual-plane coordinates, ambient projection, and two-dimensional converse

Write \(q_n=|n_{\tan}|>0\), retaining the actual frame
\[
K_a=n_{\tan}/q_n,\quad N_a=((K_a)_z,-(K_a)_\theta),
\quad s_a=n_r/q_n.
\tag{R18}
\]
Thus \(n=q_n(s_ae_r+K_a)\). The real vectors \(e_r,K_a,N_a\) are an orthonormal basis of the ambient three-space. The orientation is the one in the source: if \(K=(-N_z,N_\theta)\), then \((K_z,-K_\theta)=N\).

Set \(\gamma_0=c_0\sqrt{1+s^2}\ne0\), and write
\[
U=[e_r-s_aK_a,N_a],\quad
C=\begin{pmatrix}e_r^T\\N_a^T\end{pmatrix},\quad
M=\begin{pmatrix}1&1\\\gamma_0&-\gamma_0\end{pmatrix},
\quad B=UM,\quad B^\ell=M^{-1}C.
\tag{R19}
\]
Both columns of \(U\) are perpendicular to \(n\): their dot products are respectively \(q_n(s_a-s_a)=0\) and \(q_nK_a^TN_a=0\). Direct multiplication gives
\[
CU=I_2,\quad\det M=-2\gamma_0,\quad
M^{-1}=\begin{pmatrix}1/2&1/(2\gamma_0)\\1/2&-1/(2\gamma_0)\end{pmatrix}.
\tag{R20}
\]
For any \(w=ae_r+bK_a+cN_a\in\mathbb C^3\), the condition \(n^Tw=0\) is \(s_aa+b=0\), and in that case \(w=a(e_r-s_aK_a)+cN_a=UCw\). It follows that \(U:\mathbb C^2\to n^\perp\) and \(B:\mathbb C^2\to n^\perp\) are surjective, as well as injective by (R20). The exact inverse on that codomain is \(B^\ell|_{n^\perp}\), because
\[
B^\ell B=M^{-1}CUM=I_2,
\qquad BB^\ell w=U Cw=w\quad(w\in n^\perp).
\tag{R21}
\]

On the full ambient space, however, multiplication gives the following exact matrix:
\[
\boxed{BB^\ell=UC=I-\frac{K_an^T}{q_n}.}
\tag{R22}
\]
Indeed \(UCw=ae_r-s_aaK_a+cN_a\), whereas
\(w-UCw=(b+s_aa)K_a=K_an^Tw/q_n\). Equation (R22) is idempotent since \(n^TK_a=q_n\). Its image is \(n^\perp\) and its kernel is \(\operatorname{span}_{\mathbb C}\{K_a\}\). It acts as identity on \(w\) **if and only if** \(n^Tw=0\). For example \(BB^\ell K_a=0\), although \(K_a\ne0\). Thus \(BB^\ell\ne I_3\), including when \(s_a=0\).

Its precise relation to the orthogonal projector in (R10) is
\[
(BB^\ell)\Pi_n=\Pi_n,\qquad
\Pi_n(BB^\ell)=BB^\ell,
\quad
BB^\ell-\Pi_n=\left(\frac n{|n|^2}-\frac{K_a}{q_n}\right)n^T.
\tag{R23}
\]
The first two identities follow because the images of both matrices are the same plane and each is identity there; the final identity follows by subtracting their displayed formulas. They coincide as ambient projectors exactly when \(s_a=0\): the radial component of \(n/|n|^2-K_a/q_n\) is \(s_a/[q_n(1+s_a^2)]\), and when \(s_a=0\) both vectors are \(K_a/q_n\).

The exact coordinate equation is
\[
z'=\left[B^\ell(\mathcal AB-B')-m^2dI_2\right]z-B^\ell\Pi_nf.
\tag{R24}
\]
If \(t\) solves the constrained projected equation, then \(z=B^\ell t\) and \(t=Bz\). Differentiating the latter equality gives \(t'=B'z+Bz'\). Substitution in (R14), followed by \(B^\ell B=I_2\), proves (R24). This forward calculation does not discard the derivative of a moving frame.

Conversely, let \(z\) solve (R24), and put \(t=Bz\). Its constraint holds identically because \(n^TB=0\). Differentiating this matrix identity gives
\[
n^TB'=-n'^TB.
\]
Equation (R15) gives \(n^T\mathcal AB=-n'^TB\); subtracting proves
\[
n^T(\mathcal AB-B')=0.
\tag{R25}
\]
Thus every column of \(\mathcal AB-B'\) lies in \(n^\perp\), as do \(Bz\) and \(\Pi_nf\). Multiplying (R24) by \(B\) and applying (R21) on precisely these vectors gives
\[
Bz'=(\mathcal AB-B')z-m^2dBz-\Pi_nf.
\]
Adding \(B'z\) proves \(t'=\mathcal At-m^2dt-\Pi_nf\). The full equation and unique pressure now follow from Section 3. The two transformations \(t\mapsto B^\ell t\) and \(z\mapsto Bz\) have both inverse compositions on the stated solution spaces. This is the full two-dimensional converse, with no use of an ambient right-inverse identity.

## 5. Reference growing direction and actual homogeneous polarization

Retain \(F_0>0\), \(g_0=|g_0|N\), \(K=(-N_z,N_\theta)\), and the source's \(a>0\), \(t_s=-b_s/a\), \(v_s=a(1+t_s^2)>2\). The original formulas give
\[
N=-\frac{(1,t_s)}{\sqrt{1+t_s^2}},\quad
|g_0|=aF_0\sqrt{1+t_s^2},\quad
\lambda_0^2=-2F_0N_\theta(2F_0N_\theta+|g_0|)
=2aF_0^2(1-2/v_s)>0.
\tag{R26}
\]
With the positive root \(\lambda_0\),
\[
c_0=\lambda_0/(2F_0N_\theta)<0,
\qquad c_0^2=(v_s-2)/2.
\tag{R27}
\]
These signs follow from \(N_\theta=-1/\sqrt{1+t_s^2}<0\).

For \(e=e_r-sK\), direct multiplication of the retained cylindrical matrix \(\mathcal K_0\) gives
\[
e^T(-\mathcal K_0e)=sK\cdot g_0=0,\quad
e^T(-\mathcal K_0N)=2F_0N_\theta,
\]
\[
N^T(-\mathcal K_0e)=-(2F_0N_\theta+|g_0|),\quad
N^T(-\mathcal K_0N)=0.
\]
The orthogonal reference-plane basis has squared lengths \(1+s^2\) and \(1\). Therefore the reference projected matrix in that basis is
\[
\mathcal D=
\begin{pmatrix}0&2F_0N_\theta/(1+s^2)\\-(2F_0N_\theta+|g_0|)&0\end{pmatrix}.
\tag{R28}
\]
Multiplication by \((1,\gamma_0)^T\) gives first entry \(\lambda_0/\sqrt{1+s^2}\) and second entry
\(-[2F_0N_\theta+|g_0|]=\lambda_0^2/(2F_0N_\theta)\), which is \((\lambda_0/\sqrt{1+s^2})\gamma_0\). Multiplication by \((1,-\gamma_0)^T\) gives the negative eigenvalue. Thus the columns of \(M\) have the growing and decaying orientations claimed in the source.

The actual coordinate equation retains the actual \(B\) and its derivative and writes
\[
B^\ell(\mathcal AB-B')=\operatorname{diag}(\lambda,-\lambda)+E,
\quad\lambda=\lambda_0/\sqrt{1+s^2},\quad
|E_{ij}|\le C_E/S_*,\quad|d-d_{\rm ref}|\le C_d/S_*.
\tag{R29}
\]
These are the phase/frame coefficient bounds constructed in the inputs, with \(\lambda\ge\lambda_->0\) and \(L_s\le C_LS_*\). Their local polarization consequence can be checked without replacing the actual equation by its reference equation. Let \(P>0\) be the source envelope with \(P'=(\lambda-d_{\rm ref})P\), and use the actual homogeneous initial data \(z_+(0)=P(0)>0,z_-(0)=0\).

While \(z_+>0\), quotient differentiation gives the exact equation
\[
r'=E_{21}+(-2\lambda+E_{22}-E_{11})r-E_{12}r^2,
\qquad r=z_-/z_+.
\tag{R30}
\]
One explicit invariant-band choice is \(K_b=\max\{1,2C_E/\lambda_-\}\) followed by \(S_*\ge2K_b\). At either endpoint \(r=\pm K_b/S_*\), its outward derivative is at most
\[
\frac{-2\lambda_-K_b+C_E+2C_EK_b/S_*+C_EK_b^2/S_*^2}{S_*}
\le\frac{-2\lambda_-K_b+(9/4)C_E}{S_*}<0.
\tag{R31}
\]
For \(C_E>0\) the last numerator is at most \(-7C_E/4\); for \(C_E=0\) it is \(-2\lambda_-K_b<0\). A first exit would have nonnegative outward derivative, contradicting (R31). Thus the band persists up to any putative first zero of \(z_+\).

Inside the band,
\[
\left(\log\frac{z_+}{P}\right)'=-(d-d_{\rm ref})+E_{11}+E_{12}r,
\quad
\left|\left(\log\frac{z_+}{P}\right)'\right|
\le\frac{C_d+(3/2)C_E}{S_*}.
\]
Writing \(a_x=\exp[-C_L(C_d+(3/2)C_E)]>0\), integration from the actual initial value gives
\[
a_xP\le z_+\le a_x^{-1}P.
\tag{R32}
\]
On the finite interval \(P\) is strictly positive. Continuity of \(z_+\) therefore rules out that putative zero. The band and (R32) hold on the full interval.

Since \(t=Bz=U Mz\), its actual \(U\)-coordinates are exactly
\[
x=z_++z_-=z_+(1+r),\quad
y=\gamma_0(z_+-z_-)=\gamma_0z_+(1-r).
\tag{R33}
\]
The band gives \(c_xP\le x\le C_xP\) with the explicit choices \(c_x=a_x/2\) and \(C_x=3/(2a_x)\). It also gives
\[
\frac yx-\gamma_0=-\frac{2\gamma_0r}{1+r},\qquad
\left|\frac yx-\gamma_0\right|\le\frac{4\Gamma_{\max}K_b}{S_*}
\tag{R34}
\]
when \(|\gamma_0|\le\Gamma_{\max}\). Thus (AS30)'s actual polarization estimate is the output of the actual homogeneous ODE. One may take \(E_\gamma=4\Gamma_{\max}K_b\), or retain any valid source constant. The equation includes the damping throughout this argument.

## 6. Force–pressure bijection with the same actual phase

Let \(\mathcal K_0=\mathcal K(F_0,g_0)\), and keep the same \(n,n',d,k,m\) on both sides. Set \(\Delta F=F-F_0\). Then direct subtraction gives
\[
\Delta\mathcal K=\mathcal K-\mathcal K_0=
\begin{pmatrix}0&-2\Delta F&0\\2\Delta F+\Delta g_\theta&0&0\\\Delta g_z&0&0\end{pmatrix}.
\tag{R35}
\]
In particular no matrix entry involving \(\Delta F\) is omitted. Subtracting (R14)'s operator formulas gives
\[
\mathcal A-\mathcal A_0=-\Delta\mathcal K+
\frac{nn^T\Delta\mathcal K}{|n|^2}=-\Pi_n\Delta\mathcal K.
\tag{R36}
\]
The \(n'\) terms cancel because their actual normal is identical.

On the full constrained solution-data triples define
\[
t_0=t,\quad f_0=f+\Pi_n\Delta\mathcal Kt,\quad
\pi_0=\pi-\frac{i}{km}\frac{n^T\Delta\mathcal Kt}{|n|^2}.
\tag{R37}
\]
Multiplication of the pressure increment by \(ikmn\) gives
\(+n(n^T\Delta\mathcal Kt)/|n|^2\). Therefore
\[
t_0'+\mathcal K_0t_0+m^2dt_0+ikmn\pi_0
=-f-\Delta\mathcal Kt+\frac{nn^T\Delta\mathcal Kt}{|n|^2}
=-f_0.
\tag{R38}
\]
The constraint remains \(n^Tt_0=0\). Conversely put
\[
t=t_0,\quad f=f_0-\Pi_n\Delta\mathcal Kt_0,\quad
\pi=\pi_0+\frac{i}{km}\frac{n^T\Delta\mathcal Kt_0}{|n|^2}.
\tag{R39}
\]
Its pressure increment contributes \(-nn^T\Delta\mathcal Kt_0/|n|^2\), so the actual left-hand side equals
\(-f_0+\Delta\mathcal Kt_0-nn^T\Delta\mathcal Kt_0/|n|^2=-f\). Both compositions recover \(t,f,\pi\) entry by entry, because \(t\) is unchanged and the other increments have opposite signs. All denominators are already nonzero. This proves (AS20)–(AS22) as a bijection of the complete constrained solution-data spaces. If \(f=0\), then \(f_0=\Pi_n\Delta\mathcal Kt\); the map does not claim that a homogeneous actual pulse is a homogeneous frozen-background pulse.

## 7. Actual energy identity and the prescribed-cone threshold (AS28)

Now take the source's real homogeneous pulse, \(m=1,f=0\), and define \(T=t_r(t_\theta,t_z)\in\mathbb R^2\). Direct matrix multiplication retains both cylindrical terms:
\[
t^T\mathcal Kt
=-2Ft_rt_\theta+(2F+g_\theta)t_rt_\theta+g_zt_rt_z
=g\cdot T.
\tag{R40}
\]
The normal term of \(\mathcal At\) is perpendicular to \(t\). Taking the dot product of (R14) with \(t\) gives exactly
\[
\frac12\partial_v|t|^2=-g\cdot T-d|t|^2.
\tag{R41}
\]
The coordinate called \(T\) in (R1) remains the original slow coordinate; in (R40)–(R41), as in the source, \(T=t_r(t_\theta,t_z)\) denotes the stress vector. No derivative with respect to the slow \(T\) is taken in these equations.

Since \(g_0=|g_0|N\), writing the stress \(T=T_NN+T_KK\) yields
\[
\boxed{-g\cdot T=-|g_0|T_N-\Delta g\cdot T.}
\tag{R42}
\]
The same multiplication applied to (R35) gives \(t^T\Delta\mathcal Kt=\Delta g\cdot T\): the \(2\Delta F\) terms cancel in this scalar expression, although they remain in the force map.

The compact prescribed stress cone gives \(-T_N\ge c_T|T|\), with \(c_T>0\), and \(|g_0|\ge g_->0\). Thus the Cauchy–Schwarz inequality and (R8) give
\[
-g\cdot T\ge
\left[g_-c_T-C_B2^{-2h\ell}-L_gC_{\rm box}\ell^{-6}\right]|T|.
\tag{R43}
\]
No division by \(|T|\) occurred, so this also holds at \(T=0\).

Let \(A_T=g_-c_T>0\). For the exact integer threshold in (AS28),
\[
\ell\ge\left\lceil\max\left\{
1,\left(\frac{4L_gC_{\rm box}}{A_T}\right)^{1/6},
\frac{\log\max\{1,4C_B/A_T\}}{2h\log2}
\right\}\right\rceil,
\tag{R44}
\]
the power bound gives \(L_gC_{\rm box}\ell^{-6}\le A_T/4\). For the other term, if \(4C_B/A_T\le1\), then \(C_B2^{-2h\ell}\le C_B\le A_T/4\). If \(4C_B/A_T>1\), multiplying the logarithmic bound by \(2h\log2>0\) and exponentiating gives \(2^{-2h\ell}\le A_T/(4C_B)\). Hence this term is again at most \(A_T/4\). This argument includes \(C_B=0\) and \(L_gC_{\rm box}=0\), with no logarithm of zero. Substitution in (R43) proves
\[
-g\cdot T\ge\tfrac12g_-c_T|T|.
\tag{R45}
\]
This additional finite threshold is taken together with the source thresholds. It does not replace them, and its dependence on the originally fixed \(h>0\) is retained.

## 8. Actual-frame estimates and exact constants in (AS31)–(AS37)

The constructed actual phase estimate used here is
\[
|n-B_s(se_r+K)|\le E_n/S_*,\qquad B_s\ge B_->0,
\quad s(v)=\sigma(u_*/2+u_*v/L_s),\quad |s|\le s_{\max}=3u_*/2.
\tag{R46}
\]
Assume the selected finite source threshold has also been enlarged to \(S_*\ge2E_n/B_-\); if \(E_n=0\), the conclusion follows directly. Reverse triangle inequality gives
\(q_n=|n_{\tan}|\ge B_s-E_n/S_*\ge B_-/2\).

For nonzero vectors \(a,b\), addition and subtraction of \(a/|b|\), followed by reverse triangle inequality, gives
\[
\left|\frac a{|a|}-\frac b{|b|}\right|
\le |a|\left|\frac1{|a|}-\frac1{|b|}\right|+\frac{|a-b|}{|b|}
=\frac{\bigl||b|-|a|\bigr|+|a-b|}{|b|}
\le\frac{2|a-b|}{|b|}.
\tag{R47}
\]
Apply this to \(a=n_{\tan}\), \(b=B_sK\). The quarter-turn sending \(K_a\mapsto N_a\), \(K\mapsto N\) is an isometry, so
\[
|K_a-K|=|N_a-N|\le\frac{2E_n}{B_-S_*}.
\tag{R48}
\]
Also
\[
s_a-s=\frac{n_r-sq_n}{q_n}
=\frac{(n_r-B_ss)+s(B_s-q_n)}{q_n},
\]
where each normal-component error and tangential norm error is at most \(E_n/S_*\). This proves
\[
|s_a-s|\le\frac{2(1+s_{\max})E_n}{B_-S_*}.
\tag{R49}
\]
These are precisely (AS31), with the same actual frame and no rotation of the original coordinates.

Let \(0<c_-\le|c_0|\le c_+\), and define
\[
\Gamma_{\max}=c_+\sqrt{1+s_{\max}^2},\qquad
C_T=\frac{2E_n}{B_-}(1+2s_{\max}+\Gamma_{\max})+E_\gamma.
\tag{R50}
\]
The actual radial component is \(t_r=x\), and \(t_{\tan}=-s_axK_a+yN_a\). Since \(x\ge c_xP>0\),
\[
T=x^2\left(-s_aK_a+\frac yxN_a\right)
=x^2(-sK+\gamma_0N+e_T),
\tag{R51}
\]
with exact error
\[
e_T=-(s_a-s)K_a-s(K_a-K)
       +(y/x-\gamma_0)N_a+\gamma_0(N_a-N).
\tag{R52}
\]
Its four summands have bounds, in their written order,
\[
\frac{2(1+s_{\max})E_n}{B_-S_*},\quad
\frac{2s_{\max}E_n}{B_-S_*},\quad
\frac{E_\gamma}{S_*},\quad
\frac{2\Gamma_{\max}E_n}{B_-S_*}.
\]
Their sum is \(C_T/S_*\). This verifies every coefficient in (AS32)–(AS33), including the second \(s_{\max}\) contribution.

Since \(N\cdot K=0\), \(|N|=1\), and \(g=g_0+\Delta g\), equation (R51) gives the exact identity
\[
\frac{-g\cdot T}{x^2}
=-|g_0|\gamma_0-g_0\cdot e_T
-\Delta g\cdot(-sK+\gamma_0N+e_T).
\tag{R53}
\]
For \(|g_0|\le g_+\), the absolute value of the last two terms is at most
\[
\mathcal E_\ell=g_+C_T\ell^{-2}
 +(C_B2^{-2h\ell}+L_gC_{\rm box}\ell^{-6})
 (s_{\max}+\Gamma_{\max}+C_T\ell^{-2}).
\tag{R54}
\]
All constants in this expression are nonnegative and independent of \(\ell\) after fixing the source parameters. Every factor is nonincreasing for \(\ell\ge1\); all additive terms tend to zero. No derivative smallness is used.

Put \(A_P=g_-c_->0\) and \(W=s_{\max}+\Gamma_{\max}+C_T>0\). For \(\ell\ge1\), the final factor in (R54) is at most \(W\). The exact threshold (AS36) is
\[
\ell\ge\left\lceil\max\left\{
1,\left(\frac{4g_+C_T}{A_P}\right)^{1/2},
\left(\frac{8WL_gC_{\rm box}}{A_P}\right)^{1/6},
\frac{\log\max\{1,8WC_B/A_P\}}{2h\log2}
\right\}\right\rceil.
\tag{R55}
\]
The square-root threshold bounds the first error by \(A_P/4\), the sixth-root threshold bounds the \(WL_gC_{\rm box}\ell^{-6}\) term by \(A_P/8\), and the logarithmic threshold bounds \(WC_B2^{-2h\ell}\) by \(A_P/8\). The two cases for that logarithm are exactly the two cases proved for (R44), with \(4C_B/A_T\) replaced by \(8WC_B/A_P\). Therefore \(\mathcal E_\ell\le A_P/2\).

The leading coefficient in (R53) lies between \(A_P\) and \(g_+\Gamma_{\max}\), because
\(-\gamma_0=|c_0|\sqrt{1+s^2}\ge c_->0\). Thus
\[
\frac{A_P}{2}\le\frac{-g\cdot T}{x^2}
\le g_+\Gamma_{\max}+\frac{A_P}{2}.
\]
Both endpoints are positive. Applying \(c_xP\le x\le C_xP\) proves exactly
\[
\boxed{\frac12g_-c_-c_x^2P(v)^2\le-g\cdot T
\le\left(g_+\Gamma_{\max}+\frac12g_-c_-\right)C_x^2P(v)^2.}
\tag{R56}
\]
This is (AS37), including its upper constant. It proves production for the actual homogeneous pulse, without presupposing that this pulse lies in the prescribed stress cone used in Section 7. That independence of the two routes follows from the explicit actual polarization (R51)–(R53).

Finally the actual orthonormal frame gives, without an error term,
\[
|t|^2=x^2+|-s_axK_a+yN_a|^2=(1+s_a^2)x^2+y^2.
\tag{R57}
\]
Neither (R56) nor (R57) removes the damping term in (R41), so neither asserts positive \(\partial_v|t|^2\) throughout the interval.

## 9. Exact coefficient product rule and derivative correction (AS40)

Retain the full actual phase data
\[
H_\Phi=pF+p_zG,\quad
n_{\Phi,r}=x_0-v\partial_RH_\Phi,
\quad
E_{\rm ik}=\varepsilon v(\partial_TH_\Phi-G\partial_ZH_\Phi)+bn_{\Phi,r}.
\tag{R58}
\]
The constants \(p,p_z,x_0\), the representative, and the label are fixed. Here \(D^I\) denotes ordinary coefficient derivatives in \((R,Z,T,H_1,H_2)\). The auxiliary geometry states \(v=(\eta_g+r_0)/c_i\), with label-fixed \(c_i\), and the common-torus pullback depends only on the auxiliary coordinates. In those coordinates
\[
D_Hv=T_g^\Delta\lambda_t/c_i,\quad D_HH_w=I-v_t\lambda_t,
\tag{R59}
\]
and higher derivatives of these affine maps vanish. In particular \(\partial_Rv=\partial_Zv=\partial_Tv=0\). Consequently the illustrative radial derivative in (AS40) is exact in the declared convention:
\[
\partial_Rn_{\Phi,r}=-v\partial_R^2H_\Phi.
\tag{R60}
\]
The coefficient \(v\) ranges over an interval of length \(L_s=O(S_*)\); it is not a label constant that can be dropped from this product. Auxiliary derivatives of \(v\) in (R59) are also \(O(S_*)\).

For a multi-index \(I\in\mathbb N^5\), write \(J\le I\) componentwise and \(\binom IJ=\prod_{a=1}^5\binom{I_a}{J_a}\). Repeated use of the one-derivative product rule yields the exact finite identity
\[
D^I(bn_{\Phi,r})=\sum_{J\le I}\binom IJ(D^Jb)(D^{I-J}n_{\Phi,r}).
\tag{R61}
\]
One can prove it by induction on \(|I|\): differentiating the sum in a coordinate produces terms differentiating its first and second factor, and Pascal's identity combines their coefficients into those for \(I+e_a\). This also establishes that no derivative allocation is omitted.

Use the actual source coefficient estimates
\[
|D^Jb|\le C_{b,J}\varepsilon,\qquad
|D^Jn_{\Phi,r}|\le C_{n,J}S_*^{d_J}.
\tag{R62}
\]
Triangle inequality in (R61) gives exactly
\[
|D^I(bn_{\Phi,r})|
\le\varepsilon\sum_{J\le I}\binom IJ C_{b,J}C_{n,I-J}S_*^{d_{I-J}}.
\tag{R63}
\]
For fixed \(I\), let \(d_I^*=\max_{J\le I}d_{I-J}\). Since the sum is finite and \(S_*\ge1\),
\[
|D^I(bn_{\Phi,r})|
\le\varepsilon S_*^{d_I^*}\sum_{J\le I}\binom IJ C_{b,J}C_{n,I-J}.
\tag{R64}
\]
Equations (R61)–(R64) prove (AS40). They do not yield a derivative-free \(C_I\varepsilon\) estimate for the whole product when the phase derivative factors carry polynomial powers. The value bound for \(b\) and all its derivatives controls only the \(b\) factor; (R60) identifies an actual phase derivative factor that must also be retained.

For explicit coverage of the other term in (R58), label fixing makes \(\varepsilon\) constant under \(D\), so
\[
D^I\!\left[\varepsilon v(\partial_TH_\Phi-G\partial_ZH_\Phi)\right]
=\varepsilon\sum_{J\le I}\binom IJ(D^Jv)
 D^{I-J}(\partial_TH_\Phi-G\partial_ZH_\Phi),
\tag{R65}
\]
and, for every \(L\le I\),
\[
D^L(G\partial_ZH_\Phi)
=\sum_{K\le L}\binom LK(D^KG)(D^{L-K}\partial_ZH_\Phi).
\tag{R66}
\]
Every term in these finite sums has one retained \(\varepsilon\) factor and products of the source's bounded or polynomially bounded coefficient derivatives; \(D^Jv=0\) for \(|J|\ge2\). Taking the maximum of the finitely many sums of polynomial degrees and summing the finitely many product constants proves a bound \(C_I\varepsilon S_*^{b_I}\) for (R65). Combining with (R64) proves the stated \(C_I\varepsilon S_*^{b'_I}\) bound for the full \(D^IE_{\rm ik}\), with a finite exponent for every fixed \(I\). No extra smallness assumption on a higher derivative is required.

## 10. Findings and local continuity record

The complete plane, pressure, and force–pressure calculations above introduce no correction to (AS16)–(AS22) or to the base pulse audit's stated converse. Formula (R22) provides the exact ambient projection behind that converse. The production constants and the actual polarization calculations in (AS28), (AS31)–(AS37) are valid as written, with all source and denominator thresholds retained. The derivative correction (AS40) is valid in the source's coefficient-derivative convention, which was checked against the affine auxiliary coordinate.

The initially inspected reconstruction bytes identified above contained the frozen-only production sentence and the narrow statement about derivatives of the entire \(b\)-term. Their exact replacements are (R42) with (R43) or (R56), and (R61)–(R64) with (R65)–(R66), respectively. No source file was edited by this reviewer. Propagation belongs to the parent task and the canonical-source owner.

## 11. Final-state verification after concurrent source propagation

At the closing check, 2026-09-09 00:20:35 +02:00, the parent and source owner had updated two of the inputs. The initial hashes in Section 1 remain the provenance for the first read. The following additional hashes identify the later files, both of which were read in full after their updates:

| Updated input | SHA-256 |
|---|---|
| Programme lanes/web_bundle_audit/actual_shear_energy_morphism.md | C890D02FEE1E06DB6767301BEC0FC0509DB19DF4F6148A1A6F62CE2A27C89315 |
| Workspace research/released_ns/oscillations/02_pulse_equation.md | D4D5D37041EC829A45D28B350F14C4A0793393095F9ACBD2B09642228A88C2EC |

The updated shear note adds the exact historical manuscript-capture provenance; its requested (AS1)–(AS40) formulas retain the algebra verified above. This reviewer did not inspect that PDF and makes no additional source-page verification claim.

The updated pulse reconstruction includes the full ambient projection formula, the complete moving-plane converse, the product-rule derivative correction, and both actual-shear production estimates. Its actual-pulse threshold also writes the frame-denominator requirement explicitly as the additional maximum entry \((2E_n/B_-)^{1/2}\). Since \(S_*=\ell^2\) and \(\ell\ge0\), that entry is exactly the requirement \(S_*\ge2E_n/B_-\) already retained in Section 8. The remaining entries and error allocations coincide with the verified calculation (R55). The propagated pressure, plane, product, and production formulas agree with Sections 3–9; no new error was found in these updated inputs.

The final source-state finding therefore concerns corrections already present in the inspected updated reconstruction. The earlier wording findings in Section 10 identify the initial source bytes, not an outstanding defect in the later bytes.
