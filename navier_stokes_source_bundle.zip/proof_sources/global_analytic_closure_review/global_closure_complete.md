# Constructed leading profiles, complete background and pulse inputs

## 1. Exact input and its provenance

Retain
\[
0<h<1/100,\quad A=\tfrac12+h,\quad D=\tfrac12-h,\quad
z=q^D\eta,\quad 1-t=q(1-\eta^2),\quad X=\frac{r^2}{2q},
\quad d=1-\eta^2,\quad L=1-2h\eta^2.
\]
The particular \(h\) is the one selected in the completed leading-profile assembly. It is not a new arbitrary member of the displayed interval. In particular, \(L\ge1-2h>0\) on \(-1\le\eta\le1\).

The constructed leading profiles have physical interpretation
\[
u_{\theta,0}=q^{-A}E_0,\quad u_{z,0}=q^{-A}U_0,\quad
ru_{r,0}=V_0,\quad p_0=q^{-2A}\Pi_0^{\rm profile},
\qquad E_0=\sqrt{2X}\phi_0/C.
\]
Here the notation \(\Pi_0^{\rm profile}\) in this audit distinguishes the complete zero-order pressure profile from the axis datum also called \(\Pi_0\) in the assembly; it denotes exactly the zero-index \(\Pi_n\) of the base recursion. Their exact relationship is
\[
\Pi_0^{\rm profile}(X,\eta)=\Pi_{\rm ax}(\eta)+\int_0^X\frac{E_0(x,\eta)^2}{2x}\,dx.
\]

The full proof at reader 5676–5751 produces, for the same fixed object:

* one interval \([0,X_{\rm an}]\), extending beyond the stress-free endpoint \(X_a\), with smooth radial coefficients and one complex parameter neighborhood on which every fixed radial derivative is holomorphic;
* the exact totals \(M(\infty)=J(\infty)=S(\infty)=0\), canonical pressure, and zero renormalized angular total;
* strictly positive compact cone margins for the leading shear and stress direction on \([X_a,X_b]\times[-1,1]\);
* the original weight \(\zeta=\exp(-t_1^2/y_a^2-4/y_b^2)\) and distance \(\delta=\min\{1,y_a,y_b\}\), with \(y_a=\log(X/X_a)\), \(y_b=\log(X_b/X)\), and all fixed weighted stress bounds;
* the exact heat exterior and \(U_0=V_0=0\) for \(X\ge X_v<X_b\);
* the unchanged reserved intervals \(I_{\rm pos}=I_3<I_4=I_{\rm mean}\), lying before \(X_v\), with
  \[
  U_0=0,\qquad E_0=c_{\rm patch}(1+\eta^2)^{-1}X^{-1/2-\lambda},\qquad\lambda>0.
  \]

These are actual outputs of the assembly, not hypotheses imported from the later base construction. The common holomorphic collar is proved at reader 7106 (the original continuation proof at 713); the nonlinear five-moment restorations preserve that entire collar and preserve the outer fields pointwise. The exact exterior morphism is reader 7593–7603. Neither restoration is based only on an asymptotic comparison. The finite parameter sequence and all leading-profile choices precede physical \(q\), band number, correction stage, and requested derivative order.

## 2. The common-radius analytic solution map

Choose once
\[
X_a<X_-<X_{\rm keep}<X_{\rm cut}<a^2\le X_{\rm an}<\inf I_{\rm pos}.
\]
The first five radii can all be chosen inside the unchanged analytic collar; no later positive-order coefficient changes their values. At order \(n\ge1\), put \(\lambda_n=2nh\). The finalized lower orders are used in the equations at reader 1020–1033, rather than the uncut inner versions of those lower orders.

For every real \(b\), the exact physical differentiation maps are
\[
\partial_t(q^bf)=q^{b-1}T_bf,\quad
T_bf=\frac{-bf+D\eta f_\eta+Xf_X}{L},
\]
\[
\partial_z(q^bf)=q^{b-D}Z_bf,\quad
Z_bf=\frac{2b\eta f+df_\eta-2\eta Xf_X}{L}.
\]
Thus two axial derivatives are \(Z_{b-D}Z_b\), in this order. Incompressibility with the original powers gives
\[
F_n(X,\eta)=\int_0^XU_n(x,\eta)\,dx,
\qquad
V_n=\frac{2\eta XU_n-2\eta(D+\lambda_n)F_n-d(F_n)_\eta}{L}.
\tag{B1}
\]
In particular the factor \(D+\lambda_n\) cannot be replaced by \(D\).

Set \(X=\xi^2\), \(K_n=F_n/X-U_n\), and
\[
W_n=(\phi_n,U_n,K_n,\Pi_n,\partial_\xi\phi_n,\partial_\xi U_n)^T.
\]
The exact system is
\[
\partial_\xi W_n+\xi^{-1}\operatorname{diag}(0,0,2,0,3,1)W_n
=A_0W_n+A_1\partial_\eta W_n+f_n,
\qquad W_n(0)=0.
\tag{B2}
\]
Here \(f_n\) contains only the finalized lower orders. The current-index products are precisely the pairs \((0,n),(n,0)\), so (B2) is linear in the current unknown. Every apparent axis quotient is smooth: (B1) gives \(V_n=Xv_n\), and every term of \(\Omega_{n-1}\) has a factor \(X\). The pressure row is
\[
\Pi_{n,\xi}=4\xi C^{-2}\phi_0\phi_n+f_{n,4}.
\]
Using that row in the axial equation eliminates the \(X\Pi_{n,X}\) occurrence without differentiating an unknown pressure in the radial direction again.

For \(H_c=D\eta+dU_0\), the only potentially nonzero entries of \(A_1\) are
\[
\begin{aligned}
(A_1)_{51}&=2H_c/L,&
(A_1)_{52}=(A_1)_{53}&=-2d(\phi_0+X\phi_{0,X})/L,\\
(A_1)_{62}&=2(H_c-dXU_{0,X})/L,&
(A_1)_{63}&=-2dXU_{0,X}/L,&
(A_1)_{64}&=2d/L.
\end{aligned}
\tag{B3}
\]
These entries follow directly from the \(\eta\) derivative terms in the original coefficient equations; the factor two comes from the transformed radial second-order operators. They remain unchanged as a list of positions under every parameter derivative. Therefore \(A_1\) maps the first four coordinate subspace into the last two and kills the last two, including after parameter differentiation.

Let \(c_i=(0,0,2,0,3,1)_i\) and define
\[
(Gg)_i(\xi)=\int_0^\xi(s/\xi)^{c_i}g_i(s)\,ds,
\qquad K=G(A_0+A_1\partial_\eta).
\]
The diagonal kernel preserves both subspaces above. In a composition, two adjacent derivative choices vanish: when the left derivative hits the right matrix the product is \(A_1D_0\partial_\eta A_1=0\), and when it hits the remaining function the product is \(A_1D_0A_1=0\). Consequently a nonzero word of \(k\) factors has at most \(p_k=\lceil k/2\rceil\) parameter differentiations. This statement counts differentiations on coefficients as well as on the terminal source.

For each fixed \(n\), choose a sufficiently small bounded complex neighborhood \(S_\rho\) of \([-1,1]\) on which \(L\) has no zero and the coefficients and source are bounded uniformly for \(0\le\xi\le a\). This is possible because \(f_n\) uses only finitely many previously constructed orders and finitely many derivatives. For \(0<\rho'<\rho\), split \(\Delta=\rho-\rho'\) among the at most \(p_k\) derivative operators. Applying Cauchy's estimate to the successive holomorphic operator compositions bounds them by \(\max(1,p_k/\Delta)^{p_k}\), without adding uncounted Leibniz terms. The ordered \(k+1\) radial integrals have volume \(a^{k+1}/(k+1)!\), and the at most \(2^k\) words are absorbed into \(C_n^{k+1}\). Hence
\[
\|K^kGf_n\|_{S_{\rho'}}\le
\frac{C_n^{k+1}a^{k+1}}{(k+1)!}
\max(1,p_k/\Delta)^{p_k}.
\tag{B4}
\]
The logarithm of this bound divided by \(k\) is \(-\tfrac12\log k+O_n(1)\). Its \(k\)-th root tends to zero. Thus \(\sum_{k\ge0}K^kGf_n\) converges for the entire chosen \(a\), whatever the finite size of \(C_n\). Applying the same estimate with \(k\) radial integrals to a homogeneous solution \(W=K^kW\) proves uniqueness in the uniformly bounded holomorphic class.

The identities
\[
(Gg)_i=\xi\int_0^1t^{c_i}g_i(t\xi)dt,
\qquad
\partial_\xi(Gg)_i=g_i(\xi)-c_i\int_0^1t^{c_i}g_i(t\xi)dt
\]
bootstrap radial regularity, after decreasing the parameter neighborhood for each fixed derivative if needed. The reflected equations have even first four components and odd last two. Uniqueness gives these parities. Taylor's formula for an even smooth function of \(\xi\), to order \(2m+2\), proves smoothness through \(X=\xi^2=0\) with \(m\) derivatives, for every fixed \(m\).

This proves an exact map from the finalized lower coefficients on the common radial rectangle to the unique current inner coefficient on that same radial rectangle. The parameter neighborhood is allowed to depend on \(n\) and the fixed radial derivative. The frozen source says this explicitly at extracted-text lines 2874–2882. The argument makes no claim of one complex radius uniform in every order, and no such claim is needed by subsequent summation.

## 3. Exact extension, five rows, and common support

Multiply the inner \(\phi_n,U_n\) by a fixed radial cutoff equal to one through \(X_{\rm keep}\) and zero from \(X_{\rm cut}\). On \(I_{\rm pos}\), add two axial bumps and three angular bumps in \(R=\sqrt{2X}\), with \(dX=R\,dR\). The bumps are nonnegative with unit \(dR\) integral and ordered disjoint supports. The exact leading law there is
\[
U_0=0,\qquad E_0=e_*f(\eta)R^{-1-2\lambda},
\quad f=(1+\eta^2)^{-1},\quad
e_*=2^{1/2+\lambda}c_{\rm patch}>0.
\]
The last factor is the exact conversion from the unchanged \(X\) power law.

The five moments are
\[
\begin{aligned}
m_1&=\int_0^\infty RU_n\,dR,&m_2&=\int_0^\infty R^2E_n\,dR,&m_3&=\int_0^\infty\Pi_{n,R}\,dR,\\
m_4&=\int_0^\infty R^2\sum_{i+j=n}U_iE_j\,dR,&
m_5&=\int_0^\infty\left(R\sum_{i+j=n}U_iU_j-\tfrac12R^2\Pi_{n,R}\right)dR.
\end{aligned}
\]
Reconstruct \(V_n\) by (B1) and pressure with zero axis value by
\[
\Pi_{n,R}=\frac{2E_0E_n+\sum_{i=1}^{n-1}E_iE_{n-i}-\Omega_{n-1}}{R}.
\]
With the lower orders fixed, the exact current-order increments are
\[
\begin{array}{ll}
\delta m_1=\int R\delta U_n\,dR,&
\delta m_4=e_*f\int R^{1-2\lambda}\delta U_n\,dR,\\
\delta m_2=\int R^2\delta E_n\,dR,&
\delta m_3=2e_*f\int R^{-2-2\lambda}\delta E_n\,dR,\\
&\delta m_5=-e_*f\int R^{-2\lambda}\delta E_n\,dR.
\end{array}
\tag{B5}
\]
There is no current-order quadratic remainder because \(n>0\) and \(i+j=n\). Let \(B_U,B_E\) be the bump moment matrices with row powers \((1,1-2\lambda)\), \((2,-2-2\lambda,-2\lambda)\). Their determinants do not vanish: a sum of \(m\) distinct real powers has at most \(m-1\) positive zeros, by division by the least power and induction using Rolle's theorem. Thus the evaluation determinant on ordered nodes is continuous, never zero, and has one sign. Its integral against the ordered nonnegative bump product is the bump moment determinant, by multilinearity and Fubini, and has that same nonzero sign.

For pre-correction moments \(m^0\), the coefficient vectors are exactly
\[
\alpha=-B_U^{-1}(m_1^0,m_4^0/(e_*f))^T,
\qquad
\beta=-B_E^{-1}(m_2^0,m_3^0/(2e_*f),-m_5^0/(e_*f))^T.
\tag{B6}
\]
Thus every moment vanishes for every \(\eta\). The inverse works for arbitrary finite discrepancies; no smallness condition is being assumed. The correction coefficients are smooth because \(f\ge1/2\) on the parameter interval. They do not affect parameter analyticity on \([0,a^2]\), since their supports lie after that interval and the earlier cutoff is independent of \(\eta\). Reconstruction by forward integration leaves the original inner solution exactly unchanged through \(X_-\). This closes induction on \(n\).

Past the velocity bump supports, \(F_n=m_1=0\), so \(V_n=0\). Choose a common \(X_+\) after both those supports and the leading axial pulse, with \(X_v<X_+<X_b\). Every term of every \(\Omega_k\) then vanishes there, including its shifted axial viscosity term. At positive total order every \(\phi_i\phi_j\) has a positive-order factor, so \(\Pi_{n,X}=0\) there and \(\Pi_n=m_3=0\). This proves common compact support of every reconstructed positive-order velocity, pressure and potential. Merely choosing \(X_+\) after \(I_{\rm pos}\) would not prove this pressure statement; the actual proof at reader 1280–1287 explicitly retains the leading-pulse requirement.

## 4. Exact integrated residual map and the edge term

The conservative angular and axial residual identities, including their cylindrical connection terms, are reader 1299–1303. Their integrated current-order terms are respectively
\[
q^{3/2-A+\lambda_n}m_2,\quad q^{3/2-2A+\lambda_n}m_4,
\qquad
q^{1-A+\lambda_n}m_1,\quad q^{1-2A+\lambda_n}m_5.
\]
For the pressure contribution, integration by parts gives
\[
\int_0^\infty R\Pi_n\,dR=-\frac12\int_0^\infty R^2\Pi_{n,R}\,dR.
\]
Its two boundary terms are zero by axis smoothness and the proved compact pressure support. These moments vanish as functions of the parameter before any physical differentiation, so their \(t,z\) derivatives vanish as well. Axis parity and compact support eliminate the radial flux boundaries.

At order one the shifted angular viscosity uses the leading field. The exact needed integral is
\[
\int_0^\infty r^2\left(u_{\theta,0}-c_\infty(r^2/2)^{-A}\right)dr=0.
\tag{B7}
\]
It follows from the exact assembled renormalized moment by \(r=\sqrt qR\). The subtracted power has integrable weight \(r^{1-2h}\) at zero, and the heat asymptotic difference and time derivative have integrable weight \(O_h(r^{-1-2h})\) at infinity. The exterior heat field is independent of \(z\); all its remaining \(z\) derivatives have bounded radial support on compact physical parameter neighborhoods. Thus the required two axial differentiations of (B7) are legitimate and zero. The leading axial moment is already zero. For higher orders the same assertion uses \(m_{n-1,2}=m_{n-1,1}=0\).

Consequently the exact weighted residual totals are zero, and the stress is both the negative forward primitive and positive backward primitive:
\[
T_{n,\theta}=-R^{-2}\int_0^R\rho^2r_{\theta,n}\,d\rho
=R^{-2}\int_R^\infty\rho^2r_{\theta,n}\,d\rho,
\]
\[
T_{n,z}=-R^{-1}\int_0^R\rho r_{z,n}\,d\rho
=R^{-1}\int_R^\infty\rho r_{z,n}\,d\rho.
\]
The support is \([X_-,X_+]\) for \(n\ge2\), and \([X_-,X_b]\) for \(n=1\). The latter reaches the exterior collar because of the leading angular axial-viscosity term, not because of an uncontrolled pressure constant.

For this single edge term, the exact flat primitive is
\[
\int_0^\delta e^{-c/u^2}u^{-j}b(u,\eta)du
=\frac12e^{-c/\delta^2}\delta^{3-j}
\int_0^\infty e^{-cv}(1+\delta^2v)^{(j-3)/2}
b\left(\frac\delta{\sqrt{1+\delta^2v}},\eta\right)dv.
\tag{B8}
\]
It is obtained by \(u=\delta(1+\delta^2v)^{-1/2}\). Every fixed derivative of the integral coefficient is dominated by an exponential times a polynomial in \(v\), uniformly on the closed parameter rectangle. The coefficient is smooth, with boundary value \(b(0,\eta)/c\). In the actual angular order-one source, the two terms carry \(c=4,j=6\) and \(c=4,j=3\); (B8) yields the exact permitted inverse-distance powers after the radial integral. The physical power is
\[
q^{-A-2D+1/2}=q^{-A-1/2+2h}.
\]
Hence \(|\partial^IT_1|\le C_I\zeta\delta^{-N_I}\). All \(T_n/\zeta\), \(n\ge2\), are smooth and have finite fixed derivative bounds because they have common compact support strictly within the stress annulus. The proof uses reader 2296–2318, not a generic claim that every flat function has a bounded quotient by \(\zeta\).

## 5. Exact Borel map and all fixed derivative bounds

The positive-order streamfunction and potential are
\[
S_n=q^{1-A+2nh}F_n,
\qquad
\mathcal A_n=(S_n/r)e_\theta
=\tfrac12q^{-A+2nh}(F_n/X)(-x_2,x_1,0).
\]
The equality \(F_n/X=\int_0^1U_n(tX,\eta)dt\) proves Cartesian axis smoothness. Their curls give the original radial and axial velocity exactly. Apply the cutoff to this potential. Direct differentiation, retaining the original sign \(ru_r=-\partial_zS\), gives
\[
ru_{r,n}^{\rm cut}=q^{2nh}
\left[\chi(c_nq)V_n-\frac{2\eta}{L}(c_nq)\chi'(c_nq)F_n\right],
\]
\[
u_{z,n}^{\rm cut}=q^{-A+2nh}\chi(c_nq)U_n,
\qquad
u_{\theta,n}^{\rm cut}=q^{-A+2nh}\chi(c_nq)E_n.
\tag{B9}
\]
Every potential curl is divergence free, and every axisymmetric angular cutoff field is divergence free. Local finiteness at \(q>0\) therefore proves exact incompressibility even in cutoff transition regions.

The derivative loss is independent of \(n\). A fixed physical derivative of a term \(q^bg\) costs \(q^{-|\beta|/2-Dk-\ell}\) for \(\partial_{x_\perp}^{\beta}\partial_z^k\partial_t^\ell\); powers of \(b\) enter only its finite constant. A differentiated cutoff contributes \(c_n^j\chi^{(j)}(c_nq)\) together with \(q^j\) from the differentiated \(q\)'s. On its support \(1/2\le c_nq\le1\), these factors are bounded uniformly in \(c_n\). Thus the extra curl derivative also has an order-independent physical loss.

At step \(n\), choose \(c_n\ge2c_{n-1}\) large enough for the finite list of physical and normalized coefficient seminorms through order \(n\), including the bracket in (B9) and \(T_n/\zeta\) for \(n\ge2\). After retaining the original \(q^{2nh}\), make each such term at most \(2^{-n}q^{nh}\). This is possible because \(q^{nh}\) dominates every fixed power of \(|\log q|\) near zero. The choices fix one sequence; no choice is made after a derivative order is requested.

For any fixed derivative order \(m\), the finitely many terms below the tail retain their original powers at least \(q^{2h}\). Start the tail at \(n\ge\max(2,m+2)\). For \(0<q\le1\),
\[
\sum_{n\ge\max(2,m+2)}2^{-n}q^{nh}\le2q^{2h}.
\]
This proves all fixed normalized derivative estimates
\[
\widehat E-E_0=O(q^{2h}),\qquad\widehat U-U_0=O(q^{2h}),
\]
\[
q^Au_r-\frac{q^h}{\sqrt{2X}}V_0=O(q^{3h}),
\qquad
|\partial^I(\widehat T-T_0)|\le C_Iq^{2h}\zeta\delta^{-N_I}.
\tag{B10}
\]
In the radial estimate, the additional cutoff term in (B9) is included. Separating the single order-one edge term proves the stress estimate. The diagonal choice is made on one rectangle containing all common correction supports; larger rectangles add only the exact leading heat field. This is why the construction is simultaneous on every compact profile range.

For completeness, the retained coefficient equations give finite augmented residual bound
\[
|F_{\rm slow}(U^{[N]})|_m\le C_{N,m}q^{2h(N+1)-(2A+1/2+m)}.
\]
The Borel tail after \(J\ge\max(1,m)\) has bound \(2^{-J}q^{h(J+1)-\ell'_m}\) near zero, with \(\ell'_m\) independent of \(J\). For a fixed desired derivative and decay power, choose one finite \(J\) so both exponents dominate all losses in the finite differential-polynomial residual comparison. Then decrease the neighborhood of zero to absorb the fixed finite constants and logarithms. This proves flat augmented residual. It does not exchange the \(J\to\infty\) limit with an uncontrolled family of fixed-stage remainders.

## 6. The exact chart morphism into the pulse hypotheses

For a fixed band, retain
\[
Q=2^{-\ell},\qquad\varepsilon=Q^h,\quad S_*=\ell^2,
\qquad R=r/\sqrt Q,\quad Z=z/Q^D,\quad T=(1-t)/Q.
\]
Set \(s_Q=q/Q\). The exact chart/profile map is
\[
Z=s_Q^D\eta,\quad T=s_Q(1-\eta^2),\quad X=R^2/(2s_Q),
\qquad R_{\rm profile}=R/\sqrt{s_Q}.
\tag{B11}
\]
On the fixed enlarged annulus and \(1/2\le s_Q\le2\), its first derivatives have denominators only in \(s_Q,L,R\), bounded below by \(1/2,1-2h,\sqrt{X_a}\). Repeated differentiation gives finite sums of the same type, so all fixed derivative bounds are uniform in the band. The complete calculation is reader 7713–7756. It proves a map of derivative classes, not equality of the two radius coordinates.

Let \(b,V,G\) be the actual chart velocity \(Q^Au\), in radial, angular, axial order. The exact leading tangential chart coefficients are
\[
V^{(0)}=s_Q^{-A}E_0(X,\eta),\qquad G^{(0)}=s_Q^{-A}U_0(X,\eta),
\]
while
\[
b^{(0)}=\varepsilon V_0(X,\eta)/R.
\]
Inserting (B9)–(B10) in these formulas yields, at every fixed slow derivative,
\[
b=O(\varepsilon),\qquad b-b^{(0)}=O(\varepsilon^3),
\qquad V-V^{(0)}=O(\varepsilon^2),\quad G-G^{(0)}=O(\varepsilon^2).
\tag{B12}
\]
The auxiliary derivatives are zero because the background is auxiliary independent. These bounds do not need a polynomial \(S_*\) loss: the profile and compact chart maps are fixed. The weaker allowance \(O(\varepsilon S_*^B)\) at reader 10077 is therefore consistent but does not weaken the \(O(\varepsilon)\) input used by the phase proof at 8213.

For stress, the exact scale is
\[
\Sigma=Q^{2A}q^{-A-1/2}\widehat T,
\qquad
Q^{2A}q^{-A-1/2}=\varepsilon(Q/q)^{A+1/2}.
\]
Since \(q^{2h}=\varepsilon^2s_Q^{2h}\), (B10) gives the actual normalized stress difference of mean class \(\mathcal M_3\), including the \(\zeta,\delta\) factors. No scale ratio is replaced by one. The leading compact cone and its derivative bounds pass through (B11); this is the concrete input needed for the frozen representative, the plane isomorphism and both covariance columns.

## 7. Exact preservation of the reserved interval

The entire reserved mean interval, including gaps between the later bumps, matters because the induced streamfunction can be nonzero in those gaps. The actual outer schedule gives
\[
\mathfrak m=eX_R\left(4+\int_0^{T_d}k(v)e^v\,dv\right)>0,
\qquad M(X,\eta)=\mathfrak m\eta
\]
throughout \(I_4\). This follows by integrating \(U=4\eta\) to \(eX_R\), then \(U=k(v)\eta\) with \(X=eX_Re^v\), and then \(U=0\) to \(I_4\). The two exact moment restorations preserve \(M\) and all its parameter derivatives at every later radius; the heat edits have zero axial increment. Thus (B1) at zero order gives
\[
V_0=-\mathfrak m\frac{2D\eta^2+1-\eta^2}{1-2h\eta^2}=-\mathfrak m.
\]
The final equality uses \(2D=1-2h\). Every positive-order \(E_n,U_n,F_n,V_n\) is identically zero throughout this interval, by (B5)–(B6) and the strict ordering \(I_3<I_4\). Every term in (B9), including its derivative-of-cutoff term, is therefore zero there, for all parameter values.

Accordingly the actual summed chart background has the exact full-interval law
\[
b=-\varepsilon\mathfrak m/R,
\qquad V=a(\eta)s_Q^{\lambda-h}R^{-1-2\lambda},
\qquad G=0,
\]
where \(a(\eta)=2^{1/2+\lambda}c_{\rm patch}(1+\eta^2)^{-1}\). This proves the advertised five-dimensional mean matrix is evaluated at the actual Borel background. Positive-order pressure has not been asserted zero on \(I_4\); it is not part of the matrix input. The exact proof occupies reader 9042–9254.

## 8. Bounded disposition

The base-side chain closes for the actual constructed profile: the analytic collar, zero totals, strict cone, reserved intervals, heat exterior, and flat edge factors are supplied by the completed leading-profile assembly; the recursion and five-row correction construct every positive order on a common radial interval; the cutoff potential preserves exact incompressibility and the reserved mean law; and the diagonal estimates give every fixed derivative required by the phase/pulse proof.

There is one precise pulse interpretation repair, described in `pulse_check.md`: the actual shear \(g\) differs by \(O(\varepsilon^2)\) from its leading value at the representative. Therefore the production term after the exact energy identity is \(-|g_0|T_N-(g-g_0)\cdot T\), not literally \(-|g_0|T_N\). This is a missing term in the explanatory equality, not in the displayed energy equation or the pulse ODE. Its controlled contribution must be retained when asserting positivity. The independent pulse note proves that contribution does not destroy the positive lower production bound and verifies the pulse estimates entering covariance.

No conditional theorem, unresolved analytic assumption, or Lean result is used to supply this bounded base-to-pulse chain. The parent retains responsibility for the later stages outside the scope stated at the beginning.

# Full phase, pulse, inverse and covariance audit

## 1. Frozen labels and rounded carrier

Keep \(Q=2^{-\ell}\), \(\varepsilon=Q^h\), \(S_*=\ell^2\), \(0<h<1/100\), and each label fixed under the continuous derivatives. The geometry gives

\[
\frac1{T_gS_*}<c_i\le\frac1{S_*},\qquad
L_s=\frac{2r_0}{c_i},\qquad
2r_0S_*\le L_s<2r_0T_gS_*.
\]

The original \(F=V/R\), \(g=(RF_R,G_R)\), and compact positive annulus make all fixed slow derivatives of \(F,g\) bounded. Let the leading shear at the representative be \(g_0=F_0(-a,b_s)=|g_0|N\), and retain \(K=(-N_z,N_\theta)\), \(t_s=-b_s/a\), \(v_s=a(1+t_s^2)\). Substituting

\[
N=-\frac{(1,t_s)}{\sqrt{1+t_s^2}},\quad
K=\frac{(t_s,-1)}{\sqrt{1+t_s^2}}
\]

in the original formula gives

\[
\lambda_0^2=2aF_0^2(1-2/v_s)>0,\qquad
c_0=\frac{\lambda_0}{2F_0N_\theta}<0,\qquad c_0^2=(v_s-2)/2.
\]

All denominator and spectral lower bounds therefore follow from the given compact leading cone. The quantities \(F_0,g_0,N,K,\lambda_0,c_0,B_s,p,p_z,L_s\) are label constants; none is differentiated through a moving representative or a rounding rule.

For \(k=\lceil\varepsilon^{-1/2}\rceil\), \(1\le\varepsilon k^2\le4\) and \(k^{-1}\le\sqrt\varepsilon\). A nearest nonzero integer \(j\) to \(k\widetilde p\) satisfies \(|j-k\widetilde p|\le1\), including \(k\widetilde p=0\). Thus \(p=j/k\ne0\) and \(|p-\widetilde p|\le k^{-1}\). This choice both controls the perturbation and supplies the exact angular identity used below.

With the source's original constants,

\[
B_s^2=\frac{\lambda_0}{\varepsilon k^2(1+u_*^2)^{3/2}},\quad
(\widetilde p/R_0,p_z)=B_s\left(K-\frac{\sigma u_*g_0}{L_s|g_0|^2}\right),
\]

the scalar product of the last vector with \(g_0\) is exactly \(-\sigma B_su_*/L_s\). At a varying slow point,

\[
(H_\Phi)_R=(p/R,p_z)\cdot g,\qquad H_\Phi=pF+p_zG.
\]

The three differences are: \(R^{-1}-R_0^{-1}=O(S_*^{-3})\), the leading shear variation \(O(S_*^{-3})\) plus actual shear difference \(O(\varepsilon^2)\), and the integer rounding \(O(k^{-1})\). All multiplying factors are uniformly bounded. Consequently

\[
\left|(H_\Phi)_R+\frac{\sigma B_su_*}{L_s}\right|
\le C(S_*^{-3}+\varepsilon^2+k^{-1}).
\]

## 2. Exact gradient and transport defect

The affine pulse coordinate obeys \(D_rv=D_zv=0\), \(\mathsf t_*v=1\), while \(\mathsf t_*=-\varepsilon\partial_T+c_iN_i\). Directly differentiating the full phase, with its axial inverse power retained, gives

\[
\Phi=p\theta+p_zZ/\varepsilon+x_0R-vH_\Phi,
\qquad
n_\Phi=(x_0-v(H_\Phi)_R,p/R,p_z-\varepsilon v(H_\Phi)_Z).
\]

The target radial component is \(B_ss(v)=\sigma B_s(u_*/2+u_*v/L_s)\). The radial error is bounded by \(CL_s(S_*^{-3}+\varepsilon^2+k^{-1})\). The tangential errors are bounded by \(C(S_*^{-1}+S_*^{-3}+k^{-1}+\varepsilon L_s)\). One fixed lower bound on \(\ell\) makes

\[
S_*^2(\varepsilon+\varepsilon^2+k^{-1})\le1,
\]

because every power of \(\ell\) multiplied by \(2^{-h\ell/2}\) tends to zero. Hence

\[
|n_\Phi-B_s(s(v),K)|\le C/S_*,\qquad
n_\Phi'=(-(H_\Phi)_R,0,-\varepsilon(H_\Phi)_Z)=O(S_*^{-1}).
\]

Each fixed coefficient derivative of these expressions is polynomially bounded in \(S_*\). The term \(p_zZ/\varepsilon\) cancels exactly with the \(\varepsilon\partial_Z\) in the gradient; it has not been removed from the phase or the physical exponential.

The term-by-term transport identity is

\[
\mathsf t_*\Phi=-H_\Phi+\varepsilon v(H_\Phi)_T,\qquad
F\partial_\theta\Phi+GD_z\Phi=H_\Phi-\varepsilon vG(H_\Phi)_Z,
\]

and therefore

\[
E_{\rm ik}=\varepsilon v((H_\Phi)_T-G(H_\Phi)_Z)+bn_{\Phi,r}.
\]

The precise product estimate is

\[
D^I(bn_{\Phi,r})=
\sum_{J\le I}\binom IJ(D^Jb)(D^{I-J}n_{\Phi,r})
=O_I(\varepsilon S_*^{d_I}).
\]

For example, \(\partial_Rn_{\Phi,r}=-v(H_\Phi)_{RR}\) can be \(O(S_*)\); a derivative-free \(O_I(\varepsilon)\) claim for the entire product is not justified by the stated hypotheses. The exact product estimate, together with the other displayed term, proves the required \(D^IE_{\rm ik}=O_I(\varepsilon S_*^{b_I})\), on the same fixed domain.

## 3. Pressure and the exact plane morphism

For the real normal \(n=n_\Phi\), retain

\[
\mathcal K=\begin{pmatrix}0&-2F&0\\2F+RF_R&0&0\\G_R&0&0\end{pmatrix},\quad
d=\varepsilon k^2|n|^2,\quad
\mathcal A=-\mathcal K+\frac{n(n^T\mathcal K-(n')^T)}{|n|^2}.
\]

Normal multiplication of the full equation, using \((n\cdot t)'=0\), gives the unique pressure

\[
\pi_m=\frac{i}{km}\frac{n\cdot\mathcal Kt_m-n'\cdot t_m+n\cdot f_m}{|n|^2}.
\]

Its sign is \(+i/(km)\): multiplication by \(ikm n\) produces minus the displayed normal vector. Substitution gives

\[
t_m'=\mathcal A t_m-m^2dt_m-\operatorname{proj}_{n^\perp}f_m,
\quad
(n\cdot t_m)'=-m^2d(n\cdot t_m).
\]

The initially zero constraint therefore persists and the projected/full equations are equivalent, with normal forcing included.

The uniform lower bound for \(|n_{\tan}|\) follows from the phase comparison and \(|B_sK|=B_s\ge c>0\). Put \(K_a=n_{\tan}/|n_{\tan}|\), \(N_a=((K_a)_z,-(K_a)_\theta)\), \(s_a=n_r/|n_{\tan}|\),

\[
U=[e_r-s_aK_a,N_a],\quad
M=\begin{pmatrix}1&1\\c_0\sqrt{1+s^2}&-c_0\sqrt{1+s^2}\end{pmatrix},\quad
B=UM,\quad B^\ell=M^{-1}\begin{pmatrix}e_r^T\\N_a^T\end{pmatrix}.
\]

Both columns of \(U\) lie in \(n^\perp\), the indicated row matrix times \(U\) is \(I_2\), and \(\det M=-2c_0\sqrt{1+s^2}\ne0\). Thus \(B:\mathbb C^2\to n^\perp\) is an exact isomorphism, \(B^\ell B=I_2\), and \(BB^\ell t=t\) for \(t\in n^\perp\).

For completeness the coordinate converse also follows exactly. Differentiate \(n^TB=0\) to obtain \(n^TB'=-n'^TB\). Since \(n^T\mathcal AB=-n'^TB\), every column of \(\mathcal AB-B'\) lies in \(n^\perp\). The damping and projected forcing lie in this plane too. Applying \(BB^\ell\) therefore recovers their original vectors. Thus solving the two-dimensional coordinate equation and setting \(t=Bz\) really solves the three-dimensional constrained equation; no right-inverse assertion outside \(n^\perp\) is used.

At the reference normal the matrix in the \((e_r-sK,N)\) basis is

\[
\begin{pmatrix}0&2F_0N_\theta/(1+s^2)\\-(2F_0N_\theta+|g_0|)&0\end{pmatrix}.
\]

Multiplication verifies that the columns of \(M\) have respective eigenvalues \(\lambda_0/\sqrt{1+s^2}\) and its negative. The actual-frame and normal-motion perturbations are \(O(S_*^{-1})\), giving precisely

\[
B^\ell(\mathcal AB-B')=\operatorname{diag}(\lambda,-\lambda)+E,
\quad |E|\le C/S_*,\quad |d-d_{\rm ref}|\le C/S_*.
\]

Their fixed derivatives are polynomially bounded by ordinary product and quotient rules, with the already established uniform denominators.

## 4. Forward inverse and every fixed derivative

The original envelope has \(P'=a_{\rm net}P\), \(P(L_s/2)=1\), with

\[
a_{\rm net}=\frac{\lambda_0}{\sqrt{1+s^2}}-
\frac{\lambda_0(1+s^2)}{(1+u_*^2)^{3/2}}=\lambda-d_{\rm ref}.
\]

Direct differentiation gives \(-C/L_s\le a_{\rm net}'\le-c/L_s\) on the full pulse interval. Both \(\log P\) and its first derivative vanish at the midpoint. Integrating the second derivative on either side proves

\[
e^{-C_P(v-L_s/2)^2/L_s}\le P(v)\le e^{-c_P(v-L_s/2)^2/L_s}\le1.
\]

For \(A_m=\operatorname{diag}(\lambda,-\lambda)+E-m^2dI_2\), the real part of \(z^*A_1z\) is at most \((\lambda-d_{\rm ref}+C/S_*)|z|^2\). Hence its forward propagator satisfies \(\|V_1(v,w)\|\le C P(v)/P(w)\). The scalar commutation gives exactly

\[
V_m(v,w)=\exp\left(-(m^2-1)\int_w^v d(a)\,da\right)V_1(v,w).
\]

This is verified by differentiation and the initial identity matrix at \(v=w\). For every nonzero integer \(m\) the scalar exponential is at most one; the value estimate is therefore uniform over all nonzero harmonics.

Existence of the propagator can, without a further hypothesis, be obtained by the time-ordered series \(I+\sum_{j\ge1}\int_{w<a_j<\cdots<a_1<v}A_m(a_1)\cdots A_m(a_j)\,da_j\cdots da_1\). On a fixed label and finite \(m\), boundedness of \(A_m\) by \(K_m\) bounds term \(j\) by \(K_m^j(v-w)^j/j!\). Uniform convergence and the same bound after one \(v\)-derivative prove the differential equation. The norm inequality above gives uniqueness, so this series is the propagator used in the formulas.

For \(g_m=-B^\ell\operatorname{proj}_{n^\perp}f_m\), the zero-data solution is

\[
z_m(v)=\int_0^vV_m(v,w)g_m(w)\,dw.
\]

At fixed slow and transverse point, \(X,\zeta,\delta\) are constant in this integral. The \(P(w)\) in the source cancels \(P(w)^{-1}\) in the propagator. The only interval-length factor is \(L_s=O(S_*)\), proving the stated value weight.

Use slow variables and the initial transverse coordinate as parameters \(\mathfrak p\), with \(v\) held fixed. Differentiation gives exactly

\[
(\partial_{\mathfrak p}^Iz_m)'=A_m\partial_{\mathfrak p}^Iz_m+
\partial_{\mathfrak p}^Ig_m+
\sum_{0<J\le I}\binom IJ(\partial_{\mathfrak p}^JA_m)
\partial_{\mathfrak p}^{I-J}z_m.
\]

All initial parameter derivatives are zero. For fixed \(|m|\le M\), \(|\partial^JA_m|\le C_{J,M}S_*^{c_J}\). Induction on \(|I|\), the same forward estimate, and \(0<\delta\le1\) give a bound \(C_{I,M}\varepsilon^\alpha S_*^{b'_I}\sqrt\zeta\delta^{-a'_I}P(v)\), choosing \(a'_I\) at least every exponent already present and \(b'_I\ge1+\max\{b_I,\max_{0<J\le I}(c_J+b'_{I-J})\}\). Thus no exponential propagator is differentiated in isolation and no positive power of \(\varepsilon\) is lost.

Pulse derivatives follow by differentiating \(z'=A_mz+g_m\); each fixed mixed derivative is a finite sum of coefficient/source derivatives and already controlled derivatives. The common-torus map is affine:

\[
H_w=H+T_g^{-\Delta}c_i(w-v(H))v_t,\quad
D_Hv=T_g^\Delta\lambda_t/c_i=O(S_*),\quad
D_HH_w=I-v_t\lambda_t,
\]

and higher derivatives vanish. Consequently conversion to the stated coefficient derivatives in \((R,Z,T,H)\) introduces only polynomial powers. Multiplication by \(B\) preserves the required weights. The pressure formula introduces the additional \(1/(km)\le1/k\le\sqrt\varepsilon\), while every other factor has the proved fixed-derivative bounds. This establishes exactly the velocity exponent \(\alpha\) and pressure exponent \(\alpha+1/2\).

These inductions impose no additional smallness inequalities. The single threshold is determined by the finite value comparisons, tangential-normal and frame denominators, and the fixed invariant-band threshold below.

## 5. Support, smoothness, and descent

The path fixes the slow and transverse coordinates. Outside the specified closed slow/transverse support the source is zero for the whole path; the Duhamel integral is zero. Its parameter-differentiated equations give zero jets at the boundaries. At the active-shell edges every bound \(\sqrt\zeta\delta^{-a}\) tends to zero faster than every power of edge distance, and the same is true after each fixed derivative, proving smooth zero extension. This argument concerns exactly the three support variables specified in the original proposition; it does not assert that a source's temporal support is preserved by a forward ODE.

The covering deck translations reindex the lifted rectangle copies and commute with the path. Their pullbacks obey the same ODE with the same pulled-back data, so uniqueness proves descent to the common torus even when the source differs at distinct preimages of a band point. On the prescribed fixed-factor rectangle enlargement, \(|v|\le C_{\mathrm{enl}}L_s\). The tangential phase comparison above consequently remains \(n_{\Phi,\tan}=B_sK+O(S_*^{-1})\): replacing \(v\le L_s\) by this bound changes only the fixed constant in the axial error \(\varepsilon v(H_\Phi)_Z\). Hence the normal and frame denominators stay uniformly nonzero there after the same type of finite threshold choice. The coefficients and source are smooth on that enlargement by the stated input, and the finite-dimensional integral equation extends the solution there. For \(v<0\), its successive-integral construction uses the signed integrals from zero to \(v\); their absolute values are bounded by the same factorial series with \(|v|\) in place of \(v\). Its differentiated equations prove smooth dependence on the whole enlargement. At compact one-sided slow endpoints with \(q>0\), these parameter equations transfer the prescribed background/source derivatives to the solution and pressure.

## 6. Homogeneous lower bound and exact energy production

For real \(m=1,f=0\), take \(z_+(0)=P(0)>0,z_-(0)=0\). The actual ratio satisfies

\[
r'=E_{21}+(-2\lambda+E_{22}-E_{11})r-E_{12}r^2.
\]

At the boundaries \(r=\pm K_b/S_*\), the outward derivative is at most

\[
\frac{-2c_\lambda K_b+C(1+K_b/S_*+K_b^2/S_*^2)}{S_*}.
\]

A fixed sufficiently large \(K_b\), followed by a fixed large-\(S_*\) threshold, makes both outward derivatives negative. Thus \(|r|\le K_b/S_*\) until a potential zero of \(z_+\). On this invariant band,

\[
\left(\log\frac{z_+}{P}\right)'=-(d-d_{\rm ref})+E_{11}+E_{12}r=O(S_*^{-1}).
\]

Integration on \(0\le v\le L_s\) gives \(cP\le z_+\le CP\), which excludes that potential zero. Taking the threshold also so that \(K_b/S_*\le1/2\) gives

\[
x=z_+(1+r),\quad
y=c_0\sqrt{1+s^2}z_+(1-r),\quad
c_xP\le x\le C_xP,\quad
\frac yx=c_0\sqrt{1+s^2}+O(S_*^{-1}).
\]

The nonzero datum \(P(0)\) is fixed with the label, so its positive-order parameter derivatives vanish. The order-zero term is controlled by \(\|V_1(v,0)\|P(0)\le CP(v)\). The derivative induction above therefore applies without change to the homogeneous solution.

The exact actual energy equation is already correct in the source:

\[
\frac12\frac d{dv}|t|^2=-g\cdot T-\varepsilon k^2|n_\Phi|^2|t|^2,
\qquad T=t_r(t_\theta,t_z).
\]

Indeed the normal part of \(\mathcal At\) is orthogonal to \(t\), and

\[
t\cdot\mathcal Kt=-2Ft_rt_\theta+(2F+RF_R)t_rt_\theta+G_Rt_rt_z=g\cdot T.
\]

At the representative the actual \(g\), not merely its leading term, enters this identity. Writing \(T=T_NN+T_KK\) gives the exact correction to the prose following that identity:

\[
-g\cdot T=-|g_0|T_N-(g-g_0)\cdot T.
\]

Here \(g-g_0=O(\varepsilon^2)\) at the representative, and \(O(S_*^{-3}+\varepsilon^2)\) throughout its enlarged slow box. No equality \(g=g_0\) was supplied or derived. For a prescribed stress in the compact cone, \(-T_N\ge c_T|T|\) and \(|g_0|\ge g_->0\). Consequently, for the fixed large-band threshold,

\[
-g\cdot T\ge(g_-c_T-C(S_*^{-3}+\varepsilon^2))|T|
\ge\tfrac12g_-c_T|T|.
\]

For the actual homogeneous pulse there is a still more specific relation. Since \(t=x(e_r-s_aK_a)+yN_a\),

\[
T=x^2\left(-s_aK_a+\frac yxN_a\right)
=x^2\left[-sK+c_0\sqrt{1+s^2}N+O(S_*^{-1})\right].
\]

Thus, using the actual shear variation,

\[
-g\cdot T=
\left[-|g_0|c_0\sqrt{1+s^2}+O(S_*^{-1})\right]x^2.
\]

The leading coefficient is uniformly positive, since \(c_0<0\), \(|c_0|\ge c_->0\), and \(|g_0|\ge g_->0\). It follows that \(cP(v)^2\le-g\cdot T\le CP(v)^2\) after a fixed threshold. Also

\[
|t|^2=(1+s_a^2)x^2+y^2,
\]

so \(cP(v)^2\le|t(v)|^2\le CP(v)^2\). Positive shear production is compatible with decay after the midpoint because the actual damping remains in the exact energy equation. Neither the equality repair nor these estimates require deleting a part of the actual background.

## 7. Exact transfer of the lower bound to covariance mass

The positive covariance mass used downstream comes from the proved \(x\ge c_xP\), not from discarding damping in the energy equation. The angular frequency \(kp\ne0\) gives exactly \(\langle\cos^2(k\Phi)\rangle_\theta=1/2\). Haar preservation and the original rectangle Jacobian give

\[
h_\sigma=D_gc_iI_0,\quad
I_0=\int_0^{L_s}\psi^2x^2\,dv,\quad
D_g=\frac{1+b_g^2}{2}\int_\mathbb R\chi_g(\xi)^2\,d\xi>0.
\]

The expanded reader at lines 9503–9554 explicitly proves the constants. For \(L_s\ge25\), the interval \(|v-L_s/2|\le\sqrt{L_s}\) lies where \(\psi=1\), giving

\[
2c_x^2e^{-2C_P}\sqrt{L_s}\le I_0
\le C_x^2\sqrt{\frac\pi{2c_P}}\sqrt{L_s}.
\]

The floor bound and \(c_i\sqrt{L_s}=\sqrt{2r_0c_i}\) therefore give the strictly positive original mass bounds

\[
D_g(2c_x^2e^{-2C_P})\sqrt{2r_0/T_g}\,S_*^{-1/2}
\le h_\sigma\le
D_gC_x^2\sqrt{\frac\pi{2c_P}}\sqrt{2r_0}\,S_*^{-1/2}.
\]

Furthermore

\[
\int_0^{L_s}\frac{|v-L_s/2|}{L_s}\psi^2x^2\,dv
\le\frac{C_x^2}{2c_P}.
\]

Dividing by the positive \(I_0\) bounds the corresponding mean absolute scaled displacement by \(CL_s^{-1/2}\). Applying this probability measure to the exact flux polarization above, and using \(|s(v)-\sigma u_*|=u_*|v-L_s/2|/L_s\), gives

\[
H_\sigma=h_\sigma(-A_cN-\sigma u_*K+e_\sigma),\quad
A_c=-c_0\sqrt{1+u_*^2}>0,\quad |e_\sigma|\le CS_*^{-1/2}.
\]

This is the precise original-variable map from the homogeneous pulse lower bound to the two positive covariance columns. The reader includes its complete integral constants, retained angular half, retained Jacobian, retained \(c_i\,dv\), and both original signs. All fixed slow derivatives of these finite integrals follow from the proved homogeneous derivative bounds, with label-fixed endpoints and cutoffs.

# Actual shear and the full force-pressure correspondence

## 1. Original chart and the two contributions to the shear difference

Retain the source parameters and coordinates
\[
0<h<1/100,\quad A=1/2+h,\quad D=1/2-h,
\quad Q=2^{-\ell},\quad\varepsilon=Q^h,\quad S_*=\ell^2,
\quad R=r/\sqrt Q,\quad Z=z/Q^D,\quad T=(1-t)/Q.
\tag{AS1}
\]
The value of \(h\) is the one selected by the preceding profile construction. Constants below may depend on that value and the fixed source profiles. No uniform threshold as \(h\downarrow0\) is asserted. Work on the original compact enlarged chart annulus, whose inner radius is denoted by \(R_->0\). The label and its representative \(p_0=(R_0,Z_0,T_0)\) are held fixed under every continuous derivative.

Write \(s_Q=q/Q\). The exact leading tangential chart fields and the actual Borel fields are
\[
V^{(0)}=s_Q^{-A}E_0(X,\eta),\quad
G^{(0)}=s_Q^{-A}U_0(X,\eta),\quad
X=R^2/(2s_Q),\quad Z=s_Q^D\eta,\quad T=s_Q(1-\eta^2),
\tag{AS2}
\]
\[
\delta V=V-V^{(0)},\qquad \delta G=G-G^{(0)}.
\tag{AS3}
\]
The constructed base estimate (B12), on this fixed enlarged annulus, gives for each fixed slow multi-index \(I\) actual constants
\[
|\partial^I\delta V|\le C_{V,I}\varepsilon^2,
\qquad |\partial^I\delta G|\le C_{G,I}\varepsilon^2.
\tag{AS4}
\]
The base is independent of the auxiliary torus variables. The source supplies (AS4) through its Borel and chart constructions; this note does not replace that construction by a hypothesis about arbitrary fields.

Define the actual, varying leading, and frozen shear coordinates by
\[
F=V/R,\quad F^{(0)}=V^{(0)}/R,\quad F_0=F^{(0)}(p_0),
\quad g=(R\partial_RF,\partial_RG),
\quad g^{(0)}=(R\partial_RF^{(0)},\partial_RG^{(0)}),
\quad g_0=g^{(0)}(p_0).
\tag{AS5}
\]
Their exact difference is
\[
\begin{aligned}
\delta g&:=g-g^{(0)}=(\partial_R\delta V-\delta V/R,\partial_R\delta G),\\
\Delta g&:=g-g_0=\delta g+g^{(0)}(p)-g^{(0)}(p_0),\\
\Delta F&:=F-F_0=\delta V/R+F^{(0)}(p)-F^{(0)}(p_0).
\end{aligned}
\tag{AS6}
\]
At the representative the varying-leading differences in the second terms vanish exactly. The Borel differences in the first terms have not been shown to vanish, and are retained.

For \(I=(i_R,i_Z,i_T)\), the full derivative formula is
\[
\begin{aligned}
\partial^I\delta g_\theta
&=\partial^{I+e_R}\delta V
-\sum_{j=0}^{i_R}\binom{i_R}{j}(-1)^j j!R^{-j-1}
\partial^{I-je_R}\delta V,\\
\partial^I\delta g_z&=\partial^{I+e_R}\delta G.
\end{aligned}
\tag{AS7}
\]
Indeed \(\partial_R^j(R^{-1})=(-1)^jj!R^{-j-1}\); applying the full product rule to the first line of (AS6) gives exactly (AS7). Consequently the respective constants in the bounds for the two entries are
\[
C_{\theta,I}=C_{V,I+e_R}
+\sum_{j=0}^{i_R}\binom{i_R}{j}j!R_-^{-j-1}C_{V,I-je_R},
\qquad C_{z,I}=C_{G,I+e_R},
\tag{AS8}
\]
and the Euclidean vector bound is \(|\partial^I\delta g|\le(C_{\theta,I}^2+C_{z,I}^2)^{1/2}\varepsilon^2\). Every factor of the original radius and every derivative is present. The frozen difference \(\Delta g\) has a different derivative identity: for \(|I|>0\),
\[
\partial^I\Delta g=\partial^I\delta g+\partial^Ig^{(0)}.
\tag{AS9}
\]
Thus its higher derivatives are not inferred to be \(O(\varepsilon^2)\) from a small value difference on a narrow box.

Let the original box satisfy \(|p-p_0|\le C_{\rm box}S_*^{-3}\), with the connecting segment inside the enlarged domain. Let \(L_g\) be a bound for the Euclidean operator norm of \(D_pg^{(0)}\) there, and set \(C_B=(C_{\theta,0}^2+C_{z,0}^2)^{1/2}\). Integration along that segment gives
\[
|\Delta g|\le C_B\varepsilon^2+L_gC_{\rm box}S_*^{-3}.
\tag{AS10}
\]
This proves the precise value bound used by the pulse audit. It retains the independent Borel and box-variation contributions.

## 2. Complete first-jet coordinate map and both inverses

For each original \(R>0\), regard the first radial jet difference as the four-coordinate vector
\(j=(v,v_R,w,w_R)\in\mathbb C^4\). The shear map and its retained fibre coordinates are
\[
L_Rj=\begin{pmatrix}-1/R&1&0&0\\0&0&0&1\end{pmatrix}j,
\qquad
\mathcal J_Rj=(L_Rj,v,w)\in\mathbb C^2\oplus\mathbb C^2.
\tag{AS11}
\]
They apply to \(j=(\delta V,\partial_R\delta V,\delta G,\partial_R\delta G)\), without identifying a field value with its derivative. The complete inverse is
\[
\mathcal J_R^{-1}(a,b,v,w)=(v,a+v/R,w,b).
\tag{AS12}
\]
Substitution gives \((a+v/R)-v/R=a\), leaves the fourth entry \(b\), and recovers \(v,w\). Conversely, substituting \(a=v_R-v/R\) and \(b=w_R\) into (AS12) returns the original four entries. This proves both inverse compositions. In particular \(L_R\) is onto, has right inverse \((a,b)\mapsto(0,a,0,b)\), and has exactly the kernel
\[
\ker L_R=\{(v,v/R,w,0):v,w\in\mathbb C\}.
\tag{AS13}
\]
All these maps are smooth in the original positive radius. The entire jet has been retained in the bijection; a small shear difference does not erase the two fibre coordinates.

## 3. The same actual phase in the two background operators

Use the source's actual phase \(\Phi\), actual nonzero normal \(n=n_\Phi\), and its derivative \(n'=\partial_vn\). They are fixed as the same functions on both sides of the following comparison. Retain the original harmonic \(m\in\mathbb Z\setminus\{0\}\), source choice \(k=\lceil\varepsilon^{-1/2}\rceil\ge1\), and damping \(d=\varepsilon k^2|n|^2\). In particular \(km\ne0\) on the original domain of every pressure formula below. Define
\[
\mathcal K(F,g)=
\begin{pmatrix}0&-2F&0\\2F+g_\theta&0&0\\g_z&0&0\end{pmatrix},
\quad \mathcal K_0=\mathcal K(F_0,g_0),
\quad \Pi_n=I-\frac{nn^T}{|n|^2}.
\tag{AS14}
\]
Their exact matrix difference is
\[
\Delta\mathcal K=
\begin{pmatrix}0&-2\Delta F&0\\2\Delta F+\Delta g_\theta&0&0\\\Delta g_z&0&0\end{pmatrix}.
\tag{AS15}
\]
The comparison operator uses frozen background entries and the actual phase. The ideal reference phase \(B_s(s(v),K)\) is not silently substituted for \(n\).

The complex constrained equation is
\[
t'+\mathcal Kt+m^2dt+ikm n\pi=-f,
\qquad n^Tt=0.
\tag{AS16}
\]
Differentiating the constraint gives \(n^Tt'=-n'^Tt\). Multiplying the first equation by \(n^T\) and solving the scalar equation gives the unique pressure
\[
\pi=\frac{i}{km}\frac{n^T\mathcal Kt-n'^Tt+n^Tf}{|n|^2}.
\tag{AS17}
\]
Substituting this value, including \(i^2=-1\), gives
\[
t'=\mathcal A t-m^2dt-\Pi_nf,
\qquad
\mathcal A=-\mathcal K+
\frac{n(n^T\mathcal K-n'^T)}{|n|^2}.
\tag{AS18}
\]
The same formula with \(\mathcal K_0\) gives \(\mathcal A_0\), and direct subtraction proves
\[
\mathcal A-\mathcal A_0=-\Pi_n\Delta\mathcal K.
\tag{AS19}
\]
The normal-motion term cancels because it is the same actual term, not because it is zero.

## 4. Exact force–pressure bijection on the full constrained solution data

For each datum \((t,f,\pi)\) satisfying (AS16), set
\[
t_0=t,\qquad f_0=f+\Pi_n\Delta\mathcal Kt,
\qquad \pi_0=\pi-\frac{i}{km}\frac{n^T\Delta\mathcal Kt}{|n|^2}.
\tag{AS20}
\]
The data satisfy the equation with \(\mathcal K_0\), the same normal and damping, and right side \(-f_0\). To check the complete equation, calculate
\[
\begin{aligned}
t_0'+\mathcal K_0t_0+m^2dt_0+ikm n\pi_0
&=-f-\Delta\mathcal Kt
+n\frac{n^T\Delta\mathcal Kt}{|n|^2}\\
&=-f-\Pi_n\Delta\mathcal Kt=-f_0.
\end{aligned}
\tag{AS21}
\]
The constraint remains \(n^Tt_0=0\). Conversely, the exact inverse on the full solution data is
\[
t=t_0,\qquad f=f_0-\Pi_n\Delta\mathcal Kt_0,
\qquad \pi=\pi_0+\frac{i}{km}\frac{n^T\Delta\mathcal Kt_0}{|n|^2}.
\tag{AS22}
\]
Both compositions return every component because the unchanged vector \(t\) appears in equal and opposite increments. Substitution in (AS21) also proves the converse equation, so this is a bijection of the constrained solution-data spaces, including their pressure. For the actual homogeneous pulse \(f=0\), the comparison force is exactly \(\Pi_n\Delta\mathcal Kt\); it is not asserted zero. Smoothness follows from the explicit expressions and the source's positive normal denominator. The force increment can have support wherever \(t\) and the background difference overlap; no unsupported support equality is claimed.

## 5. Exact real energy production and an explicit finite positivity threshold

Restrict now to the original real homogeneous pulse, \(m=1\) and \(f=0\). Put
\[
T=t_r(t_\theta,t_z)\in\mathbb R^2.
\tag{AS23}
\]
Multiplication of the original matrix gives
\[
t^T\mathcal Kt=-2Ft_rt_\theta+(2F+g_\theta)t_rt_\theta+g_zt_rt_z=g\cdot T.
\tag{AS24}
\]
Because \(n^Tt=0\), the normal term in (AS18) has zero inner product with \(t\). Thus the exact energy identity is
\[
\frac12\partial_v|t|^2=-g\cdot T-d|t|^2.
\tag{AS25}
\]
Let \(N=g_0/|g_0|\), with the nonzero frozen shear supplied by the compact cone, and \(K=(-N_z,N_\theta)\). Then \((N,K)\) is an orthonormal ordered basis in the original \((\theta,z)\) plane. Writing \(T=T_NN+T_KK\), the exact replacement for the disputed sentence is
\[
-g\cdot T=-|g_0|T_N-\Delta g\cdot T.
\tag{AS26}
\]
In particular (AS26) is still the formula at \(p_0\), where \(\Delta g=\delta g\). Equation (AS24) with the matrix difference also gives \(t^T\Delta\mathcal Kt=\Delta g\cdot T\): both \(2\Delta F\) contributions cancel algebraically. No component of \(\Delta\mathcal K\) is removed from (AS20).

For the actual prescribed source stress cone, write its positive compact margin as \(-T_N\ge c_T|T|\), and write \(|g_0|\ge g_->0\). The Cauchy–Schwarz inequality and (AS10) give
\[
-g\cdot T\ge
\bigl[g_-c_T-C_B2^{-2h\ell}-L_gC_{\rm box}\ell^{-6}\bigr]|T|.
\tag{AS27}
\]
This includes \(T=0\), without division by its norm. One explicit sufficient integer threshold is
\[
\ell\ge\left\lceil\max\left\{
1,\left(\frac{4L_gC_{\rm box}}{g_-c_T}\right)^{1/6},
\frac{\log\max\{1,4C_B/(g_-c_T)\}}{2h\log2}
\right\}\right\rceil.
\tag{AS28}
\]
The first power bound makes the box term at most \(g_-c_T/4\); the logarithmic bound makes the Borel term at most the same number. Hence (AS27) gives the proved bound \(-g\cdot T\ge(g_-c_T/2)|T|\). The threshold is added to the already selected finite source value thresholds, never substituted for them.

## 6. Quantitative production for the actual homogeneous pulse

For that pulse use its actual frame
\[
K_a=n_{\tan}/|n_{\tan}|,\quad N_a=((K_a)_z,-(K_a)_\theta),
\quad s_a=n_r/|n_{\tan}|,\quad
t=x(e_r-s_aK_a)+yN_a.
\tag{AS29}
\]
The source's fixed-label reference has \(B_s\ge B_->0\),
\(s(v)=\sigma(u_*/2+u_*v/L_s)\), and \(|s(v)|\le s_{\max}=3u_*/2\) on \(0\le v\le L_s\). Write the actual proved phase and ratio bounds with constants as
\[
|n-B_s(s,K)|\le E_n/S_*,\quad
|y/x-\gamma_0|\le E_\gamma/S_*,\quad
\gamma_0=c_0\sqrt{1+s^2},\quad c_0<0,
\quad c_xP\le x\le C_xP.
\tag{AS30}
\]
These are the constructed pulse bounds; their invariant-band and propagator proofs were read in the complete pulse audit. Choose \(S_*\ge2E_n/B_-\), so \(|n_{\tan}|\ge B_-/2\). For any nonzero vectors \(a,b\), direct addition and subtraction of \(a/|b|\) proves
\(|a/|a|-b/|b||\le2|a-b|/|b|\). Applying this to \(a=n_{\tan}\), \(b=B_sK\), and using (AS30), gives
\[
|K_a-K|=|N_a-N|\le\frac{2E_n}{B_-S_*},
\qquad
|s_a-s|\le\frac{2(1+s_{\max})E_n}{B_-S_*}.
\tag{AS31}
\]
The second inequality follows by writing the numerator as
\(n_r-s|n_{\tan}|=(n_r-B_ss)+s(B_s-|n_{\tan}|)\), with denominator \(|n_{\tan}|\).

Let \(c_+\) bound \(|c_0|\), let \(c_->0\) bound it below, and set
\[
\Gamma_{\max}=c_+\sqrt{1+s_{\max}^2},\quad
C_T=\frac{2E_n}{B_-}(1+2s_{\max}+\Gamma_{\max})+E_\gamma.
\tag{AS32}
\]
The exact stress has the form
\[
T=x^2[-sK+\gamma_0N+e_T],\qquad
e_T=-(s_aK_a-sK)+(y/x)N_a-\gamma_0N,
\quad |e_T|\le C_T/S_*.
\tag{AS33}
\]
For this bound, expand \(s_aK_a-sK=(s_a-s)K_a+s(K_a-K)\) and
\((y/x)N_a-\gamma_0N=(y/x-\gamma_0)N_a+\gamma_0(N_a-N)\), then use (AS30)–(AS32). Every summand is retained.

Let \(g_+\) bound \(|g_0|\). The exact production is
\[
\frac{-g\cdot T}{x^2}=-|g_0|\gamma_0
-g_0\cdot e_T-\Delta g\cdot(-sK+\gamma_0N+e_T).
\tag{AS34}
\]
The last two terms have total absolute value at most
\[
\mathcal E_\ell=
g_+C_T\ell^{-2}
+\bigl(C_B2^{-2h\ell}+L_gC_{\rm box}\ell^{-6}\bigr)
\bigl(s_{\max}+\Gamma_{\max}+C_T\ell^{-2}\bigr).
\tag{AS35}
\]
This is a concrete nonnegative expression decreasing to zero. Set \(W=s_{\max}+\Gamma_{\max}+C_T>0\). In addition to the prior source and (AS31) thresholds, it suffices to choose
\[
\ell\ge\left\lceil\max\left\{
1,\left(\frac{4g_+C_T}{g_-c_-}\right)^{1/2},
\left(\frac{8WL_gC_{\rm box}}{g_-c_-}\right)^{1/6},
\frac{\log\max\{1,8WC_B/(g_-c_-)\}}{2h\log2}
\right\}\right\rceil.
\tag{AS36}
\]
The three resulting error contributions are at most \(g_-c_-/4\), \(g_-c_-/8\), and \(g_-c_-/8\). Thus \(\mathcal E_\ell\le g_-c_-/2\). The leading coefficient in (AS34) is at least \(g_-c_-\), because \(-\gamma_0=|c_0|\sqrt{1+s^2}\ge c_-\). Consequently
\[
\frac12g_-c_-c_x^2P(v)^2\le -g\cdot T
\le\bigl(g_+\Gamma_{\max}+g_-c_-/2\bigr)C_x^2P(v)^2.
\tag{AS37}
\]
This proves the two-sided production bound with every remainder retained. It does not assert that \(\partial_v|t|^2\) is positive: the original damping term in (AS25) is still present. The exact norm identity
\[
|t|^2=(1+s_a^2)x^2+y^2
\tag{AS38}
\]
also follows from the actual orthonormal frame; no ideal frame is substituted into this identity.

## 7. The derivative bound for the radial transport product

For the actual phase let
\[
H_\Phi=pF+p_zG,\qquad n_{\Phi,r}=x_0-v\partial_RH_\Phi,
\qquad
E_{\rm ik}=\varepsilon v(\partial_TH_\Phi-G\partial_ZH_\Phi)+bn_{\Phi,r}.
\tag{AS39}
\]
Here \(p,p_z,x_0\) and the label are fixed; \(v\) is the original affine pulse coordinate. Let \(D^I\) be the ordinary coefficient derivatives in \((R,Z,T,H_1,H_2)\), not the evaluated physical derivative operator. The actual source gives \(|D^Jb|\le C_{b,J}\varepsilon\), and the full phase formula gives \(|D^Jn_{\Phi,r}|\le C_{n,J}S_*^{d_J}\) for each fixed \(J\). Their exact product rule and resulting bound are
\[
D^I(bn_{\Phi,r})=
\sum_{J\le I}\binom IJ(D^Jb)(D^{I-J}n_{\Phi,r}),
\qquad
|D^I(bn_{\Phi,r})|
\le\varepsilon\sum_{J\le I}\binom IJ C_{b,J}C_{n,I-J}S_*^{d_{I-J}}.
\tag{AS40}
\]
For fixed \(I\) the sum is finite; since \(S_*\ge1\), it is bounded by
\(\varepsilon S_*^{\max_{J\le I}d_{I-J}}\sum_{J\le I}\binom IJ C_{b,J}C_{n,I-J}\).
Already \(\partial_Rn_{\Phi,r}=-v\partial_R^2H_\Phi\) may carry the interval-length factor \(L_s\). The bounds do not supply a uniform derivative-free \(C_I\varepsilon\) estimate for the entire product. Applying the same full finite product rule to the first term in (AS39), with the retained \(v\) and its affine derivatives, gives the source's stated \(C_I\varepsilon S_*^{b_I}\) transport-defect bound. Thus the corrected derivative sentence proves exactly the coefficient class used subsequently.

# Complete downstream closure of the constructed finite states

## 1. The exact physical mean-stress domain is attained

Retain

\[
0<h<1/100,\quad A=\tfrac12+h,\quad D=\tfrac12-h,
\quad \kappa_s=10^{-5},\quad Q=2^{-\ell},\quad
\varepsilon=Q^h,\quad S_*=\ell^2.
\]

The active shell is \(X_a<X<X_b\), where \(X=r^2/(2q)\), with

\[
\zeta(X)=\exp\!\left(-\frac{a_a}{\log^2(X/X_a)}
-\frac{a_b}{\log^2(X_b/X)}\right),\qquad
\delta=\min\{1,\log(X/X_a),\log(X_b/X)\},
\]

and the same original positive constants \(a_a,a_b,X_a,X_b\). The mean class used by the physical signed inverse consists of compatible, real, angular-independent, shell-supported coefficients satisfying every fixed coefficient derivative estimate

\[
|D^If|\le C_I\varepsilon^\alpha S_*^{b_I}\zeta\delta^{-d_I}
\]

and smooth zero extension. Its auxiliary-independent subspace is the domain needed for the physical stress inverse. These requirements, not auxiliary independence alone, are indispensable. The proof and the explicit counterexample for an enlarged domain occur under “Physical assembly, chart maps, and the missing domain qualification” (observed lines 9876–9962).

At the beginning of step (ii) of the actual stage cycle, put \(B=B_j=1/2+\sigma_j\), \(C=C_j=1+\sigma_j\), with \(\sigma_j=1/5+j/10\). Step (i) and the full integrated mean identities have established

\[
E_\theta,E_z\in\mathcal M_{C-\kappa_s},\qquad
\int R^2\overline{E_\theta}\,dR,
\int R\overline{E_z}\,dR\in\mathcal S_{C+1-\kappa_s}.
\]

Bars here are normalized auxiliary Haar averages; angular averaging has already been performed when defining the mean residual. For \(e=2\) take \(E_e=\overline{E_\theta}\), and for \(e=1\) take \(E_e=\overline{E_z}\). The actual physical quantities in step (ii) are

\[
F_e(r,z,t)=Q^{-2A-1/2}E_e(R,Z,T),\quad R=r/\sqrt Q,
\]
\[
b_e(r,z,t)=q^{-(e+1)/2}\widehat b_e(r/\sqrt q),
\quad\int_0^\infty x^e\widehat b_e(x)\,dx=1,
\]
\[
M_e=\int_0^\infty r^eF_e(r,z,t)\,dr,
\qquad
\sigma_e=-r^{-e}\int_0^r (r')^e(F_e(r')-b_e(r')M_e)\,dr'.
\]

The bump is fixed strictly inside the shell. Every radial integral keeps \((z,t)\), and hence \(q\), fixed. The change of variable \(r=\sqrt Q R\), with its original measure, proves

\[
m_e:=\int_0^\infty R^eE_e(R)\,dR,
\qquad M_e=Q^{-2A+e/2}m_e.
\tag{GC1}
\]

Define the exact chart representative of the unit-moment bump by

\[
b_{e,Q}(R)=Q^{(e+1)/2}b_e(\sqrt Q R)
=\left(\frac Qq\right)^{(e+1)/2}
\widehat b_e\!\left(\sqrt{\frac Qq}\,R\right).
\tag{GC2}
\]

With \(x=\sqrt{Q/q}\,R\), the integral of \(R^eb_{e,Q}\,dR\) equals

\[
\left(\frac Qq\right)^{(e+1)/2}
\left(\frac qQ\right)^{e/2}
\left(\frac qQ\right)^{1/2}
\int x^e\widehat b_e(x)\,dx=1.
\]

Substitution in the definition of \(\sigma_e\) gives the exact, unaltered chart stress

\[
\boxed{\quad Q^{2A}\sigma_e
=-R^{-e}\int_0^R(R')^e
\big(E_e(R')-b_{e,Q}(R')m_e\big)\,dR'.\quad}
\tag{GC3}
\]

Indeed the factors in the first source term are
\(Q^{-e/2}Q^{e/2}Q^{1/2}Q^{-2A-1/2}=Q^{-2A}\).
For the second source term, (GC1) and (GC2) give the same factor. No ratio \(q/Q\) or neighboring band scale has been set equal to one.

Let \(f_{e,Q}=E_e-b_{e,Q}m_e\). Equations (GC1)–(GC2) prove

\[
\int_0^\infty R^ef_{e,Q}\,dR=m_e-m_e=0.
\tag{GC4}
\]

The chart/profile map is smooth with every fixed derivative bounded on the original compact rectangle \(X_a\le X\le X_b\), \(1/2\le q/Q\le2\), \(-1\le\eta\le1\). Its denominators are positive powers of \(q/Q\), \(R\), and \(L=1-2h\eta^2\), all bounded away from zero. The support of \(b_{e,Q}\) stays in the original fixed interior profile interval, where \(\zeta\) has a positive lower bound. Thus the bump has mean exponent zero with all required weighted derivatives. Since \(m_e\) has exponent \(C+1-\kappa_s\), the product \(b_{e,Q}m_e\) has that exponent. Because \(0<\varepsilon\le1\), it also has the weaker exponent \(C-\kappa_s\). Consequently \(f_{e,Q}\in\mathcal M_{C-\kappa_s}^{\rm independent}\).

The actual weighted radial inverse RF12–RF18 was read in full. On an auxiliary-independent source its characteristic torus moment is its ordinary weighted integral. Equation (GC4) therefore makes that entire obstruction zero, not merely its Haar average. In this case the cutoff correction term in RF12 is identically zero and (GC3) is exactly \(-T_ef_{e,Q}\). Its lower and upper primitives vanish below and above the shell, respectively.

The weighted estimate uses the same edge exponents. For an inner edge coordinate \(s>0\), differentiation of the input gives a finite bound \(C e^{-a_a/s^2}s^{-M}\) times a smooth bounded outer factor. Substitution \(u=a_a/s^2\) gives

\[
\int_0^\delta s^{-M}e^{-a_a/s^2}\,ds
=\frac12a_a^{(1-M)/2}
\int_{a_a/\delta^2}^{\infty}u^{(M-3)/2}e^{-u}\,du
\le C_{a_a,M}\delta^{3-M}e^{-a_a/\delta^2}.
\]

For \(u=u_0+y\), \(u_0\ge1\), a nonpositive exponent of \(u\) is at most its value at \(u_0\); a positive exponent is at most \(u_0^{(M-3)/2}(1+y)^{(M-3)/2}\). Integrating that bound proves the displayed estimate. The corresponding upper primitive uses the same argument at the outer edge with \(a_b\). A fixed derivative is a finite sum of such integrals and differentiated endpoint factors. The fixed-shift RF16 formula makes the moving support produce no boundary terms. On the remaining compact interior, the positive lower bound for \(\zeta\) supplies the weighted estimate. Every fixed inverse-distance power multiplying either exponential vanishes with all derivatives at its endpoint. It follows that

\[
\Sigma:=Q^{2A}(\sigma_2,\sigma_1)
\in\mathcal M_{C-\kappa_s}^{\rm independent}
\tag{GC5}
\]

with precisely the shell support and smooth zero extension required by the corrected signed covariance domain.

The construction is independent of the chosen band chart. The quantities \(F_e,b_e,M_e,\sigma_e\) above are physical functions; on an overlap with scale \(Q'\), applying the same change of variables gives \(\Sigma'=Q'^{2A}\sigma=(Q'/Q)^{2A}\Sigma\). Their chart arguments are

\[
R'=(Q/Q')^{1/2}R,\quad Z'=(Q/Q')^DZ,
\quad T'=(Q/Q')T.
\]

Haar averaging agrees under the covering pullbacks because \((J_g^i)^Tk=0\) exactly when \(k=0\). This proves that the averaged residual used to define \(F_e\) is itself one compatible physical field. The radial integration and the unit-moment subtraction therefore define that same \(\sigma\) in every chart. This proves the remaining domain-and-compatibility interface of stage (ii).

## 2. Covariance inversion and the actual residual gain

The signed inverse uses the original positive amplitudes. Its local map is

\[
d\Sigma=H^{-1}(\Sigma/\varepsilon),\qquad
\delta a_\sigma=(d\Sigma)_\sigma/(2a_\sigma),
\]

and sends \(\mathcal M_\alpha^{\rm independent}\) to \(\mathcal W_{\alpha-1/2}\). The proved lower bound for \(a_\sigma\), including its shell factor, gives

\[
|D^I\delta a_\sigma|\le
C_I\varepsilon^{\alpha-1}S_*^{P_I}\sqrt\zeta\delta^{-M_I}.
\]

The fixed original envelope restores the required \(P(v)\) factor. The map never takes a square root of a newly perturbed stress. Under the actual squared partition, one label contributes

\[
Q_\beta^{-2A}\eta_\beta^2\,
\mathcal B\big(W_{0,\beta},\mathcal L_\beta(Q_\beta^{2A}\sigma)\big)
=\eta_\beta^2\sigma.
\]

Every product of distinct simultaneously active labels is zero before and after evaluation, including derivative products: their closed supports are disjoint on the common torus. Summing and using \(\sum_\beta\eta_\beta^2=1\) gives the exact physical covariance target \(\sigma\). On the complement of the shell both sides are zero by (GC5). This proves the identity on its full actual domain.

For the complete signed curl increment \(s=t_s+r_s\), put \(\alpha=C-\kappa_s\), \(\rho=0.68\). The uncurled signed field has exponent \(\alpha-1/2=B-\kappa_s\), while its curl remainder has exponent \(\alpha-\kappa_s=C-2\kappa_s\). The complete covariance identity is

\[
\Delta\mathcal C
=\Sigma+\mathcal B(w-w_0^{\rm tan},t_s)
+\mathcal B(w,r_s)+\mathcal C(s).
\tag{GC6}
\]

The three error exponents before divergence are

\[
C+0.18-\kappa_s,\qquad
C+\tfrac12-2\kappa_s,\qquad
2C-1-2\kappa_s=C+\sigma_j-2\kappa_s.
\]

The last expression includes all three terms
\(\mathcal C(t_s)+\mathcal B(t_s,r_s)+\mathcal C(r_s)\).
The weaker radial derivative map costs at most \(\kappa_s\), so the three gains above \(C\) are

\[
0.18-2\kappa_s=0.17998,\quad
\tfrac12-3\kappa_s=0.49997,\quad
\sigma_j-3\kappa_s\ge0.19997.
\]

All exceed \(0.17\). The uncanceled compact bump in the integrated residual has exponent \(C+1-\kappa_s\), also higher. These are the exact exponents of the corrected physical target, so the scope qualification in the covariance audit causes no loss of the stage-(ii) conclusion.

After this step the actual temporal inverse uses

\[
\Delta v=-c^{-1}N^{-1}E_\theta^\circ,\quad
\gamma_d=-c^{-1}N^{-1}E_z^\circ,\quad
\Psi=T_1\gamma_d,
\]
\[
\Delta\beta=-\varepsilon\partial_Z\Psi,\qquad
\Delta\gamma=(D_r+R^{-1})\Psi
=\gamma_d-A_1\gamma_d.
\]

The radial obstruction term is retained in \(\Delta\gamma\), all new quadratic products, and recomputed pressure. Its flatness follows from RF20–RF22 on the same fixed domain. Zero Haar mean implies both original moments stay zero, but is never used as a false assertion that the full characteristic obstruction vanishes. The remaining non-flat residual gains are the displayed stage-(iii) values \(H+1\), \(H+1-\kappa_s\), and \(H+1-2\kappa_s\), where \(H=C-2\kappa_s\). The five-row correction is auxiliary independent, has identically zero axial projector, and leaves defect exponent

\[
H+0.9-2\kappa_s=C+0.9-4\kappa_s.
\]

The exact expressions MC28–MC30 and SI9 retain the pressure-source contribution \(-\tfrac12\int R^2\overline{R_g}\,dR\) in the new \(J_z\). This is necessary for the fifth-row sign \(-\int RV\Delta v\,dR\). It is present in the included proof.

Combining the complete actual substeps yields \(B_{j+1}=B_j+0.1\), \(C_{j+1}=C_j+0.1\). The fixed retained field budgets remain \(\mathcal W_{0.5}\), \(\mathcal W_{0.68}\), \(\mathcal M_{0.9}\), and \(\mathcal M_{1.9}\), because the smallest signed increment is \(B_j-\kappa_s\ge0.69999>0.68\), the temporal increment has \(H\ge1.19998>0.9\), and the radial increments have one additional \(\varepsilon\). The initial values are actually constructed in SI1–SI10; they are not an additional assumed stage.

## 3. The finite stage residual is the physical residual used by summation

The exact evaluation map is

\[
(\mathcal EF)(r,\theta,z,t)=
F(r,\theta,z,t,v_rr^{d_r}+v_tt\bmod\mathbb Z^2).
\]

It preserves products and intertwines \(\partial_t,\partial_r,\partial_z,\partial_\theta\) with \(\mathsf t,\mathsf r,\partial_z,\partial_\theta\). The cylindrical frame derivatives are included in the residual and curl formulas. Iterating the chain rule therefore sends the extended residual identity to the actual Cartesian Navier–Stokes residual. Auxiliary averaging is a separate linear map: the identity
\(\mathcal EF=\mathcal PF+\mathcal E(F-\mathcal J\mathcal PF)\)
retains the nonzero auxiliary part. No physical residual is replaced by its Haar mean.

The actual coefficient invariant SI12 includes the original supports, zero extension, \(\sqrt\zeta\delta^{-d_I}P(v)\), every fixed derivative, and finite harmonics at every stage. Products of same-label waves use \(P^2\le P\); distinct-label products vanish; multiplication by a mean keeps the wave support and envelope. The pulse inverse holds slow and transverse coordinates fixed, so its \(P(v)/P(w)\) kernel cancels exactly the source's \(P(w)\). Radial integration keeps \(q\) fixed, and its count of boxes adds only a polynomial in \(S_*\). These proved operations establish the stated invariant for the actual finite residual graph.

One fixed threshold SI11 serves every stage. The later harmonic propagators satisfy

\[
V_m(v,w)=
\exp\!\left(-(m^2-1)\int_w^v d(s)\,ds\right)V_1(v,w),
\quad |m|\ge1,\quad d>0.
\]

The prefactor has modulus at most one for forward time. Differentiated inhomogeneous ODEs have lower-order parameter derivatives as sources, so fixed derivative estimates change polynomial degrees and constants, not the threshold. The signed covariance map divides only by original amplitudes, and the radial, temporal, pressure, and five-row maps are fixed. This verifies that the physical domain is one positive \(q_{\rm big}\), not an unverified intersection of shrinking stage domains.

At fixed physical derivative order, the exact conversion costs at most

\[
\partial_r:\tfrac12+h\kappa_s,\quad
\partial_z:\tfrac12-h,\quad
\partial_t:1+h,\quad
\text{frame}:\tfrac12.
\]

Phase differentiation is dominated by
\(s_x=1/2+h/2\), \(s_t=1+3h/2\), since
\(k=\lceil\varepsilon^{-1/2}\rceil\le2\varepsilon^{-1/2}\).
Every fixed coefficient derivative obeys the same coefficient exponent; the additional input derivative counts in an inverse affect only the fixed-stage constant and polynomial \(S_*\) power. Thus a finite-stage-dependent derivative graph does not create a stage-dependent physical power loss. With

\[
\ell_m=2A+(m+1)(1+3h/2),\qquad g_j=hj/10,
\]

the representatives obey (9.17), and the residual conversion has the fixed factor \(Q^{-2A-1/2}\). The wave exponent \(B_j=1/2+\sigma_j\), the mean exponent \(C_j=1+\sigma_j\), and the compact radial defect all dominate the common retained exponent \(\sigma_j\). Consequently one obtains exactly (9.18):

\[
|\mathcal R(u^{[j]},p^{[j]})|_m
\le C_{j,m}q^{h\sigma_j-K_m}
(1+|\log q|)^{P_{j,m}}+E_{j,m},
\quad |E_{j,m}|\le C_{j,m,N}q^N,
\tag{GC7}
\]

where \(K_m\) is independent of \(j\). Here the logarithmic factor multiplies the preceding \(q\)-term, exactly as in (9.18); the displayed line break is not an additional summand. Every flat contribution comes from the actual base residual, terminal pulse cutoff, radial projector, or a product with one such factor. At fixed order its physical derivative has the form \(CQ^{-M}S_*^b e^{-c\ell^2}\), or the arbitrary-order RF22 estimate. The exponent identity
\(-c\ell^2+(M+N)\ell\log2+2b\log\ell\to-\infty\)
proves the first kind is \(O(q^N)\) for every \(N\); the flat ideal proof in SI12 handles all products. Thus (GC7) is supplied by the included actual construction, rather than only by an exponent calculation at one label.

## 4. The exact representative sum and terminal residual

For \(j\ge1\), use the actual physical representatives

\[
A_j=A_j^w+\Psi_je_\theta,\quad B_j=b_je_\theta,
\quad p_j=p^{[j]}-p^{[j-1]},
\quad\Delta u_j=\operatorname{curl}A_j+B_j.
\]

The direct scalar \(b_j\) is independent of \(\theta\). Let \(\chi=1\) for positive arguments at most \(1/2\), \(\chi=0\) for arguments at least one, and retain the actual diagonal scales \(a_j\). The actual cut increment is

\[
V_j=\operatorname{curl}(\chi(a_jq)A_j)+\chi(a_jq)B_j
=\chi(a_jq)\Delta u_j+a_j\chi'(a_jq)\nabla q\times A_j,
\]
\[
\Pi_j=\chi(a_jq)p_j.
\tag{GC8}
\]

The exact similarity map gives
\(\partial_z^a\partial_t^bq=q^{1-aD-b}F_{a,b}(\eta)\),
with \(F_{a,b}\) smooth on \([-1,1]\) because \(L\ge1-2h>0\).
Every nonzero differentiated cutoff term contains

\[
a_j^k\chi^{(k)}(a_jq)
\prod_{\nu=1}^k\partial_z^{a_\nu}\partial_t^{b_\nu}q,
\qquad \sum a_\nu=a,\quad\sum b_\nu=b.
\]

On its support \(a_jq\in[1/2,1]\); the product's factor \(q^k\) pairs with \(a_j^k\). Therefore the exact derivative loss is \(aD+b\), independent of \(a_j\). Leibniz applied to (GC8) supplies a common loss

\[
L_m=\ell_{m+1}+m+1
\]

for \(|(V_j,\Pi_j)|_m\). The finite scale inequalities at index \(j\) give

\[
|(V_j,\Pi_j)|_m\le2^{-j}q^{g_j/2-L_m},\qquad m\le j.
\tag{GC9}
\]

Their existence is proved by \(q^\gamma(1+|\log q|)^P\to0\) for each fixed \(\gamma>0\), imposing finitely many conditions at each \(j\), and \(a_j\ge2a_{j-1}\). These are one selected sequence of scales, not a sequence reselected for each output derivative.

On every compact positive-\(q\) set only finitely many summands survive. The sum is therefore a smooth actual physical field. Divergence of each curl is zero. Also \(\nabla\chi(a_jq)\) has only an axial component and \(B_j\) has only an angular component; hence its divergence is \(r^{-1}\partial_\theta(\chi(a_jq)b_j)=0\). Smooth Cartesian extension proves the identity at the axis.

For fixed \(J\ge m\) and \(q<(2a_J)^{-1}\), the first \(J\) cutoffs and all their derivatives equal the uncut prefix. Thus

\[
e_J:=(u_{\rm loc},p_{\rm loc})-(u^{[J]},p^{[J]}),
\quad |e_J|_m\le2^{-J}q^{g_{J+1}/2-L_m}.
\tag{GC10}
\]

Write \(e_J=(v_J,\pi_J)\). The exact nonlinear residual difference is

\[
\partial_tv_J-\Delta v_J+\nabla\pi_J
+(u^{[J]}\cdot\nabla)v_J+(v_J\cdot\nabla)u^{[J]}
+(v_J\cdot\nabla)v_J.
\tag{GC11}
\]

Its order-\(m\) bound is
\(C_m|e_J|_{m+2}(1+|u^{[J]}|_{m+2}+|e_J|_{m+2})\).
For given \(m,N\), choose one finite \(J\ge m+2\) so that

\[
g_{J+1}/2-L_{m+2}>N+K_{m+2}+2,\qquad
h\sigma_J-K_m>N+1.
\]

Both left sides tend to infinity with \(J\). Keep that stage fixed thereafter. Its finite logarithmic powers are \(O(q^{-1})\). Equations (GC7), (GC10), and (GC11) then give

\[
|\mathcal R(u_{\rm loc},p_{\rm loc})|_m=O(q^N).
\tag{GC12}
\]

Only the flat estimate of that one selected stage is used. No summation of its stage residuals or uniform bound in \(j\) on the flat constants is required.

## 5. Representatives, endpoint jets, localization, and the classical equation

The actual base potential is \(S e_\theta/r\), where

\[
S_n=q^{1-A+2nh}\int_0^XU_n(X',\eta)\,dX'.
\]

The zero full radial moment of each \(U_n\) makes this potential zero beyond its common axial support. Near the axis it is \(a(r^2,z,t)(-x_2,x_1,0)\), hence smooth Cartesian. Wave potentials are annular; mean potentials vanish outside the radial source and the fixed interior subtraction region. The diagonal stage sum is locally finite on \(q\ge c>0\). Each of these actual representatives, not just its curl, has every fixed one-sided derivative on \(-1\le\eta\le1\), after the proved base/pulse regularity and the fixed linear mean maps. Coordinate conversion has no divisor \(1-\eta^2\). Bounding one additional derivative and integrating it gives uniform Cauchy convergence of each derivative as \(t\uparrow1\) on such compact sets. Spatial segment integration identifies the limiting spatial derivatives; time integration identifies successive time jets.

For \(r>0\) and small \(q\), the exact exterior is

\[
K(r,\tau)=r^{-1-2h}H_{\rm ext}(\tau/r^2),
\quad H_{\rm ext}(s)=2^Ac_\infty H(4s),
\]
\[
H(Z)=\Gamma(1+h)^{-1}\int_0^\infty
e^{-v}v^h(1+Zv)^{-h}\,dv,
\qquad
p_{\rm ext}=-\int_r^\infty K(\rho,\tau)^2\,d\rho/\rho.
\]

The \(m\)-th derivative integrand has factor
\((-1)^m(h)_mv^m(1+Zv)^{-m}\), so its common integrable bound gives

\[
\sup_{s\ge0}|H_{\rm ext}^{(m)}(s)|
\le2^Ac_\infty4^m(h)_m(1+h)_m.
\]

The full pressure product rule is bounded by \(C_j\rho^{-3-4h-2j}\), integrable for positive lower radius. It permits all time derivatives through the pressure integral, uniformly including \(\tau=0\). The lower endpoint gives \(\partial_rp_{\rm ext}=K^2/r\), cancelling the radial convection \(-K^2/r\); the exact heat equation cancels the angular residual; the axial residual is zero. Thus the exact representative endpoint coverage includes \(z=0,r>0\), where \(q\to0\), as well as \(z\ne0\), where \(q\ge|z|^{1/D}>0\).

With the actual compact cutoffs \(c=\chi_x\chi_t\), localization is

\[
u=\operatorname{curl}(c\mathcal A)+cBe_\theta
=cu_{\rm loc}+\nabla c\times\mathcal A,
\qquad p=cp_{\rm loc}.
\tag{GC13}
\]

The support lies strictly inside the positive local-domain margin. Define the actual force by

\[
f=\partial_tu+(u\cdot\nabla)u-\Delta u+\nabla p.
\tag{GC14}
\]

Every cutoff derivative and quadratic interaction in (GC13) is part of this identity. Near the singular point \(c=1\); (GC12) applies in the bounded profile region and the exterior residual is exactly zero. The exact elementary bound
\(q\le C_0(\tau+|z|^{1/D})\)
therefore makes every force derivative tend to zero at \((0,1)\). On the rest of the fixed compact support, the proved one-sided representative bounds give uniform limits. Hence every terminal jet
\(F_j=\lim_{t\uparrow1}\partial_t^jf\)
belongs to \(C_c^\infty(K;\mathbb R^3)\), and mixed spatial derivatives are the limits of the corresponding derivatives of \(f\).

The actual extension is

\[
f(x,1+\sigma)=\sum_{j\ge0}\chi_0(b_j\sigma)
\frac{\sigma^j}{j!}F_j(x),\qquad\sigma\ge0.
\]

The exact differentiated cutoff-monomial estimate is

\[
\left\|\partial_x^\alpha\partial_\sigma^m
\left(\chi_0(b\sigma)\frac{\sigma^j}{j!}F_j\right)\right\|_\infty
\le\left(\sum_{\substack{0\le a\le m\\m-a\le j}}
\binom ma\frac{\|\chi_0^{(a)}\|_\infty}{(j-m+a)!}\right)
b^{m-j}\|F_j\|_{C^{|\alpha|}}.
\]

Choosing the least increasing integers satisfying the finite bounds E.11 makes every differentiated tail uniformly summable. At \(\sigma=0\) the \(m\)-th derivative has exactly the \(j=m\) contribution \(F_m\). This proves joint smooth gluing and \(f\in C_c^\infty(\mathbb R^3\times(0,\infty);\mathbb R^3)\). The trace theorem T.1–T.9 proves the exact relation to any other extension with these jets: the difference is in the closed kernel of the trace, smooth and flat at the terminal slice. It does not assert equality of the later forces or a positive gap in their supports. The continuous linear isomorphism is the quotient map, and the included scaling argument correctly rules out a continuous linear section of the full jet space.

The compact support before time one justifies the exact energy identity

\[
\tfrac12\frac d{dt}\|u(t)\|_2^2+\|\nabla u(t)\|_2^2
=\langle f(t),u(t)\rangle.
\]

Writing \(F(t)=\int_0^t\|f(s)\|_2ds\) and dividing first by
\((\|u\|_2^2+\delta^2)^{1/2}\), then letting \(\delta\downarrow0\), gives \(\|u(t)\|_2\le F(t)\). Integrating the original identity gives

\[
\|u(t)\|_2^2+2\int_0^t\|\nabla u(s)\|_2^2ds\le F(t)^2.
\]

Thus both energy and total dissipation are bounded up to time one. The whole-space comparison proof was read through E.22: its harmonic pressure-gradient ambiguity is removed in \(H^{-3}\), its localized commutator kernel has \(L^{4/3}\)-norm \(O(R^{-3/4})\), and its pressure and convection fluxes are absorbed into localized dissipation. The final estimate \(E_R(t)\le C_T/R\) proves equality with every smooth finite-energy competitor on \([0,T]\), \(T<1\), without an added pressure condition at infinity.

The actual unchanged inner path has

\[
x_\tau=(\sqrt{2X_{\rm in}\tau},0,0),\qquad
u_\theta(x_\tau,1-\tau)=\tau^{-A}(e_0+O(\tau^{2h})),\quad e_0>0.
\]

Both localization cutoffs are one there and all annular corrections vanish. The positive-order base cutoff sum is included in the error. For small \(\tau\), the bracket is at least \(e_0/2\), proving divergence along points approaching the origin. The comparison estimate would force any global smooth finite-energy competitor to have these values, contradicting its continuity on a compact neighborhood of \((0,1)\).

The viscosity map E.24 and parabolic map E.26 were checked on the complete triple. In particular
\(\mathscr T_\nu=\mathscr S_{\sqrt\nu}\circ\mathscr A_\nu\)
has prefactors \((\nu,\nu^2,\nu^2)\), time argument \(\nu t\), and energy factor \(\nu^2\). Periodization E.29–E.30 has disjoint compact translated supports, so every convection cross term is zero. It preserves the original unit periods of velocity, pressure, and force and transfers the actual divergent path with factor \(\lambda\sqrt\nu\). No relation between independently chosen analytical and formal representative sequences is inferred from these exact adapters.

## 6. Audited conclusion and remaining integration record

The corrected physical signed-stress domain is satisfied by the actual stage-(ii) stress; (GC1)–(GC5) are a complete proof of that interface. The downstream finite-stage, physical evaluation, shrinking-cutoff, representative endpoint, compact force extension, comparison, and periodization interfaces close with the original objects. No still-unproved new analytic assertion was found in those interfaces. Standard analytical background results explicitly used by the reader (the inverse-function theorem, the classical three-dimensional Sobolev inequality, and the classical Riesz-transform bounds) remain visible uses of established theorems; this statement does not claim that their foundational proofs are included in the 162-page reader.

The independent base/pulse conclusion and any concrete wording repairs are to be read in `base_pulse/`; the final combined audit records that result separately. The analytical proof-map assessment is not a Lean kernel certificate, a validation of every source revision, or a theorem inferred from symbolic replay counts.

# Complete ambient projection and both directions of the coordinate equation

Retain the actual nonzero real normal \(n_\Phi\), the actual tangential frame
\(K_a,N_a\), the original reference coordinate \(s(v)\), and the same matrix
\(\mathcal A_\Phi\) and damping \(d\) from the full pulse audit. With
\[
U=[e_r-s_aK_a,N_a],\qquad
M=\begin{pmatrix}1&1\\c_0\sqrt{1+s^2}&-c_0\sqrt{1+s^2}\end{pmatrix},
\qquad B=UM,\quad B^\ell=M^{-1}(e_r^T;N_a^T),
\]
the determinant \(-2c_0\sqrt{1+s^2}\) is nonzero by the original compact
cone. The full equation and its pressure have already been proved with
the original \(m\in\mathbb Z\setminus\{0\}\), \(k\ge1\), and right side
\(-f_m\). The following calculation proves the ambient map and the
converse of the coordinate transformation without extending a right-inverse
identity beyond its exact domain.


For clarity the ambient map also has an exact formula. Regard \(K_a\)
as the three-vector with zero radial component, and let
\(W_a=(e_r^T;N_a^T)\). Direct multiplication gives \(W_aU=I_2\).
For any \(w=w_re_r+w_KK_a+w_NN_a\in\mathbb C^3\),
\[
BB^\ell w=UW_aw=w_r(e_r-s_aK_a)+w_NN_a
=w-K_a(w_K+s_aw_r).
\]
Since \(n_\Phi=|n_{\Phi,\tan}|(s_ae_r+K_a)\), this proves
\[
B^\ell B=I_2,\qquad
BB^\ell=I_3-\frac{K_an_\Phi^T}{|n_{\Phi,\tan}|}.
\]
Thus \(BB^\ell\) is the projection onto \(n_\Phi^\perp\)
along \(\operatorname{span}_{\mathbb C}\{K_a\}\). Its restriction
to \(n_\Phi^\perp\) is the identity; its action on \(K_a\) is zero.
In particular the inverse assertion is not made on all of \(\mathbb C^3\).

The moving-plane differential equation has the exact coordinate form
\[
z_m'=B^\ell(\mathcal A_\Phi B-B')z_m-m^2dz_m
-B^\ell\operatorname{proj}_{n_\Phi^\perp}f_m.
\]
For its converse, differentiate \(n_\Phi^TB=0\) to obtain
\(n_\Phi^TB'=-(n_\Phi')^TB\). The definition of
\(\mathcal A_\Phi\) gives
\(n_\Phi^T\mathcal A_\Phi B=-(n_\Phi')^TB\).
Therefore each column of \(\mathcal A_\Phi B-B'\) lies in
\(n_\Phi^\perp\). Both \(Bz_m\) and the projected force lie there
as well. Multiplying the coordinate equation by \(B\) and using
\(BB^\ell=I\) on these three terms yields
\[
Bz_m'=(\mathcal A_\Phi B-B')z_m-m^2dBz_m
-\operatorname{proj}_{n_\Phi^\perp}f_m.
\]
Adding \(B'z_m\) proves the projected equation for \(t_m=Bz_m\),
and \(n_\Phi^Tt_m=0\) holds by construction. The displayed pressure
then recovers the full equation with its actual normal forcing.
Conversely, a constrained solution has \(z_m=B^\ell t_m\) and
\(t_m=Bz_m\). Differentiating the latter identity and multiplying
the projected equation by \(B^\ell\) gives exactly the coordinate
equation above. Both inverse compositions, including their initial
data and the unique pressure, are therefore proved.

# Combined analytic interface disposition

The original leading profiles, positive-order background, auxiliary geometry, pulse, covariance, correction cycle, representative sum, and force extension are the constructed objects retained in the accompanying full derivations. The original source is the 165-page edition with SHA-256 `8c8a94ad9ac824c8b605b9827cadf7beaca48bd10b380de3cfc872a2c37afa81`. The 166-page revision is a distinct source. Neither the interfaces proved here nor the preservation of an earlier reader identifies those editions.

The full base audit proves the common-radius solution map from finalized lower coefficients to each positive order, its exact five moments and common compact support, the integrated stress with its original edge weight, the Borel potential cutoff with its radial derivative term, the exact chart powers, and the full reserved interval. The full pulse audit proves the phase and transport formulas, pressure sign, the constrained evolution and harmonic propagator, all fixed derivative classes and supports, the homogeneous lower bound, and the covariance integral with its angular half and original Jacobian. The full downstream audit proves the exact physical stress-domain morphism, complete signed-curl errors and stage gains, physical residual evaluation, the one-selected-stage realization comparison, endpoint representative and force jets, and the original comparison, viscosity and periodization maps. These derivations are reproduced in full, rather than replaced by this disposition.

The literal frozen-shear production equality has been corrected in every affected live component copy. The retained term is \(-(g-g_0)\cdot T\), which may remain nonzero even at the representative. The appended complete actual-shear calculation establishes the first-radial-jet coordinate isomorphism and both inverses, the full force-pressure bijection using the same actual phase, and the explicit positivity bounds from the actual homogeneous pulse polarization. Positive shear production is not a claim that the damped energy derivative is positive. The exact polynomial coefficient-product estimate for \(bn_{\Phi,r}\) is propagated at the same time. The completed coordinate converse uses the explicitly computed projection \(I_3-K_an_\Phi^T/|n_{\Phi,\tan}|\), whose kernel is the original tangential direction and whose restriction to the constrained plane is the identity.

The first-jet and actual-shear force-pressure derivations (AS1)-(AS40) are reproduced with attribution to the independent source-comparison lane's note, *Actual shear, frozen leading shear, and the exact pulse force-pressure correspondence*. The present continuation checked those formulas, propagated their correction, and added the full ambient-projection and coordinate converse. Independent reviews identify their exact source hashes. This attribution distinguishes mathematical derivation from later source propagation.

No additional unresolved analytical assertion was identified in the bounded interfaces actually audited. The concrete corrections above are proved and integrated into the live components. This disposition does not turn a source ledger, symbolic execution count, or earlier publication into a proof. In particular, the inverse-function theorem, the classical three-dimensional Sobolev inequality, and the classical Riesz-transform bounds remain named established analytical inputs of the cumulative construction; their foundational proofs are not supplied by this audit. No Lean certificate is asserted, and this standalone interface document is not a substitute for the complete original-component proofs included in the cumulative reader.

The published earlier edition remains immutable. Its historical sentence is an identified correction for a later edition, not a retroactive edit. The durable source-change receipt records the six live component repairs, their exact preimages and postimages, and the unchanged protected objects. Cumulative integration and verification of the new edition remain distinct recorded tasks until their own build and review receipts are complete.
