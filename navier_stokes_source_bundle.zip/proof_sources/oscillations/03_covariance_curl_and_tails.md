# Covariance, signed stress increments, exact curls, and cutoff residuals

This file gives direct proofs for source pp. 81-87, Propositions 7.5-7.6, Lemma 7.7, and Corollary 7.8. The background inputs and pulse estimates are recorded and derived in the preceding files. All averages below are on the extended domain at fixed slow coordinates, before physical evaluation.

## Two columns and their positive coefficients

For real extended vector fields define
\[
\mathcal C(w)=\langle\langle w_rw_{\tan}\rangle_\theta\rangle_Y,\qquad
\mathcal B(w,v)=
\langle\langle w_rv_{\tan}+v_rw_{\tan}\rangle_\theta\rangle_Y,
\quad w_{\tan}=(w_\theta,w_z).
\]
Expanding the product proves \(\mathcal C(w+v)=\mathcal C(w)+\mathcal B(w,v)+\mathcal C(v)\) and \(D\mathcal C(w)[v]=\mathcal B(w,v)\). These maps preserve the original component order \((r\theta,rz)\).

For a slow box \(\beta=(\ell,a)\), its two signs have disjoint auxiliary rectangles and the same slow cutoff. Write
\[
b_\sigma=\chi_g(\xi_g)\psi(v)t_\sigma^h\cos(k\Phi_\sigma),\qquad
H=[\mathcal C(b_+)\mid\mathcal C(b_-)].
\]
Each \(b_\sigma\) is extended by zero outside its rectangle, using its smooth transverse and temporal cutoffs. The integer \(kp\ne0\) ensures that
\[
\frac1{2\pi}\int_0^{2\pi}\cos^2(k\Phi_\sigma)\,d\theta=\frac12
\]
exactly, whatever the non-angular part of the phase. Haar pullback permits averaging on the band torus. The coordinate map \((\xi_g,\eta_g)\mapsto c_\gamma+\xi_gv_r+\eta_gv_t\) has the retained Jacobian \(|\det(v_r,v_t)|=1+b_g^2\), and \(d\eta_g=c_i\,dv\). The homogeneous amplitude is independent of \(\xi_g\), since its ODE coefficients depend on slow coordinates and \(v\), and its initial value is fixed with the label. With radial component \(x\), this gives
\[
H_\sigma=D_g c_i\int_0^{L_s}\psi^2x\,t_{\sigma,\tan}^h\,dv,\qquad
h_\sigma=D_g c_i\int_0^{L_s}\psi^2x^2\,dv,
\]
\[
D_g=\frac{|\det(v_r,v_t)|}{2}\int_{\mathbb R}\chi_g(\xi)^2\,d\xi>0.
\]
Thus the angular factor \(1/2\), the rectangular Jacobian, the time measure \(c_i\,dv\), and the transverse cutoff integral are all present.

The proved bounds \(cP\le x\le CP\) and \(P(v)\asymp\exp(-c(v-L_s/2)^2/L_s)\), with separate upper and lower constants, imply
\[
c\sqrt{L_s}\le\int_0^{L_s}\psi^2x^2\,dv\le C\sqrt{L_s}.
\]
For the lower bound, integrate over \(|v-L_s/2|\le\sqrt{L_s}\), which lies in the region \(\psi=1\) for all sufficiently large \(L_s\); \(P\) there has a fixed positive lower bound. The upper bound follows by extending the Gaussian integral to \(\mathbb R\). The same substitution \(w=(v-L_s/2)/\sqrt{L_s}\) proves
\[
\int_0^{L_s}\frac{|v-L_s/2|}{L_s}\psi^2x^2\,dv\le C.
\]
It follows that \(h_\sigma\asymp c_i\sqrt{L_s}\asymp S_*^{-1/2}\), and the probability measure proportional to \(\psi^2x^2\,dv\) has expectation of \(|v-L_s/2|/L_s\) at most \(CS_*^{-1/2}\).

Since \(t_{\sigma,\tan}^h/x=-s_aK_a+(y/x)N_a\), the previous file proves its uniform difference from \(-s(v)K+c_0\sqrt{1+s(v)^2}N\) is \(O(S_*^{-1})\). The latter function is Lipschitz in \(s\) on the fixed compact range, and \(|s(v)-\sigma u_*|=u_*|v-L_s/2|/L_s\). Taking the weighted average therefore gives
\[
H_\sigma=h_\sigma(-A_cN-\sigma u_*K+e_\sigma),\quad
A_c=-c_0\sqrt{1+u_*^2}>0,\quad |e_\sigma|\le CS_*^{-1/2}.
\]
Every fixed slow derivative of \(H_\sigma\) is polynomially bounded: differentiate the finite integral using the already proved pulse derivatives, fixed \(L_s\), and fixed label cutoffs. None of these parameter derivatives differentiates a discrete label or moves the integration endpoints.

In coordinates \(N,K\), omit \(e_\sigma\) temporarily and solve the exact two-by-two system:
\[
h_+y_+=\frac12(-T_N/A_c-T_K/u_*),\qquad
h_-y_-=\frac12(-T_N/A_c+T_K/u_*).
\]
The cone choice made in the previous file gives a fixed \(\eta_c>0\) such that
\[
\frac{|T_K|}{u_*}\le(1-\eta_c)\frac{-T_N}{A_c},
\qquad T=T_{0,*}.
\]
Since \(N,K\) are orthonormal and \(T_N<0\), this also gives \(-T_N\ge c|T|\). Hence the two displayed reference coefficients are at least \(c|T|\) and at most \(C|T|\).

The reference column matrix in these coordinates is
\[
H_{\rm ref}=
\begin{pmatrix}-A_ch_+&-A_ch_-\\-u_*h_+&u_*h_-\end{pmatrix},
\quad
\det H_{\rm ref}=-2A_cu_*h_+h_-.
\]
Writing \(H=(H_{\rm ref}\operatorname{diag}(h_+^{-1},h_-^{-1})+
\mathcal E)\operatorname{diag}(h_+,h_-)\), the first factor differs from a fixed invertible matrix by \(O(S_*^{-1/2})\). For \(\|H_0^{-1}\mathcal E\|<1/2\), the exact inverse of
\(I+H_0^{-1}\mathcal E\) is the convergent series
\(\sum_{n=0}^{\infty}(-H_0^{-1}\mathcal E)^n\).
Indeed multiplication of its finite partial sum through \(n=N\) by
\(I+H_0^{-1}\mathcal E\), in either order, gives
\(I-(-H_0^{-1}\mathcal E)^{N+1}\), and the last power tends to zero.
The sum has norm at most \(2\), and its difference from \(I\) has norm
at most \(2\|H_0^{-1}\mathcal E\|\), by the geometric-series bounds.
Thus the exact first-factor inverse is
\((I+H_0^{-1}\mathcal E)^{-1}H_0^{-1}\); the original diagonal
\(\operatorname{diag}(h_+,h_-)^{-1}\) remains on its left. The coefficient perturbation is then bounded by \(CS_*^{-1/2}|T|\) before dividing by \(h_\sigma\). For a further fixed lower band threshold, it is smaller than half the positive reference coefficient margin. Therefore
\[
|\det H|\ge c/S_*,\quad \|H^{-1}\|\le C\sqrt{S_*},\quad
c\sqrt{S_*}|T_{0,*}|\le y_\sigma\le C\sqrt{S_*}|T_{0,*}|,
\quad y=H^{-1}T_{0,*}.
\]
This proves positivity uniformly up to limiting stress directions at the shell edges. At an edge the actual target is zero; the positive inequalities for \(y\) are asserted in the open shell.

The background profile theorem gives \(|T_{0,*}|\ge c\zeta\) and \(|D^IT_{0,*}|\le C_I\zeta\delta^{-a_I}\), using the exact chart/profile transition from the first file. Differentiating \(HH^{-1}=I\) expresses each fixed derivative of \(H^{-1}\) as a finite sum of products of \(H^{-1}\) and derivatives of \(H\), hence gives polynomial \(S_*\) bounds. Leibniz's rule proves
\[
y_\sigma\ge c\sqrt{S_*}\zeta,\qquad
|D^Iy_\sigma|\le C_IS_*^{b_I}\zeta\delta^{-a_I}.
\]
For \(a_\sigma=\sqrt{y_\sigma}\), every derivative of positive order is a finite sum
\[
c\,y_\sigma^{1/2-n}\prod_{\nu=1}^nD^{I_\nu}y_\sigma,
\qquad |I_\nu|\ge1,\quad \sum I_\nu=I.
\]
The numerator contributes \(\zeta^n\), while the inverse power contributes \(\zeta^{1/2-n}\); the product has exactly the remaining \(\sqrt\zeta\). The \(S_*\)-powers and inverse edge-distance powers are finite at every fixed order. The value bound uses the upper bound for \(y_\sigma\). Thus
\[
|D^Ia_\sigma|\le C_IS_*^{b'_I}\sqrt\zeta\,\delta^{-a'_I},
\]
which proves smooth zero extension of every coefficient at both shell edges.

Set \(W_0=\sqrt\varepsilon\sum_{\sigma=\pm}a_\sigma b_\sigma\). The two disjoint supports remove the cross products, and the scalar amplitudes are independent of both averaging variables. Consequently
\[
\mathcal C(W_0)=\varepsilon H(a_+^2,a_-^2)^T
=\varepsilon T_{0,*}
\]
exactly. The pulse and square-root estimates give the local \(\mathcal W_{1/2}\) bounds. Multiplying by \(\eta_\beta\) gives the required slow support.

The physical covariance of the assembled field is obtained with the original factors:
\[
Q^{-2A}\varepsilon T_{0,*}
=Q^{-2A+h}(Q/q)^{A+1/2}T_0
=Q^{-A+h+1/2}q^{-A-1/2}T_0
=q^{-A-1/2}T_0.
\]
The final equality uses \(A=1/2+h\). Each physical slow point has bounded overlap, and cross-label products vanish. Summing the squared partition \(\sum_\beta\eta_\beta^2=1\) therefore supplies precisely the leading physical stress, with the sign suitable to cancel the negative stress divergence in Proposition 5.5.

## Signed differential inverse and assembly across bands

Let \(\Sigma(R,Z,T)\) be a real auxiliary-independent two-vector in \(\mathcal M_\alpha\). Keep the previously chosen positive amplitudes fixed. Define
\[
d_\Sigma=H^{-1}(\Sigma/\varepsilon),\qquad
\delta a_\sigma=(d_\Sigma)_\sigma/(2a_\sigma),\qquad
\mathcal L\Sigma=\sqrt\varepsilon\sum_{\sigma=\pm}\delta a_\sigma b_\sigma.
\]
Here the division is taken only on the open shell before smooth zero extension. Every derivative of \(y_\sigma^{-1/2}\) is a finite sum
\[
c\,y_\sigma^{-n-1/2}\prod_{\nu=1}^nD^{I_\nu}y_\sigma,
\]
so it has the weight \(\zeta^{-1/2}\) with allowed polynomial and edge-distance factors. Since \(d_\Sigma\) has weight \(\varepsilon^{\alpha-1}\zeta\), the product defining \(\delta a_\sigma\) has
\[
|D^I\delta a_\sigma|
\le C_I\varepsilon^{\alpha-1}S_*^{b_I}\sqrt\zeta\,\delta^{-a_I}.
\]
This proves smooth zero extension and the local \(\mathcal W_{\alpha-1/2}\) bound for \(\mathcal L\Sigma\), with the envelope supplied by \(b_\sigma\).

Disjointness and the retained bilinear factor two give
\[
\mathcal B(W_0,\mathcal L\Sigma)
=\varepsilon H(2a_+\delta a_+,2a_-\delta a_-)^T
=\Sigma.
\]
This is an exact linear right inverse of \(D\mathcal C(W_0)\), without positivity or smallness assumptions on \(\Sigma\). It is not an exact nonlinear inverse: the retained identity is
\[
\mathcal C(W_0+\mathcal L\Sigma)
=\varepsilon T_{0,*}+\Sigma+\mathcal C(\mathcal L\Sigma).
\]
The last term lies in \(\mathcal M_{2\alpha-1}\), as both wave coefficients have exponent \(\alpha-1/2\) and the product has the mean weight \(\zeta\).

For a real physical auxiliary-independent stress \(\sigma(r,z,t)\)
supported in the active shell, whose representatives
\(Q_\beta^{2A}\sigma\) belong to the stated local \(\mathcal M_\alpha\)
domain, use the source's assembled maps. This domain includes every fixed
derivative bound with the weight \(\zeta\delta^{-a_I}\), compatibility on
overlapping charts, and smooth zero extension at the shell edges. The
previously chosen positive amplitudes remain fixed. The following identity
holds throughout the active partition domain and extends by zero outside it
because the input stress vanishes there:
\[
W_{0,\rm phys}^{\rm as}
=\sum_\beta Q_\beta^{-A}\eta_\beta W_{0,\beta},\qquad
\mathcal L_{\rm phys}^{\rm as}\sigma
=\sum_\beta Q_\beta^{-A}\eta_\beta
\mathcal L_\beta(Q_\beta^{2A}\sigma).
\]
The different \(Q_\beta\) are retained. The contribution of box \(\beta\) to the bilinear covariance is
\[
Q_\beta^{-2A}\eta_\beta^2Q_\beta^{2A}\sigma
=\eta_\beta^2\sigma.
\]
There are no cross-box terms, so summation gives \(\mathcal B(W_{0,\rm phys}^{\rm as},\mathcal L_{\rm phys}^{\rm as}\sigma)=\sigma\). In a reference chart of scale \(Q\), the representatives are
\[
W_0^{\rm as}=Q^AW_{0,\rm phys}^{\rm as},\quad
\mathcal L^{\rm as}\Sigma=Q^A\mathcal L_{\rm phys}^{\rm as}(Q^{-2A}\Sigma).
\]
Thus the exact chart identity is \(\mathcal B(W_0^{\rm as},\mathcal L^{\rm as}\Sigma)=\Sigma\). Overlapping \(Q_\beta/Q\) lie between fixed positive bounds, so chart changes preserve all claimed exponents; the bounded covering changes preserve derivatives and averages. Equal label-harmonic contributions are collected before class membership is tested. Auxiliary independence of \(\Sigma\) is essential to taking the amplitudes outside the integral and is explicitly a hypothesis here.

## Curl identity with all cylindrical terms

The normalized cylindrical curl is
\[
\operatorname{curl}_*A=
\left(R^{-1}\partial_\theta A_z-D_zA_\theta,\,
D_zA_r-D_rA_z,\,
(D_r+R^{-1})A_\theta-R^{-1}\partial_\theta A_r\right).
\]
For a smoothly supported \(t_m\in\mathcal W_\alpha\) with \(n_\Phi\cdot t_m=0\), put
\[
C_m=\frac{i\,n_\Phi\times t_m}{km|n_\Phi|^2},
\quad A_m=C_me^{ikm\Phi}.
\]
Using the right-handed \((e_r,e_\theta,e_z)\) orientation, the exponential differentiation contributes
\[
ikm\,n_\Phi\times C_m
=-\frac{n_\Phi\times(n_\Phi\times t_m)}{|n_\Phi|^2}
=t_m-\frac{n_\Phi(n_\Phi\cdot t_m)}{|n_\Phi|^2}=t_m.
\]
The exact remainder is
\[
r_m=\left(-D_z(C_m)_\theta,\,
D_z(C_m)_r-D_r(C_m)_z,\,
(D_r+R^{-1})(C_m)_\theta\right).
\]
The multiplier \(n_\Phi/|n_\Phi|^2\) has all polynomial coefficient bounds. Hence \(C_m\in\mathcal W_{\alpha+1/2}\), and \(r_m\in\mathcal W_{\alpha+1/2-\kappa_s}\). The less costly \(D_z\) and frame terms satisfy the same weaker common bound. Supports are preserved by local differentiation and smooth extension.

For any smooth normalized vector potential, retain
\[
\operatorname{div}_*a=(D_r+R^{-1})a_r+R^{-1}\partial_\theta a_\theta+D_za_z.
\]
Because \(D_r(R^{-1})=-R^{-2}\), one has \((D_r+R^{-1})(R^{-1}f)=R^{-1}D_rf\). Substitution of the three curl entries gives the six terms
\[
R^{-1}D_r\partial_\theta A_z
-(D_r+R^{-1})D_zA_\theta
+R^{-1}D_z\partial_\theta A_r
-R^{-1}\partial_\theta D_rA_z
+D_z(D_r+R^{-1})A_\theta
-R^{-1}D_z\partial_\theta A_r.
\]
They cancel in pairs by the commuting coordinate derivations and \(D_z(R^{-1})=0\). Thus divergence of the exact curl vanishes. The pullback intertwining proved in the first file transfers this identity exactly to physical space.

For the full amplitude \(a_m=t_m+r_m\), its coefficient is angular-independent. Expanding the divergence of \(a_me^{ikm\Phi}\) proves
\[
ikm\,n_\Phi\cdot a_m
=-\big((D_r+R^{-1})(a_m)_r+D_z(a_m)_z\big).
\]
The scalar \(n_\Phi\cdot a_m=n_\Phi\cdot r_m\) belongs to \(\mathcal W_{\alpha+1/2-\kappa_s}\), since \(n_\Phi\cdot t_m=0\) and the full phase vector has polynomial coefficient bounds. The displayed left side includes the additional factor \(ikm\), with \(k=O(\varepsilon^{-1/2})\) and fixed nonzero harmonic \(m\); its class is therefore \(\mathcal W_{\alpha-\kappa_s}\). This is also the class supplied by the amplitude derivative on the right. In particular, the complete amplitude is not asserted to be transverse: its retained longitudinal component is precisely what the divergence identity controls. Physical vector potentials are \(Q^{1/2-A}A_*\), because physical curl contributes \(Q^{-1/2}\); physical pressures are \(Q^{-2A}p_*\). These factors give exactly the prescribed physical velocity and normalized pressure.

Real waves use conjugate harmonic pairs. For real \(t\cos(k\Phi)\), the velocity coefficients are \(t/2\) for \(m=\pm1\); the factor \(i/(km)\) changes by complex conjugation when \(m\) changes sign. Thus the potentials and pressures also form real physical fields. No missing factor is introduced by replacing the cosine with exponentials.

## Exact cutoff residual and terminal flatness at each fixed stage

Let the zero-data inverse solve the principal equation for an actual supported source \(f_m\), and set \(\widehat t_m=\psi t_m,\widehat\pi_m=\psi\pi_m\). The principal equation yields exactly
\[
\widehat t_m'+\mathcal K\widehat t_m+m^2d\widehat t_m
+ikmn_\Phi\widehat\pi_m+f_m
=(1-\psi)f_m+\psi't_m.
\]
The source on the left remains \(f_m\), not \(\psi f_m\). This is why the uncancelled \((1-\psi)f_m\) term is required. The support of either right-hand term lies in \(|v-L_s/2|\ge L_s/5\), since \(\psi=1\) on the complementary central region. There the proved Gaussian estimate is \(P(v)\le e^{-cL_s/25}\le e^{-c'S_*}\). For every fixed coefficient derivative, Leibniz's formula gives the same exponential factor times allowed polynomial powers: derivatives of \(\psi\) are supported in the same exterior region, and all derivatives of \(f_m,t_m\) already obey the envelope bound. The transverse/slow/shell weights stay unchanged.

When the corresponding exponential and physical factors are differentiated any fixed number of times, only a fixed power \(Q^{-M}\) and a polynomial \(S_*^C\) are added. This can be verified directly: on band pullbacks, \(T_g^i\le Q^{-1-h}/S_*\), \(\Lambda_g^i\le Q^{-(1+h)\rho_g}S_*^{-\rho_g}\), \(k\le2Q^{-h/2}\); chart derivatives contribute fixed powers \(Q^{-1},Q^{-D},Q^{-1/2}\); and the phase itself has only the displayed \(p_zZ/\varepsilon\), \(vH_\Phi\), \(p\theta\), \(x_0R\) terms, with \(v=O(S_*)\) and all relevant differentiated coefficients bounded polynomially. The cylindrical frame has \(r^{-1}=Q^{-1/2}R^{-1}\), with \(R\) bounded away from zero. A fixed product/chain-rule expansion contains finitely many such factors. The exponents \(M,C\) may depend on the derivative order, stage, and finite harmonic set, but not on the band.

For every fixed \(M,C,N\), \(q\asymp Q=2^{-\ell}\) gives
\[
q^{-N}Q^{-M}S_*^Ce^{-c'S_*}
\le C_N\exp(-c'\ell^2+(M+N)\ell\log2+2C\log\ell)\longrightarrow0.
\]
For a direct bound, choose \(\ell\) so that the last two positive terms are at most \(c'\ell^2/2\); the remaining Gaussian is bounded and tends to zero. This proves every physical derivative of this fixed-stage cutoff residual is \(O(q^N)\) for every \(N\). Homogeneous pulse cutoff tails obey the same argument, with source zero and the retained \(\psi't^h\) term.

At each physical point only a bounded number of slow labels occur, so local summation retains the same bound. On their annular supports, \(r^2/(2q)\ge X_a>0\) implies \(q\le r^2/(2X_a)\). Thus these derivative bounds give arbitrary vanishing order at the singular space-time point \(r=z=0,t=1\). Every one-sided derivative jet there has value zero; the derivative identities persist at that boundary point by induction and the fundamental theorem of calculus along coordinate segments lying in the time half-space. Outside the annular supports the fields vanish smoothly. At \(t=1,z\ne0\), however, \(q=|z|^{1/D}>0\), so this estimate does not assert zero values on the whole terminal plane. One-sided smooth jets there are supplied by the parameter-dependent ODE proof. Any continuation across that plane, and the infinite-stage diagonal sum, are the later sections' responsibilities and are not inferred merely from the fixed-stage tail estimate.

## Actual covariance increment with every remainder retained

Let \(U=W_0^{\rm as}+E\) be the actual real divergence-free wave field, with \(U\in\mathcal W_{1/2}\), \(E\in\mathcal W_\rho\). Given \(\Sigma\in\mathcal M_\alpha\) independent of the averaging variables, applying the exact curl construction to \(\mathcal L^{\rm as}\Sigma\) gives
\[
V=\mathcal L^{\rm as}\Sigma+R,\qquad R\in\mathcal W_{\alpha-\kappa_s}.
\]
The latter exponent is \((\alpha-1/2)+(1/2-\kappa_s)\). Then
\[
\begin{aligned}
\mathcal C(U+V)-\mathcal C(U)
&=\mathcal B(U,V)+\mathcal C(V)\\
&=\Sigma+\mathcal B(E,\mathcal L^{\rm as}\Sigma)
+\mathcal B(U,R)+\mathcal C(V).
\end{aligned}
\]
The exact bilinear identity at the fixed \(W_0^{\rm as}\) is the only cancellation used. Products yield the respective mean exponents
\[
\rho+\alpha-\tfrac12,\qquad
\alpha+\tfrac12-\kappa_s,\qquad
2\alpha-1.
\]
For the last exponent, \(\kappa_s<1/2\) and \(0<\varepsilon\le1\) imply \(R\in\mathcal W_{\alpha-1/2}\); hence \(V\) is in that class. The radial divergence is the original componentwise operator \(D_r+2/R\) or \(D_r+1/R\), respectively. Its derivative term loses at most \(\kappa_s\), and its bounded frame terms cause no further loss. Thus all three remainder exponents after radial divergence are their displayed values minus at most \(\kappa_s\). These are precise local estimates. Their compatibility with the residual-improvement exponents selected in Section 9 must be checked where those exponents are selected.
