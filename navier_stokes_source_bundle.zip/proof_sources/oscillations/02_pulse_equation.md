# Phase, constrained evolution, and every fixed derivative

This file independently derives the claims of source pp. 73-81, Lemma 7.1, Proposition 7.2, Corollary 7.3, and Lemma 7.4. The exact auxiliary maps and operators are proved in the preceding file. The imported background assertion is Proposition 5.5: on the fixed enlarged annulus its chart radial component \(b\) is \(O(\varepsilon)\), its tangential components \(V,G\) differ from their leading profiles by \(O(\varepsilon^2)\), and these statements hold at every fixed slow derivative. The construction of that background belongs to another audit lane. Here the consequences for the pulse system are established explicitly.

## Cone coordinates and the phase gradient

Write \(F=V/R\), \(g=(RF_R,G_R)\) in component order \((\theta,z)\). At the fixed representative of a slow box, the leading shear is
\[
g_0=F_0(-a,b_s),\quad N=g_0/|g_0|,\quad K=(-N_z,N_\theta).
\]
Let \(t_s=-b_s/a\) and \(v_s=a(1+t_s^2)\). Since \(a,F_0>0\),
\[
N=-\frac{(1,t_s)}{\sqrt{1+t_s^2}},\quad
K=\frac{(t_s,-1)}{\sqrt{1+t_s^2}},\quad
|g_0|=aF_0\sqrt{1+t_s^2}.
\]
Retain the source's
\[
\lambda_0^2=-2F_0N_\theta(2F_0N_\theta+|g_0|),
\qquad c_0=\lambda_0/(2F_0N_\theta).
\]
Substitution gives
\[
\lambda_0^2
=2F_0^2\left(a-\frac2{1+t_s^2}\right)
=2aF_0^2(1-2/v_s)>0,\qquad
c_0^2=(v_s-2)/2,\quad c_0<0.
\]
The positive lower bounds on \(F_0,a,v_s-2\) and compact upper bounds give positive lower bounds on \(\lambda_0,|c_0|\), and finite upper bounds.

At the same, unfrozen profile point, \(T_0=F(p_s-(a,-b_s))\), \(P_c=p_{s,1}+t_sp_{s,2}\), \(J_c=p_{s,2}-t_sp_{s,1}\). Consequently
\[
T_0\cdot N=-\frac{F(P_c-v_s)}{\sqrt{1+t_s^2}},
\qquad
T_0\cdot K=-\frac{FJ_c}{\sqrt{1+t_s^2}}.
\]
Multiplication of \(T_0\) by the positive chart factor \((Q/q)^{A+1/2}\) changes neither sign nor quotient. Thus the two stress cone inequalities are exactly \(T_{0,*}\cdot N<0\) and
\[
\left|c_0\frac{T_{0,*}\cdot K}{T_{0,*}\cdot N}\right|<1.
\]
The weighted direction at a vanishing edge is used, not a division of zero values. Its smooth extension and strict compact margin give a supremum \(\mu<1\). Choosing \(u_*>0\) with \(u_*/\sqrt{1+u_*^2}>\mu\) is possible because that function increases to one. All quantities now frozen at representatives are kept fixed under differentiation. Uniform continuity in the compact chart domain makes the same strict cone margin valid on every enlarged box of diameter \(CS_*^{-3}\), after one lower bound on \(\ell\).

Retain \(k=\lceil\varepsilon^{-1/2}\rceil\), so for \(0<\varepsilon\le1\),
\[
1\le\varepsilon k^2\le(1+\sqrt\varepsilon)^2\le4,\qquad
k^{-1}\le\sqrt\varepsilon.
\]
Define
\[
B_s^2=\frac{\lambda_0}{\varepsilon k^2(1+u_*^2)^{3/2}},
\quad s(v)=\sigma(u_*/2+u_*v/L_s),\quad x_0=\sigma B_su_*/2.
\]
The \(B_s\) have fixed positive lower and upper bounds. Set
\[
(\widetilde p/R_0,p_z)
=B_s\left(K-\frac{\sigma u_*g_0}{L_s|g_0|^2}\right).
\]
Choose \(kp\) as the specified nearest nonzero integer to \(k\widetilde p\). The error \(|p-\widetilde p|\le k^{-1}\) suffices, including when the nearest unrestricted integer would have been zero. The integer is constant with the label. Put
\[
\Phi=p\theta+p_zZ/\varepsilon+x_0R-vH_\Phi,\qquad H_\Phi=pF+p_zG.
\]
Because \(D_rv=D_zv=0\) and the base is auxiliary-independent,
\[
n_\Phi=\nabla_*\Phi
=\bigl(x_0-v(H_\Phi)_R,\ p/R,\ p_z-\varepsilon v(H_\Phi)_Z\bigr).
\]
At the representative, before rounding, \((\widetilde p/R_0,p_z)\cdot g_0=-\sigma B_su_*/L_s\). Variation across the slow box changes this by \(O(S_*^{-3})\); the background change contributes \(O(\varepsilon^2)\); rounding contributes \(O(k^{-1})\). Hence
\[
|(H_\Phi)_R+\sigma B_su_*/L_s|
\le C(S_*^{-3}+\varepsilon^2+k^{-1}).
\]
Multiplication by \(v\le L_s=O(S_*)\) gives the radial comparison with \(B_ss(v)\). The tangential comparison has contributions \(O(S_*^{-1})\) from the deliberate tilt, \(O(S_*^{-3}+\varepsilon^2+k^{-1})\) from freezing and rounding, and \(O(\varepsilon S_*)\) from the axial phase term. A single sufficiently large \(\ell_*\) satisfies
\[
S_*^2(\varepsilon+\varepsilon^2+k^{-1})\le1
\]
for every \(\ell\ge\ell_*\), since \(S_*=\ell^2\) and \(\varepsilon=2^{-h\ell}\). Therefore
\[
|n_\Phi-B_s(s(v),K)|\le C/S_*.
\]
Differentiation in \(v\) gives \(n_\Phi'=(-(H_\Phi)_R,0,-\varepsilon(H_\Phi)_Z)\), also \(O(S_*^{-1})\). Each fixed number of slow derivatives of these coefficients is bounded by a polynomial in \(S_*\): the only growing factors in these formulas are \(v\), \(\varepsilon^{-1}\) in the phase itself, and the fixed chart derivatives. The \(\varepsilon^{-1}\) term of \(\Phi\) disappears in \(n_\Phi\); it is not discarded from the full exponential when physical derivatives are later taken.

The exact transport defect follows term by term:
\[
\mathsf t_*\Phi=-H_\Phi+\varepsilon v(H_\Phi)_T,\qquad
F\partial_\theta\Phi+GD_z\Phi=H_\Phi-\varepsilon vG(H_\Phi)_Z.
\]
Thus
\[
E_{\rm ik}:=(\mathsf t_*+bD_r+F\partial_\theta+GD_z)\Phi
=\varepsilon v((H_\Phi)_T-G(H_\Phi)_Z)+bn_{\Phi,r}.
\]
The background satisfies \(D^Ib=O_I(\varepsilon)\), while every
fixed coefficient derivative of \(n_{\Phi,r}\) is polynomially
bounded in \(S_*\). The exact product rule therefore gives
\[
D^I(bn_{\Phi,r})
=\sum_{J\le I}\binom IJ(D^Jb)(D^{I-J}n_{\Phi,r})
=O_I(\varepsilon S_*^{d_I}).
\]
For example, at fixed pulse coordinate,
\(\partial_Rn_{\Phi,r}=-v(H_\Phi)_{RR}\), whose bound can contain
a factor \(S_*\). Auxiliary coefficient derivatives of \(v\)
are \(O(S_*)\), and derivatives of the fixed affine path of order
two or greater vanish. Applying the same finite product rule
to \(\varepsilon v((H_\Phi)_T-G(H_\Phi)_Z)\) proves
\(D^IE_{\rm ik}=O_I(\varepsilon S_*^{b_I})\) for every fixed
\(I\), on the same domain. This introduces no smallness condition
on the higher derivatives.

## Exact pressure elimination and plane isomorphism

Set
\[
\mathcal K=
\begin{pmatrix}0&-2F&0\\2F+RF_R&0&0\\G_R&0&0\end{pmatrix},
\quad d=\varepsilon k^2|n_\Phi|^2,\quad
\mathcal A_\Phi=-\mathcal K+
\frac{n_\Phi(n_\Phi^T\mathcal K-(n_\Phi')^T)}{|n_\Phi|^2}.
\]
For the original equation
\[
t_m'+\mathcal Kt_m+m^2dt_m+ikm n_\Phi\pi_m=-f_m,
\quad n_\Phi\cdot t_m=0,
\]
differentiate its constraint to get \(n_\Phi\cdot t_m'=-n_\Phi'\cdot t_m\). Taking its normal component then forces
\[
\pi_m=\frac{i}{km}\,
\frac{n_\Phi\cdot\mathcal Kt_m-n_\Phi'\cdot t_m+n_\Phi\cdot f_m}{|n_\Phi|^2}.
\]
The factor has sign \(+i/(km)\): multiplying it by \(ikm n_\Phi\) gives the negative of the required normal vector. Substituting gives the projected equation
\[
t_m'=\mathcal A_\Phi t_m-m^2dt_m-\operatorname{proj}_{n_\Phi^\perp}f_m.
\]
Conversely this projected equation and the displayed pressure imply the original equation provided the constraint holds. For any solution of the projected equation,
\[
(n_\Phi\cdot t_m)'=-m^2d(n_\Phi\cdot t_m).
\]
An initially zero constraint remains zero, proving equivalence, existence, and uniqueness once the finite-dimensional initial-value equation is solved.

Since \(n_{\Phi,\tan}\) stays close to \(B_sK\), its norm has a uniform positive lower bound. The nonzero \(p/R\) also prevents it from being literally zero. Define
\[
K_a=n_{\Phi,\tan}/|n_{\Phi,\tan}|,\quad
N_a=((K_a)_z,-(K_a)_\theta),\quad
s_a=n_{\Phi,r}/|n_{\Phi,\tan}|.
\]
Then \(N_a\perp K_a\), \(|N_a|=|K_a|=1\), and
\[
U=[e_r-s_aK_a,N_a],\quad
M=\begin{pmatrix}1&1\\c_0\sqrt{1+s^2}&-c_0\sqrt{1+s^2}\end{pmatrix},
\quad B=UM
\]
maps \(\mathbb C^2\) isomorphically onto the actual complex plane \(n_\Phi^\perp\). The exact left inverse is
\[
B^\ell=M^{-1}\begin{pmatrix}e_r^T\\N_a^T\end{pmatrix}
\]
because the last displayed row matrix times \(U\) is \(I_2\). The determinant of \(M\) is \(-2c_0\sqrt{1+s^2}\), bounded away from zero. All factors and their inverses are uniformly bounded in value and polynomially bounded in each fixed coefficient derivative.

For clarity the ambient map also has an exact formula. Regard \(K_a\)
as the three-vector with zero radial component, and let
\(W_a=(e_r^T;N_a^T)\). Direct multiplication gives \(W_aU=I_2\).
For any \(w=w_re_r+w_KK_a+w_NN_a\in\mathbb C^3\),
\[
BB^\ell w=UW_aw=w_r(e_r-s_aK_a)+w_NN_a
=w-K_a(w_K+s_aw_r).
\]
Since \(n_\Phi=|n_{\Phi,\tan}|(s_ae_r+K_a)\), this proves
\[
B^\ell B=I_2,\qquad
BB^\ell=I_3-\frac{K_an_\Phi^T}{|n_{\Phi,\tan}|}.
\]
Thus \(BB^\ell\) is the projection onto \(n_\Phi^\perp\)
along \(\operatorname{span}_{\mathbb C}\{K_a\}\). Its restriction
to \(n_\Phi^\perp\) is the identity; its action on \(K_a\) is zero.
In particular the inverse assertion is not made on all of \(\mathbb C^3\).

The moving-plane differential equation has the exact coordinate form
\[
z_m'=B^\ell(\mathcal A_\Phi B-B')z_m-m^2dz_m
-B^\ell\operatorname{proj}_{n_\Phi^\perp}f_m.
\]
For its converse, differentiate \(n_\Phi^TB=0\) to obtain
\(n_\Phi^TB'=-(n_\Phi')^TB\). The definition of
\(\mathcal A_\Phi\) gives
\(n_\Phi^T\mathcal A_\Phi B=-(n_\Phi')^TB\).
Therefore each column of \(\mathcal A_\Phi B-B'\) lies in
\(n_\Phi^\perp\). Both \(Bz_m\) and the projected force lie there
as well. Multiplying the coordinate equation by \(B\) and using
\(BB^\ell=I\) on these three terms yields
\[
Bz_m'=(\mathcal A_\Phi B-B')z_m-m^2dBz_m
-\operatorname{proj}_{n_\Phi^\perp}f_m.
\]
Adding \(B'z_m\) proves the projected equation for \(t_m=Bz_m\),
and \(n_\Phi^Tt_m=0\) holds by construction. The displayed pressure
then recovers the full equation with its actual normal forcing.
Conversely, a constrained solution has \(z_m=B^\ell t_m\) and
\(t_m=Bz_m\). Differentiating the latter identity and multiplying
the projected equation by \(B^\ell\) gives exactly the coordinate
equation above. Both inverse compositions, including their initial
data and the unique pressure, are therefore proved.

For the reference normal \(n_{\rm ref}=B_s(s,K)\), use \(e=e_r-sK\) and \(N\) as an orthogonal plane basis, of lengths \(\sqrt{1+s^2}\) and \(1\). The actual source matrix \(\mathcal K_0\) gives
\[
\mathcal K_0e=(2F_0sK_\theta,\ 2F_0e_\theta+g_0),\quad
\mathcal K_0N=(-2F_0N_\theta,0).
\]
Consequently
\[
e\cdot(-\mathcal K_0e)=sK\cdot g_0=0,\quad
e\cdot(-\mathcal K_0N)=2F_0N_\theta,
\]
\[
N\cdot(-\mathcal K_0e)=-(2F_0N_\theta+|g_0|),\quad
N\cdot(-\mathcal K_0N)=0.
\]
Orthogonal projection onto \(n_{\rm ref}^\perp\) leaves these scalar products unchanged. Dividing the first coordinate by \(1+s^2\) produces
\[
\mathcal D=
\begin{pmatrix}
0&2F_0N_\theta/(1+s^2)\\
-(2F_0N_\theta+|g_0|)&0
\end{pmatrix}.
\]
Its two eigenvectors are exactly the columns of \(M\), with eigenvalues \(\lambda=\lambda_0/\sqrt{1+s^2}\) and \(-\lambda\), since \(c_0=\lambda_0/(2F_0N_\theta)\) and \(\lambda_0^2=-2F_0N_\theta(2F_0N_\theta+|g_0|)\). This verifies the orientation and signs of the growing coordinate.

Replacing the background and normal by the actual ones changes the algebraic projected matrix by \(O(S_*^{-1})\). This follows from the explicit rational expression for the projection, the uniform positive denominators, the value bounds already proved, and the mean-value formula on their common compact range. Also \(K_a-K,s_a-s=O(S_*^{-1})\), while their \(v\)-derivatives and \(s'\) are \(O(S_*^{-1})\). Hence \(B'=O(S_*^{-1})\) and the normal-motion term in \(\mathcal A_\Phi\) is \(O(S_*^{-1})\). Therefore
\[
B^\ell(\mathcal A_\Phi B-B')=
\operatorname{diag}(\lambda,-\lambda)+E,\qquad |E|\le C/S_*.
\]
Every fixed derivative of \(E\) is polynomially bounded; no derivative-smallness claim is needed. The damping comparison is
\[
d_{\rm ref}=\varepsilon k^2B_s^2(1+s^2),\qquad
|d-d_{\rm ref}|\le C/S_*,
\]
because \(\varepsilon k^2\) is bounded and \(|n_\Phi|^2-B_s^2(1+s^2)\) is \(O(S_*^{-1})\).

## Envelope and uniform forward inverse

Let
\[
a_{\rm net}(y)=\frac{\lambda_0}{\sqrt{1+y^2}}-
\frac{\lambda_0(1+y^2)}{(1+u_*^2)^{3/2}},
\qquad y=|s(v)|=u_*/2+u_*v/L_s.
\]
It is zero at \(v=L_s/2\), and direct differentiation gives
\[
\frac{d}{dv}a_{\rm net}(|s(v)|)
=-\frac{u_*\lambda_0|s(v)|}{L_s}
\left((1+s(v)^2)^{-3/2}+2(1+u_*^2)^{-3/2}\right).
\]
Since \(u_*/2\le|s|\le3u_*/2\), its value lies between \(-C/L_s\) and \(-c/L_s\), for fixed positive \(c,C\). Define \(P(v)=\exp(\int_{L_s/2}^v a_{\rm net}(|s(w)|)\,dw)\). Integrating the derivative inequality on either side of the midpoint, keeping the direction of each integral, gives
\[
-C_1(v-L_s/2)^2/L_s\le\log P(v)\le-c_1(v-L_s/2)^2/L_s.
\]
This proves the two Gaussian bounds and \(0<P\le1\) with the source's integral normalization.

Writing \(t_m=Bz_m\) gives
\[
z_m'=A_mz_m+g_m,\quad
A_m=\operatorname{diag}(\lambda,-\lambda)+E-m^2dI_2,
\quad g_m=-B^\ell\operatorname{proj}_{n_\Phi^\perp}f_m.
\]
For the complex Euclidean norm, taking the real part of \(z^*A_1z\) bounds the upper right derivative of \(|z|\) by \((\lambda-d_{\rm ref}+C/S_*)|z|\). Integration gives
\[
\|V_1(v,w)\|\le
\exp(C(v-w)/S_*)\,P(v)/P(w)\le C'P(v)/P(w).
\]
The factor \(C'\) is fixed because \(0\le v-w\le L_s\asymp S_*\). Since the difference of \(A_m\) from \(A_1\) is the scalar matrix \(-(m^2-1)dI_2\), differentiation directly verifies
\[
V_m(v,w)=\exp\left(-(m^2-1)\int_w^v d(a)\,da\right)V_1(v,w).
\]
For every nonzero integer \(m\), \(m^2-1\ge0\) and \(d>0\), so the same value bound is valid for all such harmonics. This is the exact mechanism preventing a new small-domain requirement when the finite harmonic set increases.

If the source obeys
\[
|D^If_m|\le C_I\varepsilon^\alpha S_*^{b_I}
\sqrt\zeta\,\delta^{-a_I}P(v),
\]
the zero-data Duhamel integral gives
\[
z_m(v)=\int_0^vV_m(v,w)g_m(w)\,dw,\quad
|z_m(v)|\le C\varepsilon^\alpha S_*^{b+1}
\sqrt\zeta\,\delta^{-a}P(v).
\]
The source's \(P(w)\) cancels the propagator's denominator exactly. The shell weights are constant along the integration path because \(X\) is constant there.

For completeness, parameter differentiation can be performed without differentiating a possibly exponentially large propagator in isolation. Hold \(v\) fixed and use slow variables and the initial transverse coordinate as parameters. They commute with \(\partial_v\); the zero initial data and all their parameter derivatives vanish. For each multi-index \(I\),
\[
(\partial^Iz_m)'=A_m\partial^Iz_m+\partial^Ig_m+
\sum_{0<J\le I}\binom IJ(\partial^JA_m)\partial^{I-J}z_m.
\]
At fixed finite harmonic bound \(M\), each \(\partial^JA_m\) is bounded by \(C_{J,M}S_*^{c_J}\). Induction on \(|I|\), using the already proved propagator bound, shows that every source term on the right has the same \(\varepsilon^\alpha\sqrt\zeta P\) weight with a larger inverse-distance exponent and polynomial degree. A further time integral contributes only \(L_s\). One may choose the degree at step \(I\) to exceed
\[
1+\max\{b_I,\max_{0<J\le I}(c_J+b'_{I-J})\}.
\]
Pulse derivatives follow from the differential equation, and mixed pulse/parameter derivatives follow by repeated differentiation of that equation. Returning to the current \(H\) uses \(D_Hv=O(S_*)\), \(D_HH_w=I-v_t\lambda_t\), with higher affine derivatives zero, and therefore introduces only additional polynomial powers. Multiplying by \(B\) yields the stated bound for \(t_m\). The explicit pressure has the extra factor \((km)^{-1}=O(\varepsilon^{1/2})\); its other factors have the proved derivative bounds. Thus the exponent for pressure is \(\alpha+1/2\).

The support argument also follows from this equation. If a fixed slow/transverse point is outside the source's closed support, the entire source path is zero; uniqueness gives a zero solution. At a boundary all source jets vanish by the prescribed smooth zero extension, so the differentiated equations inductively give zero solution jets. Across a shell edge the retained \(\sqrt\zeta\delta^{-a_I}\) bounds give the same conclusion. Deck translations preserve the path and the prescribed data, giving common-torus descent by uniqueness. Smooth extension to the rectangle enlargement follows from smooth finite-dimensional ODE dependence on its coefficients and data; no temporal zero extension is asserted before cutoff. On compact sets with \(q>0\), one-sided background/source derivatives at \(\tau=0\) pass through the same parameter equations and pressure formula.

Only the lower bounds for denominators and finitely many value comparisons determine \(q_*\). The induction above changes constants and polynomial degrees for each fixed \(M,I\); it does not impose further smallness inequalities. This proves the quantifier statement of Corollary 7.3.

## The real homogeneous pulse and energy transfer

For \(m=1,f=0\), specify \(z_+(0)=P(0)>0,z_-(0)=0\). While \(z_+>0\), the ratio \(r=z_-/z_+\) obeys exactly
\[
r'=E_{21}+(-2\lambda+E_{22}-E_{11})r-E_{12}r^2.
\]
Let \(c_\lambda=\inf\lambda>0\). On \(r=\pm K_b/S_*\), the outward derivative is at most
\[
\frac{-2c_\lambda K_b+C(1+K_b/S_*+K_b^2/S_*^2)}{S_*}.
\]
Choose fixed \(K_b>C/c_\lambda\), then enlarge the fixed band threshold to make the numerator negative. The closed interval \([-K_b/S_*,K_b/S_*]\) is invariant until any putative first zero of \(z_+\). On this interval,
\[
\left(\log(z_+/P)\right)'=-(d-d_{\rm ref})+E_{11}+E_{12}r=O(S_*^{-1}).
\]
Since \(z_+(0)=P(0)\) and \(L_s/S_*\) is bounded, integration proves \(cP\le z_+\le CP\), ruling out that putative zero. For all \(v\),
\[
x=z_++z_-=z_+(1+r),\quad
y=c_0\sqrt{1+s^2}(z_+-z_-),
\]
so
\[
cP\le x\le CP,\qquad
y/x=c_0\sqrt{1+s^2}+O(S_*^{-1}).
\]
The same differentiated equation used for the inverse proves every fixed derivative bound, with the nonzero initial value retained: it is fixed with the label, so all slow/transverse derivatives of that datum vanish. The value solution contributes \(\|V_1(v,0)\|P(0)\le CP(v)\). Pulse derivatives are obtained from the equation. Pressure again has the extra \(\varepsilon^{1/2}\).

For the real homogeneous amplitude \(t\), \(n_\Phi\cdot t=0\) makes the normal component of \(\mathcal A_\Phi t\) perpendicular to \(t\). Direct multiplication, keeping both cylindrical \(2F\) terms, gives
\[
t\cdot\mathcal Kt
=-2Ft_rt_\theta+(2F+RF_R)t_rt_\theta+G_Rt_rt_z
=g\cdot(t_r(t_\theta,t_z)).
\]
Taking \(t\cdot t'\) therefore proves the exact identity
\[
\frac12\frac{d}{dv}|t|^2
=-g\cdot(t_r(t_\theta,t_z))-\varepsilon k^2|n_\Phi|^2|t|^2.
\]
For the flux \(T=t_r(t_\theta,t_z)=T_NN+T_KK\), the exact
production is
\[
-g\cdot T=-|g_0|T_N-\Delta g\cdot T,\qquad \Delta g=g-g_0.
\]
Here \(g_0\) is the leading shear frozen at the representative;
it is not identified with the actual shear even there. To keep both
sources of its difference, let \(V^{(0)},G^{(0)}\) denote the exact
leading chart fields, put \(\delta V=V-V^{(0)}\),
\(\delta G=G-G^{(0)}\), and write
\[
g^{(0)}=(\partial_RV^{(0)}-V^{(0)}/R,\partial_RG^{(0)}),
\quad g_0=g^{(0)}(p_0),
\]
\[
\Delta g=(\partial_R\delta V-\delta V/R,\partial_R\delta G)
+g^{(0)}(p)-g^{(0)}(p_0).
\]
The leading and actual fields here are the constructed backgrounds.
Their proved chart estimates give
\(|\partial^I\delta V|\le C_{V,I}\varepsilon^2\) and
\(|\partial^I\delta G|\le C_{G,I}\varepsilon^2\).
Let \(R_->0\) be the minimum radius on the compact enlarged chart,
\(L_g\) bound \(D_pg^{(0)}\), and
\(|p-p_0|\le C_{\rm box}S_*^{-3}\), with the connecting segment
in that chart. Set
\[
C_B=\left[(C_{V,e_R}+R_-^{-1}C_{V,0})^2+C_{G,e_R}^2\right]^{1/2}.
\]
The product rule and segment integration give the actual bound
\[
|\Delta g|\le C_B\varepsilon^2+L_gC_{\rm box}S_*^{-3}
=C_B2^{-2h\ell}+L_gC_{\rm box}\ell^{-6}.
\]
At \(p_0\) only the segment term is zero. The Borel term remains.
For a vector in the prescribed compact stress cone, retain its margin
\(-T_N\ge c_T|T|\), \(c_T>0\), and \(|g_0|\ge g_->0\).
Then Cauchy--Schwarz proves
\[
-g\cdot T\ge
[g_-c_T-C_B2^{-2h\ell}-L_gC_{\rm box}\ell^{-6}]|T|.
\]
One sufficient additional integer threshold is
\[
\ell\ge\left\lceil\max\left\{
1,\left(\frac{4L_gC_{\rm box}}{g_-c_T}\right)^{1/6},
\frac{\log\max\{1,4C_B/(g_-c_T)\}}{2h\log2}
\right\}\right\rceil.
\]
Each error is then at most \(g_-c_T/4\), so the lower bound is
\((g_-c_T/2)|T|\), including \(T=0\).

For the actual homogeneous pulse, positivity follows directly from its
proved polarization. This requires no assertion that its instantaneous
flux lies in the prescribed target cone. Retain
\[
t=x(e_r-s_aK_a)+yN_a,\quad
s_{\max}=3u_*/2,\quad \gamma_0=c_0\sqrt{1+s^2},
\]
and choose the constants in the already proved estimates as
\[
|n_\Phi-B_s(s,K)|\le E_n/S_*,\quad B_s\ge B_->0,
\quad |y/x-\gamma_0|\le E_\gamma/S_*,\quad c_xP\le x\le C_xP.
\]
The quantities \(g_-,g_+,c_-,c_+\) denote positive uniform bounds
\(g_-\le|g_0|\le g_+\), \(c_-\le|c_0|\le c_+\), with
\(c_0<0\). Choose \(S_*\ge2E_n/B_-\). Then
\(|n_{\Phi,\tan}|\ge B_-/2\). For nonzero vectors \(a,b\),
addition and subtraction of \(a/|b|\), followed by
\(\big||a|-|b|\big|\le|a-b|\), gives
\(|a/|a|-b/|b||\le2|a-b|/|b|\). Therefore
\[
|K_a-K|=|N_a-N|\le\frac{2E_n}{B_-S_*},\qquad
|s_a-s|\le\frac{2(1+s_{\max})E_n}{B_-S_*}.
\]
The last estimate follows by writing
\(n_{\Phi,r}-s|n_{\Phi,\tan}|
=(n_{\Phi,r}-B_ss)+s(B_s-|n_{\Phi,\tan}|)\)
and dividing by the actual tangential norm.
Define
\[
\Gamma_{\max}=c_+\sqrt{1+s_{\max}^2},\qquad
C_T=\frac{2E_n}{B_-}(1+2s_{\max}+\Gamma_{\max})+E_\gamma.
\]
The exact flux and its exact remainder are
\[
T=x^2[-sK+\gamma_0N+e_T],\qquad
e_T=-(s_aK_a-sK)+(y/x)N_a-\gamma_0N.
\]
Expand the first difference as
\((s_a-s)K_a+s(K_a-K)\) and the second as
\((y/x-\gamma_0)N_a+\gamma_0(N_a-N)\).
The preceding bounds give \(|e_T|\le C_T/S_*\), with all four
terms retained. Hence
\[
\frac{-g\cdot T}{x^2}=-|g_0|\gamma_0-g_0\cdot e_T
-\Delta g\cdot(-sK+\gamma_0N+e_T).
\]
The absolute value of the last two terms is at most
\[
\mathcal E_\ell=g_+C_T\ell^{-2}
+(C_B2^{-2h\ell}+L_gC_{\rm box}\ell^{-6})
(s_{\max}+\Gamma_{\max}+C_T\ell^{-2}).
\]
Set \(W=s_{\max}+\Gamma_{\max}+C_T>0\). In addition to all
previous phase and invariant-band thresholds, it suffices to choose
\[
\ell\ge\left\lceil\max\left\{
1,\left(\frac{2E_n}{B_-}\right)^{1/2},
\left(\frac{4g_+C_T}{g_-c_-}\right)^{1/2},
\left(\frac{8WL_gC_{\rm box}}{g_-c_-}\right)^{1/6},
\frac{\log\max\{1,8WC_B/(g_-c_-)\}}{2h\log2}
\right\}\right\rceil.
\]
For \(\ell\ge1\), the last factor in \(\mathcal E_\ell\) is at
most \(W\). The three error contributions are then at most
\(g_-c_-/4,g_-c_-/8,g_-c_-/8\), respectively.
Since \(-|g_0|\gamma_0\ge g_-c_-\), this proves
\[
\tfrac12g_-c_-c_x^2P(v)^2\le-g\cdot T
\le(g_+\Gamma_{\max}+\tfrac12g_-c_-)C_x^2P(v)^2.
\]
All constants concern the same selected \(h\), fixed profiles and
original compact label family. The displayed thresholds are finite and
are added to the previous finite value thresholds; no uniformity as
\(h\downarrow0\) is asserted. The exact actual-frame norm is
\[
|t|^2=(1+s_a^2)x^2+y^2.
\]
The damping \(\varepsilon k^2|n_\Phi|^2|t|^2\) remains in the
energy equation, so positive production is not a claim of positive total
energy derivative. Covariance mass uses the proved positive \(x\) and
the original positive integral of \(\psi^2x^2\); its argument does
not omit this damping. The carrier physical wavelength is \(\sqrt Q/k\asymp Q^{1/2+h/2}\), while the leading physical wave amplitude has power \(Q^{-A}\sqrt\varepsilon=Q^{-1/2-h/2}\), up to polynomial factors in \(S_*\). Their product has power \(Q^0\); this agrees with the retained leading damping \(\varepsilon k^2\asymp1\).
