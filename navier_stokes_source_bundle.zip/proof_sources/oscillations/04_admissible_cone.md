# Admissible shear loop, radial modulation, and moment restoration

This file independently proves the operations in Appendix C, pp. 157-165. It retains the original logarithmic coordinate \(D_X=X\partial_X\), profile \(E>0,U\), pressure integration constant \(\Pi_0(\eta)\), component signs, interval ordering, and all five moments. The existence and numerical parameter margins of the input profile from Appendices A and B are audited by the profiles lane. This file verifies what Appendix C does to that input, including the exact restoration map; it does not claim that its imported input construction has been independently proved here.

## Scalar cone and its four gaps

At \(a>0\), set
\[
t_s=-b_s/a,\quad v_s=a(1+t_s^2),\quad
P_c=p_{s,1}+t_sp_{s,2},\quad
J_c=p_{s,2}-t_sp_{s,1}.
\]
The relaxed condition is \(P_c>2\), \(v_s<U(P_c,J_c)\), with
\[
U(P,J)=P+\frac{J^2}{4}
-|J|\sqrt{\frac{P-2}{2}+\frac{J^2}{16}}.
\]
The admissible condition also requires \(v_s>2\). The quadratic expression
\[
G(v)=2(P-v)^2-(v-2)J^2
\]
has roots \(U(P,J)\) and the same expression with a plus before the square root. For \(P>2\), \(U>2\): writing \(w=P-2>0\), the inequality
\[
\left(w+\frac{J^2}{4}\right)^2
-J^2\left(\frac w2+\frac{J^2}{16}\right)=w^2>0
\]
proves \(w+J^2/4>|J|\sqrt{w/2+J^2/16}\). Also \(U\le P\), because the square-root term is at least \(J^2/4\), with equality only for \(J=0\). When \(J=0\), \(U=P>2\). Therefore for \(v>2\), admissibility is exactly
\[
P-v>0,\qquad 2(P-v)^2-(v-2)J^2>0.
\]
The four continuous smooth gaps on \(a>0\) are \(a\), \(v_s-2\), \(P_c-v_s\), and \(2(P_c-v_s)^2-(v_s-2)J_c^2\). Positivity on a compact parameter set gives one positive lower margin for all four. The root \(U\) need only be continuous; no differentiation of its \(|J|\) term at zero is used.

## A smooth loop whose average is exactly the original shear

Let \(I\times[-1,1]\) be the fixed compact domain from Appendix C, with relaxed data and admissibility on radial boundary collars. The positive minimum of \(P_c(t_s)-2\) permits a constant
\[
0<d_0<\tfrac12\min(P_c(t_s)-2).
\]
Here \(P_c(t)=p_{s,1}+p_{s,2}t\) and \(J_c(t)=p_{s,2}-p_{s,1}t\) for a variable slope \(t\). With normalized \(\theta'\)-average on \([0,2\pi]\), define
\[
M_e(z)=\frac1{2\pi}\int_0^{2\pi}e^{z\sin\theta'}\,d\theta',
\quad
t(\theta';\mu)=t_s+
\frac{d_0}{p}\left(\frac{e^{\mu p\sin\theta'}}{M_e(\mu p)}-1\right),
\quad p=p_{s,2}.
\]
For \(p=0\) the quotient is defined by continuity. Its numerator is smooth in \(p,\mu,\theta'\), zero at \(p=0\), and the identity
\[
\frac{G(p)}p=\int_0^1G'(up)\,du
\]
proves joint smoothness, including all parameters and derivatives. Since \(M_e(0)=1,M_e'(0)=0\), the value there is \(t=t_s+d_0\mu\sin\theta'\).

The definitions give
\[
\langle t\rangle_{\theta'}=t_s,\qquad
P_c(t)=P_c(t_s)+d_0\left(\frac{e^{\mu p\sin\theta'}}{M_e(\mu p)}-1\right)
\ge P_c(t_s)-d_0>2.
\]
The variance is
\[
V(\mu,p)=\langle(t-t_s)^2\rangle
=\frac{d_0^2}{p^2}
\left(\frac{M_e(2\mu p)}{M_e(\mu p)^2}-1\right),
\]
with value \(d_0^2\mu^2/2\) at \(p=0\). To show strict increase, let \(g(z)=\log M_e(z)\). Differentiating under the finite integral gives
\[
g''(z)=
\langle(\sin\theta'-\langle\sin\theta'\rangle_z)^2\rangle_z>0,
\]
where the tilted probability density is \(e^{z\sin\theta'}/(2\pi M_e(z))\). It is strictly positive on the circle and \(\sin\theta'\) is not constant, so the variance is strictly positive. For \(p\ne0,\mu>0\),
\[
\partial_\mu(g(2\mu p)-2g(\mu p))
=2p(g'(2\mu p)-g'(\mu p))>0.
\]
For \(p>0\) both factors on the right are positive; for \(p<0\) both are negative. Thus \(V\) strictly increases in \(\mu>0\), including its separately proved formula at \(p=0\).

Here is the required growth bound, without an unproved asymptotic invocation. For \(z\ge1\), write \(\theta'=\pi/2+x\) near the maximum. On a fixed small interval \(|x|\le a<\pi\), there are \(c_1,c_2>0\) with \(1-c_2x^2\le\cos x\le1-c_1x^2\). A lower bound integrates over \(|x|\le z^{-1/2}\min(a,1)\), giving \(ce^zz^{-1/2}\). An upper bound on the same interval uses the Gaussian integral and gives \(Ce^zz^{-1/2}\). On its complement \(\sin\theta'\le1-c_a\), so the contribution is at most \(e^{(1-c_a)z}\), also bounded by \(Ce^zz^{-1/2}\). For \(z<0\), shift \(\theta'\) by \(\pi\) to obtain \(M_e(z)=M_e(-z)\). Hence
\[
c\,e^{|z|}/\sqrt{|z|}
\le M_e(z)\le C\,e^{|z|}/\sqrt{|z|}\quad (|z|\ge1).
\]
Taking the ratio yields positive constants bounding \(M_e(2z)/M_e(z)^2\) above and below by multiples of \(\sqrt{|z|}\). Therefore \(V(\mu,p)\to\infty\) for each fixed \(p\ne0\); for \(p=0\) its explicit quadratic formula proves the same.

The compact range of \(p\) admits a uniform finite \(\mu_{\max}\) such that \(V(\mu_{\max},p)>3/\min a\). To prove uniformity, for each \(p_0\) select a finite \(\mu_{p_0}\) giving the strict bound there; continuity gives a neighborhood in \(p\); a finite subcover gives finitely many such \(\mu\), and their maximum works by monotonicity. This step is valid at \(p=0\), so no divergent factor \(p^{-2}\) is being used near zero.

All slopes \(t(\theta';\mu)\) for \(0\le\mu\le\mu_{\max}\) form a compact smooth family with \(P_c(t)>2\). Continuity of \(U\) and the strict inequality \(U(P,J)>2\) established above give a positive minimum of \(U-2\). Choose \(0<\delta_L<1\) smaller than that minimum, and smaller than the positive minimum of \(v_s-2\) on chosen smaller radial boundary collars.

Choose a smooth \(0\le\zeta_L\le1\) as a function of \(v_s\), equal to one for \(v_s\le2+\delta_L/8\) and zero for \(v_s\ge2+\delta_L/4\). Put
\[
v_*=2+\delta_L/2,\qquad
\rho=\zeta_L(v_s)^2(v_*-v_s),\qquad
v=v_s+\rho,
\]
and define \(\rho=0\) where \(\zeta_L=0\). On its possible nonzero support, \(v_*-v_s\ge\delta_L/4\), so
\[
\sqrt\rho=\zeta_L(v_s)\sqrt{v_*-v_s}
\]
extends smoothly by zero. Since \(v_s>0\), \(0\le\rho<v_*<3\).

There is a unique \(0\le\mu<\mu_{\max}\) solving \(V(\mu,p)=\rho/a\), by the preceding strict monotonicity and endpoint bounds. Its smoothness at \(\rho=0\) needs a distinct verification. Expanding the finite integral in its convergent power series gives \(M_e(z)=1+z^2/4+O(z^4)\), and therefore
\[
V(\mu,p)=\tfrac12d_0^2\mu^2+O(\mu^4p^2)
\]
uniformly for bounded \(p\). Thus the signed square root is \(\mu(d_0/\sqrt2+O(\mu^2p^2))\), a smooth odd function of \(\mu\) near zero with positive derivative \(d_0/\sqrt2\). Applying the implicit-function theorem to this function and \(\sqrt{\rho/a}\), already proved smooth, gives smooth \(\mu\) there. For \(\rho>0\), strict positivity of \(\partial_\mu V\) gives the same conclusion. On the overlap the two local inverses agree by uniqueness.

The three cutoff regimes show \(v>2\) everywhere. Where \(\zeta_L\ne0\), \(v\le v_*<2+\delta_L<U(P_c(t),J_c(t))\). Where \(\zeta_L=0\), \(\mu=0,t=t_s,v=v_s>2\), and the original relaxed condition gives \(v<U\). Thus each proposed state lies in the admissible cone.

Define a lifted phase coordinate by
\[
\phi(0)=0,\qquad
\frac{d\phi}{d\theta'}=\frac{a(1+t^2)}{2\pi v},
\quad
(a_L,-b_L)=\frac{v(1,t)}{1+t^2}.
\]
Since \(\langle t\rangle=t_s\) and \(\langle(t-t_s)^2\rangle=V\),
\[
a\langle1+t^2\rangle=a(1+t_s^2)+aV=v_s+\rho=v.
\]
Therefore \(\phi(\theta'+2\pi)=\phi(\theta')+1\). Its derivative has a uniform positive lower bound on the compact parameter set; it defines an orientation-preserving circle diffeomorphism with a smooth parameter-dependent inverse. Changing variables proves both original mean components exactly:
\[
\int_0^1a_L\,d\phi
=\frac a{2\pi}\int_0^{2\pi}1\,d\theta'=a,
\quad
\int_0^1(-b_L)\,d\phi
=\frac a{2\pi}\int_0^{2\pi}t\,d\theta'=at_s=-b_s.
\]
Also \(-b_L/a_L=t\), \(a_L(1+t^2)=v\), so the verified scalar cone inequalities are the desired vector cone gaps. At boundary collars \(\zeta_L=0\), and the reparametrized shear is exactly the original constant-in-\(\phi\) shear. Compactness gives one \(\kappa_L>0\) for all four cone gaps. This completes the complete loop construction, including the mean, boundary, and smoothness claims.

## Exact insertion into the unchanged original radial coordinate

Let \(\mathcal A,\mathcal B\) be the zero-mean periodic antiderivatives
\[
\partial_\phi\mathcal A=-\tfrac12(a_L-a),\qquad
\partial_\phi\mathcal B=\tfrac12E(b_L-b_s).
\]
They exist because the right sides have zero \(\phi\)-mean. One explicit construction for any zero-mean \(g\) is
\[
\mathcal I g(\phi)=\int_0^\phi g(w)\,dw-
\int_0^1\int_0^s g(w)\,dw\,ds.
\]
It is periodic, zero mean, smooth in all parameters, and has derivative \(g\). It vanishes identically when \(g\equiv0\). Therefore these antiderivatives vanish on the boundary collars and extend smoothly by zero outside \(I\).

For an integer \(N>0\), keep the source's exact definitions
\[
E_N=E\exp(\mathcal A(X,\eta,N\log X)/N),\qquad
U_N=U+\mathcal B(X,\eta,N\log X)/N.
\]
The modified \(E_N\) is positive without approximation. The chain rule in the logarithmic coordinate is \(X\partial_X=D_X+N\partial_\phi\) after substitution. Hence
\[
\begin{aligned}
a_N
&=1-2X\partial_X\log E_N\\
&=a-2D_X\mathcal A/N-2\partial_\phi\mathcal A
=a_L-2D_X\mathcal A/N,
\end{aligned}
\]
\[
\begin{aligned}
b_N
&=\frac{2X\partial_XU_N}{E_N}\\
&=e^{-\mathcal A/N}
\left(\frac{2D_XU+2\partial_\phi\mathcal B}{E}
+\frac{2D_X\mathcal B}{NE}\right)\\
&=e^{-\mathcal A/N}
\left(b_L+\frac{2D_X\mathcal B}{NE}\right).
\end{aligned}
\]
The axial exponential denominator is retained; replacing it by one would destroy this exact shear formula.

On the fixed compact interval from \(X_-\) through the first reserved patch, \(X,E,H=\sqrt{2X}E,L\) have positive lower bounds. The phase \(N\log X\) is independent of \(\eta\), so every fixed number \(m\) of \(\eta\)-derivatives of \(E_N-E,U_N-U,a_N-a_L,b_N-b_L\) is bounded by \(C_m/N\). For the exponential difference, use
\[
e^{\mathcal A/N}-1
=\frac{\mathcal A}N\int_0^1e^{s\mathcal A/N}\,ds
\]
and then differentiate under its fixed finite integral; all factors of \(\mathcal A\) and its parameter derivatives are uniformly bounded on the periodic compact domain. For radial derivatives, \(r\ge1\) differentiations produce at most \(N^r\) from the phase and retain the initial \(N^{-1}\), giving \(C_{r,m}N^{r-1}\). Thus no small-radial-derivative assertion is used for the modulation.

## All five moments and the dependence of the integrated stress

Retain exactly
\[
M=\int_0^XU\,dx,\quad I=\int_0^X\sqrt{2x}E\,dx,\quad
J=\int_0^XU\sqrt{2x}E\,dx,
\]
\[
S=\int_0^X(U^2-E^2/2)\,dx,\qquad
C_p=\int_0^X E^2/(2x)\,dx,\qquad \Pi=\Pi_0+C_p.
\]
On the support of the differences, all scalar weights are bounded, since it is a compact interval with positive left endpoint. For instance
\[
U_N^2-U^2=(U_N-U)(U_N+U),\qquad
E_N^2-E^2=(E_N-E)(E_N+E).
\]
These identities, the product rule, and integration of the uniform \(C_m/N\) profile bounds prove every fixed \(\eta\)-derivative of the full prefix moment difference is \(O_m(N^{-1})\), uniformly in the endpoint \(X\). The pressure datum is the same, so \(\Pi_N-\Pi=C_{p,N}-C_p\) has exactly that bound.

The formulas whose continuity matters are
\[
W=1-\frac{2D\eta M+(1-\eta^2)M_\eta}{X},
\]
\[
Q_s=-W+
\frac{(1-h)I-D\eta I_\eta-(1-\eta^2)J_\eta+2(h-D)\eta J}{XH},
\]
\[
N_s=-WU+
\frac{D(M-\eta M_\eta)+4h\eta S-(1-\eta^2)S_\eta}{X}
+4A\eta\Pi-(1-\eta^2)\Pi_\eta,
\]
\[
p_s=(XQ_s/L,\ XN_s/(LE)).
\]
All denominators are bounded away from zero on the fixed interval. Differences of reciprocals are exactly
\[
E_N^{-1}-E^{-1}=-(E_N-E)/(E_NE),\qquad
H_N^{-1}-H^{-1}=-(H_N-H)/(H_NH).
\]
Applying the product rule to the displayed formulas proves the \(m\)-th parameter derivative bound for \(p_{s,N}-p_s\) from the profile and moment bounds through order \(m+1\), with no radial derivative of the differences. This proves the precise assertion needed for the cone stability.

The compact loop has positive four-gap margin. Its values and the original \(p_s\) range in a compact subset of \(a>0\); take a fixed small neighborhood still in \(a>0\), on which the four-gap map has a finite Lipschitz constant. The just-proved \(O(N^{-1})\) errors in \(a,b,p_s\) preserve each gap for sufficiently large finite \(N\). Between \(I\) and the first correction patch, \(E_N=E,U_N=U\), so the shears themselves equal the originals; the \(p_s\) error remains \(O(N^{-1})\). The original strict admissible margins on that compact intervening interval are preserved by the same argument.

## Nonlinear moment correction with an exact endpoint map

On the first reserved patch, the original profile is \(U=0,E=K(\eta)X^{-1/2-\lambda}\), where fixed \(\lambda>0\) and positive \(K\) have been selected before \(N\). The earlier modulation is zero on this patch. Add two smooth compactly supported \(U\)-bumps and three \(E\)-bumps with five coefficient functions \(c(\eta)\). Each block's bumps are nonnegative, nonzero, and supported on ordered disjoint intervals.

Differentiate the five original moment functionals at zero correction. In row order \((M,J;I,S,C_p)\), the two \(U\)-columns have weights \(1,H=\sqrt{2X}E\), and the three \(E\)-columns have weights \(\sqrt{2X},-E,E/X\). The off-diagonal blocks are zero because \(U=0\) before the correction. Up to the displayed nonzero factors, the exponent lists are
\[
(0,-\lambda),\qquad
(1/2,-1/2-\lambda,-3/2-\lambda).
\]
All powers within each block are distinct for the fixed \(\lambda>0\). To establish invertibility directly, a nonzero linear combination of \(m\) distinct powers has at most \(m-1\) distinct positive zeros: divide by the least power, use Rolle's theorem on \(m\) putative zeros, and apply induction to the derivative, which has \(m-1\) distinct powers and nonzero coefficients wherever the original nonconstant coefficients were nonzero. Thus the evaluation determinant \(\det[x_j^{\alpha_i}]\) never vanishes for ordered \(0<x_1<\cdots<x_m\). Its sign is constant on that connected set. Multilinearity and Fubini give
\[
\det\left[\int x^{\alpha_i}\beta_j(x)\,dx\right]
=\int\det[x_j^{\alpha_i}]\prod_j\beta_j(x_j)\,dx_1\cdots dx_m\ne0.
\]
The integrand has a constant nonzero sign on a set of positive measure. This proves each block's rank and hence the full moment Jacobian's rank. Smooth dependence on \(\eta\), compactness of \([-1,1]\), and the derivative identity for the inverse give uniform finite bounds at every fixed parameter order. No uniform estimate as \(\lambda\to0\) is claimed or needed.

The exact moment increment map is \(B(\eta)c+Q_\eta(c,c)\), because \(M,I\) are linear, \(J\) is bilinear in \(U,E\), and \(S,C_p\) are quadratic. Let \(d_N(\eta)\) be the negative moment discrepancy accumulated before the patch; it obeys \(\|d_N\|_{C^m}\le C_m/N\). On the \(C^0\) ball of radius \(r=2\beta_0\|d_N\|_{C^0}\), where \(\beta_0=\|B^{-1}\|_{C^0\to C^0}\), the map
\[
\mathcal T(c)=B^{-1}(d_N-Q(c,c))
\]
maps the ball to itself and has Lipschitz constant at most \(2\beta_0\kappa_0r\le1/2\), provided \(8\beta_0^2\kappa_0\|d_N\|_{C^0}\le1\). Thus it has a unique fixed point selected by iteration from zero. The derivative \(B+D_cQ(c,c)\) is invertible by the same estimate, giving smooth parameter dependence including one-sided endpoint derivatives. In each preselected finite \(C^m\) norm the identical contraction proof works after increasing \(N\), with the relevant multiplication and bilinear norms, and yields \(C_m/N\) for the same branch.

The assertion that every other fixed derivative is \(O_m(N^{-1})\) can also be justified without demanding simultaneous smallness of infinitely many norms. Differentiate the pointwise equation \(m\) times. The highest coefficient derivative is multiplied by the uniformly invertible \(B+D_cQ(c,c)\). All other terms contain either a derivative of \(d_N\), \(O_m(N^{-1})\), or a lower derivative of \(c\); induction gives \(O_m(N^{-1})\) for them, with the fixed data derivatives included in the constants. The same inverse bound therefore proves the estimate for the highest derivative. Only the finite orders needed for positivity and the cone gaps determine the actual choice of \(N\).

The bump shapes and widths are fixed, so their radial derivatives multiply these small coefficients by fixed constants. The correction is therefore small in the radial derivatives entering \(a,b_s\), in the first parameter derivatives entering \(p_s\), and in all prefix moments. The compact input cone margin on the correction patch persists. Positivity of \(E\) there also persists, after one further finite lower bound on \(N\).

At the right endpoint \(X_{\rm rep}\), the five corrected moments equal the original moments exactly as functions of \(\eta\), while the corrected profiles equal the original profiles for every \(X\ge X_{\rm rep}\). Their derivatives as functions of \(\eta\) also agree. Each difference moment has zero derivative in \(X\) there, by the original moment integrands, so it stays zero at every later radius. The common axis pressure datum gives identical \(\Pi\). The displayed formulas for \(Q_s,N_s,p_s\) and the original incompressibility formula
\[
V_0=\frac X L\left(2\eta U-2D\eta M/X-(1-\eta^2)\partial_\eta(M/X)\right)
\]
then prove exact equality of these fields at every later radius. This is the exact morphism from the five-moment endpoint data to exterior pressure, velocity, and stress; it proves preservation of the terminal compensation, both unused reserved correction patches, and the entire exterior. The inner collar is unchanged because both modifications start later and pressure was integrated from the same axis datum.

## Edge direction and the common weight

Appendix C leaves both original collars unchanged. The input edge facts it uses are: at the inner edge, with \(y_a=\log(X/X_a)\), the stress is
\[
T_0=e^{-t_1^2/y_a^2}g_a(y_a)B_0(X,\eta),\qquad
g_a(0)>0,\quad B_0(X_a,\eta)=F p_{s,r}\ne0;
\]
its limiting direction is a positive multiple of the limiting shear \((a,-b_s)=a(1,t_s)\). At the outer edge, with \(y_b=\log(X_b/X)\), the component factorization has common exponential \(e^{-4/y_b^2}\), angular prefactor \(y_b^{-3}b_\theta\) with \(b_\theta(0,\eta)>0\), and the direction
\[
n=\frac{(b_\theta,y_b^6b_z)}
{\sqrt{b_\theta^2+y_b^{12}b_z^2}}.
\]
The original collar analysis supplies smooth factors and the fixed-order derivative bounds. Their derivation is assigned to the profiles lane; their exact use here is as follows.

The positive factors cancel in \(n=T_0/|T_0|\), giving a smooth direction through both endpoints. At the inner edge \(n_z-t_sn_\theta=0\) and \(n_\theta+t_sn_z>0\). At the outer edge \(n=(1,0)\), \(t_s=0\), giving the same two conclusions. In the interior,
\[
n_\theta+t_sn_z=\frac{P_c-v_s}{|p_s-(a,-b_s)|}>0,\qquad
n_z-t_sn_\theta=\frac{J_c}{|p_s-(a,-b_s)|}.
\]
The admissible cone makes
\[
2-(v_s-2)\frac{(n_z-t_sn_\theta)^2}{(n_\theta+t_sn_z)^2}>0.
\]
Both the denominator and this gap extend continuously to the closed annulus, where the gap has value two at both radial edges. Their positive compact minima permit one \(0<\kappa<2\) with
\[
n_\theta+t_sn_z\ge\kappa,\quad
(v_s-2)(n_z-t_sn_\theta)^2
\le(2-\kappa)(n_\theta+t_sn_z)^2.
\]
The positive lower bounds on \(F,a,v_s-2\) in the interior and the original endpoint bounds likewise extend uniformly by compactness.

The original stress identity \(T_0=F(p_s-(a,-b_s))\) proves nonvanishing throughout the open shell: if it vanished, \(P_c=v_s\), contrary to admissibility. The outside stress remains zero by the exact endpoint restoration and unchanged inner region. Define the original proposed common edge weight
\[
\zeta(X)=\exp(-t_1^2/y_a^2-4/y_b^2),\qquad
\delta=\min(1,y_a,y_b),
\]
extended by zero outside the open shell. On a sufficiently short inner collar, the second exponential is smooth and bounded above and below by positive constants, while \(g_a,B_0\) have the required nonzero value bounds and fixed derivative bounds. The inner factorization therefore proves \(|T_0|\ge c\zeta\) and \(|\partial^IT_0|\le C_I\zeta\delta^{-m_I}\). On a short outer collar the first exponential is similarly a smooth positive factor; \(y_b^{-3}b_\theta\) has a lower positive bound and its derivatives have only finite inverse powers of \(y_b\). The supplied outer factor derivative bounds give the same conclusion. On the remaining compact interior both \(\zeta\) and \(|T_0|\) have positive minima and every fixed derivative is bounded, so the same pair of inequalities follows after increasing constants. These three regions cover the annulus. The elementary exponential argument in the first file proves smooth zero extension of all stress derivatives at both boundaries.

All remaining completion claims in C.3 are exact preservation statements: the axis Cartesian formulas remain unchanged on the analytic rectangle; the pressure at infinity and exterior moment values remain unchanged by the proved five-moment map; the exterior heat function is unchanged pointwise; and on \(X\ge X_v=X_{\rm end}\) the original \(U=M=0\) gives \(V_0=0\) directly by its formula. The third and fourth reserved intervals remain the exact original \(U=0,E=c_{\rm patch}(1+\eta^2)^{-1}X^{-1/2-\lambda}\) intervals, with their original order. Fixing this one finite \(N\) before the physical scale \(q\), all dyadic bands, and all later correction stages proves the claimed independence of the resulting derivative constants from those later parameters.
