# Read scope, dependency boundary, and outputs

Source inspected: the supplied 165-page PDF *Finite Time Blowup for Navier-Stokes*. Its SHA-256 was checked twice, including by exact_checks.py: 8c8a94ad9ac824c8b605b9827cadf7beaca48bd10b380de3cfc872a2c37afa81. The full local path and URL are in LOGBOOK.md. No external source instruction was executed.

## Complete assigned reading and reconstruction

| Source unit | Source pages | Written reconstruction |
|---|---:|---|
| Section 6.1 and exact physical evaluation | 62-64 | 01_auxiliary_geometry.md, coordinate and Fourier sections |
| Lemma 6.1, partitions and rectangle separation | 64-66 | Same file, graph coloring and exact covering obstruction |
| Lemma 6.2, common torus and operations | 66-68 | Same file, explicit lifts, Haar characters, deck lattice |
| Lemma 6.3, counts and integration paths | 68-69 | Same file, mesh counts and affine path derivatives |
| Definitions 6.4-6.5, Proposition 6.6 | 69-72 | Same file, weighted product and derivative rules |
| Lemma 7.1, phase and frame | 73-77 | 02_pulse_equation.md, phase, projection and plane calculations |
| Proposition 7.2, Corollary 7.3 | 77-80 | Same file, pressure sign, propagator, differentiated ODE, supports, quantifiers |
| Lemma 7.4 and energy identity | 80-81 | Same file, invariant Riccati strip, homogeneous bounds and energy transfer |
| Proposition 7.5 | 81-84 | 03_covariance_curl_and_tails.md, exact averages, two columns, determinant, positive roots, physical assembly |
| Proposition 7.6 | 84-85 | Same file, signed differential inverse and band assembly |
| Lemma 7.7 and equation (7.40) | 85-87 | Same file, exact curl, pressure conjugacy, retained cutoff terms and every-order flatness |
| Corollary 7.8 | 87 | Same file, full four-term expansion and all exponent losses |
| Lemma C.1 | 158-160 | 04_admissible_cone.md, loop, removable singularity, monotone variance, uniform choice, circle reparametrization |
| Proposition C.2 | 161-163 | Same file, exact insertion shears, five moments, Jacobian rank, nonlinear correction and exterior map |
| Proposition C.3 | 163-165 | Same file, direct use of preserved collar factors, common weight and retained profile data |

All text and every proof in Section 6, Section 7, and Appendix C were read. The tails of neighboring sections on pages 62, 87, and 157 do not constitute complete reads of those neighboring sections.

## Additional dependency reading

- Pages 24-31: coordinate definitions, profile-to-stress identity, moments (4.15), explicit integrated coefficients (4.16), exact restoration and stability Lemma 4.4, cone definitions and Lemma 4.5. Relevant identities are independently derived or used in exact displayed formulas in the output. Page 32 was displayed in a batch whose output was truncated, so no full reading of page 32 is asserted.
- Page 33: full Theorem 4.6 conclusions, including direction, edge weights, moment equalities, exterior and reserved patches.
- Pages 34 and 37: finite-moment lemma, construction statement fragments and order of choices. These are dependency inspection, not a full audit of Section 4.
- Formula (4.35), around page 38: exact four-gap definition retrieved separately and checked against the Appendix C reconstruction.
- Pages 59-60: nearby summation argument and Proposition 5.5 statement, including all derivative, shell-weight, endpoint and reserved-patch properties. Its full proof and its earlier inputs are not reconstructed by this lane.
- Pages 126-129: complete Lemmas A.1-A.2 and Corollary A.3; the five-moment rank and nonlinear solve are independently proved in 04_admissible_cone.md. The beginning of A.2 and reserved-patch ordering were read.
- Pages 140-143: complete Lemma A.8, Lemma A.9, Proposition A.10 and their proofs, plus the end of the preceding proof. This confirms the exact external edge factors (A.48)-(A.51) used by C.3. The full outer-profile construction and its parameter margins remain owned by the profiles lane.
- Pages 152-153: activation equations and inner factorization (B.26)-(B.31), and Corollary B.6. Their statements and calculations were inspected; the full preceding axis-profile existence and continuation are not reconstructed by this lane.

## Visual PDF checks

Rendered source pages 63, 74, 75, 78, 82, 83, 85, 86, 159, 160, 161, 162, and 164 to PNG with Poppler at a maximum dimension of 1600 pixels, and inspected all thirteen images. The actual matrices, square-root placements, signs, powers, integration measures and support formulas on these pages agree with the formulas used in the derivations. The page extracts in the directory are scratch inspection material; the new mathematical output is in the four derivation files.

## Imported mathematical inputs not proved in this lane

1. Existence of the complete input profiles satisfying Theorem 4.6's axis, heat-exterior, moment and initial relaxed/admissible margin data, as produced by Appendices A-B. Appendix C's transformation of those data is proved here; the initial construction is another lane's responsibility.
2. Existence of the realized background in Proposition 5.5 with its every-fixed-order coefficient bounds and one-sided endpoint extensions. Every pulse consequence and the exact constrained inverse are proved here; the background construction is another lane's responsibility.
3. The source's full normalized residual expansion in Section 9 and its improvement cycle. This lane proves the operator maps and all local exponents from Sections 6-7 but has not reconstructed every term of the complete Navier-Stokes residual.
4. The infinite correction summation, compactification, terminal extension and whole-space/torus endpoint theorem in Sections 9-10. Fixed-stage Gaussian tails are proved flat to every physical order here. That result alone is not substituted for the infinite-stage proof.

These are explicit audit boundaries, not newly posited mathematical assumptions intended to replace the corresponding source proofs. No standalone global Navier-Stokes theorem is claimed by this lane.

## Reproducible output

- complete_derivations.md: concatenation of all four full mathematical files.
- oscillations_body.tex: directly includable LaTeX body generated by the installed Pandoc; requires amsmath, amssymb, and hyperref in the receiving document.
- build_tex.py: local reproducible generation of the combined Markdown and TeX body.
- exact_checks.py and exact_checks_results.json: 28 exact algebra checks, with source-hash verification recorded separately. The executable calculations supplement the written analytic proofs and are not substituted for them. The latest replay also retains the correction that the longitudinal scalar has class W_(alpha+1/2-kappa_s), whereas its harmonic derivative has class W_(alpha-kappa_s).
- qa/syntax_check.tex: minimal wrapper for a pdflatex -draftmode syntax check. This lane does not publish a standalone PDF.
- STATUS.md and LOGBOOK.md: findings and durable work record.
