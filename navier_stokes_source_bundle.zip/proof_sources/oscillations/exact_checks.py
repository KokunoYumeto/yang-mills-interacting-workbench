"""Exact algebra checks supplementing (not replacing) the written proofs.

Run with the already installed system Python and SymPy. No Lean/Lake/Elan.
No numerical tolerances are used. Original constants, signs, and variables are
retained; a residual is checked by exact algebraic expansion/cancellation.
"""

from pathlib import Path
import hashlib
import json
import argparse
import sympy as s

HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-pdf', type=Path,
                    default=HERE.parents[2]/'output/navier_stokes_research_2026-09-08/lanes/web_bundle_audit/coordination/claimed_proof/openai_navier_stokes.pdf')
SOURCE = parser.parse_args().source_pdf
EXPECTED = "8c8a94ad9ac824c8b605b9827cadf7beaca48bd10b380de3cfc872a2c37afa81"
results = []


def zero(name, value):
    vals = list(value) if isinstance(value, s.MatrixBase) else [value]
    residuals = [s.cancel(s.expand(v)) for v in vals]
    assert all(v == 0 for v in residuals), (name, residuals)
    results.append({"name": name, "status": "exact zero", "components": len(vals)})


source_rehashed = SOURCE.is_file()
digest = hashlib.sha256(SOURCE.read_bytes()).hexdigest() if source_rehashed else EXPECTED
assert digest == EXPECTED, 'source revision mismatch'

sqrt2 = s.sqrt(2)
Jg = s.Matrix([[3, 1], [1, 5]])
bg = sqrt2 - 1
vr, vt = s.Matrix([1, -bg]), s.Matrix([bg, 1])
zero("radial eigenvector", Jg * vr - (4 - sqrt2) * vr)
zero("temporal eigenvector", Jg * vt - (4 + sqrt2) * vt)
zero("orthogonality", vr.dot(vt))
zero("covering degree", Jg.det() - 14)
zero("rectangle Jacobian", s.Matrix.hstack(vr, vt).det() - (1 + bg**2))

h, rho, kappa, af, e = s.symbols("h rho kappa af e", real=True)
A = s.Rational(1, 2) + h
dr = 2 * ((1 + h) * rho - h * kappa)
zero("radial auxiliary Q exponent", -(1 + h) * rho + dr / 2 + h * kappa)
zero("chart time exponent", 2 * A + s.Rational(1, 2) - A - (1 + h))
zero("chart viscosity exponent", 2 * A + s.Rational(1, 2) - A - 1 - h)
zero("physical leading stress Q exponent", -2 * A + h + A + s.Rational(1, 2))
zero("moment Jacobian exponent", af - e / 2 - s.Rational(1, 2) - (af - (e + 1) / 2))

# Exact reference plane calculation with the unit relation retained.
F, Nt, Nz, gn, sv = s.symbols("F Ntheta Nz gnorm s", real=True)
er = s.Matrix([1, 0, 0])
N = s.Matrix([0, Nt, Nz])
K = s.Matrix([0, -Nz, Nt])
ell = er - sv * K
Kmat = s.Matrix([[0, -2 * F, 0], [2 * F + gn * Nt, 0, 0], [gn * Nz, 0, 0]])
zero("reference radial diagonal scalar", ell.dot(-Kmat * ell))
zero("reference radial off diagonal", ell.dot(-Kmat * N) - 2 * F * Nt)
zero("reference tangential off diagonal with unit relation",
     N.dot(-Kmat * ell) + 2 * F * Nt + gn * (Nt**2 + Nz**2))
zero("reference tangential diagonal scalar", N.dot(-Kmat * N))
L0, u = s.symbols("lambda0 u", nonzero=True, real=True)
# Introduce q=sqrt(1+s^2) as a retained algebraic coordinate with q^2=1+s^2.
qframe = s.symbols("qframe", nonzero=True, real=True)
cf = L0 / (2 * F * Nt)
Dmat = s.Matrix([[0, 2 * F * Nt / qframe**2], [L0**2 / (2 * F * Nt), 0]])
M = s.Matrix([[1, 1], [cf * qframe, -cf * qframe]])
zero("reference two eigenvectors", Dmat * M - M * s.diag(L0 / qframe, -L0 / qframe))

# Pressure and constraint for arbitrary 3-vector data.
n1, n2, n3, p1, p2, p3 = s.symbols("n1 n2 n3 np1 np2 np3")
t1, t2, t3, f1, f2, f3 = s.symbols("t1 t2 t3 f1 f2 f3")
km, dm = s.symbols("km dm", nonzero=True)
n, np = s.Matrix([n1, n2, n3]), s.Matrix([p1, p2, p3])
t, f = s.Matrix([t1, t2, t3]), s.Matrix([f1, f2, f3])
n2norm = n.dot(n)
Proj = s.eye(3) - n * n.T / n2norm
Ap = -Kmat + n * (n.T * Kmat - np.T) / n2norm
tp = Ap * t - dm * t - Proj * f
pi = s.I / km * (n.dot(Kmat * t) - np.dot(t) + n.dot(f)) / n2norm
zero("pressure full cancellation", tp + Kmat * t + dm * t + s.I * km * n * pi + f)
zero("constraint evolution", np.dot(t) + n.dot(tp) + dm * n.dot(t))
Cm = s.I * n.cross(t) / (km * n2norm)
zero("curl exponential amplitude", s.I * km * n.cross(Cm) - t + n * n.dot(t) / n2norm)

ac, us, hp, hm, tn, tk = s.symbols("Ac ustar hplus hminus TN TK", nonzero=True)
H = s.Matrix([[-ac * hp, -ac * hm], [-us * hp, us * hm]])
y = s.Matrix([(-tn/ac-tk/us)/(2*hp), (-tn/ac+tk/us)/(2*hm)])
zero("two positive covariance coefficients solve the target", H * y - s.Matrix([tn, tk]))
zero("covariance determinant", H.det() + 2 * ac * us * hp * hm)

a, bs, ps1, ps2 = s.symbols("a bs ps1 ps2", nonzero=True)
ts = -bs/a
vs = a * (1 + ts**2)
Pc, Jc = ps1 + ts*ps2, ps2 - ts*ps1
Ttheta, Tz = F*(ps1-a), F*(ps2+bs)
zero("stress parallel gap", Ttheta + ts*Tz - F*(Pc-vs))
zero("stress transverse gap", Tz - ts*Ttheta - F*Jc)
v, P, J, w = s.symbols("v P J w")
poly = 2*(P-v)**2 - (v-2)*J**2
zero("cone polynomial expansion", poly - (2*v**2 + (-4*P-J**2)*v + 2*P**2 + 2*J**2))
zero("strict smaller-root lower bound identity",
     (w+J**2/4)**2 - J**2*(w/2+J**2/16) - w**2)

z = s.symbols("z")
# M_e coefficients follow exactly by integrating the even powers of sin.
Me = 1 + z**2/s.Integer(4) + z**4/s.Integer(64) + z**6/s.Integer(2304)
ratio = s.series(Me.subs(z,2*z)/Me**2-1,z,0,6).removeO()
zero("variance Taylor leading coefficient", ratio.coeff(z,2) - s.Rational(1,2))
zero("variance Taylor has no odd coefficients", ratio.coeff(z,1)+ratio.coeff(z,3)+ratio.coeff(z,5))

# Insertion identities retaining derivatives at fixed phi.
Nfreq, DXA, DXB, Et, aloop, bloop, olda, oldb = s.symbols("N DXA DXB E aL bL a bs", nonzero=True)
phia = -(aloop-olda)/2
phib = Et*(bloop-oldb)/2
zero("radial insertion a", olda - 2*DXA/Nfreq - 2*phia - (aloop-2*DXA/Nfreq))
zero("radial insertion b numerator", oldb + 2*DXB/(Nfreq*Et) + 2*phib/Et - (bloop+2*DXB/(Nfreq*Et)))

report = {"source_sha256": digest, "source_capture_rehashed_this_run": source_rehashed,
          "checks": results, "count": len(results),
          "meaning": "Exact algebra supplements the human-written analytic/support/quantifier proofs; no finite numerical test certifies those proofs."}
(HERE / "exact_checks_results.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"count": len(results), "status": "all exact checks passed", "source_sha256": digest}))
