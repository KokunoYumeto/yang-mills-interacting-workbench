# Auxiliary geometry and coefficient algebra: independent derivation

Source: supplied *Finite Time Blowup for Navier-Stokes*, Section 6, pp. 62-72. Source identity and audit boundary are recorded in `LOGBOOK.md` and `READ_SCOPE.md`. The formulas below use the source's original cylindrical coordinate orientation, chart scales, integer covering, and support domains. The geometric and algebraic assertions are proved here directly.

## Coordinate maps and exact derivative intertwining

Let \(A=1/2+h\), \(D=1/2-h\), \(0<h<1/100\), \(Q=2^{-\ell}\), \(\varepsilon=Q^h\), \(S_*=\ell^2\), and
\[
R=r/Q^{1/2},\quad Z=z/Q^D,\quad T=(1-t)/Q.
\]
The profile radius is \(R_{\rm profile}=r/q^{1/2}\), so the exact transition is \(R=\sqrt{q/Q}\,R_{\rm profile}\). No equality of these different radius coordinates is used. The original similarity variables obey \(z=q^D\eta\), \(1-t=q(1-\eta^2)\), with \(L=1-2h\eta^2>0\). On a dyadic shell \(q/Q\in[1/2,2]\), \(q/Q\) and \(\eta\) are smooth functions of \(Z,T\), including one-sided derivatives at \(T=0\). Indeed \(T=s-Z^2s^{2h}\), \(s=q/Q\), has derivative \(1-2hZ^2s^{2h-1}=L\ge1-2h\). Repeated implicit differentiation bounds each fixed chart derivative on the compact shell. Thus the ordinary chart and profile derivatives used below are related by finite sums with uniformly bounded smooth coefficients.

Set
\[
J_g=\begin{pmatrix}3&1\\1&5\end{pmatrix},\quad b_g=\sqrt2-1,
\quad v_r=(1,-b_g),\quad v_t=(b_g,1),
\]
\[
\Lambda_g=4-\sqrt2,\quad T_g=4+\sqrt2,\quad
\rho_g=\frac{\log\Lambda_g}{\log T_g},\quad \kappa_s=10^{-5},
\quad d_r=2((1+h)\rho_g-h\kappa_s).
\]
Direct multiplication gives \(J_gv_r=\Lambda_gv_r\), \(J_gv_t=T_gv_t\), \(v_r\cdot v_t=0\), and \(\det J_g=14\). Also \(\rho_g>0\) and \(\rho_g>\kappa_s\), hence \(d_r>0\). For example \(\Lambda_g>2\), \(T_g<6\) imply \(\rho_g>\log2/\log6>1/3>\kappa_s\).

On the extended domain with independent \(Y\in\mathbb R^2/\mathbb Z^2\), define
\[
\iota(r,\theta,z,t)=(r,\theta,z,t,v_rr^{d_r}+v_tt\bmod\mathbb Z^2).
\]
For every smooth extended scalar \(F\), the ordinary chain rule proves the exact identities
\[
\partial_t(\iota^*F)=\iota^*((\partial_t+v_t\cdot\partial_Y)F),\qquad
\partial_r(\iota^*F)=\iota^*((\partial_r+d_rr^{d_r-1}v_r\cdot\partial_Y)F).
\]
The \(z,\theta\) identities have no extra term. These are morphisms of differential algebras: pullback preserves sums and products and intertwines the four stated derivations. Their commutators vanish because the only variable coefficient depends on \(r\), the extra directions are constant and independent of \(Y,t,z,\theta\), and the radial derivation is the only derivation differentiating that coefficient. The fields depending on \(Y\) vanish in a neighborhood of the axis at each \(q>0\), so no differentiability of \(r^{d_r}\) at \(r=0\) is invoked.

For \(i=\lfloor\log_{T_g}(Q^{-1-h}/S_*)\rfloor\ge0\), let \(\pi_i(Y)=J_g^iY\bmod\mathbb Z^2\). This is a surjective group homomorphism of tori with finite kernel of cardinality \(14^i\). On a pullback \(f\circ\pi_i\), the two directional operators are exactly \(T_g^iN_if\) and \(\Lambda_g^iL_if\), where \(N_i=v_t\cdot\partial_{Y_i}\), \(L_i=v_r\cdot\partial_{Y_i}\). Thus
\[
\mathsf t_*=Q^{1+h}\mathsf t=-\varepsilon\partial_T+c_iN_i,
\quad D_r=\sqrt Q\,\mathsf r=\partial_R+M_id_rR^{d_r-1}L_i,
\]
\[
c_i=T_g^iQ^{1+h},\quad M_i=\Lambda_g^iQ^{d_r/2},\quad
D_z=\sqrt Q\partial_z=\varepsilon\partial_Z,
\quad D_\theta=R^{-1}\partial_\theta.
\]
The floor inequality is strict on its left:
\[
T_g^{-1}Q^{-1-h}/S_*<T_g^i\le Q^{-1-h}/S_*.
\]
It follows that \(T_g^{-1}S_*^{-1}<c_i\le S_*^{-1}\), and, using \(\Lambda_g^i=(T_g^i)^{\rho_g}\),
\[
T_g^{-\rho_g}\varepsilon^{-\kappa_s}S_*^{-\rho_g}
<M_i\le\varepsilon^{-\kappa_s}S_*^{-\rho_g}.
\]
Every radial derivative of \(d_rR^{d_r-1}\) is bounded on the fixed positive radial interval. This proves the claimed additional radial cost \(\varepsilon^{-\kappa_s}\), with its retained power of \(S_*\).

For physical velocity \(Q^{-A}u_*\), pressure \(Q^{-2A}p_*\), and residual multiplier \(Q^{2A+1/2}\), the time, spatial first-derivative, and Laplacian coefficients are respectively
\[
Q^{2A+1/2-A}=Q^{1+h},\qquad
Q^{1/2},\qquad
Q^{2A+1/2-A-1}=Q^h=\varepsilon.
\]
These identities retain the source's viscosity-one chart convention; scaling to arbitrary viscosity is outside this lane.

## Fourier inversion and descent

For \(n=(n_1,n_2)\ne0\),
\[
v_r\cdot n=(n_1+n_2)-\sqrt2n_2.
\]
Its product with the algebraic conjugate is the nonzero integer \((n_1+n_2)^2-2n_2^2\). It cannot be zero unless \(n_2=0=n_1\), by irrationality of \(\sqrt2\). The conjugate has absolute value at most \(C|n|\), so \(|v_r\cdot n|\ge1/(C|n|)\). For \(v_t\cdot n=(n_2-n_1)+\sqrt2n_1\), the same argument uses \((n_2-n_1)^2-2n_1^2\). Therefore both directional inverses on zero-mean smooth torus functions have Fourier multipliers bounded by \(C(1+|n|)\), retaining the Fourier derivative factor \(2\pi i\): the inverse of \(v\cdot\partial_Y\) multiplies the \(n\)-coefficient by \((2\pi i\,v\cdot n)^{-1}\). Rapid Fourier decay is preserved. In Sobolev norms this gives \(\|L^{-1}f\|_{H^s}\le C_s\|f\|_{H^{s+1}}\), with the zero coefficient defined to be zero. Taking a further fixed Sobolev embedding loss gives all fixed classical derivatives. No infinite derivative loss occurs.

If \(f\) descends through \(\pi_i\), its Fourier support lies in \((J_g^i)^T\mathbb Z^2\). Translation multiplies each coefficient by a character, averaging deletes nonzero coefficients, and a directional Fourier inverse multiplies them by scalar values. Each operation preserves this sublattice. Radial integration at fixed \(z,t\) preserves deck invariance pointwise in the integral. These are the precise maps proving the descent claims.

## Separation of all interacting labels

Use the dyadic squared partition \(\sum_\ell\chi_\ell(q)^2=1\), the product grid squared partitions of mesh \(S_*^{-3}\), and the duplicated signs in the source's labels \(\gamma=(\ell,a,\sigma)\). On the active annulus select every grid support meeting the active shell and a representative in that intersection. Then \(\eta_\gamma=\chi_\ell\chi_{\ell,a}\) gives \(\sum_{\beta=(\ell,a)}\eta_\beta^2=1\), counting each box once and the two signs separately only when assigning rectangles.

Overlapping dyadic supports imply \(|\ell-\ell'|\le2\). Join labels whenever the fixed-factor enlarged physical grid boxes intersect and the band difference is at most four, and join the two signs of each box. A chart scale ratio for bands differing by four is bounded above and below; \(\ell^2/(\ell')^2\) has the same property for \(\ell,\ell'\ge\ell_0>4\). A grid box thus meets a uniformly bounded number of boxes in each of finitely many bands. The countable graph has maximum degree \(d<\infty\). Enumerating its vertices and assigning the first unused color in \(\{1,\ldots,d+1\}\) gives a proper coloring.

Writing \(f(\ell)=((1+h)\ell\log2-2\log\ell)/\log T_g\), the mean-value bound and the floor operation give
\[
|i(\ell)-i(\ell')|\le1+\frac{4(1+h)\log2+8/\ell_0}{\log T_g}.
\]
Fix an integer upper bound \(\Delta_{\max}\). There are only finitely many ordered color constraints
\[
c_\mu\ne J_g^\Delta c_\nu\pmod {\mathbb Z^2},\qquad0\le\Delta\le\Delta_{\max},
\]
excluding only the tautological constraint \((\Delta,\mu,\nu)=(0,\nu,\nu)\). For different colors, the forbidden equality is a proper closed subset with empty interior of the finite product of tori. For a self-pair with \(\Delta>0\), \(J_g^\Delta-I\) is nonsingular because its eigenvalues are \(\Lambda_g^\Delta-1,T_g^\Delta-1>0\); its kernel on the torus is finite, so this forbidden subset also has empty interior. A finite union of these closed sets has empty interior. The complement is open and nonempty, and rational tuples are dense, giving the rational centers specified in the source. There is consequently a strictly positive minimum distance \(d_c\) of every forbidden difference from the lattice.

Let \(C_J=\max_{0\le\Delta\le\Delta_{\max}}\|J_g^\Delta\|\) and \(C_v=\|v_r\|+\|v_t\|\). Choose \(r_0>0\) sufficiently small that all enlarged rectangles are injective and \(2r_0 C_v(C_J+1)<d_c\). If two absolute preimages of enlarged rectangles at levels \(i,i+\Delta\) intersect, their common point produces
\[
c_\mu-J_g^\Delta c_\nu=J_g^\Delta e_\nu-e_\mu\pmod{\mathbb Z^2},
\quad |e_\nu|,|e_\mu|\le2r_0C_v.
\]
The right side has distance from zero less than \(d_c\), a contradiction for joined labels. All labels whose slow supports meet were joined. Therefore their enlarged auxiliary preimages are disjoint. For smoothly extended fields supported in these products, the support of every derivative is contained in the same closed support, so all cross-label derivative products vanish before and after \(\iota^*\). This proves the required nonlinear support assertion, including boundaries.

On a band rectangle, write \(Y_i-c_\gamma-k=\xi_gv_r+\eta_gv_t\) and \(v=(\eta_g+r_0)/c_i\), \(L_s=2r_0/c_i\). Orthogonality gives \(L_i\eta_g=N_i\xi_g=0\), \(L_i\xi_g=N_i\eta_g=1\). Hence \(D_rv=D_zv=0\), \(\mathsf t_*v=1\). This is the exact reason spatial differentiation of the pulse does not incur a time-direction torus frequency.

## Common torus, lifts, integration paths, and label counts

At a fixed \((z_0,t_0)\), put \(q_{\mathrm{loc}}=q(z_0,t_0)>0\).
By continuity choose a neighborhood \(U\) with
\(q(U)\subset(q_{\mathrm{loc}}/2,2q_{\mathrm{loc}})\).
An active dyadic band obeys \(q/2\le Q_\ell\le2q\).
Every band meeting \(U\) therefore has
\(q_{\mathrm{loc}}/4<Q_\ell<4q_{\mathrm{loc}}\), so its dyadic
indices lie in a finite set \(\mathcal L(U)\) with span at most four.
The previously proved four-band bound on \(i(\ell)-i(\ell')\)
therefore applies to this entire set. Take \(i_0=\min_{\ell\in\mathcal L(U)}i(\ell)\), \(H=J_g^{i_0}Y\). Then \(Y_i=J_g^\Delta H\), \(0\le\Delta\le\Delta_{\max}\). The preimage of an injective rectangle consists exactly of the \(14^\Delta\) images
\[
J_g^{-\Delta}(c_\gamma+k+\xi_gv_r+\eta_gv_t)\pmod {\mathbb Z^2},
\quad[k]\in\mathbb Z^2/J_g^\Delta\mathbb Z^2.
\]
Different cosets give disjoint copies: an overlap would imply that their \(k\)-difference is in \(J_g^\Delta\mathbb Z^2\), after using injectivity in the band rectangle. This also proves there are no omitted copies. Derivative factors of \(J_g^\Delta\) are uniformly bounded. Surjectivity of \(\pi_{i_0}\) transfers the previously proved support separation to \(H\).

For a torus character \(e^{2\pi i n\cdot Y_i}\), pullback has frequency \((J_g^\Delta)^Tn\), zero exactly when \(n=0\). Integrating a Fourier series therefore proves exact preservation of normalized Haar measure, not an approximation depending on frequency. This proves agreement of the absolute, common, and band averages. On overlaps the representatives pull back to the identical extended field; their compatibility is equality after the respective covering maps. Those maps are independent of \(R,Z,T\), so slow derivatives preserve compatibility. The normalized fast derivatives are the same absolute operators \(Q^{1+h}N_{\rm abs}\) and \(Q^{d_r/2}L_{\rm abs}\); they also preserve it.

A mesh of spacing \(S_*^{-3}\) gives \(O(1)\) overlap at a point, \(O(S_*^9)\) boxes in a compact three-dimensional chart set, and \(O(S_*^3)\) boxes along a bounded radial line. The two signs and bounded covering multiplicities contribute fixed factors. Radial integration fixes \(q(z,t)\); it can collect radial boxes but no additional bands. The collected sum therefore introduces only a polynomial in \(S_*\).

Define \(\lambda_t(w)=v_t\cdot w/(1+b_g^2)\). In a lifted common rectangle, the exact path holding slow and transverse coordinates fixed is
\[
H_w=H+T_g^{-\Delta}c_i(w-v(H))v_t.
\]
Because \(\lambda_tJ_g^\Delta=T_g^\Delta\lambda_t\),
\[
D_Hv=T_g^\Delta\lambda_t/c_i,\quad
D_HH_w=I-v_t\lambda_t,
\]
and all higher derivatives of these affine expressions vanish. The first is \(O(S_*)\), the second uniformly bounded. No phase-averaging operation is hidden in this path: values at distinct preimages remain distinct. Deck translations commute with the path and merely reindex the rectangle copy. A uniquely prescribed initial-value solution therefore descends to the common torus.

## Weighted coefficient classes and complete product rules

On \(X_a<X<X_b\), let
\[
\zeta=\exp\left(-\frac{a_a}{\log^2(X/X_a)}-\frac{a_b}{\log^2(X_b/X)}\right),
\quad\delta=\min\{1,\log(X/X_a),\log(X_b/X)\},
\]
with fixed \(a_a,a_b>0\), and extend \(\zeta\) by zero. For any \(b>0,N\ge0\), \(\zeta^b\delta^{-N}\to0\) faster than every power at either edge: put \(x=1/\delta\to\infty\) and use \(x^Ne^{-cx^2}\to0\), proved for example by comparing \(N\log x-cx^2\) with \(-cx^2/2\) for large \(x\). Repeated derivatives of the explicit exponential have the same exponential times a finite sum of inverse edge-distance powers. Thus all stated derivative bounds imply smooth zero extension at radial boundaries.

The mean class \(\mathcal M_\alpha\) consists of angular-independent compatible coefficients with derivatives bounded by \(C_I\varepsilon^\alpha S_*^{b_I}\zeta\delta^{-d_I}\), smooth zero extension outside the active shell, and no rectangle or envelope condition. The wave class \(\mathcal W_\alpha\) uses the same derivative variables \((R,Z,T,H_1,H_2)\), retains a label and nonzero harmonic, has the prescribed closed slow/transverse/shell supports, and bounds \(C_I\varepsilon^\alpha S_*^{b_I}\sqrt\zeta\delta^{-d_I}P(v)\). Actual cutoff coefficients also have compact pulse support and smooth extension there. Equal label-harmonic contributions must be added before testing the bounds. \(P(v)\) is a pointwise weight; these definitions already require all coefficient derivatives to obey it, so no differentiation of a mere inequality for \(P\) is being assumed.

Leibniz's formula has finitely many terms at each order. The retained products of weights obey
\[
\zeta^2\le\zeta,\quad\zeta^{3/2}P\le\sqrt\zeta P,
\quad\zeta P^2\le\zeta,\quad\zeta P^2\le\sqrt\zeta P
\]
because \(0\le\zeta,P\le1\). These prove \(\mathcal M_\alpha\mathcal M_\beta\subset\mathcal M_{\alpha+\beta}\), \(\mathcal M_\alpha\mathcal W_\beta\subset\mathcal W_{\alpha+\beta}\), and the two same-label wave-product rules. A zero-harmonic product extends to a mean after temporal cutoff. Before cutoff it is only a mean-bounded local coefficient. Multiplication by a mean cannot enlarge the wave support; products of different actual labels are zero by separation. Finite sums retain the same exponent and suitable maxima of the polynomial degrees.

For a nonzero angular frequency \(kp_\gamma\in\mathbb Z\setminus\{0\}\), angular integration of \(e^{ik(m+m')\Phi_\gamma}\) is zero unless \(m+m'=0\), in which case it is one. This proves exactly which product coefficients survive. It does not identify angular averaging with auxiliary averaging. Products add harmonic integers and differentiation preserves them; a finite sequence of such operations leaves a finite band-independent set at each finite stage.

Ordinary coefficient derivatives shift the derivative index in the defining estimate, preserving \(\alpha\). Multiplication by \(M_id_rR^{d_r-1}\), with all its derivatives bounded above, proves \(D_r:\mathcal C_\alpha\to\mathcal C_{\alpha-\kappa_s}\), \(\mathcal C=\mathcal M,\mathcal W\). The other exact maps are \(D_z=\varepsilon\partial_Z:\mathcal C_\alpha\to\mathcal C_{\alpha+1}\), \(-\varepsilon\partial_T:\mathcal C_\alpha\to\mathcal C_{\alpha+1}\), and \(c_{i_0}N_{i_0}:\mathcal C_\alpha\to\mathcal C_\alpha\). Here \(c_{i_0}=T_g^{-\Delta}c_i\) and \(M_{i_0}=\Lambda_g^{-\Delta}M_i\), so a change to a common torus changes constants, not exponents. All these claims concern coefficients with the exponential factored out. Differentiating the exponential itself produces its exact \(ikm\nabla_*\Phi\) or \(ikm\mathsf t_*\Phi\) factor and is accounted for separately in the pulse analysis.

Finally, for \(f_*=Q^{a_f}f_{\rm phys}\), substitution \(r=\sqrt Q R\) gives the exact moment map
\[
\int R^e\langle f_*\rangle_Y\,dR
=Q^{a_f-(e+1)/2}\int r^e\langle f_{\rm phys}\rangle_Y\,dr.
\]
The measure and power weight are both retained. Normalized Haar compatibility proves that the average may be computed in any of the three torus representations.

# Phase, constrained evolution, and every fixed derivative

This file independently derives the claims of source pp. 73-81, Lemma 7.1, Proposition 7.2, Corollary 7.3, and Lemma 7.4. The exact auxiliary maps and operators are proved in the preceding file. The imported background assertion is Proposition 5.5: on the fixed enlarged annulus its chart radial component \(b\) is \(O(\varepsilon)\), its tangential components \(V,G\) differ from their leading profiles by \(O(\varepsilon^2)\), and these statements hold at every fixed slow derivative. The construction of that background belongs to another audit lane. Here the consequences for the pulse system are established explicitly.

## Cone coordinates and the phase gradient

Write \(F=V/R\), \(g=(RF_R,G_R)\) in component order \((\theta,z)\). At the fixed representative of a slow box, the leading shear is
\[
g_0=F_0(-a,b_s),\quad N=g_0/|g_0|,\quad K=(-N_z,N_\theta).
\]
Let \(t_s=-b_s/a\) and \(v_s=a(1+t_s^2)\). Since \(a,F_0>0\),
\[
N=-\frac{(1,t_s)}{\sqrt{1+t_s^2}},\quad
K=\frac{(t_s,-1)}{\sqrt{1+t_s^2}},\quad
|g_0|=aF_0\sqrt{1+t_s^2}.
\]
Retain the source's
\[
\lambda_0^2=-2F_0N_\theta(2F_0N_\theta+|g_0|),
\qquad c_0=\lambda_0/(2F_0N_\theta).
\]
Substitution gives
\[
\lambda_0^2
=2F_0^2\left(a-\frac2{1+t_s^2}\right)
=2aF_0^2(1-2/v_s)>0,\qquad
c_0^2=(v_s-2)/2,\quad c_0<0.
\]
The positive lower bounds on \(F_0,a,v_s-2\) and compact upper bounds give positive lower bounds on \(\lambda_0,|c_0|\), and finite upper bounds.

At the same, unfrozen profile point, \(T_0=F(p_s-(a,-b_s))\), \(P_c=p_{s,1}+t_sp_{s,2}\), \(J_c=p_{s,2}-t_sp_{s,1}\). Consequently
\[
T_0\cdot N=-\frac{F(P_c-v_s)}{\sqrt{1+t_s^2}},
\qquad
T_0\cdot K=-\frac{FJ_c}{\sqrt{1+t_s^2}}.
\]
Multiplication of \(T_0\) by the positive chart factor \((Q/q)^{A+1/2}\) changes neither sign nor quotient. Thus the two stress cone inequalities are exactly \(T_{0,*}\cdot N<0\) and
\[
\left|c_0\frac{T_{0,*}\cdot K}{T_{0,*}\cdot N}\right|<1.
\]
The weighted direction at a vanishing edge is used, not a division of zero values. Its smooth extension and strict compact margin give a supremum \(\mu<1\). Choosing \(u_*>0\) with \(u_*/\sqrt{1+u_*^2}>\mu\) is possible because that function increases to one. All quantities now frozen at representatives are kept fixed under differentiation. Uniform continuity in the compact chart domain makes the same strict cone margin valid on every enlarged box of diameter \(CS_*^{-3}\), after one lower bound on \(\ell\).

Retain \(k=\lceil\varepsilon^{-1/2}\rceil\), so for \(0<\varepsilon\le1\),
\[
1\le\varepsilon k^2\le(1+\sqrt\varepsilon)^2\le4,\qquad
k^{-1}\le\sqrt\varepsilon.
\]
Define
\[
B_s^2=\frac{\lambda_0}{\varepsilon k^2(1+u_*^2)^{3/2}},
\quad s(v)=\sigma(u_*/2+u_*v/L_s),\quad x_0=\sigma B_su_*/2.
\]
The \(B_s\) have fixed positive lower and upper bounds. Set
\[
(\widetilde p/R_0,p_z)
=B_s\left(K-\frac{\sigma u_*g_0}{L_s|g_0|^2}\right).
\]
Choose \(kp\) as the specified nearest nonzero integer to \(k\widetilde p\). The error \(|p-\widetilde p|\le k^{-1}\) suffices, including when the nearest unrestricted integer would have been zero. The integer is constant with the label. Put
\[
\Phi=p\theta+p_zZ/\varepsilon+x_0R-vH_\Phi,\qquad H_\Phi=pF+p_zG.
\]
Because \(D_rv=D_zv=0\) and the base is auxiliary-independent,
\[
n_\Phi=\nabla_*\Phi
=\bigl(x_0-v(H_\Phi)_R,\ p/R,\ p_z-\varepsilon v(H_\Phi)_Z\bigr).
\]
At the representative, before rounding, \((\widetilde p/R_0,p_z)\cdot g_0=-\sigma B_su_*/L_s\). Variation across the slow box changes this by \(O(S_*^{-3})\); the background change contributes \(O(\varepsilon^2)\); rounding contributes \(O(k^{-1})\). Hence
\[
|(H_\Phi)_R+\sigma B_su_*/L_s|
\le C(S_*^{-3}+\varepsilon^2+k^{-1}).
\]
Multiplication by \(v\le L_s=O(S_*)\) gives the radial comparison with \(B_ss(v)\). The tangential comparison has contributions \(O(S_*^{-1})\) from the deliberate tilt, \(O(S_*^{-3}+\varepsilon^2+k^{-1})\) from freezing and rounding, and \(O(\varepsilon S_*)\) from the axial phase term. A single sufficiently large \(\ell_*\) satisfies
\[
S_*^2(\varepsilon+\varepsilon^2+k^{-1})\le1
\]
for every \(\ell\ge\ell_*\), since \(S_*=\ell^2\) and \(\varepsilon=2^{-h\ell}\). Therefore
\[
|n_\Phi-B_s(s(v),K)|\le C/S_*.
\]
Differentiation in \(v\) gives \(n_\Phi'=(-(H_\Phi)_R,0,-\varepsilon(H_\Phi)_Z)\), also \(O(S_*^{-1})\). Each fixed number of slow derivatives of these coefficients is bounded by a polynomial in \(S_*\): the only growing factors in these formulas are \(v\), \(\varepsilon^{-1}\) in the phase itself, and the fixed chart derivatives. The \(\varepsilon^{-1}\) term of \(\Phi\) disappears in \(n_\Phi\); it is not discarded from the full exponential when physical derivatives are later taken.

The exact transport defect follows term by term:
\[
\mathsf t_*\Phi=-H_\Phi+\varepsilon v(H_\Phi)_T,\qquad
F\partial_\theta\Phi+GD_z\Phi=H_\Phi-\varepsilon vG(H_\Phi)_Z.
\]
Thus
\[
E_{\rm ik}:=(\mathsf t_*+bD_r+F\partial_\theta+GD_z)\Phi
=\varepsilon v((H_\Phi)_T-G(H_\Phi)_Z)+bn_{\Phi,r}.
\]
The background satisfies \(D^Ib=O_I(\varepsilon)\), while every
fixed coefficient derivative of \(n_{\Phi,r}\) is polynomially
bounded in \(S_*\). The exact product rule therefore gives
\[
D^I(bn_{\Phi,r})
=\sum_{J\le I}\binom IJ(D^Jb)(D^{I-J}n_{\Phi,r})
=O_I(\varepsilon S_*^{d_I}).
\]
For example, at fixed pulse coordinate,
\(\partial_Rn_{\Phi,r}=-v(H_\Phi)_{RR}\), whose bound can contain
a factor \(S_*\). Auxiliary coefficient derivatives of \(v\)
are \(O(S_*)\), and derivatives of the fixed affine path of order
two or greater vanish. Applying the same finite product rule
to \(\varepsilon v((H_\Phi)_T-G(H_\Phi)_Z)\) proves
\(D^IE_{\rm ik}=O_I(\varepsilon S_*^{b_I})\) for every fixed
\(I\), on the same domain. This introduces no smallness condition
on the higher derivatives.

## Exact pressure elimination and plane isomorphism

Set
\[
\mathcal K=
\begin{pmatrix}0&-2F&0\\2F+RF_R&0&0\\G_R&0&0\end{pmatrix},
\quad d=\varepsilon k^2|n_\Phi|^2,\quad
\mathcal A_\Phi=-\mathcal K+
\frac{n_\Phi(n_\Phi^T\mathcal K-(n_\Phi')^T)}{|n_\Phi|^2}.
\]
For the original equation
\[
t_m'+\mathcal Kt_m+m^2dt_m+ikm n_\Phi\pi_m=-f_m,
\quad n_\Phi\cdot t_m=0,
\]
differentiate its constraint to get \(n_\Phi\cdot t_m'=-n_\Phi'\cdot t_m\). Taking its normal component then forces
\[
\pi_m=\frac{i}{km}\,
\frac{n_\Phi\cdot\mathcal Kt_m-n_\Phi'\cdot t_m+n_\Phi\cdot f_m}{|n_\Phi|^2}.
\]
The factor has sign \(+i/(km)\): multiplying it by \(ikm n_\Phi\) gives the negative of the required normal vector. Substituting gives the projected equation
\[
t_m'=\mathcal A_\Phi t_m-m^2dt_m-\operatorname{proj}_{n_\Phi^\perp}f_m.
\]
Conversely this projected equation and the displayed pressure imply the original equation provided the constraint holds. For any solution of the projected equation,
\[
(n_\Phi\cdot t_m)'=-m^2d(n_\Phi\cdot t_m).
\]
An initially zero constraint remains zero, proving equivalence, existence, and uniqueness once the finite-dimensional initial-value equation is solved.

Since \(n_{\Phi,\tan}\) stays close to \(B_sK\), its norm has a uniform positive lower bound. The nonzero \(p/R\) also prevents it from being literally zero. Define
\[
K_a=n_{\Phi,\tan}/|n_{\Phi,\tan}|,\quad
N_a=((K_a)_z,-(K_a)_\theta),\quad
s_a=n_{\Phi,r}/|n_{\Phi,\tan}|.
\]
Then \(N_a\perp K_a\), \(|N_a|=|K_a|=1\), and
\[
U=[e_r-s_aK_a,N_a],\quad
M=\begin{pmatrix}1&1\\c_0\sqrt{1+s^2}&-c_0\sqrt{1+s^2}\end{pmatrix},
\quad B=UM
\]
maps \(\mathbb C^2\) isomorphically onto the actual complex plane \(n_\Phi^\perp\). The exact left inverse is
\[
B^\ell=M^{-1}\begin{pmatrix}e_r^T\\N_a^T\end{pmatrix}
\]
because the last displayed row matrix times \(U\) is \(I_2\). The determinant of \(M\) is \(-2c_0\sqrt{1+s^2}\), bounded away from zero. All factors and their inverses are uniformly bounded in value and polynomially bounded in each fixed coefficient derivative.

For clarity the ambient map also has an exact formula. Regard \(K_a\)
as the three-vector with zero radial component, and let
\(W_a=(e_r^T;N_a^T)\). Direct multiplication gives \(W_aU=I_2\).
For any \(w=w_re_r+w_KK_a+w_NN_a\in\mathbb C^3\),
\[
BB^\ell w=UW_aw=w_r(e_r-s_aK_a)+w_NN_a
=w-K_a(w_K+s_aw_r).
\]
Since \(n_\Phi=|n_{\Phi,\tan}|(s_ae_r+K_a)\), this proves
\[
B^\ell B=I_2,\qquad
BB^\ell=I_3-\frac{K_an_\Phi^T}{|n_{\Phi,\tan}|}.
\]
Thus \(BB^\ell\) is the projection onto \(n_\Phi^\perp\)
along \(\operatorname{span}_{\mathbb C}\{K_a\}\). Its restriction
to \(n_\Phi^\perp\) is the identity; its action on \(K_a\) is zero.
In particular the inverse assertion is not made on all of \(\mathbb C^3\).

The moving-plane differential equation has the exact coordinate form
\[
z_m'=B^\ell(\mathcal A_\Phi B-B')z_m-m^2dz_m
-B^\ell\operatorname{proj}_{n_\Phi^\perp}f_m.
\]
For its converse, differentiate \(n_\Phi^TB=0\) to obtain
\(n_\Phi^TB'=-(n_\Phi')^TB\). The definition of
\(\mathcal A_\Phi\) gives
\(n_\Phi^T\mathcal A_\Phi B=-(n_\Phi')^TB\).
Therefore each column of \(\mathcal A_\Phi B-B'\) lies in
\(n_\Phi^\perp\). Both \(Bz_m\) and the projected force lie there
as well. Multiplying the coordinate equation by \(B\) and using
\(BB^\ell=I\) on these three terms yields
\[
Bz_m'=(\mathcal A_\Phi B-B')z_m-m^2dBz_m
-\operatorname{proj}_{n_\Phi^\perp}f_m.
\]
Adding \(B'z_m\) proves the projected equation for \(t_m=Bz_m\),
and \(n_\Phi^Tt_m=0\) holds by construction. The displayed pressure
then recovers the full equation with its actual normal forcing.
Conversely, a constrained solution has \(z_m=B^\ell t_m\) and
\(t_m=Bz_m\). Differentiating the latter identity and multiplying
the projected equation by \(B^\ell\) gives exactly the coordinate
equation above. Both inverse compositions, including their initial
data and the unique pressure, are therefore proved.

For the reference normal \(n_{\rm ref}=B_s(s,K)\), use \(e=e_r-sK\) and \(N\) as an orthogonal plane basis, of lengths \(\sqrt{1+s^2}\) and \(1\). The actual source matrix \(\mathcal K_0\) gives
\[
\mathcal K_0e=(2F_0sK_\theta,\ 2F_0e_\theta+g_0),\quad
\mathcal K_0N=(-2F_0N_\theta,0).
\]
Consequently
\[
e\cdot(-\mathcal K_0e)=sK\cdot g_0=0,\quad
e\cdot(-\mathcal K_0N)=2F_0N_\theta,
\]
\[
N\cdot(-\mathcal K_0e)=-(2F_0N_\theta+|g_0|),\quad
N\cdot(-\mathcal K_0N)=0.
\]
Orthogonal projection onto \(n_{\rm ref}^\perp\) leaves these scalar products unchanged. Dividing the first coordinate by \(1+s^2\) produces
\[
\mathcal D=
\begin{pmatrix}
0&2F_0N_\theta/(1+s^2)\\
-(2F_0N_\theta+|g_0|)&0
\end{pmatrix}.
\]
Its two eigenvectors are exactly the columns of \(M\), with eigenvalues \(\lambda=\lambda_0/\sqrt{1+s^2}\) and \(-\lambda\), since \(c_0=\lambda_0/(2F_0N_\theta)\) and \(\lambda_0^2=-2F_0N_\theta(2F_0N_\theta+|g_0|)\). This verifies the orientation and signs of the growing coordinate.

Replacing the background and normal by the actual ones changes the algebraic projected matrix by \(O(S_*^{-1})\). This follows from the explicit rational expression for the projection, the uniform positive denominators, the value bounds already proved, and the mean-value formula on their common compact range. Also \(K_a-K,s_a-s=O(S_*^{-1})\), while their \(v\)-derivatives and \(s'\) are \(O(S_*^{-1})\). Hence \(B'=O(S_*^{-1})\) and the normal-motion term in \(\mathcal A_\Phi\) is \(O(S_*^{-1})\). Therefore
\[
B^\ell(\mathcal A_\Phi B-B')=
\operatorname{diag}(\lambda,-\lambda)+E,\qquad |E|\le C/S_*.
\]
Every fixed derivative of \(E\) is polynomially bounded; no derivative-smallness claim is needed. The damping comparison is
\[
d_{\rm ref}=\varepsilon k^2B_s^2(1+s^2),\qquad
|d-d_{\rm ref}|\le C/S_*,
\]
because \(\varepsilon k^2\) is bounded and \(|n_\Phi|^2-B_s^2(1+s^2)\) is \(O(S_*^{-1})\).

## Envelope and uniform forward inverse

Let
\[
a_{\rm net}(y)=\frac{\lambda_0}{\sqrt{1+y^2}}-
\frac{\lambda_0(1+y^2)}{(1+u_*^2)^{3/2}},
\qquad y=|s(v)|=u_*/2+u_*v/L_s.
\]
It is zero at \(v=L_s/2\), and direct differentiation gives
\[
\frac{d}{dv}a_{\rm net}(|s(v)|)
=-\frac{u_*\lambda_0|s(v)|}{L_s}
\left((1+s(v)^2)^{-3/2}+2(1+u_*^2)^{-3/2}\right).
\]
Since \(u_*/2\le|s|\le3u_*/2\), its value lies between \(-C/L_s\) and \(-c/L_s\), for fixed positive \(c,C\). Define \(P(v)=\exp(\int_{L_s/2}^v a_{\rm net}(|s(w)|)\,dw)\). Integrating the derivative inequality on either side of the midpoint, keeping the direction of each integral, gives
\[
-C_1(v-L_s/2)^2/L_s\le\log P(v)\le-c_1(v-L_s/2)^2/L_s.
\]
This proves the two Gaussian bounds and \(0<P\le1\) with the source's integral normalization.

Writing \(t_m=Bz_m\) gives
\[
z_m'=A_mz_m+g_m,\quad
A_m=\operatorname{diag}(\lambda,-\lambda)+E-m^2dI_2,
\quad g_m=-B^\ell\operatorname{proj}_{n_\Phi^\perp}f_m.
\]
For the complex Euclidean norm, taking the real part of \(z^*A_1z\) bounds the upper right derivative of \(|z|\) by \((\lambda-d_{\rm ref}+C/S_*)|z|\). Integration gives
\[
\|V_1(v,w)\|\le
\exp(C(v-w)/S_*)\,P(v)/P(w)\le C'P(v)/P(w).
\]
The factor \(C'\) is fixed because \(0\le v-w\le L_s\asymp S_*\). Since the difference of \(A_m\) from \(A_1\) is the scalar matrix \(-(m^2-1)dI_2\), differentiation directly verifies
\[
V_m(v,w)=\exp\left(-(m^2-1)\int_w^v d(a)\,da\right)V_1(v,w).
\]
For every nonzero integer \(m\), \(m^2-1\ge0\) and \(d>0\), so the same value bound is valid for all such harmonics. This is the exact mechanism preventing a new small-domain requirement when the finite harmonic set increases.

If the source obeys
\[
|D^If_m|\le C_I\varepsilon^\alpha S_*^{b_I}
\sqrt\zeta\,\delta^{-a_I}P(v),
\]
the zero-data Duhamel integral gives
\[
z_m(v)=\int_0^vV_m(v,w)g_m(w)\,dw,\quad
|z_m(v)|\le C\varepsilon^\alpha S_*^{b+1}
\sqrt\zeta\,\delta^{-a}P(v).
\]
The source's \(P(w)\) cancels the propagator's denominator exactly. The shell weights are constant along the integration path because \(X\) is constant there.

For completeness, parameter differentiation can be performed without differentiating a possibly exponentially large propagator in isolation. Hold \(v\) fixed and use slow variables and the initial transverse coordinate as parameters. They commute with \(\partial_v\); the zero initial data and all their parameter derivatives vanish. For each multi-index \(I\),
\[
(\partial^Iz_m)'=A_m\partial^Iz_m+\partial^Ig_m+
\sum_{0<J\le I}\binom IJ(\partial^JA_m)\partial^{I-J}z_m.
\]
At fixed finite harmonic bound \(M\), each \(\partial^JA_m\) is bounded by \(C_{J,M}S_*^{c_J}\). Induction on \(|I|\), using the already proved propagator bound, shows that every source term on the right has the same \(\varepsilon^\alpha\sqrt\zeta P\) weight with a larger inverse-distance exponent and polynomial degree. A further time integral contributes only \(L_s\). One may choose the degree at step \(I\) to exceed
\[
1+\max\{b_I,\max_{0<J\le I}(c_J+b'_{I-J})\}.
\]
Pulse derivatives follow from the differential equation, and mixed pulse/parameter derivatives follow by repeated differentiation of that equation. Returning to the current \(H\) uses \(D_Hv=O(S_*)\), \(D_HH_w=I-v_t\lambda_t\), with higher affine derivatives zero, and therefore introduces only additional polynomial powers. Multiplying by \(B\) yields the stated bound for \(t_m\). The explicit pressure has the extra factor \((km)^{-1}=O(\varepsilon^{1/2})\); its other factors have the proved derivative bounds. Thus the exponent for pressure is \(\alpha+1/2\).

The support argument also follows from this equation. If a fixed slow/transverse point is outside the source's closed support, the entire source path is zero; uniqueness gives a zero solution. At a boundary all source jets vanish by the prescribed smooth zero extension, so the differentiated equations inductively give zero solution jets. Across a shell edge the retained \(\sqrt\zeta\delta^{-a_I}\) bounds give the same conclusion. Deck translations preserve the path and the prescribed data, giving common-torus descent by uniqueness. Smooth extension to the rectangle enlargement follows from smooth finite-dimensional ODE dependence on its coefficients and data; no temporal zero extension is asserted before cutoff. On compact sets with \(q>0\), one-sided background/source derivatives at \(\tau=0\) pass through the same parameter equations and pressure formula.

Only the lower bounds for denominators and finitely many value comparisons determine \(q_*\). The induction above changes constants and polynomial degrees for each fixed \(M,I\); it does not impose further smallness inequalities. This proves the quantifier statement of Corollary 7.3.

## The real homogeneous pulse and energy transfer

For \(m=1,f=0\), specify \(z_+(0)=P(0)>0,z_-(0)=0\). While \(z_+>0\), the ratio \(r=z_-/z_+\) obeys exactly
\[
r'=E_{21}+(-2\lambda+E_{22}-E_{11})r-E_{12}r^2.
\]
Let \(c_\lambda=\inf\lambda>0\). On \(r=\pm K_b/S_*\), the outward derivative is at most
\[
\frac{-2c_\lambda K_b+C(1+K_b/S_*+K_b^2/S_*^2)}{S_*}.
\]
Choose fixed \(K_b>C/c_\lambda\), then enlarge the fixed band threshold to make the numerator negative. The closed interval \([-K_b/S_*,K_b/S_*]\) is invariant until any putative first zero of \(z_+\). On this interval,
\[
\left(\log(z_+/P)\right)'=-(d-d_{\rm ref})+E_{11}+E_{12}r=O(S_*^{-1}).
\]
Since \(z_+(0)=P(0)\) and \(L_s/S_*\) is bounded, integration proves \(cP\le z_+\le CP\), ruling out that putative zero. For all \(v\),
\[
x=z_++z_-=z_+(1+r),\quad
y=c_0\sqrt{1+s^2}(z_+-z_-),
\]
so
\[
cP\le x\le CP,\qquad
y/x=c_0\sqrt{1+s^2}+O(S_*^{-1}).
\]
The same differentiated equation used for the inverse proves every fixed derivative bound, with the nonzero initial value retained: it is fixed with the label, so all slow/transverse derivatives of that datum vanish. The value solution contributes \(\|V_1(v,0)\|P(0)\le CP(v)\). Pulse derivatives are obtained from the equation. Pressure again has the extra \(\varepsilon^{1/2}\).

For the real homogeneous amplitude \(t\), \(n_\Phi\cdot t=0\) makes the normal component of \(\mathcal A_\Phi t\) perpendicular to \(t\). Direct multiplication, keeping both cylindrical \(2F\) terms, gives
\[
t\cdot\mathcal Kt
=-2Ft_rt_\theta+(2F+RF_R)t_rt_\theta+G_Rt_rt_z
=g\cdot(t_r(t_\theta,t_z)).
\]
Taking \(t\cdot t'\) therefore proves the exact identity
\[
\frac12\frac{d}{dv}|t|^2
=-g\cdot(t_r(t_\theta,t_z))-\varepsilon k^2|n_\Phi|^2|t|^2.
\]
For the flux \(T=t_r(t_\theta,t_z)=T_NN+T_KK\), the exact
production is
\[
-g\cdot T=-|g_0|T_N-\Delta g\cdot T,\qquad \Delta g=g-g_0.
\]
Here \(g_0\) is the leading shear frozen at the representative;
it is not identified with the actual shear even there. To keep both
sources of its difference, let \(V^{(0)},G^{(0)}\) denote the exact
leading chart fields, put \(\delta V=V-V^{(0)}\),
\(\delta G=G-G^{(0)}\), and write
\[
g^{(0)}=(\partial_RV^{(0)}-V^{(0)}/R,\partial_RG^{(0)}),
\quad g_0=g^{(0)}(p_0),
\]
\[
\Delta g=(\partial_R\delta V-\delta V/R,\partial_R\delta G)
+g^{(0)}(p)-g^{(0)}(p_0).
\]
The leading and actual fields here are the constructed backgrounds.
Their proved chart estimates give
\(|\partial^I\delta V|\le C_{V,I}\varepsilon^2\) and
\(|\partial^I\delta G|\le C_{G,I}\varepsilon^2\).
Let \(R_->0\) be the minimum radius on the compact enlarged chart,
\(L_g\) bound \(D_pg^{(0)}\), and
\(|p-p_0|\le C_{\rm box}S_*^{-3}\), with the connecting segment
in that chart. Set
\[
C_B=\left[(C_{V,e_R}+R_-^{-1}C_{V,0})^2+C_{G,e_R}^2\right]^{1/2}.
\]
The product rule and segment integration give the actual bound
\[
|\Delta g|\le C_B\varepsilon^2+L_gC_{\rm box}S_*^{-3}
=C_B2^{-2h\ell}+L_gC_{\rm box}\ell^{-6}.
\]
At \(p_0\) only the segment term is zero. The Borel term remains.
For a vector in the prescribed compact stress cone, retain its margin
\(-T_N\ge c_T|T|\), \(c_T>0\), and \(|g_0|\ge g_->0\).
Then Cauchy--Schwarz proves
\[
-g\cdot T\ge
[g_-c_T-C_B2^{-2h\ell}-L_gC_{\rm box}\ell^{-6}]|T|.
\]
One sufficient additional integer threshold is
\[
\ell\ge\left\lceil\max\left\{
1,\left(\frac{4L_gC_{\rm box}}{g_-c_T}\right)^{1/6},
\frac{\log\max\{1,4C_B/(g_-c_T)\}}{2h\log2}
\right\}\right\rceil.
\]
Each error is then at most \(g_-c_T/4\), so the lower bound is
\((g_-c_T/2)|T|\), including \(T=0\).

For the actual homogeneous pulse, positivity follows directly from its
proved polarization. This requires no assertion that its instantaneous
flux lies in the prescribed target cone. Retain
\[
t=x(e_r-s_aK_a)+yN_a,\quad
s_{\max}=3u_*/2,\quad \gamma_0=c_0\sqrt{1+s^2},
\]
and choose the constants in the already proved estimates as
\[
|n_\Phi-B_s(s,K)|\le E_n/S_*,\quad B_s\ge B_->0,
\quad |y/x-\gamma_0|\le E_\gamma/S_*,\quad c_xP\le x\le C_xP.
\]
The quantities \(g_-,g_+,c_-,c_+\) denote positive uniform bounds
\(g_-\le|g_0|\le g_+\), \(c_-\le|c_0|\le c_+\), with
\(c_0<0\). Choose \(S_*\ge2E_n/B_-\). Then
\(|n_{\Phi,\tan}|\ge B_-/2\). For nonzero vectors \(a,b\),
addition and subtraction of \(a/|b|\), followed by
\(\big||a|-|b|\big|\le|a-b|\), gives
\(|a/|a|-b/|b||\le2|a-b|/|b|\). Therefore
\[
|K_a-K|=|N_a-N|\le\frac{2E_n}{B_-S_*},\qquad
|s_a-s|\le\frac{2(1+s_{\max})E_n}{B_-S_*}.
\]
The last estimate follows by writing
\(n_{\Phi,r}-s|n_{\Phi,\tan}|
=(n_{\Phi,r}-B_ss)+s(B_s-|n_{\Phi,\tan}|)\)
and dividing by the actual tangential norm.
Define
\[
\Gamma_{\max}=c_+\sqrt{1+s_{\max}^2},\qquad
C_T=\frac{2E_n}{B_-}(1+2s_{\max}+\Gamma_{\max})+E_\gamma.
\]
The exact flux and its exact remainder are
\[
T=x^2[-sK+\gamma_0N+e_T],\qquad
e_T=-(s_aK_a-sK)+(y/x)N_a-\gamma_0N.
\]
Expand the first difference as
\((s_a-s)K_a+s(K_a-K)\) and the second as
\((y/x-\gamma_0)N_a+\gamma_0(N_a-N)\).
The preceding bounds give \(|e_T|\le C_T/S_*\), with all four
terms retained. Hence
\[
\frac{-g\cdot T}{x^2}=-|g_0|\gamma_0-g_0\cdot e_T
-\Delta g\cdot(-sK+\gamma_0N+e_T).
\]
The absolute value of the last two terms is at most
\[
\mathcal E_\ell=g_+C_T\ell^{-2}
+(C_B2^{-2h\ell}+L_gC_{\rm box}\ell^{-6})
(s_{\max}+\Gamma_{\max}+C_T\ell^{-2}).
\]
Set \(W=s_{\max}+\Gamma_{\max}+C_T>0\). In addition to all
previous phase and invariant-band thresholds, it suffices to choose
\[
\ell\ge\left\lceil\max\left\{
1,\left(\frac{2E_n}{B_-}\right)^{1/2},
\left(\frac{4g_+C_T}{g_-c_-}\right)^{1/2},
\left(\frac{8WL_gC_{\rm box}}{g_-c_-}\right)^{1/6},
\frac{\log\max\{1,8WC_B/(g_-c_-)\}}{2h\log2}
\right\}\right\rceil.
\]
For \(\ell\ge1\), the last factor in \(\mathcal E_\ell\) is at
most \(W\). The three error contributions are then at most
\(g_-c_-/4,g_-c_-/8,g_-c_-/8\), respectively.
Since \(-|g_0|\gamma_0\ge g_-c_-\), this proves
\[
\tfrac12g_-c_-c_x^2P(v)^2\le-g\cdot T
\le(g_+\Gamma_{\max}+\tfrac12g_-c_-)C_x^2P(v)^2.
\]
All constants concern the same selected \(h\), fixed profiles and
original compact label family. The displayed thresholds are finite and
are added to the previous finite value thresholds; no uniformity as
\(h\downarrow0\) is asserted. The exact actual-frame norm is
\[
|t|^2=(1+s_a^2)x^2+y^2.
\]
The damping \(\varepsilon k^2|n_\Phi|^2|t|^2\) remains in the
energy equation, so positive production is not a claim of positive total
energy derivative. Covariance mass uses the proved positive \(x\) and
the original positive integral of \(\psi^2x^2\); its argument does
not omit this damping. The carrier physical wavelength is \(\sqrt Q/k\asymp Q^{1/2+h/2}\), while the leading physical wave amplitude has power \(Q^{-A}\sqrt\varepsilon=Q^{-1/2-h/2}\), up to polynomial factors in \(S_*\). Their product has power \(Q^0\); this agrees with the retained leading damping \(\varepsilon k^2\asymp1\).

# Covariance, signed stress increments, exact curls, and cutoff residuals

This file gives direct proofs for source pp. 81-87, Propositions 7.5-7.6, Lemma 7.7, and Corollary 7.8. The background inputs and pulse estimates are recorded and derived in the preceding files. All averages below are on the extended domain at fixed slow coordinates, before physical evaluation.

## Two columns and their positive coefficients

For real extended vector fields define
\[
\mathcal C(w)=\langle\langle w_rw_{\tan}\rangle_\theta\rangle_Y,\qquad
\mathcal B(w,v)=
\langle\langle w_rv_{\tan}+v_rw_{\tan}\rangle_\theta\rangle_Y,
\quad w_{\tan}=(w_\theta,w_z).
\]
Expanding the product proves \(\mathcal C(w+v)=\mathcal C(w)+\mathcal B(w,v)+\mathcal C(v)\) and \(D\mathcal C(w)[v]=\mathcal B(w,v)\). These maps preserve the original component order \((r\theta,rz)\).

For a slow box \(\beta=(\ell,a)\), its two signs have disjoint auxiliary rectangles and the same slow cutoff. Write
\[
b_\sigma=\chi_g(\xi_g)\psi(v)t_\sigma^h\cos(k\Phi_\sigma),\qquad
H=[\mathcal C(b_+)\mid\mathcal C(b_-)].
\]
Each \(b_\sigma\) is extended by zero outside its rectangle, using its smooth transverse and temporal cutoffs. The integer \(kp\ne0\) ensures that
\[
\frac1{2\pi}\int_0^{2\pi}\cos^2(k\Phi_\sigma)\,d\theta=\frac12
\]
exactly, whatever the non-angular part of the phase. Haar pullback permits averaging on the band torus. The coordinate map \((\xi_g,\eta_g)\mapsto c_\gamma+\xi_gv_r+\eta_gv_t\) has the retained Jacobian \(|\det(v_r,v_t)|=1+b_g^2\), and \(d\eta_g=c_i\,dv\). The homogeneous amplitude is independent of \(\xi_g\), since its ODE coefficients depend on slow coordinates and \(v\), and its initial value is fixed with the label. With radial component \(x\), this gives
\[
H_\sigma=D_g c_i\int_0^{L_s}\psi^2x\,t_{\sigma,\tan}^h\,dv,\qquad
h_\sigma=D_g c_i\int_0^{L_s}\psi^2x^2\,dv,
\]
\[
D_g=\frac{|\det(v_r,v_t)|}{2}\int_{\mathbb R}\chi_g(\xi)^2\,d\xi>0.
\]
Thus the angular factor \(1/2\), the rectangular Jacobian, the time measure \(c_i\,dv\), and the transverse cutoff integral are all present.

The proved bounds \(cP\le x\le CP\) and \(P(v)\asymp\exp(-c(v-L_s/2)^2/L_s)\), with separate upper and lower constants, imply
\[
c\sqrt{L_s}\le\int_0^{L_s}\psi^2x^2\,dv\le C\sqrt{L_s}.
\]
For the lower bound, integrate over \(|v-L_s/2|\le\sqrt{L_s}\), which lies in the region \(\psi=1\) for all sufficiently large \(L_s\); \(P\) there has a fixed positive lower bound. The upper bound follows by extending the Gaussian integral to \(\mathbb R\). The same substitution \(w=(v-L_s/2)/\sqrt{L_s}\) proves
\[
\int_0^{L_s}\frac{|v-L_s/2|}{L_s}\psi^2x^2\,dv\le C.
\]
It follows that \(h_\sigma\asymp c_i\sqrt{L_s}\asymp S_*^{-1/2}\), and the probability measure proportional to \(\psi^2x^2\,dv\) has expectation of \(|v-L_s/2|/L_s\) at most \(CS_*^{-1/2}\).

Since \(t_{\sigma,\tan}^h/x=-s_aK_a+(y/x)N_a\), the previous file proves its uniform difference from \(-s(v)K+c_0\sqrt{1+s(v)^2}N\) is \(O(S_*^{-1})\). The latter function is Lipschitz in \(s\) on the fixed compact range, and \(|s(v)-\sigma u_*|=u_*|v-L_s/2|/L_s\). Taking the weighted average therefore gives
\[
H_\sigma=h_\sigma(-A_cN-\sigma u_*K+e_\sigma),\quad
A_c=-c_0\sqrt{1+u_*^2}>0,\quad |e_\sigma|\le CS_*^{-1/2}.
\]
Every fixed slow derivative of \(H_\sigma\) is polynomially bounded: differentiate the finite integral using the already proved pulse derivatives, fixed \(L_s\), and fixed label cutoffs. None of these parameter derivatives differentiates a discrete label or moves the integration endpoints.

In coordinates \(N,K\), omit \(e_\sigma\) temporarily and solve the exact two-by-two system:
\[
h_+y_+=\frac12(-T_N/A_c-T_K/u_*),\qquad
h_-y_-=\frac12(-T_N/A_c+T_K/u_*).
\]
The cone choice made in the previous file gives a fixed \(\eta_c>0\) such that
\[
\frac{|T_K|}{u_*}\le(1-\eta_c)\frac{-T_N}{A_c},
\qquad T=T_{0,*}.
\]
Since \(N,K\) are orthonormal and \(T_N<0\), this also gives \(-T_N\ge c|T|\). Hence the two displayed reference coefficients are at least \(c|T|\) and at most \(C|T|\).

The reference column matrix in these coordinates is
\[
H_{\rm ref}=
\begin{pmatrix}-A_ch_+&-A_ch_-\\-u_*h_+&u_*h_-\end{pmatrix},
\quad
\det H_{\rm ref}=-2A_cu_*h_+h_-.
\]
Writing \(H=(H_{\rm ref}\operatorname{diag}(h_+^{-1},h_-^{-1})+
\mathcal E)\operatorname{diag}(h_+,h_-)\), the first factor differs from a fixed invertible matrix by \(O(S_*^{-1/2})\). For \(\|H_0^{-1}\mathcal E\|<1/2\), the exact inverse of
\(I+H_0^{-1}\mathcal E\) is the convergent series
\(\sum_{n=0}^{\infty}(-H_0^{-1}\mathcal E)^n\).
Indeed multiplication of its finite partial sum through \(n=N\) by
\(I+H_0^{-1}\mathcal E\), in either order, gives
\(I-(-H_0^{-1}\mathcal E)^{N+1}\), and the last power tends to zero.
The sum has norm at most \(2\), and its difference from \(I\) has norm
at most \(2\|H_0^{-1}\mathcal E\|\), by the geometric-series bounds.
Thus the exact first-factor inverse is
\((I+H_0^{-1}\mathcal E)^{-1}H_0^{-1}\); the original diagonal
\(\operatorname{diag}(h_+,h_-)^{-1}\) remains on its left. The coefficient perturbation is then bounded by \(CS_*^{-1/2}|T|\) before dividing by \(h_\sigma\). For a further fixed lower band threshold, it is smaller than half the positive reference coefficient margin. Therefore
\[
|\det H|\ge c/S_*,\quad \|H^{-1}\|\le C\sqrt{S_*},\quad
c\sqrt{S_*}|T_{0,*}|\le y_\sigma\le C\sqrt{S_*}|T_{0,*}|,
\quad y=H^{-1}T_{0,*}.
\]
This proves positivity uniformly up to limiting stress directions at the shell edges. At an edge the actual target is zero; the positive inequalities for \(y\) are asserted in the open shell.

The background profile theorem gives \(|T_{0,*}|\ge c\zeta\) and \(|D^IT_{0,*}|\le C_I\zeta\delta^{-a_I}\), using the exact chart/profile transition from the first file. Differentiating \(HH^{-1}=I\) expresses each fixed derivative of \(H^{-1}\) as a finite sum of products of \(H^{-1}\) and derivatives of \(H\), hence gives polynomial \(S_*\) bounds. Leibniz's rule proves
\[
y_\sigma\ge c\sqrt{S_*}\zeta,\qquad
|D^Iy_\sigma|\le C_IS_*^{b_I}\zeta\delta^{-a_I}.
\]
For \(a_\sigma=\sqrt{y_\sigma}\), every derivative of positive order is a finite sum
\[
c\,y_\sigma^{1/2-n}\prod_{\nu=1}^nD^{I_\nu}y_\sigma,
\qquad |I_\nu|\ge1,\quad \sum I_\nu=I.
\]
The numerator contributes \(\zeta^n\), while the inverse power contributes \(\zeta^{1/2-n}\); the product has exactly the remaining \(\sqrt\zeta\). The \(S_*\)-powers and inverse edge-distance powers are finite at every fixed order. The value bound uses the upper bound for \(y_\sigma\). Thus
\[
|D^Ia_\sigma|\le C_IS_*^{b'_I}\sqrt\zeta\,\delta^{-a'_I},
\]
which proves smooth zero extension of every coefficient at both shell edges.

Set \(W_0=\sqrt\varepsilon\sum_{\sigma=\pm}a_\sigma b_\sigma\). The two disjoint supports remove the cross products, and the scalar amplitudes are independent of both averaging variables. Consequently
\[
\mathcal C(W_0)=\varepsilon H(a_+^2,a_-^2)^T
=\varepsilon T_{0,*}
\]
exactly. The pulse and square-root estimates give the local \(\mathcal W_{1/2}\) bounds. Multiplying by \(\eta_\beta\) gives the required slow support.

The physical covariance of the assembled field is obtained with the original factors:
\[
Q^{-2A}\varepsilon T_{0,*}
=Q^{-2A+h}(Q/q)^{A+1/2}T_0
=Q^{-A+h+1/2}q^{-A-1/2}T_0
=q^{-A-1/2}T_0.
\]
The final equality uses \(A=1/2+h\). Each physical slow point has bounded overlap, and cross-label products vanish. Summing the squared partition \(\sum_\beta\eta_\beta^2=1\) therefore supplies precisely the leading physical stress, with the sign suitable to cancel the negative stress divergence in Proposition 5.5.

## Signed differential inverse and assembly across bands

Let \(\Sigma(R,Z,T)\) be a real auxiliary-independent two-vector in \(\mathcal M_\alpha\). Keep the previously chosen positive amplitudes fixed. Define
\[
d_\Sigma=H^{-1}(\Sigma/\varepsilon),\qquad
\delta a_\sigma=(d_\Sigma)_\sigma/(2a_\sigma),\qquad
\mathcal L\Sigma=\sqrt\varepsilon\sum_{\sigma=\pm}\delta a_\sigma b_\sigma.
\]
Here the division is taken only on the open shell before smooth zero extension. Every derivative of \(y_\sigma^{-1/2}\) is a finite sum
\[
c\,y_\sigma^{-n-1/2}\prod_{\nu=1}^nD^{I_\nu}y_\sigma,
\]
so it has the weight \(\zeta^{-1/2}\) with allowed polynomial and edge-distance factors. Since \(d_\Sigma\) has weight \(\varepsilon^{\alpha-1}\zeta\), the product defining \(\delta a_\sigma\) has
\[
|D^I\delta a_\sigma|
\le C_I\varepsilon^{\alpha-1}S_*^{b_I}\sqrt\zeta\,\delta^{-a_I}.
\]
This proves smooth zero extension and the local \(\mathcal W_{\alpha-1/2}\) bound for \(\mathcal L\Sigma\), with the envelope supplied by \(b_\sigma\).

Disjointness and the retained bilinear factor two give
\[
\mathcal B(W_0,\mathcal L\Sigma)
=\varepsilon H(2a_+\delta a_+,2a_-\delta a_-)^T
=\Sigma.
\]
This is an exact linear right inverse of \(D\mathcal C(W_0)\), without positivity or smallness assumptions on \(\Sigma\). It is not an exact nonlinear inverse: the retained identity is
\[
\mathcal C(W_0+\mathcal L\Sigma)
=\varepsilon T_{0,*}+\Sigma+\mathcal C(\mathcal L\Sigma).
\]
The last term lies in \(\mathcal M_{2\alpha-1}\), as both wave coefficients have exponent \(\alpha-1/2\) and the product has the mean weight \(\zeta\).

For a real physical auxiliary-independent stress \(\sigma(r,z,t)\)
supported in the active shell, whose representatives
\(Q_\beta^{2A}\sigma\) belong to the stated local \(\mathcal M_\alpha\)
domain, use the source's assembled maps. This domain includes every fixed
derivative bound with the weight \(\zeta\delta^{-a_I}\), compatibility on
overlapping charts, and smooth zero extension at the shell edges. The
previously chosen positive amplitudes remain fixed. The following identity
holds throughout the active partition domain and extends by zero outside it
because the input stress vanishes there:
\[
W_{0,\rm phys}^{\rm as}
=\sum_\beta Q_\beta^{-A}\eta_\beta W_{0,\beta},\qquad
\mathcal L_{\rm phys}^{\rm as}\sigma
=\sum_\beta Q_\beta^{-A}\eta_\beta
\mathcal L_\beta(Q_\beta^{2A}\sigma).
\]
The different \(Q_\beta\) are retained. The contribution of box \(\beta\) to the bilinear covariance is
\[
Q_\beta^{-2A}\eta_\beta^2Q_\beta^{2A}\sigma
=\eta_\beta^2\sigma.
\]
There are no cross-box terms, so summation gives \(\mathcal B(W_{0,\rm phys}^{\rm as},\mathcal L_{\rm phys}^{\rm as}\sigma)=\sigma\). In a reference chart of scale \(Q\), the representatives are
\[
W_0^{\rm as}=Q^AW_{0,\rm phys}^{\rm as},\quad
\mathcal L^{\rm as}\Sigma=Q^A\mathcal L_{\rm phys}^{\rm as}(Q^{-2A}\Sigma).
\]
Thus the exact chart identity is \(\mathcal B(W_0^{\rm as},\mathcal L^{\rm as}\Sigma)=\Sigma\). Overlapping \(Q_\beta/Q\) lie between fixed positive bounds, so chart changes preserve all claimed exponents; the bounded covering changes preserve derivatives and averages. Equal label-harmonic contributions are collected before class membership is tested. Auxiliary independence of \(\Sigma\) is essential to taking the amplitudes outside the integral and is explicitly a hypothesis here.

## Curl identity with all cylindrical terms

The normalized cylindrical curl is
\[
\operatorname{curl}_*A=
\left(R^{-1}\partial_\theta A_z-D_zA_\theta,\,
D_zA_r-D_rA_z,\,
(D_r+R^{-1})A_\theta-R^{-1}\partial_\theta A_r\right).
\]
For a smoothly supported \(t_m\in\mathcal W_\alpha\) with \(n_\Phi\cdot t_m=0\), put
\[
C_m=\frac{i\,n_\Phi\times t_m}{km|n_\Phi|^2},
\quad A_m=C_me^{ikm\Phi}.
\]
Using the right-handed \((e_r,e_\theta,e_z)\) orientation, the exponential differentiation contributes
\[
ikm\,n_\Phi\times C_m
=-\frac{n_\Phi\times(n_\Phi\times t_m)}{|n_\Phi|^2}
=t_m-\frac{n_\Phi(n_\Phi\cdot t_m)}{|n_\Phi|^2}=t_m.
\]
The exact remainder is
\[
r_m=\left(-D_z(C_m)_\theta,\,
D_z(C_m)_r-D_r(C_m)_z,\,
(D_r+R^{-1})(C_m)_\theta\right).
\]
The multiplier \(n_\Phi/|n_\Phi|^2\) has all polynomial coefficient bounds. Hence \(C_m\in\mathcal W_{\alpha+1/2}\), and \(r_m\in\mathcal W_{\alpha+1/2-\kappa_s}\). The less costly \(D_z\) and frame terms satisfy the same weaker common bound. Supports are preserved by local differentiation and smooth extension.

For any smooth normalized vector potential, retain
\[
\operatorname{div}_*a=(D_r+R^{-1})a_r+R^{-1}\partial_\theta a_\theta+D_za_z.
\]
Because \(D_r(R^{-1})=-R^{-2}\), one has \((D_r+R^{-1})(R^{-1}f)=R^{-1}D_rf\). Substitution of the three curl entries gives the six terms
\[
R^{-1}D_r\partial_\theta A_z
-(D_r+R^{-1})D_zA_\theta
+R^{-1}D_z\partial_\theta A_r
-R^{-1}\partial_\theta D_rA_z
+D_z(D_r+R^{-1})A_\theta
-R^{-1}D_z\partial_\theta A_r.
\]
They cancel in pairs by the commuting coordinate derivations and \(D_z(R^{-1})=0\). Thus divergence of the exact curl vanishes. The pullback intertwining proved in the first file transfers this identity exactly to physical space.

For the full amplitude \(a_m=t_m+r_m\), its coefficient is angular-independent. Expanding the divergence of \(a_me^{ikm\Phi}\) proves
\[
ikm\,n_\Phi\cdot a_m
=-\big((D_r+R^{-1})(a_m)_r+D_z(a_m)_z\big).
\]
The scalar \(n_\Phi\cdot a_m=n_\Phi\cdot r_m\) belongs to \(\mathcal W_{\alpha+1/2-\kappa_s}\), since \(n_\Phi\cdot t_m=0\) and the full phase vector has polynomial coefficient bounds. The displayed left side includes the additional factor \(ikm\), with \(k=O(\varepsilon^{-1/2})\) and fixed nonzero harmonic \(m\); its class is therefore \(\mathcal W_{\alpha-\kappa_s}\). This is also the class supplied by the amplitude derivative on the right. In particular, the complete amplitude is not asserted to be transverse: its retained longitudinal component is precisely what the divergence identity controls. Physical vector potentials are \(Q^{1/2-A}A_*\), because physical curl contributes \(Q^{-1/2}\); physical pressures are \(Q^{-2A}p_*\). These factors give exactly the prescribed physical velocity and normalized pressure.

Real waves use conjugate harmonic pairs. For real \(t\cos(k\Phi)\), the velocity coefficients are \(t/2\) for \(m=\pm1\); the factor \(i/(km)\) changes by complex conjugation when \(m\) changes sign. Thus the potentials and pressures also form real physical fields. No missing factor is introduced by replacing the cosine with exponentials.

## Exact cutoff residual and terminal flatness at each fixed stage

Let the zero-data inverse solve the principal equation for an actual supported source \(f_m\), and set \(\widehat t_m=\psi t_m,\widehat\pi_m=\psi\pi_m\). The principal equation yields exactly
\[
\widehat t_m'+\mathcal K\widehat t_m+m^2d\widehat t_m
+ikmn_\Phi\widehat\pi_m+f_m
=(1-\psi)f_m+\psi't_m.
\]
The source on the left remains \(f_m\), not \(\psi f_m\). This is why the uncancelled \((1-\psi)f_m\) term is required. The support of either right-hand term lies in \(|v-L_s/2|\ge L_s/5\), since \(\psi=1\) on the complementary central region. There the proved Gaussian estimate is \(P(v)\le e^{-cL_s/25}\le e^{-c'S_*}\). For every fixed coefficient derivative, Leibniz's formula gives the same exponential factor times allowed polynomial powers: derivatives of \(\psi\) are supported in the same exterior region, and all derivatives of \(f_m,t_m\) already obey the envelope bound. The transverse/slow/shell weights stay unchanged.

When the corresponding exponential and physical factors are differentiated any fixed number of times, only a fixed power \(Q^{-M}\) and a polynomial \(S_*^C\) are added. This can be verified directly: on band pullbacks, \(T_g^i\le Q^{-1-h}/S_*\), \(\Lambda_g^i\le Q^{-(1+h)\rho_g}S_*^{-\rho_g}\), \(k\le2Q^{-h/2}\); chart derivatives contribute fixed powers \(Q^{-1},Q^{-D},Q^{-1/2}\); and the phase itself has only the displayed \(p_zZ/\varepsilon\), \(vH_\Phi\), \(p\theta\), \(x_0R\) terms, with \(v=O(S_*)\) and all relevant differentiated coefficients bounded polynomially. The cylindrical frame has \(r^{-1}=Q^{-1/2}R^{-1}\), with \(R\) bounded away from zero. A fixed product/chain-rule expansion contains finitely many such factors. The exponents \(M,C\) may depend on the derivative order, stage, and finite harmonic set, but not on the band.

For every fixed \(M,C,N\), \(q\asymp Q=2^{-\ell}\) gives
\[
q^{-N}Q^{-M}S_*^Ce^{-c'S_*}
\le C_N\exp(-c'\ell^2+(M+N)\ell\log2+2C\log\ell)\longrightarrow0.
\]
For a direct bound, choose \(\ell\) so that the last two positive terms are at most \(c'\ell^2/2\); the remaining Gaussian is bounded and tends to zero. This proves every physical derivative of this fixed-stage cutoff residual is \(O(q^N)\) for every \(N\). Homogeneous pulse cutoff tails obey the same argument, with source zero and the retained \(\psi't^h\) term.

At each physical point only a bounded number of slow labels occur, so local summation retains the same bound. On their annular supports, \(r^2/(2q)\ge X_a>0\) implies \(q\le r^2/(2X_a)\). Thus these derivative bounds give arbitrary vanishing order at the singular space-time point \(r=z=0,t=1\). Every one-sided derivative jet there has value zero; the derivative identities persist at that boundary point by induction and the fundamental theorem of calculus along coordinate segments lying in the time half-space. Outside the annular supports the fields vanish smoothly. At \(t=1,z\ne0\), however, \(q=|z|^{1/D}>0\), so this estimate does not assert zero values on the whole terminal plane. One-sided smooth jets there are supplied by the parameter-dependent ODE proof. Any continuation across that plane, and the infinite-stage diagonal sum, are the later sections' responsibilities and are not inferred merely from the fixed-stage tail estimate.

## Actual covariance increment with every remainder retained

Let \(U=W_0^{\rm as}+E\) be the actual real divergence-free wave field, with \(U\in\mathcal W_{1/2}\), \(E\in\mathcal W_\rho\). Given \(\Sigma\in\mathcal M_\alpha\) independent of the averaging variables, applying the exact curl construction to \(\mathcal L^{\rm as}\Sigma\) gives
\[
V=\mathcal L^{\rm as}\Sigma+R,\qquad R\in\mathcal W_{\alpha-\kappa_s}.
\]
The latter exponent is \((\alpha-1/2)+(1/2-\kappa_s)\). Then
\[
\begin{aligned}
\mathcal C(U+V)-\mathcal C(U)
&=\mathcal B(U,V)+\mathcal C(V)\\
&=\Sigma+\mathcal B(E,\mathcal L^{\rm as}\Sigma)
+\mathcal B(U,R)+\mathcal C(V).
\end{aligned}
\]
The exact bilinear identity at the fixed \(W_0^{\rm as}\) is the only cancellation used. Products yield the respective mean exponents
\[
\rho+\alpha-\tfrac12,\qquad
\alpha+\tfrac12-\kappa_s,\qquad
2\alpha-1.
\]
For the last exponent, \(\kappa_s<1/2\) and \(0<\varepsilon\le1\) imply \(R\in\mathcal W_{\alpha-1/2}\); hence \(V\) is in that class. The radial divergence is the original componentwise operator \(D_r+2/R\) or \(D_r+1/R\), respectively. Its derivative term loses at most \(\kappa_s\), and its bounded frame terms cause no further loss. Thus all three remainder exponents after radial divergence are their displayed values minus at most \(\kappa_s\). These are precise local estimates. Their compatibility with the residual-improvement exponents selected in Section 9 must be checked where those exponents are selected.

# Admissible shear loop, radial modulation, and moment restoration

This file independently proves the operations in Appendix C, pp. 157-165. It retains the original logarithmic coordinate \(D_X=X\partial_X\), profile \(E>0,U\), pressure integration constant \(\Pi_0(\eta)\), component signs, interval ordering, and all five moments. The existence and numerical parameter margins of the input profile from Appendices A and B are audited by the profiles lane. This file verifies what Appendix C does to that input, including the exact restoration map; it does not claim that its imported input construction has been independently proved here.

## Scalar cone and its four gaps

At \(a>0\), set
\[
t_s=-b_s/a,\quad v_s=a(1+t_s^2),\quad
P_c=p_{s,1}+t_sp_{s,2},\quad
J_c=p_{s,2}-t_sp_{s,1}.
\]
The relaxed condition is \(P_c>2\), \(v_s<U(P_c,J_c)\), with
\[
U(P,J)=P+\frac{J^2}{4}
-|J|\sqrt{\frac{P-2}{2}+\frac{J^2}{16}}.
\]
The admissible condition also requires \(v_s>2\). The quadratic expression
\[
G(v)=2(P-v)^2-(v-2)J^2
\]
has roots \(U(P,J)\) and the same expression with a plus before the square root. For \(P>2\), \(U>2\): writing \(w=P-2>0\), the inequality
\[
\left(w+\frac{J^2}{4}\right)^2
-J^2\left(\frac w2+\frac{J^2}{16}\right)=w^2>0
\]
proves \(w+J^2/4>|J|\sqrt{w/2+J^2/16}\). Also \(U\le P\), because the square-root term is at least \(J^2/4\), with equality only for \(J=0\). When \(J=0\), \(U=P>2\). Therefore for \(v>2\), admissibility is exactly
\[
P-v>0,\qquad 2(P-v)^2-(v-2)J^2>0.
\]
The four continuous smooth gaps on \(a>0\) are \(a\), \(v_s-2\), \(P_c-v_s\), and \(2(P_c-v_s)^2-(v_s-2)J_c^2\). Positivity on a compact parameter set gives one positive lower margin for all four. The root \(U\) need only be continuous; no differentiation of its \(|J|\) term at zero is used.

## A smooth loop whose average is exactly the original shear

Let \(I\times[-1,1]\) be the fixed compact domain from Appendix C, with relaxed data and admissibility on radial boundary collars. The positive minimum of \(P_c(t_s)-2\) permits a constant
\[
0<d_0<\tfrac12\min(P_c(t_s)-2).
\]
Here \(P_c(t)=p_{s,1}+p_{s,2}t\) and \(J_c(t)=p_{s,2}-p_{s,1}t\) for a variable slope \(t\). With normalized \(\theta'\)-average on \([0,2\pi]\), define
\[
M_e(z)=\frac1{2\pi}\int_0^{2\pi}e^{z\sin\theta'}\,d\theta',
\quad
t(\theta';\mu)=t_s+
\frac{d_0}{p}\left(\frac{e^{\mu p\sin\theta'}}{M_e(\mu p)}-1\right),
\quad p=p_{s,2}.
\]
For \(p=0\) the quotient is defined by continuity. Its numerator is smooth in \(p,\mu,\theta'\), zero at \(p=0\), and the identity
\[
\frac{G(p)}p=\int_0^1G'(up)\,du
\]
proves joint smoothness, including all parameters and derivatives. Since \(M_e(0)=1,M_e'(0)=0\), the value there is \(t=t_s+d_0\mu\sin\theta'\).

The definitions give
\[
\langle t\rangle_{\theta'}=t_s,\qquad
P_c(t)=P_c(t_s)+d_0\left(\frac{e^{\mu p\sin\theta'}}{M_e(\mu p)}-1\right)
\ge P_c(t_s)-d_0>2.
\]
The variance is
\[
V(\mu,p)=\langle(t-t_s)^2\rangle
=\frac{d_0^2}{p^2}
\left(\frac{M_e(2\mu p)}{M_e(\mu p)^2}-1\right),
\]
with value \(d_0^2\mu^2/2\) at \(p=0\). To show strict increase, let \(g(z)=\log M_e(z)\). Differentiating under the finite integral gives
\[
g''(z)=
\langle(\sin\theta'-\langle\sin\theta'\rangle_z)^2\rangle_z>0,
\]
where the tilted probability density is \(e^{z\sin\theta'}/(2\pi M_e(z))\). It is strictly positive on the circle and \(\sin\theta'\) is not constant, so the variance is strictly positive. For \(p\ne0,\mu>0\),
\[
\partial_\mu(g(2\mu p)-2g(\mu p))
=2p(g'(2\mu p)-g'(\mu p))>0.
\]
For \(p>0\) both factors on the right are positive; for \(p<0\) both are negative. Thus \(V\) strictly increases in \(\mu>0\), including its separately proved formula at \(p=0\).

Here is the required growth bound, without an unproved asymptotic invocation. For \(z\ge1\), write \(\theta'=\pi/2+x\) near the maximum. On a fixed small interval \(|x|\le a<\pi\), there are \(c_1,c_2>0\) with \(1-c_2x^2\le\cos x\le1-c_1x^2\). A lower bound integrates over \(|x|\le z^{-1/2}\min(a,1)\), giving \(ce^zz^{-1/2}\). An upper bound on the same interval uses the Gaussian integral and gives \(Ce^zz^{-1/2}\). On its complement \(\sin\theta'\le1-c_a\), so the contribution is at most \(e^{(1-c_a)z}\), also bounded by \(Ce^zz^{-1/2}\). For \(z<0\), shift \(\theta'\) by \(\pi\) to obtain \(M_e(z)=M_e(-z)\). Hence
\[
c\,e^{|z|}/\sqrt{|z|}
\le M_e(z)\le C\,e^{|z|}/\sqrt{|z|}\quad (|z|\ge1).
\]
Taking the ratio yields positive constants bounding \(M_e(2z)/M_e(z)^2\) above and below by multiples of \(\sqrt{|z|}\). Therefore \(V(\mu,p)\to\infty\) for each fixed \(p\ne0\); for \(p=0\) its explicit quadratic formula proves the same.

The compact range of \(p\) admits a uniform finite \(\mu_{\max}\) such that \(V(\mu_{\max},p)>3/\min a\). To prove uniformity, for each \(p_0\) select a finite \(\mu_{p_0}\) giving the strict bound there; continuity gives a neighborhood in \(p\); a finite subcover gives finitely many such \(\mu\), and their maximum works by monotonicity. This step is valid at \(p=0\), so no divergent factor \(p^{-2}\) is being used near zero.

All slopes \(t(\theta';\mu)\) for \(0\le\mu\le\mu_{\max}\) form a compact smooth family with \(P_c(t)>2\). Continuity of \(U\) and the strict inequality \(U(P,J)>2\) established above give a positive minimum of \(U-2\). Choose \(0<\delta_L<1\) smaller than that minimum, and smaller than the positive minimum of \(v_s-2\) on chosen smaller radial boundary collars.

Choose a smooth \(0\le\zeta_L\le1\) as a function of \(v_s\), equal to one for \(v_s\le2+\delta_L/8\) and zero for \(v_s\ge2+\delta_L/4\). Put
\[
v_*=2+\delta_L/2,\qquad
\rho=\zeta_L(v_s)^2(v_*-v_s),\qquad
v=v_s+\rho,
\]
and define \(\rho=0\) where \(\zeta_L=0\). On its possible nonzero support, \(v_*-v_s\ge\delta_L/4\), so
\[
\sqrt\rho=\zeta_L(v_s)\sqrt{v_*-v_s}
\]
extends smoothly by zero. Since \(v_s>0\), \(0\le\rho<v_*<3\).

There is a unique \(0\le\mu<\mu_{\max}\) solving \(V(\mu,p)=\rho/a\), by the preceding strict monotonicity and endpoint bounds. Its smoothness at \(\rho=0\) needs a distinct verification. Expanding the finite integral in its convergent power series gives \(M_e(z)=1+z^2/4+O(z^4)\), and therefore
\[
V(\mu,p)=\tfrac12d_0^2\mu^2+O(\mu^4p^2)
\]
uniformly for bounded \(p\). Thus the signed square root is \(\mu(d_0/\sqrt2+O(\mu^2p^2))\), a smooth odd function of \(\mu\) near zero with positive derivative \(d_0/\sqrt2\). Applying the implicit-function theorem to this function and \(\sqrt{\rho/a}\), already proved smooth, gives smooth \(\mu\) there. For \(\rho>0\), strict positivity of \(\partial_\mu V\) gives the same conclusion. On the overlap the two local inverses agree by uniqueness.

The three cutoff regimes show \(v>2\) everywhere. Where \(\zeta_L\ne0\), \(v\le v_*<2+\delta_L<U(P_c(t),J_c(t))\). Where \(\zeta_L=0\), \(\mu=0,t=t_s,v=v_s>2\), and the original relaxed condition gives \(v<U\). Thus each proposed state lies in the admissible cone.

Define a lifted phase coordinate by
\[
\phi(0)=0,\qquad
\frac{d\phi}{d\theta'}=\frac{a(1+t^2)}{2\pi v},
\quad
(a_L,-b_L)=\frac{v(1,t)}{1+t^2}.
\]
Since \(\langle t\rangle=t_s\) and \(\langle(t-t_s)^2\rangle=V\),
\[
a\langle1+t^2\rangle=a(1+t_s^2)+aV=v_s+\rho=v.
\]
Therefore \(\phi(\theta'+2\pi)=\phi(\theta')+1\). Its derivative has a uniform positive lower bound on the compact parameter set; it defines an orientation-preserving circle diffeomorphism with a smooth parameter-dependent inverse. Changing variables proves both original mean components exactly:
\[
\int_0^1a_L\,d\phi
=\frac a{2\pi}\int_0^{2\pi}1\,d\theta'=a,
\quad
\int_0^1(-b_L)\,d\phi
=\frac a{2\pi}\int_0^{2\pi}t\,d\theta'=at_s=-b_s.
\]
Also \(-b_L/a_L=t\), \(a_L(1+t^2)=v\), so the verified scalar cone inequalities are the desired vector cone gaps. At boundary collars \(\zeta_L=0\), and the reparametrized shear is exactly the original constant-in-\(\phi\) shear. Compactness gives one \(\kappa_L>0\) for all four cone gaps. This completes the complete loop construction, including the mean, boundary, and smoothness claims.

## Exact insertion into the unchanged original radial coordinate

Let \(\mathcal A,\mathcal B\) be the zero-mean periodic antiderivatives
\[
\partial_\phi\mathcal A=-\tfrac12(a_L-a),\qquad
\partial_\phi\mathcal B=\tfrac12E(b_L-b_s).
\]
They exist because the right sides have zero \(\phi\)-mean. One explicit construction for any zero-mean \(g\) is
\[
\mathcal I g(\phi)=\int_0^\phi g(w)\,dw-
\int_0^1\int_0^s g(w)\,dw\,ds.
\]
It is periodic, zero mean, smooth in all parameters, and has derivative \(g\). It vanishes identically when \(g\equiv0\). Therefore these antiderivatives vanish on the boundary collars and extend smoothly by zero outside \(I\).

For an integer \(N>0\), keep the source's exact definitions
\[
E_N=E\exp(\mathcal A(X,\eta,N\log X)/N),\qquad
U_N=U+\mathcal B(X,\eta,N\log X)/N.
\]
The modified \(E_N\) is positive without approximation. The chain rule in the logarithmic coordinate is \(X\partial_X=D_X+N\partial_\phi\) after substitution. Hence
\[
\begin{aligned}
a_N
&=1-2X\partial_X\log E_N\\
&=a-2D_X\mathcal A/N-2\partial_\phi\mathcal A
=a_L-2D_X\mathcal A/N,
\end{aligned}
\]
\[
\begin{aligned}
b_N
&=\frac{2X\partial_XU_N}{E_N}\\
&=e^{-\mathcal A/N}
\left(\frac{2D_XU+2\partial_\phi\mathcal B}{E}
+\frac{2D_X\mathcal B}{NE}\right)\\
&=e^{-\mathcal A/N}
\left(b_L+\frac{2D_X\mathcal B}{NE}\right).
\end{aligned}
\]
The axial exponential denominator is retained; replacing it by one would destroy this exact shear formula.

On the fixed compact interval from \(X_-\) through the first reserved patch, \(X,E,H=\sqrt{2X}E,L\) have positive lower bounds. The phase \(N\log X\) is independent of \(\eta\), so every fixed number \(m\) of \(\eta\)-derivatives of \(E_N-E,U_N-U,a_N-a_L,b_N-b_L\) is bounded by \(C_m/N\). For the exponential difference, use
\[
e^{\mathcal A/N}-1
=\frac{\mathcal A}N\int_0^1e^{s\mathcal A/N}\,ds
\]
and then differentiate under its fixed finite integral; all factors of \(\mathcal A\) and its parameter derivatives are uniformly bounded on the periodic compact domain. For radial derivatives, \(r\ge1\) differentiations produce at most \(N^r\) from the phase and retain the initial \(N^{-1}\), giving \(C_{r,m}N^{r-1}\). Thus no small-radial-derivative assertion is used for the modulation.

## All five moments and the dependence of the integrated stress

Retain exactly
\[
M=\int_0^XU\,dx,\quad I=\int_0^X\sqrt{2x}E\,dx,\quad
J=\int_0^XU\sqrt{2x}E\,dx,
\]
\[
S=\int_0^X(U^2-E^2/2)\,dx,\qquad
C_p=\int_0^X E^2/(2x)\,dx,\qquad \Pi=\Pi_0+C_p.
\]
On the support of the differences, all scalar weights are bounded, since it is a compact interval with positive left endpoint. For instance
\[
U_N^2-U^2=(U_N-U)(U_N+U),\qquad
E_N^2-E^2=(E_N-E)(E_N+E).
\]
These identities, the product rule, and integration of the uniform \(C_m/N\) profile bounds prove every fixed \(\eta\)-derivative of the full prefix moment difference is \(O_m(N^{-1})\), uniformly in the endpoint \(X\). The pressure datum is the same, so \(\Pi_N-\Pi=C_{p,N}-C_p\) has exactly that bound.

The formulas whose continuity matters are
\[
W=1-\frac{2D\eta M+(1-\eta^2)M_\eta}{X},
\]
\[
Q_s=-W+
\frac{(1-h)I-D\eta I_\eta-(1-\eta^2)J_\eta+2(h-D)\eta J}{XH},
\]
\[
N_s=-WU+
\frac{D(M-\eta M_\eta)+4h\eta S-(1-\eta^2)S_\eta}{X}
+4A\eta\Pi-(1-\eta^2)\Pi_\eta,
\]
\[
p_s=(XQ_s/L,\ XN_s/(LE)).
\]
All denominators are bounded away from zero on the fixed interval. Differences of reciprocals are exactly
\[
E_N^{-1}-E^{-1}=-(E_N-E)/(E_NE),\qquad
H_N^{-1}-H^{-1}=-(H_N-H)/(H_NH).
\]
Applying the product rule to the displayed formulas proves the \(m\)-th parameter derivative bound for \(p_{s,N}-p_s\) from the profile and moment bounds through order \(m+1\), with no radial derivative of the differences. This proves the precise assertion needed for the cone stability.

The compact loop has positive four-gap margin. Its values and the original \(p_s\) range in a compact subset of \(a>0\); take a fixed small neighborhood still in \(a>0\), on which the four-gap map has a finite Lipschitz constant. The just-proved \(O(N^{-1})\) errors in \(a,b,p_s\) preserve each gap for sufficiently large finite \(N\). Between \(I\) and the first correction patch, \(E_N=E,U_N=U\), so the shears themselves equal the originals; the \(p_s\) error remains \(O(N^{-1})\). The original strict admissible margins on that compact intervening interval are preserved by the same argument.

## Nonlinear moment correction with an exact endpoint map

On the first reserved patch, the original profile is \(U=0,E=K(\eta)X^{-1/2-\lambda}\), where fixed \(\lambda>0\) and positive \(K\) have been selected before \(N\). The earlier modulation is zero on this patch. Add two smooth compactly supported \(U\)-bumps and three \(E\)-bumps with five coefficient functions \(c(\eta)\). Each block's bumps are nonnegative, nonzero, and supported on ordered disjoint intervals.

Differentiate the five original moment functionals at zero correction. In row order \((M,J;I,S,C_p)\), the two \(U\)-columns have weights \(1,H=\sqrt{2X}E\), and the three \(E\)-columns have weights \(\sqrt{2X},-E,E/X\). The off-diagonal blocks are zero because \(U=0\) before the correction. Up to the displayed nonzero factors, the exponent lists are
\[
(0,-\lambda),\qquad
(1/2,-1/2-\lambda,-3/2-\lambda).
\]
All powers within each block are distinct for the fixed \(\lambda>0\). To establish invertibility directly, a nonzero linear combination of \(m\) distinct powers has at most \(m-1\) distinct positive zeros: divide by the least power, use Rolle's theorem on \(m\) putative zeros, and apply induction to the derivative, which has \(m-1\) distinct powers and nonzero coefficients wherever the original nonconstant coefficients were nonzero. Thus the evaluation determinant \(\det[x_j^{\alpha_i}]\) never vanishes for ordered \(0<x_1<\cdots<x_m\). Its sign is constant on that connected set. Multilinearity and Fubini give
\[
\det\left[\int x^{\alpha_i}\beta_j(x)\,dx\right]
=\int\det[x_j^{\alpha_i}]\prod_j\beta_j(x_j)\,dx_1\cdots dx_m\ne0.
\]
The integrand has a constant nonzero sign on a set of positive measure. This proves each block's rank and hence the full moment Jacobian's rank. Smooth dependence on \(\eta\), compactness of \([-1,1]\), and the derivative identity for the inverse give uniform finite bounds at every fixed parameter order. No uniform estimate as \(\lambda\to0\) is claimed or needed.

The exact moment increment map is \(B(\eta)c+Q_\eta(c,c)\), because \(M,I\) are linear, \(J\) is bilinear in \(U,E\), and \(S,C_p\) are quadratic. Let \(d_N(\eta)\) be the negative moment discrepancy accumulated before the patch; it obeys \(\|d_N\|_{C^m}\le C_m/N\). On the \(C^0\) ball of radius \(r=2\beta_0\|d_N\|_{C^0}\), where \(\beta_0=\|B^{-1}\|_{C^0\to C^0}\), the map
\[
\mathcal T(c)=B^{-1}(d_N-Q(c,c))
\]
maps the ball to itself and has Lipschitz constant at most \(2\beta_0\kappa_0r\le1/2\), provided \(8\beta_0^2\kappa_0\|d_N\|_{C^0}\le1\). Thus it has a unique fixed point selected by iteration from zero. The derivative \(B+D_cQ(c,c)\) is invertible by the same estimate, giving smooth parameter dependence including one-sided endpoint derivatives. In each preselected finite \(C^m\) norm the identical contraction proof works after increasing \(N\), with the relevant multiplication and bilinear norms, and yields \(C_m/N\) for the same branch.

The assertion that every other fixed derivative is \(O_m(N^{-1})\) can also be justified without demanding simultaneous smallness of infinitely many norms. Differentiate the pointwise equation \(m\) times. The highest coefficient derivative is multiplied by the uniformly invertible \(B+D_cQ(c,c)\). All other terms contain either a derivative of \(d_N\), \(O_m(N^{-1})\), or a lower derivative of \(c\); induction gives \(O_m(N^{-1})\) for them, with the fixed data derivatives included in the constants. The same inverse bound therefore proves the estimate for the highest derivative. Only the finite orders needed for positivity and the cone gaps determine the actual choice of \(N\).

The bump shapes and widths are fixed, so their radial derivatives multiply these small coefficients by fixed constants. The correction is therefore small in the radial derivatives entering \(a,b_s\), in the first parameter derivatives entering \(p_s\), and in all prefix moments. The compact input cone margin on the correction patch persists. Positivity of \(E\) there also persists, after one further finite lower bound on \(N\).

At the right endpoint \(X_{\rm rep}\), the five corrected moments equal the original moments exactly as functions of \(\eta\), while the corrected profiles equal the original profiles for every \(X\ge X_{\rm rep}\). Their derivatives as functions of \(\eta\) also agree. Each difference moment has zero derivative in \(X\) there, by the original moment integrands, so it stays zero at every later radius. The common axis pressure datum gives identical \(\Pi\). The displayed formulas for \(Q_s,N_s,p_s\) and the original incompressibility formula
\[
V_0=\frac X L\left(2\eta U-2D\eta M/X-(1-\eta^2)\partial_\eta(M/X)\right)
\]
then prove exact equality of these fields at every later radius. This is the exact morphism from the five-moment endpoint data to exterior pressure, velocity, and stress; it proves preservation of the terminal compensation, both unused reserved correction patches, and the entire exterior. The inner collar is unchanged because both modifications start later and pressure was integrated from the same axis datum.

## Edge direction and the common weight

Appendix C leaves both original collars unchanged. The input edge facts it uses are: at the inner edge, with \(y_a=\log(X/X_a)\), the stress is
\[
T_0=e^{-t_1^2/y_a^2}g_a(y_a)B_0(X,\eta),\qquad
g_a(0)>0,\quad B_0(X_a,\eta)=F p_{s,r}\ne0;
\]
its limiting direction is a positive multiple of the limiting shear \((a,-b_s)=a(1,t_s)\). At the outer edge, with \(y_b=\log(X_b/X)\), the component factorization has common exponential \(e^{-4/y_b^2}\), angular prefactor \(y_b^{-3}b_\theta\) with \(b_\theta(0,\eta)>0\), and the direction
\[
n=\frac{(b_\theta,y_b^6b_z)}
{\sqrt{b_\theta^2+y_b^{12}b_z^2}}.
\]
The original collar analysis supplies smooth factors and the fixed-order derivative bounds. Their derivation is assigned to the profiles lane; their exact use here is as follows.

The positive factors cancel in \(n=T_0/|T_0|\), giving a smooth direction through both endpoints. At the inner edge \(n_z-t_sn_\theta=0\) and \(n_\theta+t_sn_z>0\). At the outer edge \(n=(1,0)\), \(t_s=0\), giving the same two conclusions. In the interior,
\[
n_\theta+t_sn_z=\frac{P_c-v_s}{|p_s-(a,-b_s)|}>0,\qquad
n_z-t_sn_\theta=\frac{J_c}{|p_s-(a,-b_s)|}.
\]
The admissible cone makes
\[
2-(v_s-2)\frac{(n_z-t_sn_\theta)^2}{(n_\theta+t_sn_z)^2}>0.
\]
Both the denominator and this gap extend continuously to the closed annulus, where the gap has value two at both radial edges. Their positive compact minima permit one \(0<\kappa<2\) with
\[
n_\theta+t_sn_z\ge\kappa,\quad
(v_s-2)(n_z-t_sn_\theta)^2
\le(2-\kappa)(n_\theta+t_sn_z)^2.
\]
The positive lower bounds on \(F,a,v_s-2\) in the interior and the original endpoint bounds likewise extend uniformly by compactness.

The original stress identity \(T_0=F(p_s-(a,-b_s))\) proves nonvanishing throughout the open shell: if it vanished, \(P_c=v_s\), contrary to admissibility. The outside stress remains zero by the exact endpoint restoration and unchanged inner region. Define the original proposed common edge weight
\[
\zeta(X)=\exp(-t_1^2/y_a^2-4/y_b^2),\qquad
\delta=\min(1,y_a,y_b),
\]
extended by zero outside the open shell. On a sufficiently short inner collar, the second exponential is smooth and bounded above and below by positive constants, while \(g_a,B_0\) have the required nonzero value bounds and fixed derivative bounds. The inner factorization therefore proves \(|T_0|\ge c\zeta\) and \(|\partial^IT_0|\le C_I\zeta\delta^{-m_I}\). On a short outer collar the first exponential is similarly a smooth positive factor; \(y_b^{-3}b_\theta\) has a lower positive bound and its derivatives have only finite inverse powers of \(y_b\). The supplied outer factor derivative bounds give the same conclusion. On the remaining compact interior both \(\zeta\) and \(|T_0|\) have positive minima and every fixed derivative is bounded, so the same pair of inequalities follows after increasing constants. These three regions cover the annulus. The elementary exponential argument in the first file proves smooth zero extension of all stress derivatives at both boundaries.

All remaining completion claims in C.3 are exact preservation statements: the axis Cartesian formulas remain unchanged on the analytic rectangle; the pressure at infinity and exterior moment values remain unchanged by the proved five-moment map; the exterior heat function is unchanged pointwise; and on \(X\ge X_v=X_{\rm end}\) the original \(U=M=0\) gives \(V_0=0\) directly by its formula. The third and fourth reserved intervals remain the exact original \(U=0,E=c_{\rm patch}(1+\eta^2)^{-1}X^{-1/2-\lambda}\) intervals, with their original order. Fixing this one finite \(N\) before the physical scale \(q\), all dyadic bands, and all later correction stages proves the claimed independence of the resulting derivative constants from those later parameters.
