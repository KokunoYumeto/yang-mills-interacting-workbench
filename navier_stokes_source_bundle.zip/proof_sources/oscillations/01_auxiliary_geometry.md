# Auxiliary geometry and coefficient algebra: independent derivation

Source: supplied *Finite Time Blowup for Navier-Stokes*, Section 6, pp. 62-72. Source identity and audit boundary are recorded in `LOGBOOK.md` and `READ_SCOPE.md`. The formulas below use the source's original cylindrical coordinate orientation, chart scales, integer covering, and support domains. The geometric and algebraic assertions are proved here directly.

## Coordinate maps and exact derivative intertwining

Let \(A=1/2+h\), \(D=1/2-h\), \(0<h<1/100\), \(Q=2^{-\ell}\), \(\varepsilon=Q^h\), \(S_*=\ell^2\), and
\[
R=r/Q^{1/2},\quad Z=z/Q^D,\quad T=(1-t)/Q.
\]
The profile radius is \(R_{\rm profile}=r/q^{1/2}\), so the exact transition is \(R=\sqrt{q/Q}\,R_{\rm profile}\). No equality of these different radius coordinates is used. The original similarity variables obey \(z=q^D\eta\), \(1-t=q(1-\eta^2)\), with \(L=1-2h\eta^2>0\). On a dyadic shell \(q/Q\in[1/2,2]\), \(q/Q\) and \(\eta\) are smooth functions of \(Z,T\), including one-sided derivatives at \(T=0\). Indeed \(T=s-Z^2s^{2h}\), \(s=q/Q\), has derivative \(1-2hZ^2s^{2h-1}=L\ge1-2h\). Repeated implicit differentiation bounds each fixed chart derivative on the compact shell. Thus the ordinary chart and profile derivatives used below are related by finite sums with uniformly bounded smooth coefficients.

Set
\[
J_g=\begin{pmatrix}3&1\\1&5\end{pmatrix},\quad b_g=\sqrt2-1,
\quad v_r=(1,-b_g),\quad v_t=(b_g,1),
\]
\[
\Lambda_g=4-\sqrt2,\quad T_g=4+\sqrt2,\quad
\rho_g=\frac{\log\Lambda_g}{\log T_g},\quad \kappa_s=10^{-5},
\quad d_r=2((1+h)\rho_g-h\kappa_s).
\]
Direct multiplication gives \(J_gv_r=\Lambda_gv_r\), \(J_gv_t=T_gv_t\), \(v_r\cdot v_t=0\), and \(\det J_g=14\). Also \(\rho_g>0\) and \(\rho_g>\kappa_s\), hence \(d_r>0\). For example \(\Lambda_g>2\), \(T_g<6\) imply \(\rho_g>\log2/\log6>1/3>\kappa_s\).

On the extended domain with independent \(Y\in\mathbb R^2/\mathbb Z^2\), define
\[
\iota(r,\theta,z,t)=(r,\theta,z,t,v_rr^{d_r}+v_tt\bmod\mathbb Z^2).
\]
For every smooth extended scalar \(F\), the ordinary chain rule proves the exact identities
\[
\partial_t(\iota^*F)=\iota^*((\partial_t+v_t\cdot\partial_Y)F),\qquad
\partial_r(\iota^*F)=\iota^*((\partial_r+d_rr^{d_r-1}v_r\cdot\partial_Y)F).
\]
The \(z,\theta\) identities have no extra term. These are morphisms of differential algebras: pullback preserves sums and products and intertwines the four stated derivations. Their commutators vanish because the only variable coefficient depends on \(r\), the extra directions are constant and independent of \(Y,t,z,\theta\), and the radial derivation is the only derivation differentiating that coefficient. The fields depending on \(Y\) vanish in a neighborhood of the axis at each \(q>0\), so no differentiability of \(r^{d_r}\) at \(r=0\) is invoked.

For \(i=\lfloor\log_{T_g}(Q^{-1-h}/S_*)\rfloor\ge0\), let \(\pi_i(Y)=J_g^iY\bmod\mathbb Z^2\). This is a surjective group homomorphism of tori with finite kernel of cardinality \(14^i\). On a pullback \(f\circ\pi_i\), the two directional operators are exactly \(T_g^iN_if\) and \(\Lambda_g^iL_if\), where \(N_i=v_t\cdot\partial_{Y_i}\), \(L_i=v_r\cdot\partial_{Y_i}\). Thus
\[
\mathsf t_*=Q^{1+h}\mathsf t=-\varepsilon\partial_T+c_iN_i,
\quad D_r=\sqrt Q\,\mathsf r=\partial_R+M_id_rR^{d_r-1}L_i,
\]
\[
c_i=T_g^iQ^{1+h},\quad M_i=\Lambda_g^iQ^{d_r/2},\quad
D_z=\sqrt Q\partial_z=\varepsilon\partial_Z,
\quad D_\theta=R^{-1}\partial_\theta.
\]
The floor inequality is strict on its left:
\[
T_g^{-1}Q^{-1-h}/S_*<T_g^i\le Q^{-1-h}/S_*.
\]
It follows that \(T_g^{-1}S_*^{-1}<c_i\le S_*^{-1}\), and, using \(\Lambda_g^i=(T_g^i)^{\rho_g}\),
\[
T_g^{-\rho_g}\varepsilon^{-\kappa_s}S_*^{-\rho_g}
<M_i\le\varepsilon^{-\kappa_s}S_*^{-\rho_g}.
\]
Every radial derivative of \(d_rR^{d_r-1}\) is bounded on the fixed positive radial interval. This proves the claimed additional radial cost \(\varepsilon^{-\kappa_s}\), with its retained power of \(S_*\).

For physical velocity \(Q^{-A}u_*\), pressure \(Q^{-2A}p_*\), and residual multiplier \(Q^{2A+1/2}\), the time, spatial first-derivative, and Laplacian coefficients are respectively
\[
Q^{2A+1/2-A}=Q^{1+h},\qquad
Q^{1/2},\qquad
Q^{2A+1/2-A-1}=Q^h=\varepsilon.
\]
These identities retain the source's viscosity-one chart convention; scaling to arbitrary viscosity is outside this lane.

## Fourier inversion and descent

For \(n=(n_1,n_2)\ne0\),
\[
v_r\cdot n=(n_1+n_2)-\sqrt2n_2.
\]
Its product with the algebraic conjugate is the nonzero integer \((n_1+n_2)^2-2n_2^2\). It cannot be zero unless \(n_2=0=n_1\), by irrationality of \(\sqrt2\). The conjugate has absolute value at most \(C|n|\), so \(|v_r\cdot n|\ge1/(C|n|)\). For \(v_t\cdot n=(n_2-n_1)+\sqrt2n_1\), the same argument uses \((n_2-n_1)^2-2n_1^2\). Therefore both directional inverses on zero-mean smooth torus functions have Fourier multipliers bounded by \(C(1+|n|)\), retaining the Fourier derivative factor \(2\pi i\): the inverse of \(v\cdot\partial_Y\) multiplies the \(n\)-coefficient by \((2\pi i\,v\cdot n)^{-1}\). Rapid Fourier decay is preserved. In Sobolev norms this gives \(\|L^{-1}f\|_{H^s}\le C_s\|f\|_{H^{s+1}}\), with the zero coefficient defined to be zero. Taking a further fixed Sobolev embedding loss gives all fixed classical derivatives. No infinite derivative loss occurs.

If \(f\) descends through \(\pi_i\), its Fourier support lies in \((J_g^i)^T\mathbb Z^2\). Translation multiplies each coefficient by a character, averaging deletes nonzero coefficients, and a directional Fourier inverse multiplies them by scalar values. Each operation preserves this sublattice. Radial integration at fixed \(z,t\) preserves deck invariance pointwise in the integral. These are the precise maps proving the descent claims.

## Separation of all interacting labels

Use the dyadic squared partition \(\sum_\ell\chi_\ell(q)^2=1\), the product grid squared partitions of mesh \(S_*^{-3}\), and the duplicated signs in the source's labels \(\gamma=(\ell,a,\sigma)\). On the active annulus select every grid support meeting the active shell and a representative in that intersection. Then \(\eta_\gamma=\chi_\ell\chi_{\ell,a}\) gives \(\sum_{\beta=(\ell,a)}\eta_\beta^2=1\), counting each box once and the two signs separately only when assigning rectangles.

Overlapping dyadic supports imply \(|\ell-\ell'|\le2\). Join labels whenever the fixed-factor enlarged physical grid boxes intersect and the band difference is at most four, and join the two signs of each box. A chart scale ratio for bands differing by four is bounded above and below; \(\ell^2/(\ell')^2\) has the same property for \(\ell,\ell'\ge\ell_0>4\). A grid box thus meets a uniformly bounded number of boxes in each of finitely many bands. The countable graph has maximum degree \(d<\infty\). Enumerating its vertices and assigning the first unused color in \(\{1,\ldots,d+1\}\) gives a proper coloring.

Writing \(f(\ell)=((1+h)\ell\log2-2\log\ell)/\log T_g\), the mean-value bound and the floor operation give
\[
|i(\ell)-i(\ell')|\le1+\frac{4(1+h)\log2+8/\ell_0}{\log T_g}.
\]
Fix an integer upper bound \(\Delta_{\max}\). There are only finitely many ordered color constraints
\[
c_\mu\ne J_g^\Delta c_\nu\pmod {\mathbb Z^2},\qquad0\le\Delta\le\Delta_{\max},
\]
excluding only the tautological constraint \((\Delta,\mu,\nu)=(0,\nu,\nu)\). For different colors, the forbidden equality is a proper closed subset with empty interior of the finite product of tori. For a self-pair with \(\Delta>0\), \(J_g^\Delta-I\) is nonsingular because its eigenvalues are \(\Lambda_g^\Delta-1,T_g^\Delta-1>0\); its kernel on the torus is finite, so this forbidden subset also has empty interior. A finite union of these closed sets has empty interior. The complement is open and nonempty, and rational tuples are dense, giving the rational centers specified in the source. There is consequently a strictly positive minimum distance \(d_c\) of every forbidden difference from the lattice.

Let \(C_J=\max_{0\le\Delta\le\Delta_{\max}}\|J_g^\Delta\|\) and \(C_v=\|v_r\|+\|v_t\|\). Choose \(r_0>0\) sufficiently small that all enlarged rectangles are injective and \(2r_0 C_v(C_J+1)<d_c\). If two absolute preimages of enlarged rectangles at levels \(i,i+\Delta\) intersect, their common point produces
\[
c_\mu-J_g^\Delta c_\nu=J_g^\Delta e_\nu-e_\mu\pmod{\mathbb Z^2},
\quad |e_\nu|,|e_\mu|\le2r_0C_v.
\]
The right side has distance from zero less than \(d_c\), a contradiction for joined labels. All labels whose slow supports meet were joined. Therefore their enlarged auxiliary preimages are disjoint. For smoothly extended fields supported in these products, the support of every derivative is contained in the same closed support, so all cross-label derivative products vanish before and after \(\iota^*\). This proves the required nonlinear support assertion, including boundaries.

On a band rectangle, write \(Y_i-c_\gamma-k=\xi_gv_r+\eta_gv_t\) and \(v=(\eta_g+r_0)/c_i\), \(L_s=2r_0/c_i\). Orthogonality gives \(L_i\eta_g=N_i\xi_g=0\), \(L_i\xi_g=N_i\eta_g=1\). Hence \(D_rv=D_zv=0\), \(\mathsf t_*v=1\). This is the exact reason spatial differentiation of the pulse does not incur a time-direction torus frequency.

## Common torus, lifts, integration paths, and label counts

At a fixed \((z_0,t_0)\), put \(q_{\mathrm{loc}}=q(z_0,t_0)>0\).
By continuity choose a neighborhood \(U\) with
\(q(U)\subset(q_{\mathrm{loc}}/2,2q_{\mathrm{loc}})\).
An active dyadic band obeys \(q/2\le Q_\ell\le2q\).
Every band meeting \(U\) therefore has
\(q_{\mathrm{loc}}/4<Q_\ell<4q_{\mathrm{loc}}\), so its dyadic
indices lie in a finite set \(\mathcal L(U)\) with span at most four.
The previously proved four-band bound on \(i(\ell)-i(\ell')\)
therefore applies to this entire set. Take \(i_0=\min_{\ell\in\mathcal L(U)}i(\ell)\), \(H=J_g^{i_0}Y\). Then \(Y_i=J_g^\Delta H\), \(0\le\Delta\le\Delta_{\max}\). The preimage of an injective rectangle consists exactly of the \(14^\Delta\) images
\[
J_g^{-\Delta}(c_\gamma+k+\xi_gv_r+\eta_gv_t)\pmod {\mathbb Z^2},
\quad[k]\in\mathbb Z^2/J_g^\Delta\mathbb Z^2.
\]
Different cosets give disjoint copies: an overlap would imply that their \(k\)-difference is in \(J_g^\Delta\mathbb Z^2\), after using injectivity in the band rectangle. This also proves there are no omitted copies. Derivative factors of \(J_g^\Delta\) are uniformly bounded. Surjectivity of \(\pi_{i_0}\) transfers the previously proved support separation to \(H\).

For a torus character \(e^{2\pi i n\cdot Y_i}\), pullback has frequency \((J_g^\Delta)^Tn\), zero exactly when \(n=0\). Integrating a Fourier series therefore proves exact preservation of normalized Haar measure, not an approximation depending on frequency. This proves agreement of the absolute, common, and band averages. On overlaps the representatives pull back to the identical extended field; their compatibility is equality after the respective covering maps. Those maps are independent of \(R,Z,T\), so slow derivatives preserve compatibility. The normalized fast derivatives are the same absolute operators \(Q^{1+h}N_{\rm abs}\) and \(Q^{d_r/2}L_{\rm abs}\); they also preserve it.

A mesh of spacing \(S_*^{-3}\) gives \(O(1)\) overlap at a point, \(O(S_*^9)\) boxes in a compact three-dimensional chart set, and \(O(S_*^3)\) boxes along a bounded radial line. The two signs and bounded covering multiplicities contribute fixed factors. Radial integration fixes \(q(z,t)\); it can collect radial boxes but no additional bands. The collected sum therefore introduces only a polynomial in \(S_*\).

Define \(\lambda_t(w)=v_t\cdot w/(1+b_g^2)\). In a lifted common rectangle, the exact path holding slow and transverse coordinates fixed is
\[
H_w=H+T_g^{-\Delta}c_i(w-v(H))v_t.
\]
Because \(\lambda_tJ_g^\Delta=T_g^\Delta\lambda_t\),
\[
D_Hv=T_g^\Delta\lambda_t/c_i,\quad
D_HH_w=I-v_t\lambda_t,
\]
and all higher derivatives of these affine expressions vanish. The first is \(O(S_*)\), the second uniformly bounded. No phase-averaging operation is hidden in this path: values at distinct preimages remain distinct. Deck translations commute with the path and merely reindex the rectangle copy. A uniquely prescribed initial-value solution therefore descends to the common torus.

## Weighted coefficient classes and complete product rules

On \(X_a<X<X_b\), let
\[
\zeta=\exp\left(-\frac{a_a}{\log^2(X/X_a)}-\frac{a_b}{\log^2(X_b/X)}\right),
\quad\delta=\min\{1,\log(X/X_a),\log(X_b/X)\},
\]
with fixed \(a_a,a_b>0\), and extend \(\zeta\) by zero. For any \(b>0,N\ge0\), \(\zeta^b\delta^{-N}\to0\) faster than every power at either edge: put \(x=1/\delta\to\infty\) and use \(x^Ne^{-cx^2}\to0\), proved for example by comparing \(N\log x-cx^2\) with \(-cx^2/2\) for large \(x\). Repeated derivatives of the explicit exponential have the same exponential times a finite sum of inverse edge-distance powers. Thus all stated derivative bounds imply smooth zero extension at radial boundaries.

The mean class \(\mathcal M_\alpha\) consists of angular-independent compatible coefficients with derivatives bounded by \(C_I\varepsilon^\alpha S_*^{b_I}\zeta\delta^{-d_I}\), smooth zero extension outside the active shell, and no rectangle or envelope condition. The wave class \(\mathcal W_\alpha\) uses the same derivative variables \((R,Z,T,H_1,H_2)\), retains a label and nonzero harmonic, has the prescribed closed slow/transverse/shell supports, and bounds \(C_I\varepsilon^\alpha S_*^{b_I}\sqrt\zeta\delta^{-d_I}P(v)\). Actual cutoff coefficients also have compact pulse support and smooth extension there. Equal label-harmonic contributions must be added before testing the bounds. \(P(v)\) is a pointwise weight; these definitions already require all coefficient derivatives to obey it, so no differentiation of a mere inequality for \(P\) is being assumed.

Leibniz's formula has finitely many terms at each order. The retained products of weights obey
\[
\zeta^2\le\zeta,\quad\zeta^{3/2}P\le\sqrt\zeta P,
\quad\zeta P^2\le\zeta,\quad\zeta P^2\le\sqrt\zeta P
\]
because \(0\le\zeta,P\le1\). These prove \(\mathcal M_\alpha\mathcal M_\beta\subset\mathcal M_{\alpha+\beta}\), \(\mathcal M_\alpha\mathcal W_\beta\subset\mathcal W_{\alpha+\beta}\), and the two same-label wave-product rules. A zero-harmonic product extends to a mean after temporal cutoff. Before cutoff it is only a mean-bounded local coefficient. Multiplication by a mean cannot enlarge the wave support; products of different actual labels are zero by separation. Finite sums retain the same exponent and suitable maxima of the polynomial degrees.

For a nonzero angular frequency \(kp_\gamma\in\mathbb Z\setminus\{0\}\), angular integration of \(e^{ik(m+m')\Phi_\gamma}\) is zero unless \(m+m'=0\), in which case it is one. This proves exactly which product coefficients survive. It does not identify angular averaging with auxiliary averaging. Products add harmonic integers and differentiation preserves them; a finite sequence of such operations leaves a finite band-independent set at each finite stage.

Ordinary coefficient derivatives shift the derivative index in the defining estimate, preserving \(\alpha\). Multiplication by \(M_id_rR^{d_r-1}\), with all its derivatives bounded above, proves \(D_r:\mathcal C_\alpha\to\mathcal C_{\alpha-\kappa_s}\), \(\mathcal C=\mathcal M,\mathcal W\). The other exact maps are \(D_z=\varepsilon\partial_Z:\mathcal C_\alpha\to\mathcal C_{\alpha+1}\), \(-\varepsilon\partial_T:\mathcal C_\alpha\to\mathcal C_{\alpha+1}\), and \(c_{i_0}N_{i_0}:\mathcal C_\alpha\to\mathcal C_\alpha\). Here \(c_{i_0}=T_g^{-\Delta}c_i\) and \(M_{i_0}=\Lambda_g^{-\Delta}M_i\), so a change to a common torus changes constants, not exponents. All these claims concern coefficients with the exponential factored out. Differentiating the exponential itself produces its exact \(ikm\nabla_*\Phi\) or \(ikm\mathsf t_*\Phi\) factor and is accounted for separately in the pulse analysis.

Finally, for \(f_*=Q^{a_f}f_{\rm phys}\), substitution \(r=\sqrt Q R\) gives the exact moment map
\[
\int R^e\langle f_*\rangle_Y\,dR
=Q^{a_f-(e+1)/2}\int r^e\langle f_{\rm phys}\rangle_Y\,dr.
\]
The measure and power weight are both retained. Normalized Haar compatibility proves that the average may be computed in any of the three torus representations.
