# Endpoint derivation review (Section 10)

This review compares the complete local file
`./research/released_ns/endpoint_derivation.tex`
with all source text on printed pp. 117-126 (Section 10, including its opening on p. 117),
plus the preceding source p. 116 boundary paragraph needed by Theorem 3.1's input.
The source PDF is the released 165-page manuscript; this review does not claim that any
other section was independently validated.

## Receipt and visual/read scope

- Read every line of the endpoint TeX file, including E.1-E.30, the comparison proof,
  both viscosity maps, the pressure argument and the torus construction.
- Read all Section 10 source proof text pp. 117-126 and the p. 116 paragraph that
  states the local potential/heat-exterior input. The source's p. 116-126 extraction was
  cross-checked against the original local PDF, not only a summary.
- Read the formalization inventory's `ComparatorTheorem.lean`,
  `ComparatorR3Theorem.lean`, and `ComparatorDefinitions.lean` by text search for the
  viscosity adapter, force rescaling and periodic hypotheses. No Lean process was run.
- The source's $q_*>0$ is a fixed threshold from Theorem 3.1. The endpoint file had
  used $q_*$ before defining its provenance; this was corrected in the root file by one
  sentence immediately after the local coordinates.

## Claim-by-claim outcome

The localization map is exact. A fixed axisymmetric spatial cutoff $<chi_x(r^2,z)$ and
time cutoff $<chi_t(t)$ are chosen using the exact bound
\(q\le C_0(\tau+|z|^{1/D})\), placing support in $q<q_*/2$. Applying the spatial
cutoff to the vector potential before curl preserves divergence exactly, and the product
term $\nabla c\times\mathcal A$ is retained. The azimuthal mean potential and all annular
potentials vanish in the common exterior, so $\mathcal A=0$ there. The pressure cutoff,
zero extension and initial-time cutoff are all supported with a strict margin. No substantive
gap was found.

The terminal-limit proof is complete at the level of the imported Theorem 3.1 hypotheses.
Away from the origin, compact positive-$q$ bounds give uniform Cauchy estimates by the
fundamental theorem of calculus. On the positive-radius heat exterior, differentiating the
integral profile is justified by the majorant $e^{-v}v^{h+j}$, and the pressure integral is
justified by the radial majorant $\rho^{-3-4h-2j}$. At the origin, the imported flat residual
bound and the exact coordinate estimate give arbitrary powers of
$(\tau+|z|^{1/D})$. A finite-cover argument combines the regions. Passing limits through
spatial line integrals proves compatibility, support in $K$, and vanishing terminal jets at
the origin. This matches source Lemma 10.2.

The force extension is a valid Whitney-style time series. The product-rule estimate for
$\chi_0(b_j\sigma)\sigma^jF_j/j!$ has only finitely many constraints for each $j$, all with
exponent $m-j<0$ in the chosen derivative range, so an increasing integer $b_j$ exists.
For each fixed mixed derivative the differentiated tail is summable, and at $sigma=0$ only
the $j=m$ term contributes. The extension is compactly supported in $K\times[0,2]$ and
has all required spatial/time decay. No gap found.

The energy calculation retains the full dissipation and is stronger than a bare $L^2$ bound:
\(\|u(t)\|_2^2+2\int_0^t\|\nabla u\|_2^2\le F(t)^2\). The comparison proof correctly recovers the pressure gradient without a pressure-growth assumption. The $H^{-s}$ argument for the Riesz pressure, the cutoff commutator kernel
\(CR^{-3}\min\{R^{-1}|x-y|,1\}\), its $L^{4/3}$ norm $O(R^{-3/4})$, weighted Sobolev interpolation, and expanding-ball Gronwall estimate are all valid. In particular, $u=0$ on the boundary annulus for large $R$, so $v=w$ there; this is used correctly. No substantive gap found.

The growth path preserves the exact original profile coordinate: at $z=0$, $q=\tau$ and
fixed $X_{\rm in}$ gives $u_\theta=\tau^{-A}(e_0+O(\tau^{2h}))$. The comparison argument
then excludes any global bounded-energy competitor. The force-nonzero conclusion follows from
the retained dissipation inequality.

The two viscosity maps are exact morphisms. The physical map
\(u^\nu=\sqrt\nu u(x/\sqrt\nu,t), p^\nu=\nu p, f^\nu=\sqrt\nu f\)
scales every residual term by $\sqrt\nu$, sends $K$ to $\sqrt\nu K$, preserves time one,
and scales squared energy and total dissipation by $\nu^{5/2}$. The formalization's map
`rescaledForce ν f = ν² f(ν t,x)` is the distinct fixed-period adapter
\(\mathscr T_\nu\), and the exact relation
\(\mathscr T_\nu=\mathscr S_{\sqrt\nu}\circ\mathscr A_\nu\)
is proved in the TeX file. Text inspection of the formalization confirms this is the map
used by its periodic comparator theorem; no claim that its abstract fields are literally the
constructed local representatives is made.

The periodization is exact. First use $t_0=1-\lambda^{-2}$ and the fixed-ν parabolic map,
then sum integer translates whose supports lie with positive separation in
$Q_0=(-1/2,1/2)^3$. The sums are locally finite and at most one velocity/pressure/force
translate is active, so the nonlinear convection sum has no cross terms. Pressure is
periodic separately, initial data remain zero, the singular time remains one, and force time
support is compact. The periodic difference-energy inequality gives uniqueness on every
$[0,T]$, $T<1$, and the translated growth path diverges in the zeroth cell. No gap found.

## Correction log

1. **Fixed undefined provenance of $q_*$ (root endpoint TeX).** Added: “The constant
   $q_*>0$ is the fixed local-domain threshold from Theorem 3.1 (chosen there uniformly
   for the finite correction stages).” This preserves the source domain and does not alter
   any hypothesis or estimate.

No other root-file edits were required. The pressure-growth-free uniqueness, dissipation,
viscosity factors, support margins, terminal jets, and torus pressure periodicity all survive
  exact comparison.

## Imported dependencies and claim boundary

The review accepts Theorem 3.1(ii)-(iv), Proposition 9.9 and the heat-exterior identities as
inputs from earlier sections. It does not independently prove those constructions. It verifies
every Section 10 implication once those stated inputs are available, and it does not claim
independent validation of Sections 1-9, Appendix A-C, or the full 165-page manuscript.
