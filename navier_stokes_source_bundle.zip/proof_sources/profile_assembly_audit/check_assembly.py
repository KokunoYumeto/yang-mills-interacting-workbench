from pathlib import Path
from fractions import Fraction as F
import hashlib,json,re
import sympy as s

HERE=Path(__file__).resolve().parent
u,e,U,E,X,H,eta,theta=s.symbols('u e U E X H eta theta', nonzero=True)
checks={}
checks['J_increment']=s.expand((U+u)*(H+s.sqrt(2*X)*e)-U*H-
 (H*u+U*s.sqrt(2*X)*e+s.sqrt(2*X)*u*e))==0
checks['S_increment']=s.expand((U+u)**2-(E+e)**2/2-(U**2-E**2/2)-
 (2*U*u+u*u-E*e-e*e/2))==0
checks['Cp_increment']=s.expand(((E+e)**2-E**2)/(2*X)-(E*e/X+e*e/(2*X)))==0
f=1/(1+eta**2)
checks['pressure_differential']=s.simplify(s.diff(-f**(2*theta)/2,eta)-
 2*eta*theta*f**(2*theta+1))==0
checks['axis_negative_term_bound']=F(5120000,40947201)<F(1,7)
checks['axis_root_size_denominator']=F(3200,6399)<1
checks['matching_vs_bound']=F(9,10)+F(1,100)/F(7,10)<1
checks['pulse_quadratic_1']=F(241,100)**2/8<F(74,100)
checks['pulse_quadratic_2']=F(482,100)**2/14<F(168,100)
checks['reference_width_constant']=F(188,100)*F(99,100)>F(23,10)/2
tex=(HERE/'profile_assembly.tex').read_text(encoding='utf-8')
checks['no_control_characters']=not any(ord(c)<32 and c not in '\n\t' for c in tex)
checks['no_external_tex_inputs']=not re.findall(r'\\(?:input|include)\{',tex)
labels=re.findall(r'\\label\{([^}]+)\}',tex)
refs=re.findall(r'\\(?:ref|eqref)\{([^}]+)\}',tex)
checks['labels_unique']=len(labels)==len(set(labels))
checks['all_references_internal']=set(refs)<=set(labels)
checks['labels_namespaced']=all(x.startswith('pa:') for x in labels)
receipt=json.loads((HERE/'assembly_receipt.json').read_text())
bundle=HERE.parents[1]
hash_checks=[]
for item in receipt['inputs']:
    relative=item.get('packaged_path')
    path=bundle/relative if relative else None
    if relative and not path.is_file():
        raise FileNotFoundError('Required included assembly source is missing: '+relative)
    row={'source':item['path'],'expected_sha256':item['sha256'],
         'rehashed_this_run':bool(path and path.is_file())}
    if path and path.is_file():
        row['actual_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
        row['matches']=row['actual_sha256']==item['sha256']
        assert row['matches'],row
    else:
        row['matches']=None
        row['reason']='Historical source is not included in the portable package.'
    hash_checks.append(row)
names=list(checks)
mathematical={name:checks[name] for name in names[:10]}
structural={name:checks[name] for name in names[10:]}
out={'mathematical_checks':mathematical,'structural_checks':structural,
     'source_hash_checks':hash_checks,
     'all_included_source_hashes_match':all(row['matches'] for row in hash_checks if row['rehashed_this_run']),
     'all_historical_sources_rehashed':all(row['rehashed_this_run'] for row in hash_checks),
     'passed_mathematical':sum(mathematical.values()),'passed_structural':sum(structural.values()),
     'complete_independent_analytical_validation':False,'lean_kernel_certificate':False,'prize_claim':False}
(HERE/'exact_assembly_checks.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps(out,indent=2))
assert all(checks.values())
