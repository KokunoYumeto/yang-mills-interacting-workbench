# Appendix C loop and Section 4 insertion: exact audit

## 1. Exact inputs and their provenance

The local argument takes the joined profile denoted \((U_0,E_0)\) in Section 4.6. The physical parameters have already been fixed, including
\[
A=\tfrac12+h,\qquad D=\tfrac12-h,\qquad d=1-\eta^2,
\qquad L=1-2h\eta^2,
\]
where \(0<h<1/100\), \(\eta\in[-1,1]\), and \(L\ge1-2h>0\). No change of the original radial coordinate \(X\) is used in the loop insertion. The exact logarithmic derivative is \(D_X=X\partial_X\).

The source imports the following data before Appendix C starts:

1. A positive smooth \(E_0\) for \(X>0\), smooth \(U_0\), a fixed smooth axis pressure datum \(\Pi_0(\eta)\), and the five original prefix moments. The axis factors \(F=E_0/\sqrt{2X}\), \(U_0\), \(\Pi\), and \(V_0/X\) extend smoothly to the axis and are analytic in \(\eta\) on a common neighborhood in the stipulated inner rectangle. These assertions are imported from Proposition 4.10 / Propositions B.2 and B.5 and Corollaries B.6 and B.10.
2. A joined profile having the strict relaxed cone on the open shell \((X_a,X_b)\), the admissible cone near its inner endpoint and from a radius \(X_{\rm good}\) onward, and the prescribed heat exterior and total moments. These are imported from Lemmas 4.8--4.9 / Propositions A.4, A.7 and A.10, after the exact five-moment join of Proposition B.8. Their independent existence and parameter estimates are **not proved in Appendix C**, nor does this audit pretend that they are.
3. Four ordered disjoint reserved intervals, with the first three relevant roles fixed before \(N\): \(I_1\) is for the loop repair, \(I_2\) has already been used for heat compensation, and \(I_3,I_4\) are retained for later background and mean corrections. More exactly, with local logarithmic coordinate \(y\) on the intermediate power-law interval and \(T_w=60\log(1/\lambda)\), these are
\[
(T_w-25,T_w-20),\quad(T_w-20,T_w-15),
\quad(T_w-14,T_w-9),\quad(T_w-8,T_w-3).
\]
The selected \(\lambda>0\) puts them inside that interval. On \(I_1,I_3,I_4\),
\[
U_0=0,\qquad E_0=K(\eta)X^{-1/2-\lambda},
\qquad K(\eta)=c_{\rm patch}(1+\eta^2)^{-1}>0.
\]
The source gives \(X_R<X_{\rm good}<\inf I_1\) and \(\sup I_4<X_v<X_{\rm tail}<X_b\). The pulse follows the intermediate interval; its end is \(X_v=X_{\rm end}\), so this order agrees with Appendix C's notation.
4. The precise original endpoint stress factorizations: for \(y_a=\log(X/X_a)\),
\[
T_0=e^{-t_1^2/y_a^2}g_a(y_a)B_a(y_a,\eta),
\quad g_a(0)>0,\quad B_a(0,\eta)=F(X_a,\eta)s(X_a,\eta)\ne0,
\]
and, for \(y_b=\log(X_b/X)\),
\[
T_{0,\theta}=e^{-4/y_b^2}y_b^{-3}b_\theta(y_b,\eta),\qquad
T_{0,z}=e^{-4/y_b^2}y_b^3b_z(y_b,\eta),
\]
where the factors are smooth on closed collars and \(\inf b_\theta>0\). The inner endpoint has \(a>0\), \(v_s>2+c_{\rm ex}\); the outer endpoint has \(b_s=0\), \(a>2\). These are imported from (4.33)/(B.30)--(B.31) and (4.32)/(A.48)--(A.56). The equality \(B_a(0)=Fp_{s,r}\) in Appendix C is compatible with \(B_a(0)=Fs\) in Section 4 because the unchanged axis stress is zero there, hence \(p_{s,r}=s\).

These imports are sufficient for selecting
\[
X_a<X_{\rm an}<X_-<X_+<Y_0<Y_1,
\quad I=[X_-,X_+]\Subset(X_a,\inf I_1),
\quad [Y_0,Y_1]\subset I_1,
\]
where \(I\) contains every possible failure of admissibility, its endpoints lie within admissible regions, and \(X_{\rm good}<X_+\). Shrinking the original analytic-collar endpoint to the displayed \(X_{\rm an}\) does not change the profiles. The local argument uses compact sets \(I\times[-1,1]\) and \(J\times[-1,1]\), \(J=[X_-,Y_1]\), which stay a positive distance from \(X=0\).

The remainder of this note verifies the loop, insertion, restoration, and preservation deductions for these exact input data. It does not promote the imported A/B profile construction to an independently proved global existence result.

## 2. The scalar cone and the loop

The exact shear and integrated vector are
\[
s=(a,-b_s),\quad a=1-2D_X\log E,\quad b_s=2D_XU/E,
\quad p_s=(XQ_s/L,XN_s/(LE)).
\]
For \(a>0\), set
\[
t_s=-b_s/a,\quad v_s=a(1+t_s^2),\quad
P_c(t)=p_{s,1}+p_{s,2}t,\quad J_c(t)=p_{s,2}-p_{s,1}t.
\]
The upper root used by the source is
\[
\mathcal U(P,J)=P+\frac{J^2}{4}
-|J|\sqrt{\frac{P-2}{2}+\frac{J^2}{16}}.
\]
This symbol \(\mathcal U\) names exactly the scalar function written \(U(P_c,J_c)\) in the source, without changing the axial profile \(U\). The relaxed inequalities are \(P_c(t_s)>2\) and \(v_s<\mathcal U(P_c(t_s),J_c(t_s))\); admissibility adds \(v_s>2\).

To verify the root facts, let \(w=P-2>0\). Then
\[
\left(w+J^2/4\right)^2
-J^2\left(w/2+J^2/16\right)=w^2>0.
\]
Both sides being compared before squaring are nonnegative, and \(w+J^2/4>0\). Thus \(\mathcal U>2\). Also
\(|J|\sqrt{(P-2)/2+J^2/16}\ge J^2/4\), giving \(\mathcal U\le P\). Expanding
\[
2(P-v)^2-(v-2)J^2
=2v^2-(4P+J^2)v+2P^2+2J^2
\]
shows its roots are \(\mathcal U\) and the same expression with the plus square root. If \(v>2\), positivity of this polynomial and \(P-v>0\) put \(v\) strictly below the smaller root: the alternative above the larger root would violate \(v<P\). For \(J=0\), the double root is \(P\) and the same conclusion follows from \(v<P\). Conversely, \(2<v<\mathcal U\) makes both expressions positive. The four smooth gaps are consequently
\[
\Psi(a,b,p)=\left(a,\ v-2,\ c-v,\ 2(c-v)^2-(v-2)j^2\right),
\quad v=a+b^2/a,\ c=p_1-bp_2/a,\ j=p_2+bp_1/a.
\]
Only the continuous scalar root is used to select values; no derivative of \(|J|\) at \(J=0\) is taken.

Choose \(0<d_0<\frac12\min_{I\times[-1,1]}(P_c(t_s)-2)\). Put
\[
M_e(z)=\frac1{2\pi}\int_0^{2\pi}e^{z\sin\theta'}\,d\theta',
\quad p=p_{s,2},
\quad t(\theta';\mu)=t_s+\frac{d_0}{p}
\left(\frac{e^{\mu p\sin\theta'}}{M_e(\mu p)}-1\right).
\]
The original variables, signs, and \(2\pi\)-average are retained. For any smooth numerator \(G(p)\) with \(G(0)=0\),
\(G(p)/p=\int_0^1G'(up)\,du\). Since \(M_e>0\), this identity proves the displayed quotient is jointly smooth through \(p=0\). As \(M_e(0)=1\) and \(M'_e(0)=0\), the value there is \(t_s+d_0\mu\sin\theta'\). Direct integration gives
\[
\langle t\rangle=t_s,
\qquad P_c(t)=P_c(t_s)+d_0\left(e^{\mu p\sin\theta'}/M_e(\mu p)-1\right)
\ge P_c(t_s)-d_0>2.
\]
The variance is
\[
V(\mu,p)=\langle(t-t_s)^2\rangle
=\frac{d_0^2}{p^2}\left(\frac{M_e(2\mu p)}{M_e(\mu p)^2}-1\right),
\qquad V(\mu,0)=d_0^2\mu^2/2.
\]
It is jointly smooth by the already proved quotient formula and integration.

For \(g=\log M_e\), differentiating under the integral yields the variance of \(\sin\theta'\) with respect to the everywhere positive probability density \(e^{z\sin\theta'}/(2\pi M_e(z))\), so \(g''(z)>0\). Consequently, when \(p\ne0\) and \(\mu>0\),
\[
\partial_\mu\{g(2\mu p)-2g(\mu p)\}
=2p\{g'(2\mu p)-g'(\mu p)\}>0.
\]
For \(p>0\) the two factors are positive; for \(p<0\) both are negative. This proves \(\partial_\mu V>0\), including \(p=0\) by its explicit formula.

Here is the growth calculation needed for finite uniform variance. Near a maximum, write \(\theta'=\pi/2+x\) and choose \(a_0\in(0,\pi)\). On \(|x|\le a_0\), constants \(c_1,c_2>0\) satisfy
\(1-c_2x^2\le\cos x\le1-c_1x^2\). For \(z\ge1\), integration on \(|x|\le\min(a_0,1)z^{-1/2}\) bounds \(M_e(z)\) below by \(c e^zz^{-1/2}\). The Gaussian upper bound on \(|x|\le a_0\), together with the bound \(\sin\theta'\le1-c_{a_0}\) on its complement, bounds it above by \(Ce^zz^{-1/2}\). Shifting the circle by \(\pi\) gives \(M_e(-z)=M_e(z)\). Hence
\[
c e^{|z|}|z|^{-1/2}\le M_e(z)\le Ce^{|z|}|z|^{-1/2}\quad(|z|\ge1).
\]
It follows that \(M_e(2z)/M_e(z)^2\) lies between positive constant multiples of \(\sqrt{|z|}\). Thus \(V(\mu,p)\to\infty\) for every fixed \(p\), including zero. Let \(a_{\min}>0\) be the compact minimum of the original \(a\). For each \(p_0\) in the compact range of \(p_{s,2}\), choose \(\mu_{p_0}\) giving \(V(\mu_{p_0},p_0)>3/a_{\min}\); continuity gives a neighborhood where that same strict bound holds. A finite subcover and monotonicity give a single finite \(\mu_{\max}\) with the bound everywhere. There is no division estimate that deteriorates at \(p=0\) in this compactness argument.

Only after \(\mu_{\max}\) is fixed, choose \(0<\delta_L<1\) with
\[
\mathcal U(P_c(t),J_c(t))>2+\delta_L
\quad(0\le\mu\le\mu_{\max})
\]
on the whole compact family. This follows from continuity and the strict root bound. Shrink \(\delta_L\) below the compact minimum of \(v_s-2\) on smaller radial endpoint collars. Let \(0\le\zeta_L\le1\) be a smooth cutoff of \(v_s\), equal to one for \(v_s\le2+\delta_L/8\) and zero for \(v_s\ge2+\delta_L/4\), and set
\[
v_*=2+\delta_L/2,\quad
\rho=\zeta_L(v_s)^2(v_*-v_s),\quad v=v_s+\rho.
\]
The formula for \(\rho\) is zero off the cutoff's support. Where the cutoff can be nonzero, \(v_*-v_s\ge\delta_L/4\), so its square root is the smooth function \(\zeta_L(v_s)\sqrt{v_*-v_s}\), extended by zero. Since \(v_s>0\), \(0\le\rho<v_*<3\). The equation
\[
V(\mu,p)=\rho/a,\qquad 0\le\mu<\mu_{\max}
\]
has a unique solution. Its smoothness at zero follows more precisely from the convergent integral expansion
\(M_e(z)=1+z^2/4+O(z^4)\), which gives
\[
V(\mu,p)=\mu^2\bigl(d_0^2/2+O(\mu^2p^2)\bigr).
\]
The smooth even coefficient in parentheses is positive near \(\mu=0\), uniformly for bounded \(p\). Thus the signed square root is a smooth odd function \(\mu\sqrt{d_0^2/2+O(\mu^2p^2)}\) with derivative \(d_0/\sqrt2>0\). An exact factorization, which also removes any reliance on the asymptotic notation for smoothness, is
\[
R_e(z)=\frac{M_e(2z)}{M_e(z)^2},\qquad
H_e(z)=\frac{R_e(z)-1}{z^2}\ (z\ne0),\qquad H_e(0)=\tfrac12.
\]
The finite integral power series shows that \(M_e\) is even and real analytic, and its positive values make \(R_e\) real analytic. Its expansion \(R_e(z)=1+z^2/2+O(z^4)\) proves that \(H_e\) is even and real analytic through zero. For \(z\ne0\),
\[
M_e(2z)-M_e(z)^2=\operatorname{Var}_{\theta'}(e^{z\sin\theta'})>0,
\]
because the continuous integrand is not constant and the uniform measure has positive density. Thus \(H_e(z)>0\) on the entire real line. Exactly,
\[
V(\mu,p)=d_0^2\mu^2H_e(\mu p),\qquad
F_e(\mu,p)=d_0\mu\sqrt{H_e(\mu p)}.
\]
The function \(F_e\) is a globally smooth signed square root, with \(\partial_\mu F_e(0,p)=d_0/\sqrt2\). For \(\mu>0\), its derivative is positive because \(F_e>0\) and \(\partial_\mu V=2F_e\partial_\mu F_e>0\). The implicit function theorem applies to \(F_e(\mu,p)=\sqrt\rho/\sqrt a\), including where both \(p\) and \(\rho\) vanish. Uniqueness identifies the local branches. Smoothness on the closed \(\eta\)-interval includes the specified one-sided derivatives.

The cutoff cases give \(v=v_*>2\) below the first threshold, \(2<v_s\le v\le v_*\) between thresholds, and \(v=v_s>2\) above the last threshold. On the nonzero-cutoff set, \(v\le v_*<2+\delta_L<\mathcal U\). Where the cutoff is zero, \(\mu=0\), \(t=t_s\), and the original relaxed upper bound applies. Every proposed shear is therefore admissible.

Finally set \(\phi(0)=0\) and
\[
\frac{d\phi}{d\theta'}=\frac{a(1+t^2)}{2\pi v},
\qquad (a_L,-b_L)=\frac{v(1,t)}{1+t^2}.
\]
The variance equation gives \(a\langle1+t^2\rangle=v_s+aV=v\), so \(\phi(\theta'+2\pi)=\phi(\theta')+1\). The derivative has a positive compact minimum, giving a smoothly parameter-dependent orientation-preserving circle diffeomorphism. Changing variables proves both components exactly:
\[
\int_0^1a_L\,d\phi=a,
\qquad \int_0^1(-b_L)\,d\phi=a\langle t\rangle=at_s=-b_s.
\]
Also \(-b_L/a_L=t\) and \(a_L(1+t^2)=v\). The four gaps are positive continuous functions on \(I\times[-1,1]\times\mathbb R/\mathbb Z\); their common minimum \(\mu_L\) is positive. The cutoff vanishes on the endpoint collars, so the loop there is exactly \((a,-b_s)\). This verifies the full C.1 operation used by Lemma 4.11.

## 3. Exact modulation and all five prefix errors

Let \(\mathcal A,\mathcal B\) be the unique zero-mean periodic primitives
\[
\partial_\phi\mathcal A=-\tfrac12(a_L-a_0),
\qquad \partial_\phi\mathcal B=\tfrac12E_0(b_L-b_0).
\]
For a zero-mean periodic function \(g\), the explicit primitive
\[
\mathcal I g(\phi)=\int_0^\phi g(w)\,dw
-\int_0^1\int_0^s g(w)\,dw\,ds
\]
is periodic, smooth, zero mean, and has derivative \(g\). The previously proved two mean identities apply, since \(E_0\) is independent of \(\phi\). When the loop equals the original shear the integrands are identically zero, so both primitives are identically zero there. They extend smoothly by zero off \(I\).

For integer \(N\ge1\), the exact source insertion is
\[
E_N=E_0\exp\bigl(\mathcal A(X,\eta,N\log X)/N\bigr),
\qquad U_N=U_0+\mathcal B(X,\eta,N\log X)/N.
\]
All expressions below are evaluated at \(\phi=N\log X\); \(D_X\) acting on primitives holds \(\phi\) fixed. The chain rule becomes \(D_X+N\partial_\phi\), and yields
\[
a_N=a_L-2D_X\mathcal A/N,
\qquad
b_N=e^{-\mathcal A/N}\left(b_L+2D_X\mathcal B/(NE_0)\right).
\]
The exponential in the axial denominator is essential and is present in both C.13 and Section 4 Step 2. Positivity of \(E_N\) is exact.

The phase is independent of \(\eta\). The primitives, every fixed mixed derivative, and \(E_0^{-1}\) are bounded on the fixed compact periodic domain. The identity
\[
e^{\mathcal A/N}-1=\frac{\mathcal A}{N}\int_0^1e^{s\mathcal A/N}\,ds
\]
and its \(\eta\)-derivatives prove for every fixed \(k\)
\[
\|U_N-U_0,E_N-E_0\|_k\le A_k/N,
\quad \|a_N-a_L,b_N-b_L\|_k\le B_k/N,
\]
where \(\|\cdot\|_k\) is the componentwise maximum of \(\eta\)-derivatives of orders \(0,\ldots,k\), uniformly in the stated compact radial interval. The shear estimate is on \(I\); shears are unchanged on \(J\setminus I\). A radial derivative can differentiate the phase, and \(r\ge1\) radial derivatives of the profile differences have bound \(C_{r,k}N^{r-1}\). No smallness in radial derivatives is claimed for this modulation.

Retain the full five moments in their original order:
\[
m=(M,I,J,S,C_p),\quad
M=\int_0^XU\,dx,\quad I=\int_0^X\sqrt{2x}E\,dx,\quad
J=\int_0^XU\sqrt{2x}E\,dx,
\]
\[
S=\int_0^X(U^2-E^2/2)\,dx,
\qquad C_p=\int_0^X E^2/(2x)\,dx,
\qquad \Pi=\Pi_0+C_p.
\]
With \(u_N=U_N-U_0\), \(e_N=E_N-E_0\), \(H_0=\sqrt{2X}E_0\), the exact increment integrands are
\[
\Delta m_N(X)=\int_{X_-}^{X}
\begin{pmatrix}
u_N\\
\sqrt{2x}e_N\\
H_0u_N+U_0\sqrt{2x}e_N+\sqrt{2x}u_Ne_N\\
2U_0u_N+u_N^2-E_0e_N-e_N^2/2\\
E_0e_N/x+e_N^2/(2x)
\end{pmatrix}\,dx.
\]
All scalar weights are bounded on \(J\), and every term contains at least one profile difference. The product rule and fixed integration length prove \(\|\Delta m_N\|_k\le D_k/N\). The unchanged pressure datum gives exactly \(\Delta\Pi_N=\Delta C_{p,N}\), with the same bound.

For completeness, the coefficient map being estimated is
\[
W=1-\frac{2D\eta M+dM_\eta}{X},
\]
\[
Q_s=-W+\frac{(1-h)I-D\eta I_\eta-dJ_\eta+2(h-D)\eta J}{XH},
\]
\[
N_s=-WU+\frac{D(M-\eta M_\eta)+4h\eta S-dS_\eta}{X}
+4A\eta\Pi-d\Pi_\eta,
\quad H=\sqrt{2X}E,
\quad p_s=(XQ_s/L,XN_s/(LE)).
\]
These are the original (4.16) formulas with zero regular-axis integration constants \(C_Q,C_N\). Once \(N\) is large enough that \(E_N\ge\frac12\min_J E_0>0\), every denominator stays bounded away from zero. Difference formulas such as
\[
H_N^{-1}-H_0^{-1}=-(H_N-H_0)/(H_NH_0),
\qquad E_N^{-1}-E_0^{-1}=-(E_N-E_0)/(E_NE_0)
\]
show, after the product rule, that a difference of coefficient derivatives through order \(k\) contains a profile or moment difference through order at most \(k+1\). Thus
\[
\|p_N-p_0\|_k\le C_k(A_{k+1}+D_{k+1})/N=:P_k/N.
\]
No radial derivative of a difference appears in this estimate. Holding \(C_Q=C_N=0\) is legitimate because both modifications are away from the unchanged regular axis; no new singular integration constant is introduced.

Let \(\mu_R=\min_{[X_+,Y_1]\times[-1,1]}\min_i\Psi_i(a_0,b_0,p_0)>0\). Choose a compact box containing the unperturbed triples from the loop and this interval, with its entire \(a\)-range bounded below by a positive number; enlarge its other coordinate ranges a little. The smooth map \(\Psi\) has a finite derivative bound there and hence a Lipschitz constant \(C_\Psi\). After putting the perturbed triples inside that box,
\[
\Psi_i(a_N,b_N,p_N)\ge\mu_L-C_\Psi(B_0+P_0)/N
\ge\mu_L/2\quad\text{on }I,
\]
\[
\Psi_i(a_N,b_N,p_N)\ge\mu_R-C_\Psi P_0/N
\ge\mu_R/2\quad\text{on }[X_+,Y_1].
\]
This gives the pre-repair admissible margins (4.41).

## 4. All five exact repair components and invertibility

On \((Y_0,Y_1)\), modulation is identically zero and the original profile is exactly \(U_0=0\), \(E_0=K(\eta)X^{-1/2-\lambda}\). Choose nonnegative nonzero smooth bumps \(\beta_1,\beta_2\) with ordered disjoint compact supports, and separately choose \(\gamma_1,\gamma_2,\gamma_3\) with ordered disjoint compact supports, all inside this interval. Supports need only be disjoint **within** each block; overlap between a \(\beta\) and a \(\gamma\) is permitted and is included in the quadratic \(J\)-term. Define
\[
u_c=\alpha_1(\eta)\beta_1(X)+\alpha_2(\eta)\beta_2(X),
\quad e_c=\sum_{j=1}^3\xi_j(\eta)\gamma_j(X),
\quad c=(\alpha_1,\alpha_2,\xi_1,\xi_2,\xi_3).
\]
The map \(\mathcal R_\eta:\mathbb R^5\to\mathbb R^5\) has row order \((M,J,I,S,C_p)\), and its exact five components at \(Y_1\) are
\[
\mathcal R_M(c)=\int_{Y_0}^{Y_1}u_c\,dX,
\]
\[
\mathcal R_J(c)=\int_{Y_0}^{Y_1}\bigl(H_0u_c+\sqrt{2X}u_ce_c\bigr)\,dX,
\]
\[
\mathcal R_I(c)=\int_{Y_0}^{Y_1}\sqrt{2X}e_c\,dX,
\]
\[
\mathcal R_S(c)=\int_{Y_0}^{Y_1}\bigl(u_c^2-E_0e_c-e_c^2/2\bigr)\,dX,
\]
\[
\mathcal R_{C_p}(c)=\int_{Y_0}^{Y_1}\bigl(E_0e_c/X+e_c^2/(2X)\bigr)\,dX.
\]
In particular the negative \(E_0e_c\) and \(-e_c^2/2\) signs in \(S\), the positive \(u_c^2\), and both pressure factors are retained. Expanding the original five integrands proves these formulas term by term. Thus \(\mathcal R_\eta(c)=B(\eta)c+Q_\eta(c,c)\), with \(Q_\eta\) a smooth bilinear map (or its symmetric polarization).

The exact derivative \(B=D_c\mathcal R_\eta(0)\) is block diagonal in the specified row and column order:
\[
B_U=\begin{pmatrix}
\int\beta_1&\int\beta_2\\
\int H_0\beta_1&\int H_0\beta_2
\end{pmatrix},
\qquad
B_E=\begin{pmatrix}
\int\sqrt{2X}\gamma_1&\int\sqrt{2X}\gamma_2&\int\sqrt{2X}\gamma_3\\
-\int E_0\gamma_1&-\int E_0\gamma_2&-\int E_0\gamma_3\\
\int E_0\gamma_1/X&\int E_0\gamma_2/X&\int E_0\gamma_3/X
\end{pmatrix}.
\]
All integrals here are over \((Y_0,Y_1)\). The cross blocks vanish because the base \(U_0=0\). Since \(H_0=\sqrt2K X^{-\lambda}\), the first block consists of powers \((0,-\lambda)\), with nonzero row factors \((1,\sqrt2K)\). The second has powers \((1/2,-1/2-\lambda,-3/2-\lambda)\), with row factors \((\sqrt2,-K,K)\). These lists consist of distinct powers for the fixed \(\lambda>0\).

Here is a full rank argument for these integral matrices. A nonzero combination of \(m\) distinct real powers has at most \(m-1\) distinct positive zeros. Order the exponents, divide by the least power, and assume \(m\) zeros. Rolle's theorem gives \(m-1\) zeros of the derivative. The constant term is removed and the remaining nonzero derivative is a combination of at most \(m-1\) distinct powers, contradicting induction; if all nonconstant coefficients vanish, the original nonzero constant has no zero. This proves the claim starting from \(m=1\). Therefore the determinant \(\det[x_j^{\alpha_i}]\) is never zero when \(0<x_1<\cdots<x_m\). Its continuous sign is constant on this connected ordered domain. By multilinearity and Fubini,
\[
\det\left[\int x^{\alpha_i}\beta_j(x)\,dx\right]
=\int\det[x_j^{\alpha_i}]\prod_{j=1}^m\beta_j(x_j)\,dx_1\cdots dx_m.
\]
The integrand has a constant strict sign wherever the product is positive, a set of positive measure because each smooth nonnegative bump is nonzero. The integral is therefore nonzero. This applies to both blocks. Their nonzero row factors prove \(B(\eta)\) invertible for every \(\eta\). Its entries are smooth on the closed compact interval, its determinant is never zero, and the adjugate formula proves that \(B^{-1}\) and every fixed \(\eta\)-derivative have finite bounds. The bound can depend on the selected \(\lambda\), scales, and bumps; it is not uniform as \(\lambda\to0\), where the two \(U\)-weights would coalesce.

Let \(d_N(\eta)=-\Delta m_N(Y_1,\eta)\), reordered as \((M,J,I,S,C_p)\). Then \(\|d_N\|_{C^k}\le D_k/N\), and exact repair is the equation
\[
B(\eta)c(\eta)+Q_\eta(c(\eta),c(\eta))=d_N(\eta).
\]
For \(j=0,2\), let \(\nu_j\) be the norm of multiplication by \(B^{-1}\) on \(C^j([-1,1];\mathbb R^5)\), and \(q_j\) the bilinear norm of \(Q\) there. The product rule makes these finite; no assertion that the unweighted max derivative norm has algebra constant one is needed. If
\[
8\nu_j^2q_j\|d_N\|_{C^j}\le1,
\qquad r_j=2\nu_j\|d_N\|_{C^j},
\]
then \(\mathcal T(c)=B^{-1}(d_N-Q(c,c))\) satisfies, on the closed radius-\(r_j\) ball,
\[
\|\mathcal T(c)\|_{C^j}\le r_j/2+\nu_jq_jr_j^2\le r_j,
\quad
\|\mathcal T(c)-\mathcal T(\bar c)\|_{C^j}
\le2\nu_jq_jr_j\|c-\bar c\|_{C^j}\le\tfrac12\|c-\bar c\|_{C^j}.
\]
The complete Banach spaces therefore give contractions in \(C^0\) and \(C^2\). Iteration from zero is the same sequence in both spaces; its \(C^2\) convergence implies its \(C^0\) convergence, so it selects the same solution with \(\|c\|_{C^2}\le2\nu_2D_2/N\). The pointwise derivative in \(c\) is
\(B+Q(c,\cdot)+Q(\cdot,c)\). Multiplication by \(B^{-1}\) leaves a perturbation of the identity of operator norm at most \(1/2\), so this derivative is invertible. The pointwise implicit function theorem yields a smooth branch, including one-sided parameter derivatives at the boundary, agreeing with the unique \(C^0\) small solution.

For every further fixed derivative order \(k\), differentiate the exact equation \(k\) times. The sole terms involving \(c^{(k)}\) have the same invertible coefficient just displayed. All remaining terms contain either \(d_N^{(k)}=O_k(N^{-1})\) or a lower derivative of \(c\), times finitely bounded fixed-data factors and lower derivatives. Induction proves \(c^{(k)}=O_k(N^{-1})\). This proves the all-fixed-order statement without imposing infinitely many simultaneous smallness conditions on \(N\).

## 5. Repair margins, exact exterior morphism, and finite parameter order

Because all bump shapes and supports were fixed before \(N\), their radial derivatives are fixed bounded functions. The \(C^2\) coefficient estimate gives
\[
\max_{r\le1}\|\partial_X^r(u_c,e_c)\|_2\le C/N.
\]
For \(U_f=U_N+u_c\), \(E_f=E_N+e_c\), this proves positivity \(E_f\ge\frac12\min E_0\) on the repair interval once \(N\) is large. Prefix integrals of the five exact repair components retain their \(C^2_\eta\) bound \(C/N\) when their upper endpoint is any \(X\in[Y_0,Y_1]\). The explicit shear formulas and the coefficient map of Section 3 then give
\[
\|a_f-a_N,b_f-b_N,p_f-p_N\|_0\le C_{\rm rep}/N.
\]
The final triples remain in the fixed compact \(a>0\) box for large \(N\). For
\(N\ge4C_\Psi C_{\rm rep}/\mu_R\),
\[
\Psi_i(a_f,b_f,p_f)\ge\mu_R/2-C_\Psi C_{\rm rep}/N
\ge\mu_R/4>0.
\]
Earlier points are unaffected by the repair, since their moment integrals end before its support.

At \(X=Y_1=X_{\rm rep}\), the nonlinear equation proves exact equality \(m_f(Y_1,\eta)=m_0(Y_1,\eta)\). The profiles agree exactly for every \(X\ge Y_1\), because all changes have compact support below it. For each of the five differences,
\[
\Delta m(X,\eta)=\Delta m(Y_1,\eta)
+\int_{Y_1}^X\bigl(\text{final integrand}-\text{original integrand}\bigr)(x,\eta)\,dx=0.
\]
Thus equality holds as smooth functions of \(\eta\), with every fixed parameter derivative equal. The fifth identity and the common axis datum prove \(\Pi_f=\Pi_0+C_{p,f}=\Pi_0+C_{p,0}=\Pi_{\rm original}\). Equality of \(M,U\) gives exact equality of
\[
V_0=\frac{2\eta XU-2D\eta M-dM_\eta}{L}.
\]
Equality of the remaining moments and profiles gives equal \(Q_s,N_s,p_s\) by their exact formulas. Equality of profiles on the full exterior interval gives equal radial derivatives, hence equal \(a,b_s,F\), and therefore equal stress
\[
T_0=F\bigl(p_s-(a,-b_s)\bigr).
\]
This is the exact map from the five-component endpoint data and common pressure constant to the exterior pressure, radial velocity, and stress. It preserves the already completed heat compensation on \(I_2\), both unused patches \(I_3,I_4\), the outer collar, and the full tail. The left collar and analytic axis rectangle remain identical because the modifications occur later and pressure/moments use the same forward axis data. This argument establishes exact exterior equality; smallness alone would not establish it.

The explicit finite frequency restrictions in Section 4 include
\[
N\ge8\max_{k=0,2}\nu_k^2q_kD_k,
\quad N\ge2C_\Psi(B_0+P_0)/\mu_L,
\quad N\ge2C_\Psi P_0/\mu_R,
\quad N\ge4C_\Psi C_{\rm rep}/\mu_R,
\]
together with finitely many bounds putting profiles and triples inside the chosen positive neighborhoods. All constants are determined after fixing the input profiles, \(\lambda\), radial scales, widths, the loop, and the repair bumps. One finite integer exceeding this finite list exists. In particular \(N\) is chosen after the final width \(\omega_{\rm fin}\), as specified by \(N^{-1}\ll\omega_{\rm fin}\); it is not needed to determine an earlier width. Although higher radial derivative constants can grow as powers of this \(N\), it is thereafter fixed. Physical \(q\), dyadic bands, and subsequent correction stages enter later. This local frequency choice creates no cyclic dependency and requires no uniform inverse as \(\lambda\to0\).

## 6. What the endpoint assembly actually proves

In the open shell, admissibility gives
\[
T_{0,\theta}+t_sT_{0,z}=F(P_c-v_s)>0,
\]
so \(T_0\ne0\). The exact preserved collars and exterior give the original zero stress for \(X\le X_a\) and \(X\ge X_b\). The preserved factors yield
\[
n=\frac{B_a}{|B_a|}\quad\text{near }X_a,
\qquad
n=\frac{(b_\theta,y_b^6b_z)}{\sqrt{b_\theta^2+y_b^{12}b_z^2}}
\quad\text{near }X_b.
\]
By shrinking collars, the denominators stay positive, so these are smooth through their closed radial endpoints. At the inner edge, \(n=(1,t_s)/\sqrt{1+t_s^2}\); at the outer edge, \(n=(1,0)\) and \(t_s=0\). Define
\[
A_n=n_\theta+t_sn_z,\quad B_n=n_z-t_sn_\theta.
\]
In the interior the stress identity gives
\[
A_n=\frac{P_c-v_s}{|p_s-(a,-b_s)|}>0,
\qquad B_n=\frac{J_c}{|p_s-(a,-b_s)|}.
\]
At the endpoints, \(B_n=0\), while \(A_n=\sqrt{1+t_s^2}\) at \(X_a\) and \(A_n=1\) at \(X_b\). The smooth quotient
\[
G_n=2-(v_s-2)B_n^2/A_n^2
\]
is positive in the interior by the last cone gap, and equals two at either edge. Therefore
\[
\kappa=\min\{1,\min A_n,\min G_n\}>0
\]
on the closed annulus, with \(\kappa<2\), gives both directional inequalities in Theorem 4.6(iii). The endpoint lower bounds imported for \(F,a,v_s-2\), together with their interior positivity and continuity, give their positive minima on the same compact rectangle. Positivity on the open interval alone would not suffice; the endpoint estimates are a real imported ingredient.

Set
\[
\zeta(X)=\exp(-t_1^2/y_a^2-4/y_b^2),
\quad \delta=\min\{1,y_a,y_b\}
\]
inside the shell and \(\zeta=0\) elsewhere. On an inner collar, the ratio \(\zeta/e^{-t_1^2/y_a^2}\) is smooth and bounded above and below by positive constants. On an outer collar the ratio \(\zeta/e^{-4/y_b^2}\) has the same property. The smooth nonzero inner factors and positive outer factor \(b_\theta\) then imply \(|T_0|\ge c\zeta\) on the collars; the factor \(y_b^{-3}\) is bounded below by a positive constant on a sufficiently short outer collar. Each mixed derivative differentiates smooth bounded factors and the exponentials, producing only finitely many inverse powers of \(y_a\) or \(y_b\). Thus \(|\partial^\alpha T_0|\le C_\alpha\zeta\delta^{-m_\alpha}\) there. On the intervening compact interval, \(T_0\) and \(\zeta\) have positive minima, their derivatives are bounded, and the same estimates follow by enlarging constants. The quantity \(y^{-m}e^{-c/y^2}\) tends to zero as \(y\downarrow0\) for every fixed \(m\), which follows by putting \(z=1/y\) and comparing \(m\log z\) with \(cz^2\). Therefore the derivatives have zero limits of every order, proving smooth flat extension at both edges. This proves the weight deductions from the exact imported factorizations.

The exterior moment and pressure conclusions are preserved exactly. In particular the common total pressure increment gives
\[
\Pi(X,\eta)=\Pi_0(\eta)+C_p(X,\eta)
=C_p(X,\eta)-C_p(\infty,\eta)
=-\int_X^\infty E(x,\eta)^2/(2x)\,dx.
\]
The original identities \(M(\infty)=J(\infty)=S(\infty)=0\) survive. The renormalized angular moment survives because
\[
\int_0^\infty(H_f-H_0)\,dX=I_f(Y_1)-I_0(Y_1)=0,
\]
and the exterior comparison \(H_{\rm pow}\) is unchanged. On \(X\ge X_v\), equality of the original \(U=M=0\) gives \(V_0=0\) by the explicit formula above. The heat factor and its physical evolution are inherited pointwise from the prepared exterior, not reproved by cone manipulation. The retained intervals are exactly \(I_{\rm pos}=I_3\) and \(I_{\rm mean}=I_4\) in their original order.

## 7. Audit findings and remaining provenance boundary

No algebraic or analytic defect was found in the C.1 loop, the exact C.12/C.13 insertion, the five-component nonlinear repair, the repair-patch margin argument, or their repetition in Section 4 Steps 2--3. The released note `04_admissible_cone.md` preserves the same objects and signs and contains the key full-rank and inverse-branch arguments. Section 4 spells out \(C^2_\eta\) as a sufficient finite repair tolerance and supplies an explicit finite \(N\) selection. The finite choice does not require smallness in every radial derivative or an estimate uniform in \(\lambda\).

The independent conclusion established here is the validity of these exact construction operations and preservation maps. The numerical and existential content of the joined A/B input, its canonical pressure, and its endpoint factors are imported at the specific locations listed in Section 1. Appendix C and the released loop note do not independently prove them; the parent profile-assembly audit is checking those source dependencies. C.3 is consequently an assembly of these imported facts with the locally proved maps. Describing C.3 as an independent proof of the missing A/B input would be unsupported. This is a provenance limitation, not a demonstrated failure of the loop or repair construction.

The original final derivative constants may depend on the selected finite frequency and all earlier profile parameters. That dependence is permitted by Theorem 4.6. The claim actually verified is independence from later physical \(q\), dyadic bands, and correction stages.

Work completed: source-to-note comparison; exact scalar root, variance, cutoff, and mean calculations; full insertion chain rule; all five moment increment and repair maps; integral-matrix rank; smooth small nonlinear solve; finite margin bounds; exterior pressure/velocity/stress morphism; collar direction and flat-weight deductions; reserved-patch ordering. No existing source file was edited.

The independent read-only scalar-loop reviewer also found no defect in source Lemma 4.11, lines 2276--2330, or C.1, lines 10001--10133. It supplied the exact \(H_e\) factorization incorporated above and confirmed that Lemma 4.11 invokes C.1 without a reverse dependency: C.1 uses the earlier cone and gap definitions, not Lemma 4.11. Its final report records visual inspection of the source pages 159--160 and the frozen PDF SHA-256 `8c8a94ad9ac824c8b605b9827cadf7beaca48bd10b380de3cfc872a2c37afa81`; this note's own substantive audit used the designated frozen text and the released reconstruction.
