# Exact leading-profile assembly review

The assembly of the particular leading profile asserted by Theorem 4.6 is proved in *profile_assembly.tex*. The conclusion uses the **chosen** \(h\) satisfying the outer construction's finite smallness conditions and
\[
0<h<\min\{1/100,\lambda,e^{-T_d}\}.
\]
It is an existence result for that construction. This review does not assert any later background, wave, residual iteration, localization, or full Navier--Stokes theorem.

## Actual closure and new calculations

1. **Outer schedule to axis pressure.** The complete scheduled swirl is \(c(y)f(\eta)^{\vartheta(y)}\), apart from an edit of exactly zero total pressure increment. The analytic function
   \[
   \Pi_0=-\frac12\int_{\mathbb R}c(y)^2f^{2\vartheta(y)}\,dy
   \]
   is defined before \(X_R\). On \(|\operatorname{Im}z|<1/4\), \(\operatorname{Re}(1+z^2)>15/16\), so the displayed logarithm and dominated holomorphic integral are explicit. The exact stronger derivative estimate is
   \[
   \eta\Pi_0'(\eta)\ge10P_*^2\eta^2(1+\eta^2)^{-3}>0 \quad(\eta\ne0).
   \]
   Both the pressure-neutral angular solve and the heat-plus-\(I_2\) compensation preserve this same function exactly. No pressure datum depends on the later \(C\) or \(X_R\).

2. **Concrete turning-point positivity.** At the unique root \(\eta_0=-s\) of \(H_*\), \(j_0/5<s<j_0/4\), \(s\le1/80\), \(d_0\ge6399/6400\), and \(U_*/j_0\le800/6399\). The only negative term of \(Z_*(\eta_0)\) is bounded in magnitude by
   \[
   A j_0\,5120000/40947201<A j_0/7.
   \]
   The already fixed outer pressure gives
   \[
   Z_*(\eta_0)>A j_0(P_*^2/2-1/7)>0.
   \]
   This directly closes the A-to-B positivity hypothesis without a new choice of \(P_*\) after \(j_0\).

3. **Finite acyclic order.** The written inequalities (3)--(13), (18), and (26) make the order explicit:
   \[
   M_d,T_d,P_*,\lambda,h
   \to\varepsilon_m,j_0
   \to\delta_*,\sigma_*,\Lambda
   \to(B_k),T_{\rm sh}
   \to C,X_R
   \to\kappa_0,t_1,\omega_{\rm fin}
   \to\hbox{loop and bumps}
   \to N.
   \]
   Here \(T_d=e^{M_d}+10\), \(P_*>e^{T_d}\), \(X_R=110(CP_*)^{10}\), \(X_a=4/\Lambda\), and \(X_h=X_Re^{-5}\). The matching tolerance is selected before \(X_R\), because the exact moment dilation cancels every \(X_R\) factor from \(Q_s,N_s\). The outer family is then selected at the same \(X_R\), subject to \(X_R\ge R_*\); it supplies no earlier inner construction input except the scale-independent \(\Pi_0\).

4. **Every row and exact exterior morphism.** The complete increment vector in order \((M,I,J,S,C_p)\) is
   \[
   \left(u,\sqrt{2X}e,\ Hu+U\sqrt{2X}e+\sqrt{2X}ue,\
   2Uu+u^2-Ee-e^2/2,\ Ee/X+e^2/(2X)\right).
   \]
   The inner-repair derivative blocks retain \((1,\sqrt2P_*fx^{3/5})\) and \((\sqrt2x^{1/2},-P_*fx^{1/10},P_*fx^{-9/10})\). The final-repair blocks retain \((1,\sqrt2KX^{-\lambda})\) and \((\sqrt{2X},-KX^{-1/2-\lambda},KX^{-3/2-\lambda})\). The full quadratic equations, not only their derivatives, are solved. Matching the five moments at the exact field-rejoining radius, with the same \(\Pi_0\), proves pointwise exterior equality of \(\Pi,V_0,W,Q_s,N_s,p_s,a,b_s,F,T_0\) and every fixed parameter derivative.

5. **Actual join to backward stress.** The regular joined field has the four convergent total moments and canonical pressure before any backward-stress conclusion is invoked. Equation (21) follows by integrating the exact leading residual: the angular subtraction has weight \(r^{1-2h}\) at zero and \(r^{-1-2h}\) at infinity; its time derivative is dominated. The axial pressure integral is exactly \(-\frac12\int ru_\theta^2\,dr\). Thus every hypothesis of the former Appendix A.8 import is established for the constructed object, and its positive-sign backward primitives and explicit endpoint coefficients follow.

6. **Exact scalar loop smoothness.** The complete Appendix C loop proof is embedded, including zero \(p_{s,2}\), variance monotonicity, finite uniform variance range, exact circle mean, and unchanged boundary collars. An additional exact factorization removes any smoothness inference based only on asymptotic notation:
   \[
   H_e(z)=\frac{M_e(2z)/M_e(z)^2-1}{z^2},\quad H_e(0)=1/2,\qquad
   V(\mu,p)=d_0^2\mu^2H_e(\mu p).
   \]
   Strict Cauchy--Schwarz gives \(H_e>0\) for every real \(z\). Hence \(d_0\mu\sqrt{H_e(\mu p)}\) is a smooth signed square root, with positive \(\mu\) derivative at zero and for \(\mu>0\). This proves the implicit inverse also where both pressure component and variance vanish.

7. **A single finite frequency.** The exact shears retain the factor \(e^{-\mathscr A/N}\) in the axial component. The first modulation changes fields and parameter derivatives by \(O(N^{-1})\), with no claim of small radial derivatives. Formula (26) selects one finite integer satisfying modulation and repair gap bounds, the \(j=0,2\) quadratic-contraction bounds, and swirl positivity. All unused \(I_3,I_4\), the heat compensation on \(I_2\), and both analytic/endpoint collars remain exact after the five-row repair on \(I_1\).

8. **All six profile conclusions.** The closed theorem proof derives axis smoothness/common parameter analyticity, canonical pressure and exact residual identities, nonzero interior and zero exterior stress, compact positive directional margins, the original two-edge exponential weight, all convergent total moments and exact heat exterior, and the two reserved patches. The endpoint factors retain \(e^{-t_1^2/y_a^2}\), \(e^{-4/y_b^2}y_b^{-3}\), and \(e^{-4/y_b^2}y_b^3\). Every fixed derivative is considered after \(N\), before any physical \(q\) or later dyadic/correction stage.

No algebraic contradiction or unclosed cross-component hypothesis was found in this bounded assembly.

## Files and integration

- *profile_assembly.tex*: standalone document, with all component calculations embedded and no external TeX inputs.
- *profile_assembly_body.tex*: integration-ready equivalent. It requires amsmath, amssymb, amsthm, mathtools, mathrsfs, and hyperref. Every label/reference is prefixed pa:; custom macros are paHeat, paResidual, paReal, and paSupport. It does not reset appendix numbering or create theorem environments in its host.
- *build_assembly.py*: deterministic assembly from immutable component sources and the new *assembly_main.tex*; only new files in this directory are written.
- *assembly_receipt.json*: exact frozen-source and component hashes, label inventory, and no-external-input receipt.
- *loop_check.md*: independent bounded subreview, including its exact imported-hypothesis inventory; those A/B inputs are discharged in the main assembly.
- *exact_assembly_checks.json*: 16/16 exact algebra, rational bound, reference, namespace, and source-integrity checks pass.

The final standalone build has 46 pages. The final compile has no unresolved references, duplicate labels, or overfull boxes. Displayed equation tags carry the PA. prefix (the references (3)--(26) above correspond to PA.3--PA.26 in the PDF). All 46 pages were inspected in six contact sheets; pages 3, 8, 40, and 44 were also inspected at full rendered size. No clipping, overlap, missing glyph, or broken formula was found. PDF visual QA is recorded in *visual_qa.json*.

The frozen integration body has SHA-256 32ed054afdb0aca39ad66aa03a30ef9a3d3e004b60d7d9ba1b972435703c3c28; the standalone TeX has SHA-256 ce9933963d4414fa2f00d7b756a0ea801c3c044d84095664b5cf752196d26668.

## Read and provenance boundary

The frozen 165-page source remains pinned to SHA-256 8c8a94ad9ac824c8b605b9827cadf7beaca48bd10b380de3cfc872a2c37afa81. Read the full independent core/axis/continuation and Appendix C bodies, the complete relevant Appendix A construction and endpoint body, frozen source Theorem 4.6 and its Section 4 construction/assembly, and the needed Appendix A/B source calculations. The independent loop reviewer read all Appendix C and its Section 4 insertion. Root independently reviewed the entire new main assembly proof and its finite inequalities.


