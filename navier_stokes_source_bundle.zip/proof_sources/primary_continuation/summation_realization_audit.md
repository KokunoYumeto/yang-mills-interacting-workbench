# Shrinking-cutoff summation and local realization: exact source audit

## Result and coverage

The shrinking-cutoff argument in Lemma 5.4 is valid under its stated hypotheses. The calculation below verifies its scale selection, every mixed derivative loss, local finiteness, preservation of divergence, the nonlinear differential-polynomial comparison, and its use of one fixed-stage flat remainder. No summability across stages of the flat remainders is required. The specialization to the physical Navier–Stokes residual gives the exact passage from the finite-stage bounds (9.17)–(9.18) to (9.20) and the representation (9.21).

This bounded audit found no concrete defect in that passage. It is not an independent construction of the preceding wave/mean increments, a proof of all earlier support and inverse estimates, a certification of every conclusion of Proposition 9.9, or a Lean/kernel acceptance result. In particular, validating the summation implication does not validate the input estimate (9.18) by itself.

The source is the current 166-page PDF:

`./downloaded_public_release/navier-stokes.pdf`

SHA256: `0e779481c4da40bd28d1e642e1d8ca57447d129610df28dfa5a11e9af8ae228f`.

Its preserved Poppler layout text is `downloaded_public_release/current_pdf_extracted.txt`, under the same programme root. The following physical pages and exact text-line ranges were read:

| Source | Physical pages | Layout-text lines | Coverage |
| --- | --- | --- | --- |
| (4.1), Lemma 4.1 and proof | 24–25 | 1251–1281 | Exact similarity map and derivatives used for (5.28). |
| (5.23), (5.27) | 55–56 | 2906–2910; 2981–3002 | Pointwise derivative seminorm, potential convention and tuple types. |
| Lemma 5.4, full hypotheses, statement and proof | 57–59 | 3005–3158 | Complete analytic summation argument, including (5.28)–(5.40). |
| (6.1)–(6.6), (6.11)–(6.12) | 62–64, 66 | 3295–3374; 3451–3463 | Physical graph derivative factors and pulse-coordinate derivatives. |
| (7.2)–(7.4) | 74–75 | 3899–3920 | Fixed label frequencies and exact phase used to check the derivative cost. |
| Definition 9.4 | 106 | 5535–5557 | Exact stage gains, residual orders and representation convention. |
| Lemma 9.7 and proof | 111–112 | 5804–5851 | Stated common-domain construction and finite derivative dependence. Earlier inverse proofs are not independently reconstructed here. |
| (9.15)–(9.19), Lemma 9.8 and proof | 112–114 | 5852–5937 | Physical increment tuples, derivative-loss arithmetic and finite-stage residual interface. |
| Proposition 9.9, statement and Steps 1–2 | 114–115 | 5938–5999 | Actual use of Lemma 5.4 and the full potential/direct-field/pressure assembly (9.21). |
| Proposition 9.9, Steps 3–5 | 115–116 | 6000–6055 | Read for the scope of its remaining endpoint/exterior/growth claims; these earlier dependent constructions are not certified by the summation calculation alone. |

Rendered pages 57, 58, 59, 63, 113, 114 and 115 were also inspected. This resolves two potentially misleading layout extractions: the source has

\[
d_r=2\big((1+h)\rho_g-h\kappa_s\big),\qquad
s_x=\frac12+\frac h2,\qquad s_t=1+\frac{3h}{2},
\]

with \(\kappa_s=10^{-5}\). The factor 2 in \(d_r\) multiplies both terms. No source equation is changed in this audit.

## 1. Original objects, types and derivative convention

Write \(x=(x_1,x_2,z)\), \(I=(\alpha_1,\alpha_2,\alpha_3,b)\in\mathbb N_0^4\),
\(D^I=\partial_{x_1}^{\alpha_1}\partial_{x_2}^{\alpha_2}\partial_z^{\alpha_3}\partial_t^b\), and \(|I|=|\alpha|+b\). The source seminorm (5.23) is the pointwise quantity

\[
|V|_m=\max_{|I|\le m}|D^IV|.
\]

The lemma's domain is \(\Omega\), with \(0<q(z,t)<q_0\le1\), \(q\) smooth and bounded below on compact subsets. Its exact derivative hypothesis is

\[
|\partial_z^a\partial_t^bq|\le C_{a,b}q^{1-aD-b},\qquad 0<D<1.
\tag{A1}
\]

The base is \(U_0=(u_0,p_0,T_0)\), with \(\operatorname{div}u_0=0\). The optional stress entries may be omitted. Each increment is represented by

\[
Z_j=(A_j,B_j,p_j,T_j),\qquad B_j=b_j(r,z,t)e_\theta,
\]
\[
U_j=(\operatorname{curl}A_j+B_j,p_j,T_j),\qquad
U^{[J]}=U_0+\sum_{j=1}^J U_j.
\tag{A2}
\]

These are actual physical fields on the same domain, with the Cartesian and zero-extension regularity specified before (5.30). The original bounds are

\[
|Z_j|_m\le C_{j,m}q^{g_j-\ell_m}\Lambda_{\log}(q)^{P_{j,m}},\qquad
\Lambda_{\log}(q)=1+|\log q|,
\tag{A3}
\]

where \(0<g_1\le g_2\le\cdots\to\infty\), and the nonnegative, nondecreasing \(\ell_m\) are independent of \(j\). Constants and logarithmic powers may depend on \(j\). No uniform bound for them in \(j\) is used below.

The realization map on one representative tuple is

\[
\mathcal C_a(A,B,p,T)
=\big(\operatorname{curl}(\chi(aq)A)+\chi(aq)B,
       \chi(aq)p,\chi(aq)T\big).
\tag{A4}
\]

It maps smooth potential/direct-azimuthal/scalar tuples to physical velocity/pressure/stress tuples on \(\Omega\). It is linear in the tuple. Its velocity is not defined by merely multiplying \(\operatorname{curl}A+B\) by \(\chi(aq)\); the exact extra term is retained in Section 3 below.

## 2. Exact similarity map proves the required mixed derivatives of q

For the application, the source fixes

\[
\tau=1-t,\quad A=\frac12+h,\quad D=\frac12-h,\quad
z=q^D\eta,\quad t=1-q(1-\eta^2),\quad
L=1-2h\eta^2,\quad d=1-\eta^2.
\tag{A5}
\]

The map \((q,\eta)\mapsto(z,t)\), from \((0,\infty)\times(-1,1)\) to \(\mathbb R\times(-\infty,1)\), has Jacobian

\[
\begin{pmatrix}
Dq^{D-1}\eta&q^D\\
-(1-\eta^2)&2q\eta
\end{pmatrix},\qquad
\det=q^D\big(2D\eta^2+1-\eta^2\big)=q^DL>0.
\tag{A6}
\]

For fixed \(z\) and \(\tau>0\), its inverse is the unique solution of
\(q-z^2q^{2h}=\tau\) with \(q>|z|^{1/D}\), and \(\eta=zq^{-D}\).
The left side is zero at the stated lower endpoint, tends to infinity, and has positive derivative \(1-2hz^2q^{2h-1}\ge1-2h\) there and thereafter. Thus existence and uniqueness follow without choosing a different branch. At \(z=0\), the inverse is \(q=\tau,\eta=0\).

Inverting (A6) gives exactly

\[
q_z=\frac{2\eta q^{1-D}}L,\quad q_t=-\frac1L,\quad
\eta_z=\frac{d}{q^DL},\quad \eta_t=\frac{D\eta}{qL}.
\tag{A7}
\]

For any real \(\beta\) and smooth \(F(\eta)\), the two derivative identities are

\[
\partial_z(q^\beta F)
=q^{\beta-D}\frac{2\beta\eta F+dF'}L,
\qquad
\partial_t(q^\beta F)
=q^{\beta-1}\frac{-\beta F+D\eta F'}L.
\tag{A8}
\]

Starting with \(F_{0,0}=1\), repeated application of these exact operators gives

\[
\partial_z^a\partial_t^bq=q^{1-aD-b}F_{a,b}(\eta).
\tag{A9}
\]

One concrete recursive construction is first to apply the time operator \(b\) times to \(q\), and then the axial operator \(a\) times, changing \(\beta\) by \(-1\) and \(-D\) respectively at each step. Commutation of the actual smooth derivatives identifies the same mixed derivative for any other order. Every resulting \(F_{a,b}\) is a finite expression obtained from polynomials and powers of \(L^{-1}\) by differentiation and multiplication. Since \(L\ge1-2h>0\) on \([-1,1]\), all these functions are smooth there and
\(C_{a,b}:=\max_{[-1,1]}|F_{a,b}|<\infty\). This proves (A1) with the original exponent \(1-aD-b\).

Also \(q=\tau+q\eta^2\ge\tau\). A compact subset of the open time domain \(t<1\) has a positive minimum of \(\tau\), so it has a positive lower bound for \(q\). The stronger one-sided bounds at \(\tau=0,q\ge c>0\) used later in Proposition 9.9 are separate statements about the actual input representatives, not consequences of this compact-subset observation.

## 3. Cutoff derivatives, all curl terms and an explicit fixed loss

A fixed smooth cutoff with the stated plateaux exists explicitly. Define
\(\eta_0(s)=0\) for \(s\le0\) and \(\eta_0(s)=e^{-1/s}\) for \(s>0\), and set

\[
\chi(s)=\frac{\eta_0(1-s)}{\eta_0(1-s)+\eta_0(s-1/2)}.
\tag{A10}
\]

The denominator is positive for every real \(s\). Each positive-side derivative of \(\eta_0\) is \(e^{-1/s}\) times a polynomial in \(s^{-1}\); the exponential series shows its limit is zero as \(s\downarrow0\). Hence \(\eta_0\), and then \(\chi\), are smooth. This cutoff equals one for \(s\le1/2\), is zero for \(s\ge1\), and lies between zero and one. Every positive-order derivative is supported in \([1/2,1]\).

For a positive-order mixed derivative \(\partial_z^{a'}\partial_t^{b'}\chi(aq)\), the repeated chain rule is a finite sum of terms

\[
c_{\mathcal P}\,a^k\chi^{(k)}(aq)
\prod_{\nu=1}^k\partial_z^{a_\nu}\partial_t^{b_\nu}q,
\quad a_\nu+b_\nu\ge1,
\quad\sum_\nu a_\nu=a',\quad\sum_\nu b_\nu=b',
\tag{A11}
\]

where \(c_{\mathcal P}\) is the finite integer multiplicity of the derivative partition. Applying (A1) bounds this term by

\[
|c_{\mathcal P}|\,\|\chi^{(k)}\|_\infty
\prod_{\nu=1}^k C_{a_\nu,b_\nu}\,
(aq)^kq^{-a'D-b'}.
\tag{A12}
\]

Its support has \(1/2\le aq\le1\); consequently \((aq)^k\le1\). Summing the finite list proves

\[
|\partial_z^{a'}\partial_t^{b'}\chi(aq)|
\le C^\chi_{a',b'}q^{-a'D-b'},
\tag{A13}
\]

with constants independent of the scale \(a\). Zeroth order uses \(|\chi|\le1\). Derivatives in \(x_1,x_2\) of the cutoff vanish because \(q=q(z,t)\). Thus there is no unrecorded factor of \(a\) left in the estimates.

Using the right-handed Cartesian curl and Levi-Civita symbol \(\epsilon_{ikl}\), the exact component expansion is

\[
\big(\operatorname{curl}(\chi(aq)A_j)\big)_i
=\sum_{k,l=1}^3\epsilon_{ikl}
\big(\chi(aq)\partial_k(A_j)_l
     +a\chi'(aq)(\partial_kq)(A_j)_l\big).
\tag{A14}
\]

Equivalently the additional velocity is \(a\chi'(aq)\nabla q\times A_j\), with its original sign. A derivative \(D^I\) of (A14) can instead be written directly as

\[
\sum_{k,l}\epsilon_{ikl}
\sum_{J\le I+e_k}\binom{I+e_k}{J}
 D^J\chi(aq)\,D^{I+e_k-J}(A_j)_l,
\tag{A15}
\]

where \(e_k\) is the spatial unit multi-index. Every nonzero cutoff derivative in this formula is purely in \((z,t)\). If it uses \(a'\) axial and \(b'\) time derivatives, while the derivative of the representative has total order \(d'\), then
\(d'+a'+b'\le m+1\) for \(|I|\le m\), and the total loss is \(\ell_{d'}+a'D+b'\). The pressure, direct-field and stress entries have total derivative order at most \(m\), so the same upper list also covers them.

A concrete common choice is therefore

\[
\ell'_m:=\max_{d',a',b'\in\mathbb N_0,\ d'+a'+b'\le m+1}
                 (\ell_{d'}+a'D+b').
\tag{A16}
\]

It is nonnegative, nondecreasing and independent of \(j\) and \(a\). In particular
\(\ell'_m\le\ell_{m+1}+m+1\), since \(0<D<1\).
The larger explicit choice \(\ell_{m+1}+m+1\) is also valid if desired; no exact identity with (A16) is claimed.

Applying the finite product-rule sums to the original bounds (A3), and retaining their constants and logarithmic powers in their finite maximum/sum, yields finite numbers \(\widehat C_{j,m}\), \(\widehat P_{j,m}\), independent of \(a\), such that

\[
|\mathcal C_a Z_j|_m
\le \widehat C_{j,m}q^{g_j-\ell'_m}
          \Lambda_{\log}(q)^{\widehat P_{j,m}}.
\tag{A17}
\]

This calculation includes mixed derivatives striking the potential, the cutoff, the extra curl term, and the direct/scalar fields. It does not estimate only the differentiated velocity before applying the cutoff.

## 4. Diagonal scales and exact tail estimate

For each \(j\), there are only \(j+1\) requirements in (5.37), one for every integer \(0\le m\le j\). Each has positive power \(g_j/2\):

\[
\widehat C_{j,m}\Lambda_{\log}(q)^{\widehat P_{j,m}}q^{g_j/2}\le2^{-j}
\quad(0<q\le a_j^{-1}).
\tag{A18}
\]

These inequalities can be imposed recursively together with \(a_j\ge2a_{j-1}\) and \(a_j^{-1}<q_0\). To make the selection explicit, take \(a_j\) to be the least positive integer satisfying these conditions and, for every \(m\le j\),

\[
1+\log a_j\ge\frac{2\max(\widehat P_{j,m},0)}{g_j},\qquad
\widehat C_{j,m}a_j^{-g_j/2}(1+\log a_j)^{\widehat P_{j,m}}\le2^{-j}.
\tag{A19}
\]

For \(j=1\), omit the preceding-scale condition and also require \(a_1>q_0^{-1}\). The defining set is nonempty. Indeed, for any fixed positive \(\varepsilon\) and finite real \(P\),
\(a^{-\varepsilon}(1+\log a)^P\to0\). One direct proof puts \(y=\log a\), chooses an integer \(n>\max(P,0)\), and uses
\(e^{\varepsilon y/2}\ge(\varepsilon y/2)^n/n!\) for \(y>0\); the remaining exponential and negative power tend to zero. Every condition is eventually true and the list at stage \(j\) is finite.

The endpoint test (A19) implies the full interval test (A18). For \(0<q<1\), direct differentiation gives

\[
\frac{q\,\frac{d}{dq}[q^{g_j/2}\Lambda_{\log}(q)^P]}
     {q^{g_j/2}\Lambda_{\log}(q)^P}
=\frac{g_j}{2}-\frac{P}{\Lambda_{\log}(q)}.
\tag{A20}
\]

This is nonnegative when \(\Lambda_{\log}(q)\ge2\max(P,0)/g_j\). Hence its maximum on \(0<q\le a_j^{-1}\) is attained at the upper endpoint once (A19) holds. All original logarithmic powers remain present in this check.

Combining (A17) and (A18) gives

\[
|\mathcal C_{a_j}Z_j|_m\le2^{-j}q^{g_j/2-\ell'_m}\qquad(m\le j).
\tag{A21}
\]

Outside the cutoff support, the summand and all its derivatives are zero, so this bound also applies there.
For a compact \(K\Subset\Omega\), let \(\delta_K=\min_Kq>0\). Since \(a_j\ge2^{j-1}a_1\), all summands with \(a_j>\delta_K^{-1}\) vanish on a neighborhood of \(K\). Thus the sum is locally finite; all differentiation on \(K\) is differentiation of a finite sum. No convergence assertion at \(q=0\) is needed to obtain smoothness on \(\Omega\).

If \(J\ge\max(1,m)\) and \(0<q<(2a_J)^{-1}\), then \(a_jq<1/2\) for every \(j\le J\). On a neighborhood of such a point those cutoffs are identically one, including all their derivatives. Therefore

\[
U-U^{[J]}=\sum_{j>J}\mathcal C_{a_j}Z_j.
\]

Because \(g_j\ge g_{J+1}\) for \(j>J\), \(0<q<1\), and \(\sum_{j>J}2^{-j}=2^{-J}\),

\[
|U-U^{[J]}|_m
\le\sum_{j>J}2^{-j}q^{g_j/2-\ell'_m}
\le2^{-J}q^{g_{J+1}/2-\ell'_m}.
\tag{A22}
\]

This is exactly the exponent and constant in (5.35). It compares with the uncut finite prefix, not with a differently cut finite prefix.

All added terms vanish on the common collar \(a_1^{-1}<q<q_0\), because every \(a_j\ge a_1\). They therefore extend smoothly by zero across \(q=q_0\). At a lateral support boundary with \(q>0\), local finiteness reduces smooth zero extension to the original finite list of smooth representatives.

## 5. Divergence and the coordinate-level representative map

For every smooth Cartesian vector field \(A\),

\[
\operatorname{div}(\operatorname{curl}A)
=\sum_{i,k,l}\epsilon_{ikl}\partial_i\partial_k A_l=0.
\tag{A23}
\]

The terms for \((i,k)\) and \((k,i)\) cancel because their signs are opposite and mixed derivatives commute. This applies to \(\chi(a_jq)A_j\) itself; it therefore includes every cutoff-curl contribution in (A14).

Away from the axis, the direct representative has Cartesian expression

\[
B_j=\left(-\frac{b_jx_2}{r},\frac{b_jx_1}{r},0\right),\quad
r=(x_1^2+x_2^2)^{1/2}.
\]

Its divergence is

\[
-x_2\frac{x_1}{r}\partial_r(b_j/r)
+x_1\frac{x_2}{r}\partial_r(b_j/r)=0.
\tag{A24}
\]

Moreover \(\nabla\chi(a_jq)=(0,0,a_j\chi'(a_jq)q_z)\), whose dot product with \(B_j\) is zero. Thus \(\operatorname{div}(\chi(a_jq)B_j)=0\). The smooth Cartesian extension makes the same identity hold at the axis by continuity. Adding the divergence-free base and using local finiteness proves \(\operatorname{div}u=0\).

For the mean-potential convention actually used in (9.15), the exact right-handed cylindrical map is

\[
\Psi_je_\theta\longmapsto
\operatorname{curl}(\Psi_je_\theta)
=(-\partial_z\Psi_j,0,(\partial_r+r^{-1})\Psi_j).
\tag{A25}
\]

Multiplying the potential by a function of \(q(z,t)\) gives the additional radial component \(-\partial_z\chi(a_jq)\Psi_j\), consistent with \(\nabla\chi\times\Psi_je_\theta\), since \(e_z\times e_\theta=-e_r\). The direct azimuthal term remains a different entry of the same realization map (A4), with its divergence calculation already proved.

## 6. Full differential-polynomial residual comparison

Retain the source polynomial, including its field-independent term:

\[
\mathcal F(U)^a=c_{a0}(x,t)
+\sum_{\nu=1}^{M_a}c_{a\nu}(x,t)
   \prod_{r=1}^{d_{a\nu}}D^{\beta_{a\nu r}}U^{k_{a\nu r}},
\]

with the fixed order/degree bounds \(|\beta_{a\nu r}|\le s\), \(1\le d_{a\nu}\le d\). The coefficient derivative bounds are exactly (5.32), on the fixed support regions specified there. No coefficient, support region, order or degree is allowed to depend on the truncation index.

For \(V=U^{[J]}\), \(e=U-V\), and one monomial, let
\(a_r=D^{\beta_r}(V^{k_r}+e^{k_r})\) and \(b_r=D^{\beta_r}V^{k_r}\). The exact finite product identity is

\[
\prod_{r=1}^{d_\nu}a_r-\prod_{r=1}^{d_\nu}b_r
=\sum_{r=1}^{d_\nu}
  \left(\prod_{l<r}a_l\right)(a_r-b_r)
  \left(\prod_{l>r}b_l\right).
\tag{A26}
\]

Each term contains one differentiated entry of \(e\). Apply \(D^I\), \(|I|\le m\), distributing its derivatives among the coefficient and all factors with the full multi-index product-rule coefficients. Each field derivative then has order at most \(m+s\). Since the number of coefficients, monomials and factors is fixed, all sums have bounds independent of \(J\), apart from the displayed values of \(V\) and \(e\).

For this fixed \(m\), set
\(H_m=1+\max(0,\max_{|I|\le m}K_I)\). The finitely many coefficient logarithms in (5.32) are bounded by a constant times \(q^{-1}\) on \(0<q<q_0\), by the exponential-versus-power estimate used above. It follows that their derivatives through order \(m\) are bounded by a fixed constant times \(q^{-H_m}\). The resulting comparison is

\[
|\mathcal F(V+e)-\mathcal F(V)|_m
\le C_mq^{-H_m}|e|_{m+s}
       (1+|V|_{m+s}+|e|_{m+s})^{d-1}.
\tag{A27}
\]

Outside the stated coefficient-support region a differentiated monomial vanishes, because the smooth field factors and their derivatives have the original supported extensions. Inside it the coefficient bound applies. Thus no additional support-dependent bound was used. The entire field-independent term \(c_{a0}\) cancels from this difference. It is still included in the finite-stage residual hypothesis and is not discarded from \(\mathcal F(V)\).

There is a \(J\)-independent power bound for each finite prefix. One may take
\(K_m=\max(K_m^{\mathrm{base}},\ell_{m+1})\), enlarging a negative base exponent to zero if necessary. Indeed, taking the curl of each uncut potential costs at most one derivative, while \(q^{g_j}\le1\). For fixed \(J\), the finite sum of original constants and the maximum of the finite list of original logarithmic exponents give

\[
|U^{[J]}|_m\le C_{J,m}q^{-K_m}\Lambda_{\log}(q)^{P_{J,m}}.
\tag{A28}
\]

This does not bound \(C_{J,m}\) or \(P_{J,m}\) uniformly in \(J\).

Now fix derivative order \(m\) and decay order \(N\). Choose one integer \(J\ge\max(1,m+s)\) so large that

\[
\frac{g_{J+1}}2-\ell'_{m+s}
\ge N+H_m+(d-1)(K_{m+s}+1),
\qquad
\rho_J-K_m^{\mathcal F}\ge N+1,
\tag{A29}
\]

and the first left side is nonnegative. This is possible because both original gain sequences tend to infinity. After fixing \(J\), take \(q\) small enough that:

- \(q<(2a_J)^{-1}\), so (A22) compares with the actual uncut finite prefix;
- the fixed constants/logarithms in (A28) are bounded by \(q^{-1}\);
- the fixed constants/logarithms in the primary term of (5.33) are bounded by \(q^{-1}\).

The nonnegative exponent in (A22) gives \(|e|_{m+s}\le2^{-J}\le1\). Equation (A28) then implies
\(1+|V|_{m+s}+|e|_{m+s}\le3q^{-(K_{m+s}+1)}\). Substitution into (A27) gives

\[
|\mathcal F(U)-\mathcal F(U^{[J]})|_m
\le C_m3^{d-1}2^{-J}
 q^{g_{J+1}/2-\ell'_{m+s}-H_m-(d-1)(K_{m+s}+1)}
\le C_m3^{d-1}2^{-J}q^N.
\tag{A30}
\]

The same fixed-stage primary residual is at most \(q^N\) by (A29). Its original flat term satisfies
\(E_{J,m}\le C_{J,m,N}q^N\). Therefore

\[
|\mathcal F(U)|_m
\le\big(1+C_{J,m,N}+C_m3^{d-1}2^{-J}\big)q^N.
\tag{A31}
\]

The order of choices is exactly \((m,N)\), then \(J\), then the neighborhood and constants. The only flat remainder in (A31) is \(E_{J,m}\) for this one fixed \(J\). Neither \(\sum_jE_{j,m}\) nor a bound uniform in \(j\) for their constants occurs. This closes the residual part of Lemma 5.4.

## 7. Check of the physical derivative losses in (9.17)

The source chart holds \(Q=2^{-\ell}\), \(\varepsilon=Q^h\), and \(S_*=\ell^2\) fixed while differentiating. Its coordinates are
\((R,Z,T)=(r/Q^{1/2},z/Q^D,\tau/Q)\). On the perturbation annulus \(r\asymp Q^{1/2}\). The original auxiliary covering is determined by

\[
J_g=\begin{pmatrix}3&1\\1&5\end{pmatrix},\quad
\Lambda_g=4-\sqrt2,\quad T_g=4+\sqrt2,\quad
\rho_g=\frac{\log\Lambda_g}{\log T_g},
\]
\[
\kappa_s=10^{-5},\quad d_r=2((1+h)\rho_g-h\kappa_s),\quad
i=\left\lfloor\log_{T_g}\frac{Q^{-1-h}}{S_*}\right\rfloor.
\]

From \(T_g^{-1}Q^{-1-h}/S_*<T_g^i\le Q^{-1-h}/S_*\) and \(\Lambda_g^i=(T_g^i)^{\rho_g}\),

\[
\Lambda_g^iQ^{d_r/2}\asymp
Q^{-(1+h)\rho_g}S_*^{-\rho_g}
Q^{(1+h)\rho_g-h\kappa_s}
=Q^{-h\kappa_s}S_*^{-\rho_g}.
\tag{A32}
\]

Thus a physical radial derivative of an evaluated coefficient has loss \(1/2+h\kappa_s\); an axial derivative has loss \(D=1/2-h\); a time derivative has loss \(1+h\). Cartesian differentiation of the cylindrical frame costs \(1/2\). Derivatives striking their smooth radial coefficients contribute further factors \(Q^{-1/2}\); the larger radial cost already covers each such differentiation. Powers of \(S_*\) enter the logarithmic factors and may depend on the fixed derivative order and stage.

For the label phase the exact source expression is

\[
\Phi=p\theta+p_zZ/\varepsilon+x_0R-v(pF+p_zG),\qquad
k=\lceil\varepsilon^{-1/2}\rceil.
\tag{A33}
\]

The quantities \(p,p_z,x_0,k\) are fixed for the label, including the source's integer rounding rule. The pulse coordinate obeys \(\nabla_xv=0\) and \(\partial_tv=Q^{-1-h}\), with higher physical derivatives of this first derivative zero within the fixed chart. These follow from (6.12), not from neglecting the auxiliary phase evaluation. The axial linear phase term has derivative factor
\(Q^{-D}\varepsilon^{-1}=Q^{-1/2}\). Repeated differentiation of the remaining slow phase factors and the angular coordinate on \(r\asymp Q^{1/2}\) gives the phase bound quoted in Lemma 9.8,

\[
|\nabla_x^a\partial_t^b\Phi|
\le C_{a,b}Q^{-a/2-b(1+h)}S_*^{P_{a,b}},\qquad a+b\ge1,
\tag{A34}
\]

using the stated fixed-order slow-coefficient bounds. Verification of those earlier coefficient estimates is an upstream input; the derivative exponents and auxiliary-coordinate contribution here are checked explicitly.

To avoid confusing the derivative order with the source's harmonic integer in \(e^{ikm\Phi}\), write that integer as \(m_{\rm harm}\) in the next calculation; it is the same integer, not a changed frequency. A derivative partition with \(k'\) nonzero phase-derivative factors gives

\[
(ikm_{\rm harm})^{k'}e^{ikm_{\rm harm}\Phi}
\prod_{\nu=1}^{k'}\nabla_x^{a_\nu}\partial_t^{b_\nu}\Phi,
\quad k'\le a+b,\quad\sum a_\nu=a,\quad\sum b_\nu=b.
\]

Since \(0<Q\le1\), \(k\le2Q^{-h/2}\). With (A34), its power of \(Q\) is bounded by

\[
Q^{-a/2-b(1+h)-k'h/2}
\le Q^{-a(1/2+h/2)-b(1+3h/2)}.
\tag{A35}
\]

The factor \(2^{k'}|m_{\rm harm}|^{k'}\), derivative-partition coefficients and logarithmic powers are retained in the fixed-stage derivative constant. The source's harmonic set is finite at each fixed stage, independently of band; this permits dependence on the stage in that constant. It does not produce an additional stage-dependent power of \(Q\).

The resulting costs are
\(s_x=1/2+h/2\), \(s_t=1+3h/2\). They dominate all four rows of (9.19): \(\kappa_s<1/2\), \(D=1/2-h\), \(1+h\le1+3h/2\), and \(1/2\le s_x\). Also \(s_x<s_t\). Physical rescaling has the four factors

\[
Q^{-A},\qquad Q^{-2A},\qquad Q^{1/2-A},\qquad Q^{1/2-A},
\]

for velocity, pressure, wave potential and mean potential. Each is bounded by \(Q^{-2A}\) for \(0<Q\le1\) and the original \(A=1/2+h\). The source keeps the factor \((km_{\rm harm})^{-1}\) inside the wave potential before this rescaling. One additional spatial derivative recovers velocity from a potential.

Hence the stated common choice

\[
\ell_m=2A+(m+1)\left(1+\frac{3h}{2}\right)
\tag{A36}
\]

covers all derivatives of order at most \(m\), including that extra curl derivative. Every retained stage-\(j\) increment has the source's class exponent at least \(j/10\), so its gain is \(g_j=hj/10\). This verifies the loss/gain arithmetic in (9.17). Passing from \(Q\) to comparable \(q\) may change constants and logarithmic factors, including constants depending on \(j\), but does not change the fixed exponent loss.

The residual conversion uses the fixed factor \(Q^{-2A-1/2}\). Together with (9.8), \(\sigma_j=1/5+j/10\), it gives gain \(\rho_j=h\sigma_j\) with a derivative loss independent of \(j\), as claimed in (9.18). The pointwise validity and all-label uniformity of the finite-stage remainder in (9.18) are supplied by the earlier residual decomposition, not by this exponent calculation. No such uniformity is inferred merely from a coefficient bound at one label.

## 8. Exact Navier–Stokes specialization and truncation choice

For (9.20), the tuple is \(U=(u,p)\), without the optional stress variable. The viscosity in this local construction is exactly one. In Cartesian components,

\[
\mathcal R_i(u,p)=\partial_tu_i+\sum_{k=1}^3u_k\partial_ku_i
-\sum_{k=1}^3\partial_k^2u_i+\partial_ip.
\tag{A37}
\]

This is a fixed differential polynomial of order \(s=2\) and degree \(d=2\), with constant coefficients. No singular cylindrical coefficients occur in (A37); thus the comparison can take \(H_m=0\).

Put \(V=(v,p)=U^{[J]}\), \(e=(w,\pi)=U-U^{[J]}\). For every \(I\), the complete mixed-derivative difference is

\[
\begin{aligned}
D^I[\mathcal R_i(v+w,p+\pi)-\mathcal R_i(v,p)]
={}&\partial_tD^Iw_i-\sum_{k=1}^3\partial_k^2D^Iw_i+\partial_iD^I\pi\\
&+\sum_{k=1}^3\sum_{J'\le I}\binom I{J'}
\big[
(D^{J'}v_k)(D^{I-J'+e_k}w_i)
+(D^{J'}w_k)(D^{I-J'+e_k}v_i)\\
&\hspace{46mm}+(D^{J'}w_k)(D^{I-J'+e_k}w_i)
\big].
\end{aligned}
\tag{A38}
\]

Here \(J'\) is a derivative multi-index, not the truncation stage. Every linear, cross and quadratic term is present with its sign. For Euclidean tuple norms, each scalar component is bounded by the tuple norm and the three-component output is at most \(\sqrt3\) times its maximum component. Since \(\sum_{J'\le I}\binom I{J'}=2^{|I|}\), (A38) gives the explicit sufficient bound

\[
|\mathcal R(V+e)-\mathcal R(V)|_m
\le\sqrt3\,[5+6\,2^m|V|_{m+2}+3\,2^m|e|_{m+2}]\,|e|_{m+2}
\]
\[
\le C_m(1+|V|_{m+2}+|e|_{m+2})|e|_{m+2},\qquad
C_m=\sqrt3(5+9\,2^m).
\tag{A39}
\]

If the source's absolute value convention is taken componentwise instead, the same upper constant remains valid. No norm identification is needed for this inequality.

For prescribed nonnegative integer \(m,N\), a concrete sufficient stage is any integer \(J\) satisfying

\[
J\ge\max\left\{1,m+2,
\left\lceil\frac{20}{h}(N+K_{m+2}+1+\ell'_{m+2})-1\right\rceil,
\left\lceil\frac{10}{h}(N+1+K_m^{\mathcal R})-2\right\rceil
\right\}.
\tag{A40}
\]

Indeed, the two gain inequalities become exactly

\[
\frac{h(J+1)}{20}-\ell'_{m+2}\ge N+K_{m+2}+1,
\qquad
\frac h5+\frac{hJ}{10}-K_m^{\mathcal R}\ge N+1.
\tag{A41}
\]

Keep this \(J\) fixed. On a sufficiently small common neighborhood, (A22), (A28), (A39) and the fixed-stage remainder estimate give

\[
|\mathcal R(U)|_m
\le\big(1+C_{J,m,N}+3C_m2^{-J}\big)q^N.
\tag{A42}
\]

This proves the exact quantified flatness conclusion (9.20) from the source's stated finite-state estimates. It does not assert that the finite-stage flat pieces were summed, nor that their constants are uniform in the stage.

## 9. The actual representation (9.21), initialization and remaining scope

Using the representatives in (9.15), define precisely

\[
\mathcal A=A_0+\sum_{j\ge1}\chi(a_jq)A_j,\qquad
\mathcal Be_\theta=B_0e_\theta+\sum_{j\ge1}\chi(a_jq)B_j,
\]
\[
p_{\rm loc}=p_0+\sum_{j\ge1}\chi(a_jq)p_j,\qquad
u_{\rm loc}=\operatorname{curl}\mathcal A+\mathcal Be_\theta.
\tag{A43}
\]

Every sum is locally finite on \(q>0\). Differentiation therefore commutes with these sums locally, and (A43) is exactly (A4) summed over the original representative tuples. It provides the full map to the physical fields, not an identification of potentials with velocities.

The near-axis base potential in (5.27) has Cartesian form
\(A_n=(S_n/r^2)(-x_2,x_1,0)\), where \(S_n/r^2\) is smooth in \((r^2,z,t)\) for \(q>0\). The base angular field similarly has the form \(b(r^2,z,t)(-x_2,x_1,0)\). The annular representatives vanish near the axis at each fixed \(t<1\). Their sum has a common such neighborhood locally because only finitely many summands are active there. Thus the Cartesian regularity asserted for the fields in (9.21) is preserved by this summation.

A finite initialization block with a nonpositive gain can be included in the base after one cutoff on its potentials, direct angular fields and pressures. On a fixed neighborhood of \(q=0\), this cutoff is identically one, so every original finite-state residual is unchanged there. Errors supported where that fixed cutoff varies are bounded away from \(q=0\). Once their fixed-stage uniform boundedness on that support is supplied by the stated field bounds, they satisfy a bound \(C_Nq^N\) there for every fixed \(N\), with \(C_N\) allowed to depend on the support's positive lower bound for \(q\). This operation creates no infinite family of errors that would need to be summed.

The source also states that all finite corrections agree with the exact exterior heat field outside one fixed interval of \(X\), so the finite residual is zero there. That is the input which extends the finite-stage estimate from a bounded profile interval to the whole local domain in Proposition 9.9 Step 1. The summation does not establish that exterior agreement independently. Likewise, the one-sided smoothness of the actual finite representatives at \(\tau=0,q\ge c\), fixed discrete label choices, and inner leading-coefficient growth are the further inputs used in Steps 3–5; local finiteness preserves their already established finite-term bounds, but does not replace their proofs.

The completed bounded result is therefore the analytic realization mechanism and the exact matching of its gains, losses, residual polynomial and representative map to (9.17)–(9.21). There is no extra summation gap caused by nonuniform fixed-stage flat-remainder constants. Verification of the global source construction and of the formal endpoint remains outside this result.

## 10. Bounded formal-source correspondence and the initial cutoff

All formal paths in this section are under

`./formal/released_ns_validation/NavierStokes/`.

The following declarations were located by a bounded read-only search. The summation and cutoff definitions/signatures listed in the first five rows were additionally read directly in this audit. No Lean/Lake/Elan process or proof replay was run.

| File and declaration | Exact source lines | Source scope |
| --- | --- | --- |
| `SmoothCutoffs.lean`: `cutoffBump`, `cutoff`, `scaledCutoff` | 27–44; 134–146; 161–182 | Actual smooth bump with inner radius 1/2, outer radius 1, and `scaledCutoff a q = cutoff (a*q)`; finite families equal one on a common neighborhood of zero. |
| `SolenoidalDiagonal.lean`: `cutStage`, `potentialSum`, `eventually_zero_tail`, `potentialSum_eventuallyEq_partial` | 32–38; 46–67 | Literal cut-potential `tsum`, local vanishing of a common tail and equality to a finite prefix. Its index set includes zero. |
| `CutStageEstimates.lean`: `RawStageBounds`, `cutLoss`, `exists_diagonal_cut_bounds`, `exists_finite_diagonal_cut_bounds` | 199–203; 192; 349–368; 379–417 | Raw stage estimates for positive stages; one doubling integer schedule; output gain is exactly `g j / 2`. One schedule covers a finite family of component spaces. |
| `DiagonalJetBounds.lean`: `CutStageBounds`, `potential_tail_jet_bound`, `exists_uncut_tail_order` | 196–220; 275–303 | Positive stage j controls derivatives through j+2; tail after indices 0,…,J is bounded by `2^(-J) q^(g(J+1)-L m)`; a single neighborhood compares all requested jets to the uncut prefix. |
| `MixedDiagonalResidual.lean`: `velocity`, `pressure`, `residual_eq_originalResidual`, `exists_physical_schedule_residual_zero` | 26–50; 200–232 | Curl of the cut potential sum plus direct cut-field sum, with pressure summed separately; literal nonlinear residual; one physical schedule with gain `g j / 2` and vanishing joint residual jets. |
| `ActualIterationLedger.lean`: `gain`, `sigma_formula`, `residualLoss`, `residualRate_eq` | 29; 36; 286; 292 | Literal gain `h*j/10`, sigma `1/5+j/10`, and a stage-independent physical residual loss. |
| `ActualCycleResidualBounds.lean`: `fixedLoss`, `Invariant.residual_jetRate`, `finite_residual_rates`; `ActualStageEstimates.lean`: `stageEstimates_of_representations` | 1145, 1158, 1190; 347–403 | Binding of actual finite-cycle invariants and physical representations to the stage-estimate interface; upstream hypotheses were not traversed. |
| `ActualCandidateAssembly.lean`: `estimates`, `Witness`, `witness`, `selected_witness` | 1090; 1121; 1153; 1177 | Actual mixed candidate assembly together with later localization/activation. This locator does not identify the final globally modified object with the manuscript's local field. |

The numerical `DiagonalScale.lean` comments refer to “Lemma 11.3,” rather than the present “Lemma 5.4.” Numbering is not used as correspondence evidence.

### 10.1 Exact half-gain accounting

The formal raw input has gain \(g_j\) in `RawStageBounds`. The output of `exists_diagonal_cut_bounds` is explicitly `CutStageBounds ... (fun j => g j / 2) ...`. The tail theorem's parameter called `g` is therefore the already reduced gain

\[
\widetilde g_j:=g_j/2.
\]

Its displayed output exponent is \(\widetilde g_{J+1}-L_m\), not \(\widetilde g_{J+1}/2-L_m\). Substituting the literal actual-stage gain gives

\[
\widetilde g_{J+1}=\frac{g_{J+1}}2
=\frac12\frac{h(J+1)}{10}=\frac{h(J+1)}{20}.
\tag{A44}
\]

Thus the formal sequence spends half the raw gain once, exactly as in (A18)–(A22). There is no further factor of 1/2 to turn the denominator into 40. The common loss in the formal theorem is `cutLoss L m = finiteBound L m + m`; it is a specified sufficient loss, and is not asserted to equal the sharper mixed-coordinate maximum (A16).

The formal derivative budget \(m\le j+2\) is at least as large as the paper's budget \(m\le j\). For a tail index \(j>J\), the formal condition \(m\le J+3\) implies \(m\le j+2\), explaining the tail theorem's offset. Recovering velocity still uses one additional spatial derivative of the potential, and the nonlinear residual still uses the needed further physical derivatives. Those operations are not paid for by another halving of the gain; they are handled by the fixed derivative-order losses and the finite derivative ceiling, as in Sections 3, 7 and 8.

### 10.2 Exact map between cut stage zero and an uncut base

The manuscript's Lemma 5.4 leaves \(U_0\) uncut; formal `potentialSum` cuts every natural-number index, including zero. The precise comparison uses the same original representative sequence and the same schedule. Let the formal zero entries be

\[
A(0)=A_0,\quad B(0)=B_0e_\theta,\quad P(0)=p_0,
\]

and let its entries at every \(j\ge1\) be the manuscript's \(A_j,B_j,p_j\), with no index shift. Then `uncutPrefix A (J+1)` is literally
\(A_0+\sum_{j=1}^JA_j\), because the range \(0,\ldots,J\) is the disjoint union of \(\{0\}\) and \(\{1,\ldots,J\}\). The same identity holds for the direct field and pressure. Thus their uncut finite-state objects agree under this representative dictionary.

Use the formal cutoff \(\chi_f\), which has the same required plateaux on positive arguments. It need not equal the explicit example (A10); the proof of Lemma 5.4 uses only the stated smoothness/support/plateau properties, so applies to \(\chi_f\) itself. Let \((\mathcal A_{\rm base},B_{\rm base},p_{\rm base})\) denote the manuscript-style sum with its zero entries uncut, but these same positive-stage cutoffs. Let \((\mathcal A_f,B_f,p_f)\) be the all-indices formal-style sum. Put \(c_0=\chi_f(a_0q)\). Their exact differences on \(q>0\) are

\[
\mathcal A_f-\mathcal A_{\rm base}=(c_0-1)A_0,\quad
B_f-B_{\rm base}=(c_0-1)B_0e_\theta,\quad
p_f-p_{\rm base}=(c_0-1)p_0.
\tag{A45}
\]

For the physical velocities, with \(u_0=\operatorname{curl}A_0+B_0e_\theta\), this gives

\[
u_f-u_{\rm base}
=\operatorname{curl}((c_0-1)A_0)+(c_0-1)B_0e_\theta
=(c_0-1)u_0+\nabla c_0\times A_0.
\tag{A46}
\]

No cutoff commutator is omitted. The full residual difference is (A38) with
\(w=(c_0-1)u_0+\nabla c_0\times A_0\) and \(\pi=(c_0-1)p_0\). On the open region

\[
0<q<\frac1{2a_0},
\tag{A47}
\]

the positive formal schedule has \(a_0>0\), so \(c_0\) is identically one on a neighborhood of every point. Equations (A45)–(A46) and every one of their mixed derivatives vanish there. Therefore the two representative sums, velocities, pressures and full nonlinear residuals agree exactly there, at every derivative order. Away from this region, (A45)–(A46), rather than equality, are the precise relation.

This proves the local initial-term-cutoff correspondence on the same representatives and schedule. It does not identify two independently selected schedules, different representative sequences, or the later localized/activated candidate. The formal `exists_physical_schedule_residual_zero` conclusion is phrased in terms of joint residual jets at the endpoint; no equivalence of all its filter/domain quantifiers with every clause of the manuscript is claimed by this bounded locator.

## Transcription repair record

The derivative-partition display in Section 7 contained the literal text `quad` between `k'\le a+b,` and `\sum a_\nu=a`. It has been corrected to the TeX spacing command `\quad`. This repairs transcription only; every mathematical symbol, coefficient, exponent, inequality and claim is retained. The accompanying `summation_realization_audit_receipt.json` records the final note hash and the completed audit scope.
