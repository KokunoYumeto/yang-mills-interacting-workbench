# Independent audit of compactly supported mean corrections

Source: *Finite Time Blowup for Navier-Stokes*, Section 8, printed pp.87-100, released at [the source PDF](https://cdn.openai.com/pdf/32d9f210-8b73-45e0-91bc-82a30aef8a9a/navier-stokes.pdf). Verified SHA-256: `8c8a94ad9ac824c8b605b9827cadf7beaca48bd10b380de3cfc872a2c37afa81`. All statements and proofs in this section were read, and every assigned page was rendered and visually inspected.

This audit finds no contradiction in the internal Section 8 calculations. The proofs below establish the local operator facts and algebra explicitly. The dependency ledger identifies the exact earlier data used; the existence of the actual background and the full iteration are audited elsewhere. In particular, the checks here do not establish the Navier-Stokes endpoint.

## 1. Original coordinates, operators, and spaces

Keep the paper's \(A=1/2+h\), \(D=1/2-h\), fixed \(h>0\), \(Q=2^{-\ell}\), \(\epsilon=Q^h\), \(S_*=\ell^2\), and

\[
R=Q^{-1/2}r,\quad Z=Q^{-D}z,\quad T=Q^{-1}(1-t).
\]

The positive function \(q=q(z,t)\) is independent of radius. The active shell is \(X_a<X<X_b\), where \(X=QR^2/(2q)\). In a fixed band \(q/Q\asymp1\); hence the radii are bounded above and bounded away from zero. All radial integrals below run from \(0\) to \(\infty\), except where their bounds are written otherwise. Auxiliary Haar measure has total mass one on \(\mathbb T^2=\mathbb R^2/\mathbb Z^2\). Angular averaging means componentwise averaging in the cylindrical frame.

The exact constants and vectors are

\[
J_g=\begin{pmatrix}3&1\\1&5\end{pmatrix},\quad
\Lambda_g=4-\sqrt2,\quad T_g=4+\sqrt2,\quad
b_g=\sqrt2-1,
\]
\[
v_r=(1,-b_g),\quad v_t=(b_g,1),\quad
\rho_g=\frac{\log\Lambda_g}{\log T_g},\quad
\kappa_s=10^{-5},\quad
d_r=2((1+h)\rho_g-h\kappa_s)>0.
\]

The phase map is \(Y=v_r r^{d_r}+v_t t\pmod {\mathbb Z^2}\). For an independent auxiliary variable \(Y\), differentiation after evaluation is

\[
\mathsf r=\partial_r+d_r r^{d_r-1}v_r\cdot\partial_Y,
\qquad
\mathsf t=\partial_t+v_t\cdot\partial_Y.
\]

Both commute with \(\partial_z\), and with each other: the coefficient of the auxiliary radial derivative depends only on \(r\), while the coefficient of the auxiliary temporal derivative is constant. Direct multiplication gives \(J_gv_r=\Lambda_gv_r\) and \(J_gv_t=T_gv_t\).

For a fixed common covering level \(i_0\), let \(y=J_g^{i_0}Y\), \(L=v_r\cdot\partial_y\), \(N=v_t\cdot\partial_y\), \(M=\Lambda_g^{i_0}Q^{d_r/2}\), and \(c=T_g^{i_0}Q^{1+h}\). Then

\[
D_r=\partial_R+Md_rR^{d_r-1}L,\quad
D_z=\epsilon\partial_Z,\quad
t_*=-\epsilon\partial_T+cN,
\quad \Delta_0=D_r^2+R^{-1}D_r+D_z^2.
\]

The integer \(i_0\), \(Q\), \(\epsilon\), \(M\), and \(c\) remain fixed under coefficient differentiation. At the band level,

\[
i(\ell)=\left\lfloor\log_{T_g}(Q^{-1-h}/S_*)\right\rfloor
\]

implies \(T_g^{-1}Q^{-1-h}/S_*<T_g^{i(\ell)}\le Q^{-1-h}/S_*\). Raising to \(\rho_g\) and using the displayed definition of \(d_r\) proves

\[
c\asymp S_*^{-1},\qquad
M\asymp\epsilon^{-\kappa_s}S_*^{-\rho_g},
\qquad M^{-1}\lesssim\epsilon^{\kappa_s}S_*^{\rho_g}.
\]

Bounded changes of covering level multiply these expressions by fixed constants.

The class \(\mathcal M_\alpha\) consists of angularly independent, compatible torus coefficients supported in the shell with smooth zero extension and, for every fixed multi-index \(I\) in \((R,Z,T,y_1,y_2)\), bounds

\[
|\partial^If|\le C_{j,I}\epsilon^\alpha S_*^{B_{j,I}}\zeta\delta^{-C_{j,I}'},
\quad
\zeta=\exp(-a_a/d_a^2-a_b/d_b^2),
\]
\[
d_a=\log(X/X_a),\quad d_b=\log(X_b/X),\quad
\delta=\min(1,d_a,d_b),\qquad a_a,a_b>0.
\]

The powers may depend on the fixed derivative order and correction stage, but not on the band or point. The class \(\mathcal S_\alpha\) has the same slow derivative bounds for functions of \((Z,T)\), without the radial weight. Combining powers into a common larger power is legitimate since \(S_*\ge1\), \(\delta\le1\). This does not change the source object or its exponent.

Leibniz' rule, \(0<\zeta\le1\), and the bounded shell imply \(\mathcal M_a\mathcal M_b\subset\mathcal M_{a+b}\). Slow coefficient derivatives preserve the exponent; \(D_r\) loses at most \(\kappa_s\), \(D_z\) gains one, the slow part of \(t_*\) gains one, and \(cN\) preserves it. A slow field has no \(cN\) contribution. Each assertion follows term by term from the displayed operators. Multiplying an interior-supported coefficient by a bounded smooth base coefficient preserves its weighted class even when that base coefficient has no global shell weight.

## 2. Exact radial range, inverse, obstruction, and projection

Fix \((Z,T)\), a covering level, and \(e\in\{0,1,2\}\). Write

\[
\mathcal D_e=D_r+e/R.
\]

Let \(\mathcal C\) be the smooth real functions of \(R>0,y\in\mathbb T^2\) supported in the closed active shell and smoothly zero across its edges. Define the conjugation

\[
(\Gamma H)(R,w)=H(R,w+MR^{d_r}v_r).
\]

Its inverse replaces the plus sign by a minus sign. The chain rule gives the exact intertwining identity

\[
\partial_R\Gamma(R^e\phi)=\Gamma(R^e\mathcal D_e\phi).
\tag{MC1}
\]

Consequently the full obstruction is the function on the entire torus

\[
(K_ef)(w)=\int R^ef(R,w+MR^{d_r}v_r)\,dR.
\tag{MC2}
\]

A compactly supported solution of \(\mathcal D_e\phi=f\) exists exactly when \(K_ef=0\) as a torus function. Necessity follows by integrating (MC1), since \(R^e\phi\) vanishes at both radial endpoints. For sufficiency define

\[
\phi(R,y)=R^{-e}\int_0^R(R')^e
f(R',y+M((R')^{d_r}-R^{d_r})v_r)\,dR'.
\tag{MC3}
\]

It vanishes below the shell. Above the shell it is \(R^{-e}(K_ef)(y-MR^{d_r}v_r)=0\). All derivatives extend by zero, and (MC1) proves the equation. If two compactly supported solutions exist, their difference has \(\partial_R\Gamma(R^e\phi)=0\); the constant is zero below the shell, proving uniqueness.

The obstruction map is onto \(C^\infty(\mathbb T^2)\): given \(F(w)\), choose any smooth interior bump \(h(R)\) with integral one and take \(f(R,y)=R^{-e}h(R)F(y-MR^{d_r}v_r)\). Substitution in (MC2) gives \(K_ef=F\). Thus the strongest exact relationship, at each fixed slow point, is the exact sequence

\[
0\longrightarrow\mathcal C
\xrightarrow{\mathcal D_e}\mathcal C
\xrightarrow{K_e}C^\infty(\mathbb T^2)
\longrightarrow0.
\tag{MC4}
\]

This identifies all obstructions, not only their Haar averages.

Choose the paper's slow cutoff \(\chi_m(X)\), equal to zero near the inner shell edge and one near the outer edge, with derivative supported on a fixed interior interval. For \(g=R^ef\), define

\[
Ig(R,y)=\int_0^R g(R',y+M((R')^{d_r}-R^{d_r})v_r)\,dR',
\]
\[
Jg(R,y)=\int_0^\infty g(R',y+M((R')^{d_r}-R^{d_r})v_r)\,dR',
\]
\[
T_ef=R^{-e}(Ig-\chi_mJg),\qquad
A_ef=R^{-e}(\partial_R\chi_m)Jg.
\tag{MC5}
\]

The conjugation yields \(D_rIg=g\), \(D_rJg=0\). Since \(D_r\chi_m=\partial_R\chi_m\), the product rule yields

\[
\mathcal D_eT_e=1-A_e.
\tag{MC6}
\]

Moreover \(K_eA_ef=K_ef\), because after conjugation the factor \(K_ef(w)\) is independent of \(R\) and \(\int\partial_R\chi_m\,dR=1\). Thus \(A_e^2=A_e\), \(T_e\mathcal D_e=1\) on \(\mathcal C\), and \(T_e\) is the exact inverse of \(\mathcal D_e\) on \(\ker K_e\). The paper's inverse is an explicitly split inverse with a specified obstruction projector.

Haar averaging (MC2) gives

\[
\langle K_ef\rangle=\int R^e\langle f\rangle\,dR.
\tag{MC7}
\]

The zero weighted Haar moment is therefore necessary but in general insufficient for exact compact inversion. As an explicit smooth counterexample to that stronger, unclaimed assertion, take a nonzero integer \(k\), the bump \(h\) above, and

\[
f_M(R,y)=e^{-M^2}R^{-e}h(R)
\cos(2\pi k\cdot(y-MR^{d_r}v_r)).
\]

Its Haar mean vanishes at every radius, while \(K_ef_M=e^{-M^2}\cos(2\pi k\cdot w)\ne0\). The family has all fixed coefficient derivative bounds: each derivative introduces at most a fixed power of \(M\), absorbed by \(e^{-M^2}\). With the original scale relation for \(M\), these bounds are flat in every power of \(\epsilon\). The counterexample does not contradict Lemma 8.2; it proves why its explicitly retained flat remainder cannot be deleted.

## 3. Primitive estimates and the full flatness argument

Set \(U=R^{d_r}\) and

\[
F(U,Z,T,y)=\frac{g(R,Z,T,y)}{d_rR^{d_r-1}}.
\]

Use its smooth zero extension. The change of variables has uniformly bounded derivatives on the shell. Put

\[
A_-(U,y)=\int_{-\infty}^0 F(U+u,y+Muv_r)\,du,
\qquad
A_+(U,y)=\int_0^\infty F(U+u,y+Muv_r)\,du.
\]

Then \(Ig=A_-\), \(Jg=A_-+A_+\), and \(Ig-\chi_mJg=(1-\chi_m)A_--\chi_mA_+\). In these integrals the shift \(Muv_r\) does not depend on \(U,Z,T\). Hence every fixed coefficient derivative differentiates only \(F\) and the cutoff; it introduces no factor \(M\). All integrations have bounded effective length. Since the source is smoothly zero extended, differentiating moving support creates no boundary term.

For completeness, the precise edge inequality is as follows. For any fixed real \(B\ge0\),

\[
\frac{d}{ds}\log(e^{-a/s^2}s^{-B})=2a/s^3-B/s>0
\]

whenever \(0<s<\sqrt{2a/B}\), with no upper restriction needed when \(B=0\). Near the inner edge, only \(A_-\) occurs and \(0<d_a(R')\le d_a(R)\) on its effective segment. The factor associated with \(d_b\) stays between positive constants there. This inequality bounds the complete differentiated input weight by \(C\zeta(R)\delta(R)^{-B'}\). The outer edge uses only \(A_+\) and the same argument with \(d_b\). On the fixed interior region both radial edge distances are bounded below, so the output weight is bounded below and the unweighted bound suffices. Multiplication by \(R^{\pm e}\) and the \(R\leftrightarrow U\) chain rule cost fixed constants. This proves \(T_e:\mathcal M_\alpha\to\mathcal M_\alpha\), including every fixed derivative, shell support, and projection of slow support.

The directional small divisors are controlled without a numerical approximation. For \(k=(k_1,k_2)\ne0\),

\[
v_r\cdot k=(k_1+k_2)-\sqrt2 k_2,
\]

and its product with \((k_1+k_2)+\sqrt2 k_2\) is the integer \((k_1+k_2)^2-2k_2^2\ne0\). Nonzero follows from the irrationality of \(\sqrt2\); if \(k_2=0\), it follows from \(k_1\ne0\). The conjugate has absolute value at most \(C|k|\). Therefore \(|v_r\cdot k|^{-1}\le C(1+|k|)\). The same calculation for \(v_t\cdot k=(k_2-k_1)+\sqrt2 k_1\) gives the identical bound.

For \(p\ge1\), the inverse \(L^{-p}\) on zero-mean torus functions is the multiplier \((2\pi i v_r\cdot k)^{-p}\) at \(k\ne0\), zero at \(k=0\). For a \(C^{m+p+3}\) function, integrate its Fourier coefficient \(m+p+3\) times in a coordinate with \(|k_j|\ge |k|/\sqrt2\). A derivative of order at most \(m\), followed by the multiplier bound, gives a summand bounded by \(C\|H\|_{C^{m+p+3}}(1+|k|)^{-3}\). The series over \(\mathbb Z^2\) converges, proving

\[
\|L^{-p}H\|_{C^m}\le C_{m,p}\|H\|_{C^{m+p+3}}.
\tag{MC8}
\]

It also proves commutation with slow derivatives, smoothness, and reality. There is no assertion of constants uniform in \(p\).

Under \(\int R^e\langle f\rangle\,dR=0\), the integral of the zero Fourier mode of \(F\) is zero. For \(F^\circ=F-\langle F\rangle\), differentiation in \(u\) gives

\[
\frac d{du}L^{-1}F^\circ(U+u,y+Muv_r)
=\partial_UL^{-1}F^\circ(U+u,y+Muv_r)+MF^\circ(U+u,y+Muv_r).
\]

Its full-line integral is zero by smooth compact support. Iterating this identity gives the exact equality

\[
Jg=(-M^{-1})^p\int_{\mathbb R}
\partial_U^pL^{-p}F^\circ(U+u,y+Muv_r)\,du.
\tag{MC9}
\]

Each repetition has the same minus sign. All omitted zero-mode integrals, including their slow derivatives, are exactly zero. Fixed-shift differentiation and (MC8) bound any further derivative of (MC9). For an output derivative \(I\), radial input derivatives through \(I_R+p\) and torus derivatives through \(|I_y|+p+3\), with the requested slow derivatives, suffice. The coefficient \(\partial_R\chi_m\) has fixed interior support. Thus

\[
|\partial^IA_ef|\le C_{j,I,p}
\epsilon^{\alpha+p\kappa_s}S_*^{B_{j,I,p}}
\zeta\delta^{-B'_{j,I,p}},\qquad
\langle A_ef\rangle=0.
\tag{MC10}
\]

If \(f\) is independent of \(y\), its full characteristic integral is its ordinary weighted radial integral. Under the moment condition the remainder is identically zero, not merely small.

To pass from (MC10) to physical flatness, fix the physical output normalization and derivative order before choosing \(p\). Its graph derivatives require only finitely many coefficient derivatives and cost some finite power \(q^{-L}\) times a power of \(S_*\); \(L\) depends on the output order, not on \(p\). The cutoff remainder is interior supported, so no boundary-weight loss remains there. For prescribed \(N\ge0\), choose \(p\) with \(h(\alpha+p\kappa_s)>N+L\). Since \(q\asymp Q\) and \(S_*=\ell^2\), the positive excess in the exponent dominates every fixed power of \(\ell\), proving an \(O(q^N)\) bound. This proves every fixed physical derivative is flat. Finite regularity alone would not imply this all-orders conclusion.

## 4. Mean momentum equations derived in the cylindrical frame

Let \(e_r=(\cos\theta,\sin\theta,0)\), \(e_\theta=(-\sin\theta,\cos\theta,0)\), \(e_z=(0,0,1)\). Then \(\partial_\theta e_r=e_\theta\), \(\partial_\theta e_\theta=-e_r\). For a divergence-free vector \(U=(U_r,U_\theta,U_z)\),

\[
(D_r+R^{-1})U_r+R^{-1}\partial_\theta U_\theta+D_zU_z=0.
\]

Expand transport using this identity. For example,

\[
(D_r+R^{-1})U_r^2+R^{-1}\partial_\theta(U_\theta U_r)+D_z(U_zU_r)
=U_rD_rU_r+R^{-1}U_\theta\partial_\theta U_r+U_zD_zU_r,
\]

because the extra factor multiplying \(U_r\) is the displayed divergence. The frame derivative then adds \(-U_\theta^2/R\). In the angular component it adds \(U_rU_\theta/R\), so its radial flux has weight two. In the axial component the frame contributes nothing. Therefore the transport components are

\[
\begin{aligned}
(U\cdot\nabla U)_r&=(D_r+R^{-1})U_r^2+R^{-1}\partial_\theta(U_\theta U_r)+D_z(U_zU_r)-U_\theta^2/R,\\
(U\cdot\nabla U)_\theta&=(D_r+2R^{-1})(U_rU_\theta)+R^{-1}\partial_\theta U_\theta^2+D_z(U_zU_\theta),\\
(U\cdot\nabla U)_z&=(D_r+R^{-1})(U_rU_z)+R^{-1}\partial_\theta(U_\theta U_z)+D_zU_z^2.
\end{aligned}
\tag{MC11}
\]

The cylindrical vector Laplacian is

\[
\begin{aligned}
(\Delta U)_r&=(\Delta_0+R^{-2}\partial_\theta^2-R^{-2})U_r-2R^{-2}\partial_\theta U_\theta,\\
(\Delta U)_\theta&=(\Delta_0+R^{-2}\partial_\theta^2-R^{-2})U_\theta+2R^{-2}\partial_\theta U_r,\\
(\Delta U)_z&=(\Delta_0+R^{-2}\partial_\theta^2)U_z.
\end{aligned}
\]

These follow by applying \(\partial_\theta^2\) to each component times its frame vector, which produces both the \(\mp2\partial_\theta\) terms and \(-U_{r,\theta}\). Their angular averages retain exactly the radial/angular \(-R^{-2}\) terms.

Now set \(U=(b+\beta,V+v,G+\gamma)+w\), \(\langle w\rangle_\theta=0\), and \(W^{ab}=\langle w_aw_b\rangle_\theta\). The identity

\[
\langle U_aU_b\rangle_\theta=(U_a-w_a)(U_b-w_b)+W^{ab}
\]

keeps the full actual wave covariance. No curl term can be removed from \(W\). Subtract the pure base residual, whose stress contribution is \(-(D_r+2/R)\Sigma_\theta\) in the angular row and \(-(D_r+1/R)\Sigma_z\) in the axial row. Retain its separate flat part. The remaining residual is \((D_rp_m-g_r,E_\theta,E_z)\), with

\[
\begin{aligned}
E_\theta={}&t_*v+(D_r+2/R)(bv+\beta V+\beta v+W^{r\theta})\\
&+D_z(Gv+V\gamma+\gamma v+W^{z\theta})
-\epsilon(\Delta_0-R^{-2})v-(D_r+2/R)\Sigma_\theta,\\
E_z={}&t_*\gamma+(D_r+1/R)(b\gamma+\beta G+\beta\gamma+W^{rz})\\
&+D_z(2G\gamma+\gamma^2+W^{zz}+p_m)
-\epsilon\Delta_0\gamma-(D_r+1/R)\Sigma_z,\\
g_r={}&-t_*\beta-(D_r+1/R)(2b\beta+\beta^2+W^{rr})\\
&-D_z(b\gamma+G\beta+\beta\gamma+W^{zr})
+(2Vv+v^2+W^{\theta\theta})/R
+\epsilon(\Delta_0-R^{-2})\beta.
\end{aligned}
\tag{MC12}
\]

Every sign follows from (MC11) and subtracting the radial pressure derivative to define \(g_r\). These are precisely the checked mathematical identities in source \(8.3\).

## 5. Pressure, solenoidal axial realization, and dimensions

Choose the reserved interior bump \(\widehat\rho\in C_c^\infty(I_m)\), \(I_m=\{\sqrt{2X}:X\in I_{\rm mean}\}\), with integral one. In physical variables \(\rho_{\rm phys}=q^{-1/2}\widehat\rho(r/\sqrt q)\), and in a chart \(\rho=Q^{1/2}\rho_{\rm phys}\). Changing variable \(r=\sqrt q\,x\) proves both physical and chart radial integrals of the bump equal one.

Define

\[
P=\int\langle g_r\rangle\,dR,\qquad p_m=T_0(g_r-\rho P).
\]

The input has zero radial Haar integral. Equation (MC6) gives exactly

\[
D_rp_m-g_r=-\rho P-A_0(g_r-\rho P),
\qquad
\partial_R\langle p_m\rangle=\langle g_r\rangle-\rho P.
\tag{MC13}
\]

The map \(g_r\mapsto p_m\) is linear because the bump is fixed. Radial integration maps \(\mathcal M_\alpha\to\mathcal S_\alpha\): for each fixed derivative, \(\zeta\delta^{-B}\) is bounded and the effective interval has bounded length. The interior bump then maps \(P\) back into \(\mathcal M_\alpha\), and Section 3 proves the pressure estimate and its difference estimate. Its cutoff remainder has zero Haar mean and is flat by (MC10).

For a desired axial increment \(\gamma_d\) with \(\int R\langle\gamma_d\rangle\,dR=0\), define \(\Psi_*=T_1\gamma_d\) and

\[
\Delta\beta=-\epsilon\partial_Z\Psi_*,\qquad
\Delta\gamma=(D_r+1/R)\Psi_*=\gamma_d-A_1\gamma_d.
\tag{MC14}
\]

Its divergence is

\[
(D_r+1/R)\Delta\beta+D_z\Delta\gamma
=-\epsilon(D_r+1/R)\partial_Z\Psi_*+
\epsilon\partial_Z(D_r+1/R)\Psi_*=0.
\]

This cancellation uses commutation of the differential operators on the already defined potential. It does not commute \(\partial_Z\) through the integral operator, whose moving cutoff may depend on \(Z\). The averaged axial increment equals \(\langle\gamma_d\rangle\) at each radius, and its weighted integral remains zero. The class bounds are \(\Psi_*,\Delta\gamma\in\mathcal M_\alpha\), \(\Delta\beta\in\mathcal M_{\alpha+1}\). If \(\gamma_d\) is torus independent, the axial realization is pointwise exact.

All physical scales can be checked from one change of variable. If \(f_*=Q^af_{\rm phys}\), then

\[
\int R^ef_*\,dR=Q^{a-(e+1)/2}\int r^ef_{\rm phys}\,dr,
\qquad
T_ef_*=Q^{a-1/2}r^{-e}I_{c,\rm phys}(r^ef_{\rm phys}).
\tag{MC15}
\]

Use \(u_*=Q^Au_{\rm phys}\), \(g_*=Q^{2A+1/2}g_{\rm phys}\), \(p_*=Q^{2A}p_{\rm phys}\), \(\Psi_*=Q^{A-1/2}\Psi_{\rm phys}\). In particular, normalizing \(-\partial_z\Psi_{\rm phys}\) yields \(-Q^{1/2-D}\partial_Z\Psi_*=-\epsilon\partial_Z\Psi_*\), preserving the minus sign. The pressure primitive scale is \(Q^{2A}\). The resulting moment exponents are

| Quantity | Chart value relative to physical value |
|---|---|
| \(M_\theta=\int R^2\langle v\rangle\,dR\) | \(Q^{A-3/2}\) |
| \(M_z=\int R\langle\gamma\rangle\,dR\) | \(Q^{A-1}\) |
| \(P=\int\langle g_r\rangle\,dR\) | \(Q^{2A}\) |
| \(c_\rho=\frac12\int R^2\rho\,dR\) | \(Q^{-1}\) |
| \(J_\theta\) defined below | \(Q^{2A-3/2}\) |
| \(J_z\) defined below | \(Q^{2A-1}\) |

The second term in \(J_z\), involving \(R^2g_r\), has exponent \(2A+1/2-3/2=2A-1\), exactly matching its velocity-product term. Thus the fifth moment row has a consistent physical dimension.

## 6. Integrated residuals and both covariance targets

Let bars denote Haar averages. Translation invariance on the torus proves \(\overline{D_rf}=\partial_R\bar f\), \(\overline{t_*f}=-\epsilon\partial_T\bar f\), and the corresponding second-derivative statements. For any smoothly supported scalar \(h\),

\[
\int R^e(\partial_R+e/R)h\,dR=\int\partial_R(R^eh)\,dR=0.
\]

For the angular radial viscosity, retaining all three terms,

\[
\int R^2h_{RR}\,dR=2\int h\,dR,\quad
\int Rh_R\,dR=-\int h\,dR,\quad
\int(-h)\,dR=-\int h\,dR.
\]

Their sum is zero. For the axial viscosity, \(\int Rh_{RR}\,dR=-\int h_R\,dR\), which cancels the remaining \(\int h_R\,dR\). The time and axial-viscosity contributions to the two residual moments are respectively

\[
-\epsilon\partial_TM_\theta-\epsilon^3\partial_Z^2M_\theta,
\qquad
-\epsilon\partial_TM_z-\epsilon^3\partial_Z^2M_z.
\]

They vanish when the two moments are zero at every slow point. The stress divergences vanish by their own compact support. Finally, compact support and (MC13) give

\[
\int R\bar p_m\,dR=-\frac12\int R^2\partial_R\bar p_m\,dR
=-\frac12\int R^2\bar g_r\,dR+c_\rho P.
\tag{MC16}
\]

Set

\[
J_\theta=\int R^2\overline{Gv+V\gamma+\gamma v+W^{z\theta}}\,dR,
\]
\[
J_z=\int R\overline{2G\gamma+\gamma^2+W^{zz}}\,dR
-\frac12\int R^2\bar g_r\,dR,
\qquad c_\rho=\frac12\int R^2\rho\,dR.
\]

Every surviving term of (MC12) is now accounted for, and the exact identities are

\[
\int R^2\bar E_\theta\,dR=\epsilon\partial_ZJ_\theta,
\qquad
\int R\bar E_z\,dR=\epsilon\partial_Z(J_z+c_\rho P).
\tag{MC17}
\]

The product \(c_\rho P\) must stay inside the derivative; \(c_\rho\) changes with the moving scale \(q\). These are the complete compatibility moments of the two torus-independent weighted radial equations.

Use the fixed interior bumps \(\sigma_\theta,\sigma_z\) with \(\int R^2\sigma_\theta\,dR=\int R\sigma_z\,dR=1\). Their physical versions have the powers \(q^{-3/2}\widehat\sigma_\theta(r/\sqrt q)\) and \(q^{-1}\widehat\sigma_z(r/\sqrt q)\). Define

\[
H_\theta=-T_2(\bar E_\theta-\sigma_\theta\epsilon\partial_ZJ_\theta),
\qquad
H_z=-T_1(\bar E_z-\sigma_z\epsilon\partial_Z(J_z+c_\rho P)).
\]

Their sources have zero weighted radial integrals by (MC17), and are torus independent, so their \(A_e\) remainders vanish exactly. Therefore

\[
(D_r+2/R)H_\theta=-\bar E_\theta+\sigma_\theta\epsilon\partial_ZJ_\theta,
\quad
(D_r+1/R)H_z=-\bar E_z+\sigma_z\epsilon\partial_Z(J_z+c_\rho P).
\tag{MC18}
\]

The minus signs are required because adding \(W^{r\theta}\) or \(W^{rz}\) contributes a positive divergence in (MC12). Support at a fixed \((Z,T)\) cannot be created when the whole radial source vanishes there. These are exact radial stress inverses with the two explicitly retained bump residuals.

## 7. Fast-time inverse and chart agreement

The same Diophantine proof used for \(L\) gives the unique smooth zero-Haar-mean solution of \(N\phi=F\), for \(\bar F=0\):

\[
N^{-1}F=\sum_{k\in\mathbb Z^2\setminus\{0\}}
\frac{\widehat F(k)}{2\pi i\,v_t\cdot k}e^{2\pi ik\cdot y},
\qquad
\|N^{-1}F\|_{C^m}\le C_m\|F\|_{C^{m+4}}.
\tag{MC19}
\]

All nonzero modes have nonzero divisors. A kernel element therefore has only a constant mode, and the zero-mean condition removes it. The four-derivative count is the \(p=1\) instance of (MC8). This operator is local in the independent variables \(R,Z,T\), hence preserves their closed support and smooth zero extension. It need not preserve support within a proper subset of the torus, which is allowed for \(\mathcal M_\alpha\).

Define \(P_iF(Y)=F(J_g^iY)\). A mode \(k\) pulls back to \((J_g^i)^Tk\). This lattice map is injective because \(\det J_g=14\ne0\), and hence it preserves the zero Fourier coefficient and Haar average. The exact chain rule and the eigenvector identity prove

\[
N_{\rm abs}P_i=T_g^iP_iN_i,
\qquad N_{\rm abs}^{-1}P_i=T_g^{-i}P_iN_i^{-1}
\tag{MC20}
\]

on zero-mean functions. The inverse identity also follows from uniqueness, so it does not require the covering to be one-to-one.

Define the physical tangential update as \(-N_{\rm abs}^{-1}(E_{\theta,\rm phys}^\circ,E_{z,\rm phys}^\circ)\). Its chart representative has multiplier

\[
Q^{A-(2A+1/2)}T_g^{-i_0}=Q^{-1-h}T_g^{-i_0}=c^{-1}.
\]

Thus \(\Delta v=-c^{-1}N^{-1}E_\theta^\circ\), \(\gamma_d=-c^{-1}N^{-1}E_z^\circ\). They belong to \(\mathcal M_\alpha\) when \(E_\theta,E_z\) do, since \(c^{-1}\lesssim S_*\). Both have zero Haar mean at every radius. Realize \(\gamma_d\) by (MC14), and put \(a=-A_1\gamma_d\). Then

\[
cN\Delta v=-E_\theta^\circ,
\qquad cN\Delta\gamma=-E_z^\circ+cNa.
\tag{MC21}
\]

Translations commute with \(N\), and the cutoff is torus independent, so there is no additional commutator. The remainder \(cNa\) is flat by (MC10), with one more requested torus derivative. The slow-time contribution \(-\epsilon\partial_T\) is retained and has one extra power of \(\epsilon\). The actual velocity is divergence-free and preserves both moments because its angular and axial Haar means vanish pointwise.

Radial chart agreement is equally explicit. Pulling a physical integrand \(F(J_g^iY)\) along the absolute radial shift gives

\[
F(J_g^iY+\Lambda_g^i((r')^{d_r}-r^{d_r})v_r),
\]

which is exactly the chart shift after \(r=\sqrt Q R\). Together with (MC15), this proves the radial operators in different charts define one physical field. Their integer indices are held fixed on each common neighborhood. No derivative of a floor function is taken.

## 8. Explicit five-dimensional moment correction

Preserve the exact reserved-patch base in the paper's variable \(x=r/\sqrt q\in I_m\):

\[
G_q=0,\qquad V_q=a(\eta)x^{-1-2\lambda},\qquad
a(\eta)=2^{1/2+\lambda}c_{\rm patch}(1+\eta^2)^{-1},
\qquad |a(\eta)|\ge a_0>0,\quad\lambda>0.
\tag{MC22}
\]

This is the specific input base whose construction is assigned to the base audit. The following gives the complete inverse on that specified patch, including a formula beyond just a nonzero determinant.

Choose an interior \(x_0>0\), a small fixed \(d>0\), and a nonnegative nonzero smooth bump \(\eta_0\) sufficiently narrow that its three copies

\[
\eta_j(x)=e^{-jd}\eta_0(e^{-jd}x),\qquad j=0,1,2,
\]

have disjoint supports in \(I_m\). Such a choice exists: first choose \(d\) so \(x_0,x_0e^d,x_0e^{2d}\) remain in the open interval; their finite positive separations then permit a sufficiently small common relative support width. For every real \(p\), define \(\mu_p=\int x^p\eta_0(x)\,dx>0\). The exact change of variable gives

\[
\int x^p\eta_j(x)\,dx=\mu_pe^{jdp}.
\tag{MC23}
\]

The required five rows are

\[
\int R^2\Delta v=0,\quad\int R\gamma_d=0,\quad
\int(2V/R)\Delta v=-P,
\]
\[
\int R^2(G\Delta v+V\gamma_d)=-J_\theta,
\qquad
\int(2RG\gamma_d-RV\Delta v)=-J_z,
\tag{MC24}
\]

with \(dR\) understood in each integral. After using physical targets scaled by \(q\) with the exact powers in Section 5, the angular powers are \(p_0=2,p_1=-2-2\lambda,p_2=-2\lambda\). Set \(t_i=e^{dp_i}\). All three are distinct for \(\lambda>0\).

Let \(C(s)=u_0+u_1s+u_2s^2\). The angular equations are exactly

\[
C(t_0)=0,\qquad
C(t_1)=-\frac{P_q}{2a\mu_{p_1}}=:b_1,
\qquad
C(t_2)=\frac{J_{z,q}}{a\mu_{p_2}}=:b_2.
\]

Therefore the unique polynomial and all three coefficients are given explicitly by

\[
C(s)=b_1\frac{(s-t_0)(s-t_2)}{(t_1-t_0)(t_1-t_2)}
+b_2\frac{(s-t_0)(s-t_1)}{(t_2-t_0)(t_2-t_1)}.
\tag{MC25}
\]

Evaluation at the three nodes proves all three equations exactly. Uniqueness follows since a nonzero polynomial of degree at most two cannot have three distinct roots: division by each linear factor would force degree at least three. Equivalently the displayed source matrix has determinant

\[
-2a^2\mu_2\mu_{-2-2\lambda}\mu_{-2\lambda}
(t_1-t_0)(t_2-t_0)(t_2-t_1)\ne0.
\]

For the axial block set \(t_b=e^d\), \(t_a=e^{d(1-2\lambda)}\). They are distinct. Its two coefficients are

\[
s_1=-\frac{J_{\theta,q}}{a\mu_{1-2\lambda}(t_a-t_b)},
\qquad s_0=-t_bs_1.
\tag{MC26}
\]

Then \(\mu_1(s_0+t_bs_1)=0\), and

\[
a\mu_{1-2\lambda}(s_0+t_as_1)=-J_{\theta,q}.
\]

The determinant is \(a\mu_1\mu_{1-2\lambda}(t_a-t_b)\ne0\). Define the physical corrections, with no change to their powers,

\[
\Delta v_{\rm phys}=q^{-A}\sum_{j=0}^2u_j\eta_j(r/\sqrt q),
\qquad
\gamma_{d,\rm phys}=q^{-A}\sum_{j=0}^1s_j\eta_j(r/\sqrt q).
\tag{MC27}
\]

Equations (MC23)-(MC26) prove all five rows (MC24), including the negative \(RV\Delta v\) in the last row. The profile-to-chart changes multiply every row and its target by the identical factor from (MC15), so the equations also hold in the fixed \(Q\) chart. This is an exact map from the three target functions into the five-dimensional space spanned by the chosen profiles; uniqueness concerns this chosen space, not every possible smooth correction.

All denominators except \(a\) are fixed nonzero constants; \(a^{-1}\) has bounded slow derivatives for the prescribed smooth base and nonzero lower bound. Equations (MC25)-(MC27), the smooth bounded powers of \(q/Q\), and Leibniz' rule prove \(\mathcal S_\alpha\to\mathcal M_\alpha\) at every fixed derivative order. On the interior support the weight is bounded below. Constants may deteriorate as \(\lambda\downarrow0\); the construction needs no estimate uniform in that limit. At \(\lambda=0\) the two axial powers coincide, so there is a real degeneracy outside the stated parameter domain.

The axial correction has zero ordinary weighted integral and is torus independent, so (MC14) realizes it exactly: \(\Delta\gamma=\gamma_d\). Its potential vanishes below the first bump and above the last bump but may be nonzero between them. Its entire support remains in the reserved interval. The induced radial correction is in \(\mathcal M_{\alpha+1}\). This explains precisely why local base bounds must hold throughout that interval, rather than only on the union of bump supports.

## 9. Every nonlinear change and its exponent

Keep \(w\), its complete covariance, the base, and the stress fixed. Write \(B=\Delta\beta\), \(u=\Delta v\), \(d=\Delta\gamma=\gamma_d\) only within this calculation; these are the actual fields just constructed, not altered objects. The product differences are

\[
2b(\beta+B)+(\beta+B)^2-(2b\beta+\beta^2)
=2bB+2\beta B+B^2,
\]
\[
b(\gamma+d)+G(\beta+B)+(\beta+B)(\gamma+d)
-(b\gamma+G\beta+\beta\gamma)
=bd+GB+\beta d+\gamma B+Bd,
\]
\[
2V(v+u)+(v+u)^2-(2Vv+v^2)=2Vu+2vu+u^2.
\]

Substituting these three identities into (MC12) proves the exact radial-source difference

\[
g_{r,\rm new}-g_r=(2V/R)u+R_g,
\]
\[
\begin{aligned}
R_g={}&-t_*B-(D_r+1/R)(2bB+2\beta B+B^2)\\
&-D_z(bd+GB+\beta d+\gamma B+Bd)
+(2vu+u^2)/R+\epsilon(\Delta_0-R^{-2})B.
\end{aligned}
\tag{MC28}
\]

No covariance difference is present because \(w\) is unchanged. The finite-dimensional rows cancel only the displayed terms linear in the fixed base. Integrating the radial difference and the expanded flux products gives

\[
P_{\rm new}=\int\langle R_g\rangle\,dR,
\]
\[
(J_\theta)_{\rm new}=\int R^2\langle\gamma u+vd+du\rangle\,dR,
\]
\[
(J_z)_{\rm new}=\int R\langle2\gamma d+d^2\rangle\,dR
-\frac12\int R^2\langle R_g\rangle\,dR.
\tag{MC29}
\]

To verify the last cancellation, the linear part of the pressure-source moment is

\[
-\frac12\int R^2(2V/R)u\,dR=-\int RVu\,dR,
\]

which combines with \(\int2RGd\,dR\) to form the last row of (MC24). This proves the signs in (MC29) without assuming that new defects vanish.

Take the original hypotheses \(v,\gamma\in\mathcal M_{0.9}\), \(\beta\in\mathcal M_{1.9}\), targets in \(\mathcal S_\alpha\), \(\alpha\ge0.9\). Then \(u,d\in\mathcal M_\alpha\), \(B\in\mathcal M_{\alpha+1}\). All increments are torus independent. On their potential support, retain the stated base bounds \(b=O(\epsilon S_*^B)\), \(V,G=O(S_*^B)\) for every fixed coefficient derivative. The complete term list is:

| Term in \(R_g\) | Guaranteed exponent |
|---|---|
| \(-t_*B=+\epsilon\partial_TB\) | \(\alpha+2\) |
| \(-(D_r+1/R)(2bB)\) | \(\alpha+2-\kappa_s\) |
| \(-(D_r+1/R)(2\beta B)\) | \(\alpha+2.9-\kappa_s\) |
| \(-(D_r+1/R)B^2\) | \(2\alpha+2-\kappa_s\) |
| \(-D_z(bd)\) | \(\alpha+2\) |
| \(-D_z(GB)\) | \(\alpha+2\) |
| \(-D_z(\beta d)\) | \(\alpha+2.9\) |
| \(-D_z(\gamma B)\) | \(\alpha+2.9\) |
| \(-D_z(Bd)\) | \(2\alpha+2\) |
| \(2vu/R\) | \(\alpha+0.9\) |
| \(u^2/R\) | \(2\alpha\) |
| \(\epsilon D_r^2B\) | \(\alpha+2-2\kappa_s\) |
| \(\epsilon R^{-1}D_rB\) | \(\alpha+2-\kappa_s\) |
| \(\epsilon D_z^2B\) | \(\alpha+4\) |
| \(-\epsilon R^{-2}B\) | \(\alpha+2\) |

Every exponent is at least \(\alpha+0.9-2\kappa_s\): the only potentially tight quadratic one is \(2\alpha\), and \(2\alpha-(\alpha+0.9-2\kappa_s)=\alpha-0.9+2\kappa_s\ge2\kappa_s>0\). All remaining comparisons follow by subtraction and \(\alpha\ge0.9\). Thus

\[
R_g\in\mathcal M_{\alpha+0.9-2\kappa_s},\qquad
(P_{\rm new},(J_\theta)_{\rm new},(J_z)_{\rm new})
\in\mathcal S_{\alpha+0.9-2\kappa_s}.
\tag{MC30}
\]

The two product-only defects in (MC29) actually have bounds \(\alpha+0.9\) and \(2\alpha\) before the \(R_g\) moment is added. The table records every transport and viscous term, including those compressed into the source proof's remaining-transport statement.

## 10. Recalculation, endpoint scope, and audit disposition

The exact construction order is forced by the definitions: calculate the full \(W^{ab}\) and \(g_r\) from the current actual velocity; calculate \(P\) and \(p_m\); calculate \(E_\theta,E_z\) with that pressure; calculate \(J_\theta,J_z\) from the same \(g_r\) and velocity. Repeat this sequence after every update. In particular, the temporal correction's \(a=-A_1\gamma_d\) must occur in all new products. It is insufficient that \(\bar a=0\): for example \(\overline{a^2}\) can be positive. The exact difference formulas (MC28)-(MC29) apply to the slow five-dimensional update, whose axial remainder is identically zero.

All local operations preserve one-sided slow derivatives on closed positive-\(q\) regions because the radial integrals have fixed-shift formulas, Fourier inverse estimates use finitely many derivatives for each requested derivative, and matrix coefficients are smooth functions of the slow data. This statement carries the actual source regularity through those operators; it does not construct missing source regularity. On \(q\ge c_0>0\), only finitely many bands occur, so no accumulation of covering changes is involved. Near \(q=0\), physical flatness of the radial cutoff remainders was proved in Section 3.

The verified results of this bounded audit are the full radial exact sequence and its cutoff splitting; all derivative losses for the primitive and time inverse; the exact solenoidal velocity realization; the complete integrated mean residual identities; an explicit inverse of the five moment rows; and the exact nonlinear recomputation and stated exponent gain. No Section 8 repair is required by these calculations. This conclusion is limited to these maps and estimates. The actual base input, wave construction, iteration, and passage to an exact solution remain separate portions of the coordinated source audit, listed precisely in `DEPENDENCIES.md`.
