"""Exact independent checks for Section 8, using the Python standard library.

These finite checks supplement the proofs in AUDIT.md; they do not certify a PDE
endpoint or the analytic estimates. Sparse Laurent polynomials retain every jet,
coordinate factor, sign, and rational coefficient in the tested identities.
"""
from fractions import Fraction as F
from pathlib import Path
import json


def key(powers):
    return tuple(sorted((n, p) for n, p in powers.items() if p))


class P:
    def __init__(self, terms=None):
        self.terms = {k: F(v) for k, v in (terms or {}).items() if v}

    @classmethod
    def constant(cls, x):
        return cls({(): F(x)})

    @classmethod
    def atom(cls, name, exponent=1):
        return cls({((name, exponent),): F(1)})

    @staticmethod
    def coerce(x):
        return x if isinstance(x, P) else P.constant(x)

    def __add__(self, other):
        other = self.coerce(other)
        out = dict(self.terms)
        for k, v in other.terms.items():
            out[k] = out.get(k, 0) + v
        return P(out)

    __radd__ = __add__

    def __neg__(self):
        return P({k: -v for k, v in self.terms.items()})

    def __sub__(self, other):
        return self + -self.coerce(other)

    def __rsub__(self, other):
        return self.coerce(other) + -self

    def __mul__(self, other):
        other = self.coerce(other)
        out = {}
        for ka, va in self.terms.items():
            for kb, vb in other.terms.items():
                powers = dict(ka)
                for n, p in kb:
                    powers[n] = powers.get(n, 0) + p
                k = key(powers)
                out[k] = out.get(k, 0) + va * vb
        return P(out)

    __rmul__ = __mul__

    def __pow__(self, exponent):
        assert exponent >= 0
        out = self.constant(1)
        for _ in range(exponent):
            out = out * self
        return out

    def derivative(self, direction):
        out = P()
        for monomial, coefficient in self.terms.items():
            for name, exponent in monomial:
                if name == '@R' and direction != 'R':
                    continue
                powers = dict(monomial)
                powers[name] -= 1
                if name != '@R':
                    root, _, jets = name.partition(':')
                    target = root + ':' + ''.join(sorted(jets + direction))
                    powers[target] = powers.get(target, 0) + 1
                out += P({key(powers): coefficient * exponent})
        return out


results = []


def identity(name, left, right):
    delta = P.coerce(left) - P.coerce(right)
    assert not delta.terms, (name, delta.terms)
    results.append({'name': name, 'status': 'exact equality',
                    'unmatched_monomials': len(delta.terms)})


def dr(f):
    return f.derivative('R')


def dz(f):
    return f.derivative('Z')


def dt(f):
    return f.derivative('T')


r = P.atom('@R')
ri = P.atom('@R', -1)
ri2 = P.atom('@R', -2)
b, V, G, beta, v, gamma, B, u, d, eps = [
    P.atom(n) for n in ['b', 'V', 'G', 'beta', 'v', 'gamma',
                        'Delta_beta', 'Delta_v', 'Delta_gamma', 'epsilon']]
Wrr, Wzr, Wtt = [P.atom(n) for n in ['Wrr', 'Wzr', 'Wtt']]


def radial_div(f, e):
    return dr(f) + e * ri * f


def lap(f):
    return dr(dr(f)) + ri * dr(f) + dz(dz(f))


def radial_source(beta_arg, v_arg, gamma_arg):
    return (-dt(beta_arg)
            - radial_div(2 * b * beta_arg + beta_arg**2 + Wrr, 1)
            - dz(b * gamma_arg + G * beta_arg + beta_arg * gamma_arg + Wzr)
            + ri * (2 * V * v_arg + v_arg**2 + Wtt)
            + eps * (lap(beta_arg) - ri2 * beta_arg))


old = radial_source(beta, v, gamma)
new = radial_source(beta + B, v + u, gamma + d)
Rg = (-dt(B) - radial_div(2*b*B + 2*beta*B + B**2, 1)
      - dz(b*d + G*B + beta*d + gamma*B + B*d)
      + ri*(2*v*u + u**2) + eps*(lap(B)-ri2*B))
identity('Full radial-source increment, (8.26)', new-old, 2*ri*V*u + Rg)

Jtheta_old = r**2 * (G*v + V*gamma + gamma*v)
Jtheta_new = r**2 * (G*(v+u) + V*(gamma+d) + (gamma+d)*(v+u))
identity('Angular flux difference before moment cancellation',
         Jtheta_new-Jtheta_old-r**2*(G*u+V*d),
         r**2*(gamma*u+v*d+d*u))
Jz_old = r*(2*G*gamma+gamma**2)-F(1,2)*r**2*old
Jz_new = r*(2*G*(gamma+d)+(gamma+d)**2)-F(1,2)*r**2*new
identity('Axial flux difference before moment cancellation',
         Jz_new-Jz_old-(2*r*G*d-r*V*u),
         r*(2*gamma*d+d**2)-F(1,2)*r**2*Rg)

phi = P.atom('Psi')
identity('Meridional potential has exact zero divergence',
         radial_div(-dz(phi), 1) + dz(radial_div(phi, 1)), 0)
for e in [0, 1, 2]:
    f = P.atom('f')
    identity(f'Weighted divergence integrating factor, e={e}',
             r**e * radial_div(f, e), dr(r**e*f))

# Exact eigenvector computations in Q(sqrt(2)).
def qadd(x, y):
    return (x[0]+y[0], x[1]+y[1])


def qmul(x, y):
    return (x[0]*y[0]+2*x[1]*y[1], x[0]*y[1]+x[1]*y[0])


J = [[3, 1], [1, 5]]
vr, vt = [(F(1), F(0)), (F(1), F(-1))], [(F(-1), F(1)), (F(1), F(0))]
for name, vector, eigenvalue in [
        ('radial eigenvector', vr, (F(4), F(-1))),
        ('temporal eigenvector', vt, (F(4), F(1)))]:
    left = [qadd(qmul((F(row[0]), F(0)), vector[0]),
                 qmul((F(row[1]), F(0)), vector[1])) for row in J]
    assert left == [qmul(eigenvalue, x) for x in vector]
    results.append({'name': name, 'status': 'exact equality in Q(sqrt(2))'})

# Generic symbolic Vandermonde determinant, not a floating-point test.
t0, t1, t2 = [P.atom(n) for n in ['t0', 't1', 't2']]
det = t1*t2**2-t2*t1**2-t0*t2**2+t0*t1**2+t0**2*t2-t0**2*t1
identity('Angular Vandermonde determinant', det,
         (t1-t0)*(t2-t0)*(t2-t1))

# Exact interpolation realization at original valid lambda=1/2, d=log(2).
# The positive mu values are left arbitrary in the proof; this instance checks
# all five signs using rational values, without approximating exponentials.
nodes = [F(4), F(1,8), F(1,2)]
a = F(3,2)
mu2, mum3, mum1, mu1, mu0 = map(F, [2, 3, 5, 7, 11])
Pq, Jtq, Jzq = F(13,7), F(-17,9), F(19,5)
bb1, bb2 = -Pq/(2*a*mum3), Jzq/(a*mum1)
ucoeff = [F(0), F(0), F(0)]
for value, idx, other in [(bb1, 1, 2), (bb2, 2, 1)]:
    scale = value/((nodes[idx]-nodes[0])*(nodes[idx]-nodes[other]))
    coefficients = [nodes[0]*nodes[other], -(nodes[0]+nodes[other]), F(1)]
    ucoeff = [ucoeff[j]+scale*coefficients[j] for j in range(3)]
cp = lambda x: sum(ucoeff[j]*x**j for j in range(3))
s1 = -Jtq/(a*mu0*(F(1)-F(2)))
s0 = -2*s1
actual_rows = [mu2*cp(nodes[0]), mu1*(s0+2*s1),
               2*a*mum3*cp(nodes[1]), a*mu0*(s0+s1),
               -a*mum1*cp(nodes[2])]
assert actual_rows == [0, 0, -Pq, -Jtq, -Jzq]
results.append({'name': 'All five moment rows in a valid exact instance',
                'status': 'exact rational equality',
                'rows': [str(x) for x in actual_rows]})

# Every exponent is affine in alpha. Checking slope and endpoint proves the
# inequality on the entire half-line alpha >= 9/10, not only a finite sample.
kappa = F(1, 100000)
exponents = {
    'time': (1, F(2)), 'radial bB': (1, F(2)-kappa),
    'radial betaB': (1, F(29,10)-kappa),
    'radial B squared': (2, F(2)-kappa),
    'axial bd': (1,F(2)), 'axial GB': (1,F(2)),
    'axial beta d': (1,F(29,10)), 'axial gamma B': (1,F(29,10)),
    'axial B d': (2,F(2)), 'azimuthal vu': (1,F(9,10)),
    'azimuthal u squared': (2,F(0)), 'radial second viscosity': (1,F(2)-2*kappa),
    'radial first viscosity': (1,F(2)-kappa),
    'axial viscosity': (1,F(4)), 'zeroth viscosity': (1,F(2))}
for name, (slope, intercept) in exponents.items():
    difference_slope = slope-1
    difference_at_endpoint = difference_slope*F(9,10) + intercept-F(9,10)+2*kappa
    assert difference_slope >= 0 and difference_at_endpoint >= 0
    results.append({'name': 'Exponent inequality: '+name,
                    'status': 'proved for alpha >= 9/10 by affine coefficients',
                    'difference_slope': str(difference_slope),
                    'difference_at_alpha_9_over_10': str(difference_at_endpoint)})

report = {'source_sha256': '8c8a94ad9ac824c8b605b9827cadf7beaca48bd10b380de3cfc872a2c37afa81',
          'scope': 'Section 8 exact algebra only; no analytic or PDE endpoint certification',
          'check_count': len(results), 'all_passed': True, 'checks': results}
out = Path(__file__).with_name('exact_checks.json')
out.write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'all_passed': True, 'check_count': len(results), 'report': str(out)}))
