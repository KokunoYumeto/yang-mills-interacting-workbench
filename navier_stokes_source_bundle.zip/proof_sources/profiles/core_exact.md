# Exact leading-field maps and radial primitives

This is an independent derivation of the mathematical identities used on printed pp. 24-31 and 41-45 of *Finite Time Blowup for Navier-Stokes*, source SHA-256 `8c8a94ad9ac824c8b605b9827cadf7beaca48bd10b380de3cfc872a2c37afa81`. The symbols below retain their source values and orientations. Equations are mathematical identities; the accompanying arguments are independently written. The construction of the complete outer profile and the wave cone is recorded separately in the dependency ledger, not assumed to have been validated by this file.

The completed source construction chooses and fixes \(0<h<1/100\). That restriction is retained throughout its use here. The coordinate lemma itself has the larger validity range \(0<h<1/2\), which is stated below solely to record its precise domain; it does not enlarge the construction's chosen parameter range.

## 1. Coordinates and their exact Jacobian

Take right-handed cylindrical coordinates
\[
x=(r\cos\theta,r\sin\theta,z),\quad e_\theta=(-\sin\theta,\cos\theta,0),
\quad \theta\in\mathbb R/(2\pi\mathbb Z),\quad s=r^2/2.
\]
Put
\[
\begin{aligned}
&\tau=1-t>0,\quad A=\tfrac12+h,\quad D=\tfrac12-h,\quad 0<h<\tfrac12,\\
&z=q^D\eta,\quad \tau=q(1-\eta^2),\quad X=s/q,\\
&d=1-\eta^2,\quad L=1-2h\eta^2.
\end{aligned}
\]
For fixed \(\tau>0,z\in\mathbb R\), eliminating \(\eta\) gives
\(g(q)=q-z^2q^{2h}=\tau\). At \(q_*=|z|^{1/D}\), \(g(q_*)=0\); for \(z=0\) take \(q_*=0\). For \(q>q_*\), \(z^2q^{2h-1}<1\), and
\[
g'(q)=1-2hz^2q^{2h-1}\ge1-2h>0.
\]
Moreover \(g(q)\to\infty\). Thus exactly one \(q>q_*\) exists, \(|\eta|<1\), and the implicit function theorem makes \(q,\eta\) smooth for \(t<1\). The values \(\eta=\pm1\) used for profiles are one-sided parameter endpoints; they are not additional points with \(\tau>0\).

Differentiation at fixed physical coordinates gives
\[
q_t=-L^{-1},\quad \eta_t=\frac{D\eta}{qL},\quad X_t=\frac X{qL},
\qquad q_z=\frac{2\eta q^{1-D}}L,
\quad \eta_z=\frac d{q^DL},\quad X_z=-\frac{2\eta X}{q^DL}.
\]
The formula for \(\eta_z\) uses the exact equality \(L-2D\eta^2=d\). Consequently, for every real \(b\) and smooth profile \(f\),
\[
\partial_t(q^bf)=q^{b-1}L^{-1}(-bf+D\eta f_\eta+Xf_X),
\]
\[
\partial_z(q^bf)=q^{b-D}L^{-1}(2b\eta f+df_\eta-2\eta Xf_X).
\]
No constant or power of \(q\) is discarded in these maps.

## 2. Cartesian axis extension and incompressibility

Let \(C>1\), \(F=\phi/C\), \(E=\sqrt{2X}F\), and prescribe
\[
u_\theta=q^{-A}E,\quad u_z=q^{-A}U,\quad ru_r=V_0=Xv_0,
\quad p=q^{-2A}\Pi.
\]
For \(F,U,v_0,\Pi\) smooth on \([0,R]\times[-1,1]\), the Cartesian components are exactly
\[
u_1=\frac{v_0}{2q}x_1-q^{-A-1/2}Fx_2,
\quad u_2=\frac{v_0}{2q}x_2+q^{-A-1/2}Fx_1,
\quad u_3=q^{-A}U.
\]
Since \(X=(x_1^2+x_2^2)/(2q)\), these formulas prove smoothness across \(r=0\) for each \(t<1\). Smoothness is imposed on \(F\), not on \(E\) as a function of \(X\). This explicitly proves the map from scalar profile regularity to Cartesian velocity regularity.

Incompressibility is
\(\partial_s(ru_r)+\partial_zu_z=0\). Because \(A+D=1\), its exact scalar equation is
\[
(V_0)_X=L^{-1}(2A\eta U-dU_\eta+2\eta XU_X).
\]
Integrate with \(V_0(0,\eta)=0\). Writing \(M(X,\eta)=\int_0^XU(x,\eta)\,dx\), the result is
\[
V_0=\frac{2\eta XU-2D\eta M-dM_\eta}{L}.
\]
The extension of \(M/X\) at zero is smooth because
\(M/X=\int_0^1U(vX,\eta)\,dv\); differentiating this integral proves every mixed derivative assertion. Thus the formula also proves smoothness of \(V_0/X\).

The radial derivative of pressure and centrifugal term have the common factor \(q^{-2A-1/2}\), with respective coefficients \(\sqrt{2X}\Pi_X\) and \(E^2/\sqrt{2X}\). Their exact equality is
\[
\Pi_X=\frac{E^2}{2X}=F^2.
\]
The other radial terms are still present in the full Navier-Stokes residual. Radial time differentiation, both material-transport contributions and radial viscosity have scale \(q^{-3/2}=q^{2h}q^{-2A-1/2}\). Axial viscosity of the radial velocity has scale \(q^{-1/2-2D}=q^{-3/2+2h}=q^{4h}q^{-2A-1/2}\). Axial viscosity has scale \(q^{-A-2D}=q^{2h}q^{-A-1}\) in the tangential equations. These equalities identify every remaining type of term without setting any of them to zero.

## 3. Exact transport and stress integration

All residual identities here have viscosity one, as defined on source p. 6. Define
\[
H=\sqrt{2X}E=2XF,\quad l=X\partial_X\log H,
\quad W=1-\frac{2D\eta M+dM_\eta}{X},\quad H_c=D\eta+dU.
\]
Applying the preceding derivative maps and \(u_r=V_0/r\) gives, for arbitrary \(b,f\),
\[
(\partial_t+u_r\partial_r+u_z\partial_z)(q^bf)
=\frac{q^{b-1}}L\{W Xf_X+H_cf_\eta-b(1-2\eta U)f\}.
\]
Indeed the coefficient of \(Xf_X\) before substituting \(V_0\) is \(1+LV_0/X-2\eta U\), exactly \(W\). Angular momentum is \(ru_\theta=q^{-h}H\). Hence the angular material derivative equals \(-q^{-h-1}HS_q/L\), where
\[
S_q=-Wl-h(1-2\eta U)-H_c(\log E)_\eta.
\]
For the axial velocity, add \(\partial_zp\). Since \(-2A-D=-A-1\), the result is \(-q^{-A-1}S_n/L\), with
\[
S_n=-WXU_X-A(1-2\eta U)U-H_cU_\eta
-d\Pi_\eta+4A\eta\Pi+2\eta X\Pi_X.
\]

Let \(D_X=X\partial_X\). Solve
\[
D_XQ_s+(1+l)Q_s=S_q,\qquad D_XN_s+N_s=S_n.
\]
Their integrating factors are \(XH\) and \(X\). For \(\phi>0\) smooth at the axis, \(H=2X\phi/C\), and any nonzero integration constant produces an \(X^{-2}\) singularity in \(Q_s\) or an \(X^{-1}\) singularity in \(N_s\). Therefore the unique regular choices are
\[
Q_s=\frac{\int_0^XHS_q\,dx}{XH},\qquad
N_s=\frac1X\int_0^XS_n\,dx.
\]
In particular,
\[
Q_s=\frac1{F(X,\eta)}\int_0^1vF(vX,\eta)S_q(vX,\eta)\,dv,
\quad N_s=\int_0^1S_n(vX,\eta)\,dv,
\]
which prove the scalar smooth extensions and give \(Q_s(0)=S_q(0)/2\), \(N_s(0)=S_n(0)\).

Define
\[
\begin{aligned}
&p_s=\left(\frac{XQ_s}L,\frac{XN_s}{LE}\right),\quad a=1-2D_X\log E=2-2l,\\
&b_s=\frac{2D_XU}{E},\quad s_{\rm shear}=(a,-b_s),\quad T_0=F(p_s-s_{\rm shear}).
\end{aligned}
\]
Here \(s_{\rm shear}\) is only a typographical disambiguation from the unchanged coordinate \(s=r^2/2\); it is exactly the manuscript's vector \(s\). The stress components remain ordered \((r\theta,rz)\).

For any profile \(G\), at fixed \(t,z\),
\[
(\partial_r+k/r)(q^{-A-1/2}G)
=q^{-A-1}\left(\sqrt{2X}\,G_X+\frac k{\sqrt{2X}}G\right).
\]
Substituting \(G=FXQ_s/L=HQ_s/(2L)\), \(k=2\), produces \(q^{-A-1}ES_q/L\). Substituting \(G=FXN_s/(LE)=\sqrt{X/2}N_s/L\), \(k=1\), produces \(q^{-A-1}S_n/L\). The remaining stress terms are exactly
\[
\partial_ru_\theta-u_\theta/r=-q^{-A-1/2}Fa,
\qquad \partial_ru_z=q^{-A-1/2}Fb_s.
\]
The differential identities
\[
(\partial_r+2/r)(\partial_ru_\theta-u_\theta/r)
=\partial_{rr}u_\theta+r^{-1}\partial_ru_\theta-r^{-2}u_\theta,
\]
\[
(\partial_r+1/r)\partial_ru_z=\partial_{rr}u_z+r^{-1}\partial_ru_z
\]
now prove, including both signs,
\[
R^{(0)}_\theta=-(\partial_r+2/r)(q^{-A-1/2}T_{0,\theta}),
\quad R^{(0)}_z=-(\partial_r+1/r)(q^{-A-1/2}T_{0,z}),
\]
where \(R^{(0)}_j=\mathcal R(u,p)\cdot e_j+\partial_{zz}u_j\). Thus only axial viscosity has been removed from these exact identities.

Zero stress is equivalent to
\(Q_s=-2L\phi_X/\phi\) and \(N_s=-2LU_X\). Applying the two radial operators and canceling the two opposite quadratic logarithmic-derivative terms gives exactly
\[
-2L\frac{X\phi_{XX}+2\phi_X}{\phi}=S_q,
\qquad -2L(XU_{XX}+U_X)=S_n.
\]
Conversely, these equations and regularity imply the same \(Q_s,N_s\), by uniqueness of the regular radial primitives, hence zero stress. The first displayed fraction was checked directly against PDF p. 27.

## 4. The five moments and their exact matching map

Retain all five quantities
\[
\begin{aligned}
&M=\int_0^XU\,dx,\quad I=\int_0^XH\,dx,\quad J=\int_0^XUH\,dx,\\
&S=\int_0^X(U^2-E^2/2)\,dx,\quad C_p=\int_0^X\frac{E^2}{2x}\,dx,\quad \Pi=\Pi_{\rm ax}+C_p.
\end{aligned}
\]
Since \((XW)_X=1-2D\eta U-dU_\eta\), integration by parts in \(-WXH_X\) gives \(-XWH\) and the remaining integrand
\((1-h)H-D\eta H_\eta-d(UH)_\eta+2(h-D)\eta UH\). Hence
\[
Q_s=-W+\frac{(1-h)I-D\eta I_\eta-dJ_\eta+2(h-D)\eta J}{XH}.
\]
For the axial primitive, integrate \(-WXU_X\) in the same way. Its velocity terms become
\(D(U-\eta U_\eta)+4h\eta U^2-d(U^2)_\eta\). Pressure contributes
\[
X(4A\eta\Pi-d\Pi_\eta)-2h\eta\int_0^XE^2\,dx
+\frac d2\partial_\eta\int_0^XE^2\,dx,
\]
because \(\int_0^X\Pi\,dx=X\Pi-\frac12\int_0^XE^2\,dx\). Thus
\[
N_s=-WU+\frac{D(M-\eta M_\eta)+4h\eta S-dS_\eta}{X}
+4A\eta\Pi-d\Pi_\eta.
\]
The independent exact check differentiates both right-hand primitives, retains \(\Pi_X=H^2/(4X^2)\), and obtains precisely \(HS_q\) and \(S_n\).

If two pairs \((U_i,E_i)\) agree for \(X\ge X_h>0\) and their five moment values at \(X_h\) agree as functions of \(\eta\), all five moment differences are identically zero beyond \(X_h\): their radial derivatives are zero and their initial values are zero. All parameter derivatives also agree. With the same \(\Pi_{\rm ax}\), the explicit formulas then give identical \(\Pi,V_0,Q_s,N_s,p_s\). Agreement of profiles on an interval gives agreement of radial derivatives, hence of \(a,b_s,T_0\). This proves the complete morphism from matching data to the exterior field and stress; pressure matching alone would not suffice.

On a compact \(X\)-rectangle bounded away from zero and with \(E_i\ge e_{\min}>0\), the displayed formulas are compositions of addition, multiplication and reciprocal on denominators \(X,L,E,H\) bounded away from zero. For example
\(H_2^{-1}-H_1^{-1}=-(H_2-H_1)/(H_1H_2)\). The product rule through \(k\) parameter derivatives bounds the output difference in \((Q_s,N_s,p_s)\) by the input differences in \((U,E,M,I,J,S,C_p)\) through order \(k+1\). This uses no radial derivative of the difference. The one extra parameter derivative is necessary because \(W\) contains \(M_\eta\) and the primitive formulas contain moment derivatives.

Under the exact coordinate substitution \(X=\rho x\), use
\[
\widehat U(x,\eta)=U(\rho x,\eta),\quad\widehat E(x,\eta)=E(\rho x,\eta),
\quad H=\rho^{1/2}\widehat H,
\]
\[
(M,I,J,S,C_p)=(\rho\widehat M,\rho^{3/2}\widehat I,
\rho^{3/2}\widehat J,\rho\widehat S,\widehat C_p),
\quad\widehat Q_s=Q_s,\quad\widehat N_s=N_s,\quad\widehat p_s=\rho^{-1}p_s.
\]
Direct substitution proves that precisely the same rational formulas hold on the fixed \(x\)-rectangle. This is an invertible change of variables retaining all factors, not a replacement of the original moment data.

## 5. Cone equivalence and finite-dimensional solve

For \(a>0\), define
\[
t_s=-b_s/a,\quad v_s=a(1+t_s^2),\quad P_c=p_{s,1}+t_sp_{s,2},\quad
J_c=p_{s,2}-t_sp_{s,1}.
\]
The roots in \(v\) of \(2(P_c-v)^2-(v-2)J_c^2\) are
\[
v_\pm=P_c+J_c^2/4\pm |J_c|\sqrt{(P_c-2)/2+J_c^2/16}.
\]
For \(P_c>2\), evaluate the polynomial at \(2\) and \(P_c\): it is positive at \(2\), nonpositive at \(P_c\), and has its vertex at or above \(P_c\). Consequently \(2<v_-\le P_c\). This includes \(J_c=0\), where the two roots are \(P_c\). Therefore for \(v_s>2\), the admissible inequality \(v_s<v_-\) is exactly
\[
P_c>v_s,\qquad (v_s-2)J_c^2<2(P_c-v_s)^2.
\]
In particular \(v_s\le2\), \(P_c>2\) always implies the strict relaxed inequality \(v_s<v_-\).

For \(p_{s,2}=wp_{s,1}\), put \(c=1-b_sw/a\), \(j=w+b_s/a\), \(v=a+b_s^2/a\). Direct expansion gives
\[
(v-2)j^2-2c^2=(1+b_s^2/a^2)((a-2)w^2+2b_sw+b_s^2/a-2).
\]
On the compact set specified in Lemma 4.5, choose actual minima \(c_K>0\), \(\gamma_K=\min(2c^2-(v-2)j^2)>0\), and \(B_K\ge\max\{1,v,cv\}\). For
\[
p_{s,1}\ge P_K=\max\{(B_K+2)/c_K,8B_K/\gamma_K\},
\]
one has \(P_c>\max\{2,v\}\) and
\[
\frac{2(P_c-v)^2-(v-2)J_c^2}{p_{s,1}^2}
\ge\gamma_K-4B_K/p_{s,1}\ge\gamma_K/2.
\]
These are exactly the source constants, with the endpoint \(v=2\) covered by the preceding root calculation.

Stress coordinates satisfy, by direct scalar products,
\[
T_{0,\theta}+t_sT_{0,z}=F(P_c-v_s),\quad
T_{0,z}-t_sT_{0,\theta}=FJ_c.
\]
Thus a positive margin for the two stress inequalities proves nonvanishing and controls direction independently of magnitude.

For completeness, the moment matrix invertibility used later is proved as follows. Distinct real exponents \(\alpha_i\) form a Chebyshev family on \((0,\infty)\). For \(m\) exponents, divide a nonzero combination by its smallest power and differentiate. If the original combination had \(m\) distinct positive zeros, Rolle's theorem would give \(m-1\) zeros of a combination of \(m-1\) distinct powers, contradicting the induction starting with one nonzero power. Therefore the determinant \(\det[x_j^{\alpha_i}]\) never vanishes for ordered \(x_1<\cdots<x_m\), and its sign is constant on that connected set. Multilinearity expresses the bump moment determinant as the integral of this determinant against \(\prod_j\beta_j(x_j)\ge0\). Ordered disjoint nontrivial supports make the integral nonzero. Compact smooth parameter families then have bounded inverse matrices and bounded fixed derivatives by the adjugate formula.

For the exact quadratic moment equation \(Bc+Q(c,c)=d\), multiplication by \(B^{-1}\) has norm \(\nu_k\), and \(Q\) has bilinear norm \(q_k\) on \(C^k\). On the ball of radius \(r_k=2\nu_k\|d\|_{C^k}\), the map \(c\mapsto B^{-1}(d-Q(c,c))\) has image norm at most \(r_k/2+\nu_kq_kr_k^2\) and Lipschitz constant at most \(2\nu_kq_kr_k\). The source condition \(8\nu_k^2q_k\|d\|_{C^k}\le1\) gives invariance and Lipschitz constant at most \(1/2\). Iteration from zero in \(C^0\) and \(C^k\) gives the same fixed point. Its pointwise derivative matrix is \(B+Q(c,\cdot)+Q(\cdot,c)\); the corresponding \(B^{-1}\)-perturbation has norm at most \(1/2\), proving invertibility. The finite-dimensional implicit function theorem therefore gives all higher fixed parameter derivatives without imposing infinitely many smallness conditions.

## 6. Direct heat-exterior verification

The function named \(\mathcal H\) here is exactly the source's \(H(Z)\) in (4.29), distinguished typographically from angular momentum \(H(X,\eta)\):
\[
\mathcal H(Z)=\frac1{\Gamma(1+h)}\int_0^\infty e^{-v}v^h(1+Zv)^{-h}\,dv,
\qquad Z\ge0.
\]
For each \(k\), its \(k\)-th derivative is the integral with factor \((-1)^k(h)_kv^k(1+Zv)^{-h-k}\). The integrable majorant is \((h)_ke^{-v}v^{h+k}\), proving smooth one-sided derivatives at \(Z=0\) and positivity. Differentiating
\(e^{-v}v^{h+1}(1+Zv)^{-h-1}\) with respect to \(v\) shows
\[
Z^2\mathcal H''+((2+2h)Z+1)\mathcal H'+h(1+h)\mathcal H=0.
\]
In fact the numerator of the ODE integrand after taking the common denominator \((1+Zv)^{h+2}\) is \(h(h+1-v-Zv^2)\), exactly \(h\) times that derivative numerator; both boundary values vanish. This is a full integration-by-parts proof.

For \(K=c_\infty s^{-A}\mathcal H(2\tau/s)\), let \(Z=2\tau/s\). Then
\[
\partial_tK=-2c_\infty s^{-A-1}\mathcal H',\quad
\partial_sK=c_\infty s^{-A-1}(-A\mathcal H-Z\mathcal H'),
\]
\[
(\partial_{rr}+r^{-1}\partial_r-r^{-2})K
=c_\infty s^{-A-1}\{(2A^2-\tfrac12)\mathcal H
+(4A+2)Z\mathcal H'+2Z^2\mathcal H''\}.
\]
Using \(2A^2-1/2=2h(1+h)\) and the preceding ODE proves the exact radial heat equation. Also
\[
A\mathcal H+Z\mathcal H'
=\frac1{\Gamma(1+h)}\int_0^\infty e^{-v}v^h
\frac{A+Zv/2}{(1+Zv)^{h+1}}\,dv>0,
\]
so \(K_r=rK_s<0\) for \(r>0\). Finally
\(q^{-A}c_\infty X^{-A}\mathcal H(2d/X)=c_\infty s^{-A}\mathcal H(2\tau/s)\) exactly; the exterior has no residual hidden by a coordinate substitution.
