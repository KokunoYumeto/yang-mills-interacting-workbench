# Analytic axis construction and endpoint inequalities

This independent proof calculation covers source pp. 144-150 (B.1-B.4 through Proposition B.3). It uses the exact pressure function \(\Pi_0\) prepared in Appendix A. The separate outer-profile audit must establish that preparation; the present file proves the axis operations on that specific datum and records the dependency instead of pretending to have proved Appendix A in this lane.

## 1. Axis data and the complementary parameter regions

Keep \(A=1/2+h\), \(D=1/2-h\), \(d=1-\eta^2\), \(L=1-2h\eta^2\), and the already fixed \(0<h\le10^{-2}\). The imported datum is holomorphic near \([-1,1]\), real and even on that interval, and has
\[
\Pi_0\le-\frac52P_*^2(1+\eta^2)^{-2},\qquad
\eta\Pi_0'(\eta)>0\quad(\eta\ne0).
\]
Choose \(0<j_0\le0.05\) and set exactly
\[
U_*=4\eta+j_0,\quad H_*=D\eta+dU_*,
\quad W_*=1-dU_*'-2D\eta U_*,
\]
\[
Z_*=-A(1-2\eta U_*)U_*-H_*U_*'-d\Pi_0'+4A\eta\Pi_0.
\]
For \(-1<\eta<1\),
\[
\frac{H_*}{d}=\frac{D\eta}{1-\eta^2}+4\eta+j_0,
\quad \partial_\eta(H_*/d)
=D\frac{1+\eta^2}{(1-\eta^2)^2}+4>0.
\]
Its endpoint limits are \(-\infty,+\infty\), so it has exactly one zero \(\eta_0\). Its value at zero is \(j_0>0\), hence \(\eta_0<0\). The root equation yields
\[
|\eta_0|=\frac{j_0}{4+D/(1-\eta_0^2)}.
\]
First this is at most \(j_0/4\le1/80\). Substitution back gives the useful explicit bounds \(j_0/5<|\eta_0|<j_0/4\). Further,
\[
-W_*=3-8h\eta^2+(1-2h)j_0\eta
\ge3-0.08-0.05=2.87>2.8.
\]
At the zero, \(H_*U_*'=0\) and \(-d\Pi_0'\ge0\). The term \(4A\eta_0\Pi_0\) is positive. Using \((1+\eta_0^2)^{-2}\ge1/4\), it is at least \((A/2)j_0P_*^2\). The remaining negative term has magnitude bounded by a fixed multiple of \(j_0\), since \(U_*=-D\eta_0/d\) at the zero. Therefore the already large fixed \(P_*\) gives \(Z_*(\eta_0)>0\), quantitatively at least a positive constant times \(j_0P_*^2\).

Continuity gives an open neighborhood \(V\) of \(\eta_0\) on which \(Z_*\) is bounded below by a positive number. Choose \(\delta_*>0\) smaller than half that lower bound. The compact set \(K_\delta=\{\eta:|Z_*(\eta)|\le\delta_*\}\) avoids \(V\), hence \(|H_*|\ge m>0\) there (if this set is empty, the following restriction is vacuous). Choose \(\sigma_*>0\) with \(\sigma_*^2<m^2/99\). Then
\[
\chi=\frac{H_*^2}{H_*^2+\sigma_*^2}>0.99\quad\hbox{on }K_\delta.
\]
Thus \(\chi\le0.99\) implies \(|Z_*|>\delta_*\), exactly the later endpoint alternative. Strict margins allow the same choices on a slightly larger compact interval \(I\supset[-1,1]\). There is a bounded simply connected complex neighborhood \(\Omega\) of \(I\) on whose closure \(L\) and \(H_*^2+\sigma_*^2\) are nonzero and \(\Pi_0\) is holomorphic: take a sufficiently thin neighborhood of the compact real interval, avoiding the closed zero sets.

Define
\[
\zeta_*=-\frac{LH_*}{H_*^2+\sigma_*^2},\qquad \xi_0=\Lambda\zeta_*,
\quad\phi_*(\eta)=\exp\left(\Lambda\int_0^\eta\zeta_*(w)\,dw\right).
\]
The primitive is single-valued on \(\Omega\), and \(\phi_*>0\) on \(I\). The exact identity needed below is \(H_*\zeta_*/L=-\chi\). After choosing \(\Lambda\), impose
\[
C\ge\sup_{\eta\in\Omega}|\phi_*(\eta)|.
\]
This supremum is finite after choosing \(\Omega\) with compact closure inside the holomorphic domain. Then \(g=\phi_*/C\) has a complex bound independent of both later large parameters. A real-interval bound alone would not establish the required parameter derivative bounds.

## 2. The coefficient space, with all derivative losses accounted for

Set \(Y=\Lambda X\). For coefficient sequences \(F=\sum_{\alpha\ge0}F_\alpha(\eta)Y^\alpha\), use precisely
\[
a_{\alpha\beta}=
\frac{20^{-\alpha}\rho^{-\beta}\beta!\binom{\alpha+\beta}{\beta}}
{(\alpha+1)^2(\beta+1)^2},
\qquad
\|F\|_\rho=\sup_{\alpha,\beta\ge0}\sup_{\eta\in I}
\frac{|\partial_\eta^\beta F_\alpha(\eta)|}{a_{\alpha\beta}}.
\]
Completeness follows coefficient by coefficient: a norm-Cauchy sequence converges uniformly for every derivative, and the fundamental theorem of calculus identifies each derivative limit with the derivative of its predecessor. The supremum bound passes to the limit, so this is a Banach space.

Let \(C_{\rm sq}=8\sum_{n\ge1}n^{-2}\). For \(0\le i\le N/2\), \((N+1)^2/(N-i+1)^2\le4\), while the other half has the analogous bound after \(i\mapsto N-i\). Therefore
\[
\sum_{i=0}^N\frac{(N+1)^2}{(i+1)^2(N-i+1)^2}\le C_{\rm sq}.
\]
In a coefficient product and its \(\beta\)-th derivative, the Leibniz factor \(\binom\beta k\) cancels the factorials in the two input weights. The remaining binomial quotient is at most one because
\[
\binom{i+k}{k}\binom{\alpha-i+\beta-k}{\beta-k}
\le\binom{\alpha+\beta}{\beta}.
\]
It counts subsets selecting specified numbers from the two fixed blocks. Applying the preceding convolution bound once in the radial and once in the parameter index proves
\(\|FG\|_\rho\le C_{\rm sq}^2\|F\|_\rho\|G\|_\rho\).

Define \(\mathcal I F(Y)=\int_0^YF(v)\,dv\), \(\mathcal A F=Y^{-1}\mathcal I F\), and let \(\mathcal J_\nu F\), \(\nu=1,2\), be the regular solution with zero value at \(Y=0\) of \(YG_{YY}+\nu G_Y=F\). Comparing coefficients gives
\[
(\mathcal J_\nu F)_{\alpha+1}=\frac{F_\alpha}{(\alpha+1)(\alpha+\nu)},
\quad (\mathcal J_\nu F)_0=0.
\]
The exact weight ratios are
\[
\frac{a_{\alpha\beta}}{a_{\alpha+1,\beta}}
=20\frac{(\alpha+2)^2}{(\alpha+1)^2}
\frac{\alpha+1}{\alpha+\beta+1}\le80,
\]
\[
\frac{a_{i,k+1}}{a_{i+1,k}}
=\frac{20}{\rho}(i+1)\frac{(i+2)^2}{(i+1)^2}
\frac{(k+1)^2}{(k+2)^2}\le\frac{80}{\rho}(i+1).
\]
These prove boundedness of multiplication by \(Y\), \(\mathcal I\), \(\mathcal J_\nu\), averaging (which divides coefficient \(\alpha\) by \(\alpha+1\)), and \(\partial_\eta\mathcal I\). The last assertion uses its integration divisor \(i+1\) to cancel the last factor in the second ratio.

For \(\mathcal J_\nu[(\partial_\eta F)(Y\partial_YG)]\), consider output degree \(N=\alpha+1\), split the input radial degrees as \(i\) and \(\alpha-i\), and allocate the added degree to the differentiated \(F\)-factor. Put \(I_1=i+1\), \(J_1=\alpha-i\). The weight comparison and radial inverse give, after dividing by the output weight, at most
\[
\frac{80}{\rho}\|F\|_\rho\|G\|_\rho
\sum_{i=0}^\alpha\sum_{k=0}^\beta
\frac{I_1J_1}{N(\alpha+\nu)}
\frac{(N+1)^2}{(I_1+1)^2(J_1+1)^2}
\frac{(\beta+1)^2}{(k+1)^2(\beta-k+1)^2}.
\]
The first fraction is at most one, including the zero endpoints; the two sums are bounded by \(C_{\rm sq}\). If the logarithmic derivative is absent, replace \(J_1\) by one, still giving a fraction at most one. If \(F\) is averaged, its divisor \(i+1\) cancels \(I_1\). If the parameter derivative is absent, use the first weight ratio instead. Inserting further undifferentiated factors adds the same convolution bounds with unchanged degree allocation. This proves every nonlinear operator estimate invoked below, including the case where both differentiated factors are copies of the same unknown.

A holomorphic coefficient \(b(\eta)\) bounded on a larger neighborhood belongs as degree zero to this space: Cauchy's estimate gives \(|b^{(\beta)}|\le M\beta!r^{-\beta}\), and choosing \(\rho<r\) bounds \((\beta+1)^2(\rho/r)^\beta\). This applies uniformly to \(g\), since its complex supremum is at most one.

## 3. Exact rescaling and contraction

Write the original fields as
\[
\phi=\phi_*\Phi,\quad U=U_*+\Lambda^{-1}u,
\quad \Pi=\Pi_0+\Lambda^{-1}p,
\quad p=\mathcal I(g^2\Phi^2),\quad \Phi(0)=1,\quad u(0)=0.
\]
Thus \(\Pi_X=g^2\Phi^2=\phi^2/C^2\) exactly. Set
\[
B=-2D\eta\mathcal A u-d\partial_\eta\mathcal A u,
\quad W=W_*+\Lambda^{-1}B,\quad H_c=H_*+\Lambda^{-1}du.
\]
Substitute these into the two stress-free equations in `core_exact.md`. The unchanged equations are
\[
2(Y\Phi_{YY}+2\Phi_Y)=-\chi\Phi+\Lambda^{-1}R_1,
\qquad 2(Yu_{YY}+u_Y)=-Z_*/L+\Lambda^{-1}R_2,
\]
where
\[
LR_1=[W+h(1-2\eta U)+du\zeta_*]\Phi+WY\Phi_Y+H_c\Phi_\eta,
\]
\[
LR_2=[A(1-4\eta U_*)+dU_*']u-2A\eta\Lambda^{-1}u^2
+WYu_Y+H_*u_\eta+d\Lambda^{-1}uu_\eta
-4A\eta p+d\partial_\eta p-2\eta Yp_Y.
\]
Both identities have been checked as exact rational expressions by `exact_checks.py`, before any estimate. In particular the pressure terms retain all three signs and coefficients. The angular \(-\chi\Phi\) comes from \(H_*\zeta_*/L=-\chi\); this term is order one and must be inverted, not treated as small.

The only products with both an unintegrated parameter derivative and a logarithmic radial derivative are \((\partial_\eta\mathcal A u)Y\Phi_Y\) and \((\partial_\eta\mathcal A u)Yu_Y\). They have the precise structure proved above. The term \(\partial_\eta p=\partial_\eta\mathcal I(g^2\Phi^2)\) is bounded, and \(Yp_Y=Yg^2\Phi^2\). Every other monomial is controlled by multiplication and a radial inverse, with at most one of the two derivative types. Subtracting two monomials by replacing their factors one at a time proves the corresponding local Lipschitz estimates. All constants are finite on a fixed ball, uniformly for \(\Lambda\ge1\) and \(C\) satisfying the complex bound.

Let \(M_\chi\) be the bounded multiplier norm of \(\chi\), and set \(T=\mathcal J_2\chi/2\), multiplication preceding integration. A sequence vanishing below degree \(b\) obeys
\[
\|\mathcal J_2F\|_\rho\le\frac{80}{(b+1)(b+2)}\|F\|_\rho.
\]
Multiplication by \(\chi\) preserves that vanishing order and \(\mathcal J_2\) increases it by one. Therefore
\[
\|T^k\|\le\frac{(40M_\chi)^k}{k!(k+1)!}.
\]
The absolutely convergent series \(\sum_{k\ge0}(-T)^k\) is a two-sided inverse of \(1+T\): multiply finite partial sums by \(1+T\) and use \(\|T^{k+1}\|\to0\). No smallness of \(\chi\) is required.

The center of the contraction is
\[
\Phi_0=f_0(Y\chi),\quad u_0=-\frac{YZ_*}{2L},
\qquad f_0(z)=\sum_{\alpha\ge0}\frac{(-z/2)^\alpha}{\alpha!(\alpha+1)!}.
\]
Its recurrence verifies \(2(zf_0''+2f_0')=-f_0\), \(f_0(0)=1\), so \(\Phi_0=(1+T)^{-1}1\). On the closed radius-one ball about \((\Phi_0,u_0)\), let \(M\) bound the pair
\(((1+T)^{-1}\mathcal J_2R_1/2,\mathcal J_1R_2/2)\), and let \(K\) be its Lipschitz constant. These are the finite constants supplied by the proved estimates. Choosing
\(\Lambda\ge\max\{1,2M,2K\}\) makes the map
\[
(\Phi,u)\longmapsto
\left(\Phi_0+\frac{(1+T)^{-1}\mathcal J_2R_1}{2\Lambda},
u_0+\frac{\mathcal J_1R_2}{2\Lambda}\right)
\]
invariant and a contraction with factor at most \(1/2\). Its unique fixed point has norm distance at most \(M/\Lambda\). This explicitly supplies the existential large-parameter threshold from finite operator constants.

To recover analytic functions, for \(R<20\) use
\[
\sum_{\alpha\ge0}\binom{\alpha+\beta}{\beta}(R/20)^\alpha
=(1-R/20)^{-\beta-1}.
\]
The coefficient norm therefore bounds parameter derivatives on \(|Y|\le R\) by a constant times \(\beta![\rho(1-R/20)]^{-\beta}\). It gives analytic continuation in a common positive parameter radius. Choose \(4.1<R_1<R_2<20\); Cauchy's formula on the larger radial disk and a slightly smaller parameter neighborhood gives, for every fixed \(r,s\),
\[
\sup_{[0,4.1]\times I}
\left|\partial_Y^r\partial_\eta^s(\Phi-f_0(Y\chi),u+YZ_*/(2L))\right|
\le C_{r,s}/\Lambda.
\]
The same parameter domain serves every fixed radial derivative because those derivatives use radial Cauchy estimates on the fixed larger disk. For original radial derivatives the factor is exactly \(\partial_X^r=\Lambda^r\partial_Y^r\), giving \(C_{r,s}\Lambda^{r-1}\). Real coefficients and uniqueness imply real profiles on the real rectangle.

## 4. Positivity and endpoint alternative with the original constants

For \(0\le z\le4.1\), put \(t=z/2\le2.05\). The magnitude ratio of consecutive terms of \(f_0\) is \(t/[(n+1)(n+2)]\), so the alternating tail after the cubic has decreasing magnitudes. Consequently
\[
f_0(z)\ge1-t/2+t^2/12-t^3/144
\ge305719/1152000>0.265.
\]
The cubic derivative is \(-1/2+t/6-t^2/48<0\): its discriminant is negative and its leading coefficient is negative. Its minimum is thus the displayed exact endpoint value. Grouping the alternating series after the constant term gives \(f_0\le1\). The proved \(O(\Lambda^{-1})\) bound gives \(\Phi\ge c_0>0\) when \(\Lambda\) is sufficiently large. In particular division by \(\phi\) in the original equation is justified. Uniform complex derivative bounds then give a smaller common complex domain with no zeros; derivatives of \(\log\Phi\) are bounded there.

Differentiate \(\chi=H_*^2/(H_*^2+\sigma_*^2)\):
\[
|H_*\chi'|=2|H_*'|\frac{H_*^2\sigma_*^2}{(H_*^2+\sigma_*^2)^2}
\le2\|H_*'\|_\infty\chi.
\]
Since \(f_0\) is positive and has bounded fixed derivatives on the stated compact range,
\[
|D_X\log\Phi|+|H_*\partial_\eta\log\Phi|
\le C\chi+C/\Lambda.
\]
Here \(D_X=Y\partial_Y\) and no division by \(\chi\) is used. Also
\[
-H_c\xi_0=\Lambda L\chi-du\zeta_*,\qquad
|du\zeta_*|\le C_{\sigma_*}\sqrt\chi,
\]
because \(|H_*|/(H_*^2+\sigma_*^2)\le\sigma_*^{-1}\sqrt\chi\). Thus the full source has the lower bound
\[
S_q\ge\Lambda L\chi-W_*-10h-C\chi-C_{\sigma_*}\sqrt\chi-C/\Lambda.
\]
For any fixed small \(\varepsilon>0\), Young's inequality in the exact form
\(K\sqrt\chi\le\varepsilon\Lambda L\chi+K^2/(4\varepsilon\Lambda L)\)
absorbs the square-root term. Increase \(\Lambda\) so the linear \(C\chi\) term uses the remaining part of a total \(0.05\Lambda L\chi\) allowance. Since \(-W_*>2.8\), \(10h\le0.1\), and the remaining constant error can be made at most \(0.2\), this gives
\[
S_q\ge2.5+0.95\Lambda L\chi.
\]

The integral formula
\[
Q_s(X,\eta)=\frac{\int_0^Xx\Phi(\Lambda x,\eta)S_q(x,\eta)\,dx}
{X^2\Phi(\Lambda X,\eta)}
\]
proves \(p_1/X=Q_s/L\ge c_1>0\). Stress freedom gives the exact identities
\[
p_1=\frac{XQ_s}L=a=-2Y\Phi_Y/\Phi,
\quad n_s=N_s/L=-2U_X=-2u_Y=Z_*/L+O(\Lambda^{-1}),
\quad p_2=Xn_s/E.
\]
All fixed parameter derivatives of \(\Phi,\log\Phi,u,p_1,n_s\) are bounded uniformly in subsequent \(C\), with \(\Lambda\) fixed; the radial scaling factor has already been accounted for.

At \(X_0=4/\Lambda\), first take \(\chi>0.99\), so \(t=2\chi\in(1.98,2]\). The series for \(f_0(z)+zf_0'(z)\) has terms \((-t)^n/(n!)^2\). Its alternating remainder beyond degree four is negative, giving
\[
f_0+zf_0'\le1-t+t^2/4-t^3/36+t^4/576.
\]
The derivative is \(-1+t/2-t^2/12+t^3/144\); on \([1.98,2]\) its first two terms are nonpositive and its last two have sum \(-t^2(12-t)/144<0\). Thus the polynomial decreases, and its value at \(1.98\) is exactly \(-75535511/400000000<-0.188<-0.18\). Since \(f_0\le1\),
\[
-2zf_0'/f_0=2-2(f_0+zf_0')/f_0>2.36.
\]
Taking \(\Lambda\) large gives \(p_1>2.3\).

On \(\chi\le0.99\), \(|Z_*|>\delta_*\). Since \(L\le1\) on \([-1,1]\), the preceding error estimate gives \(|n_s|\ge\delta_*/2\). At the same endpoint, exactly
\[
|p_2|=C\sqrt{2/\Lambda}\,\frac{|n_s|}{\phi_*\Phi}.
\]
For fixed \(\Lambda\), \(\phi_*\Phi\) has a finite positive upper bound independent of subsequent \(C\); \(p_1\) has a finite upper bound independent of \(C\). Thus choosing \(C\) large makes \(p_2^2/p_1>2.3\) uniformly on this complementary compact set. The two alternatives yield
\[
p_1+p_2^2/p_1>2+0.2
\quad\text{at }X_0=4/\Lambda,
\]
retaining the source's allowed \(c_{\rm ex}=0.2\). The proof uses distinct regions only after constructing their exact covering through \(\chi\) and \(Z_*\); no missing case at \(H_*=0\) remains.
