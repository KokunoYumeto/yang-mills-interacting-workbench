"""Exact algebra certificates for the bounded Section 4 / Appendix B audit.

Run with Python containing SymPy. These certificates supplement the written
proofs: they do not certify uninspected parts of the source manuscript.
No numerical sample is used as a substitute for a universal assertion.
"""
from pathlib import Path
import argparse
import hashlib
import json
from fractions import Fraction as F
import sympy as s

OUT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-pdf', type=Path, default=OUT.parents[2]/'output/navier_stokes_research_2026-09-08/lanes/web_bundle_audit/coordination/claimed_proof/openai_navier_stokes.pdf')
PDF = parser.parse_args().source_pdf
EXPECTED = '8c8a94ad9ac824c8b605b9827cadf7beaca48bd10b380de3cfc872a2c37afa81'
source_rehashed = PDF.is_file()
if source_rehashed:
    assert hashlib.sha256(PDF.read_bytes()).hexdigest() == EXPECTED, 'source revision mismatch'
results = []

def certificate(name, expression):
    # Exact polynomial/rational arithmetic, retaining the original expression
    # in this source file. This operation is a complete identity calculation.
    value = s.cancel(s.expand(expression))
    assert value == 0, (name, value)
    results.append({'name': name, 'kind': 'exact rational identity', 'result': str(value)})

h, eta, X, b, w, a, p, v, j, Y, Lam = s.symbols('h eta X b w a p v j Y Lambda', nonzero=True)
A, D, d, L = s.Rational(1, 2)+h, s.Rational(1, 2)-h, 1-eta**2, 1-2*h*eta**2
certificate('coordinate Jacobian identity L - 2 D eta^2 = d', L-2*D*eta**2-d)
certificate('A + D = 1', A+D-1)
certificate('2 A - 1 = 2 h', 2*A-1-2*h)
certificate('cone sufficient-condition factorization',
    (a+b*b/a-2)*(w+b/a)**2-2*(1-b*w/a)**2
    -(1+b*b/a**2)*((a-2)*w*w+2*b*w+b*b/a-2))
certificate('cone discriminant', (4*p+j*j)**2-8*(2*p*p+2*j*j)-j*j*(8*(p-2)+j*j))

U = s.Function('U')(X, eta)
H = s.Function('H')(X, eta)
Pi = s.Function('Pi')(X, eta)
M = s.Function('M')(X, eta)
I = s.Function('I')(X, eta)
J = s.Function('J')(X, eta)
S = s.Function('S')(X, eta)
W = 1-(2*D*eta*M+d*s.diff(M, eta))/X
SqH = -W*X*s.diff(H,X)-h*(1-2*eta*U)*H-(D*eta+d*U)*s.diff(H,eta)
Qnum = -X*W*H+(1-h)*I-D*eta*s.diff(I,eta)-d*s.diff(J,eta)+2*(h-D)*eta*J
moments = {
    s.diff(M,X): U, s.diff(M,X,eta): s.diff(U,eta),
    s.diff(I,X): H, s.diff(I,X,eta): s.diff(H,eta),
    s.diff(J,X): U*H, s.diff(J,X,eta): s.diff(U*H,eta),
    s.diff(S,X): U**2-H**2/(4*X),
    s.diff(S,X,eta): s.diff(U**2-H**2/(4*X),eta),
}
certificate('angular moment primitive derivative', s.diff(Qnum,X).subs(moments).doit()-SqH)
Sn = -W*X*s.diff(U,X)-A*(1-2*eta*U)*U-(D*eta+d*U)*s.diff(U,eta)-d*s.diff(Pi,eta)+4*A*eta*Pi+2*eta*X*s.diff(Pi,X)
Nnum = -X*W*U+D*(M-eta*s.diff(M,eta))+4*h*eta*S-d*s.diff(S,eta)+X*(4*A*eta*Pi-d*s.diff(Pi,eta))
deltaN = (s.diff(Nnum,X).subs(moments).doit()-Sn).subs({s.diff(Pi,X):H**2/(4*X**2), s.diff(Pi,X,eta):s.diff(H**2/(4*X**2),eta)}).doit()
certificate('axial moment primitive derivative retaining pressure', deltaN)

Phi = s.Function('Phi')(Y, eta)
u = s.Function('u')(Y, eta)
av = s.Function('avg_u')(Y, eta)
pr = s.Function('p')(Y, eta)
Ustar = 4*eta+s.Symbol('j0')
Hstar = D*eta+d*Ustar
Wstar = 1-d*s.diff(Ustar,eta)-2*D*eta*Ustar
zeta = s.Function('zeta_star')(eta)
ch = -Hstar*zeta/L
Piax = s.Function('Pi_axis')(eta)
Zstar = -A*(1-2*eta*Ustar)*Ustar-Hstar*s.diff(Ustar,eta)-d*s.diff(Piax,eta)+4*A*eta*Piax
UU = Ustar+u/Lam
WW = Wstar+(-2*D*eta*av-d*s.diff(av,eta))/Lam
HH = Hstar+d*u/Lam
PP = Piax+pr/Lam
Sq = -WW*(1+Y*s.diff(Phi,Y)/Phi)-h*(1-2*eta*UU)-HH*(Lam*zeta+s.diff(Phi,eta)/Phi)
R1 = ((WW+h*(1-2*eta*UU)+d*u*zeta)*Phi+WW*Y*s.diff(Phi,Y)+HH*s.diff(Phi,eta))/L
certificate('rescaled full angular source and R1', -Sq*Phi/(L*Lam)-(-ch*Phi+R1/Lam))
Sn2 = -WW*Y*s.diff(UU,Y)-A*(1-2*eta*UU)*UU-HH*s.diff(UU,eta)-d*s.diff(PP,eta)+4*A*eta*PP+2*eta*Y*s.diff(PP,Y)
R2 = ((A*(1-4*eta*Ustar)+d*s.diff(Ustar,eta))*u-2*A*eta*u*u/Lam+WW*Y*s.diff(u,Y)+Hstar*s.diff(u,eta)+d*u*s.diff(u,eta)/Lam-4*A*eta*pr+d*s.diff(pr,eta)-2*eta*Y*s.diff(pr,Y))/L
certificate('rescaled full axial source and R2', -Sn2/L-(-Zstar/L+R2/Lam))

z = s.symbols('z')
poly = sum((-z/2)**n/(s.factorial(n)*s.factorial(n+1)) for n in range(12))
certificate('f0 recurrence through degree 10', s.series(2*(z*s.diff(poly,z,2)+2*s.diff(poly,z))+poly,z,0,11).removeO())
t = F(41,20)
cubic = 1-t/2+t*t/12-t*t*t/144
assert cubic == F(305719,1152000) and cubic > F(265,1000)
t = F(99,50)
quartic = 1-t+t*t/4-t**3/36+t**4/576
assert quartic == -F(75535511,400000000) and quartic < -F(188,1000)
results.extend([
    {'name':'f0 lower endpoint', 'kind':'exact rational inequality', 'value':str(cubic), 'lower_bound':'265/1000'},
    {'name':'f0 + z f0_prime upper endpoint', 'kind':'exact rational inequality', 'value':str(quartic), 'upper_bound':'-188/1000'},
])

# Exact heat-integral ODE integrand: the result is h times a v derivative.
Z, vv = s.symbols('Z vv')
heat_numerator = (h+1)*Z**2*vv**2-((2*h+2)*Z+1)*vv*(1+Z*vv)+(h+1)*(1+Z*vv)**2
certificate('heat ODE integration-by-parts numerator', heat_numerator-(h+1-vv-Z*vv**2))
certificate('heat monotone radial derivative numerator', A*(1+Z*vv)-h*Z*vv-(A+s.Rational(1,2)*Z*vv))

report = {
    'source_pdf_sha256': EXPECTED,
    'source_capture_rehashed_this_run': source_rehashed,
    'scope':'Exact identities in Section 4 and Appendix B only; no full theorem certificate.',
    'certificates':results,
    'count':len(results),
    'status':'all exact certificates passed',
}
(OUT/'exact_checks.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
