# Continuation, exact moment repair, and assembly of the annular profile

This file gives the independent continuation derivation for source pp. 150-157 and checks the assembly on pp. 36-45. Original source parameters remain \(0<h<1/100\), \(X_0=X_a=4/\Lambda\), \(X_b^{\rm ref}=100\), \(X_i=110\). The notation \(X_b^{\rm ref}\) distinguishes the temporary number 100 in Appendix B from the final outer annular edge \(X_b=e^3X_{\rm tail}\) in Section 4; neither numerical value or role is changed. Refer to `core_exact.md` and `axis_exact.md` for all field definitions and proved identities.

## 1. The reference continuation and its estimates

The smooth step is exactly
\[
\sigma(y)=\frac{e^{-1/y^2}}{e^{-1/y^2}+e^{-1/(1-y)^2}}\quad(0<y<1),
\qquad \sigma=0\ (y\le0),\quad\sigma=1\ (y\ge1).
\]
It is increasing: the ratio of its second denominator term to its first has logarithmic derivative \(-2/(1-y)^3-2/y^3<0\). It is smooth and flat at both endpoints by the corresponding exponential formulas. Choose fixed \(\bar t>0\) with \(4e^{2\bar t}<4.1\). Set \(y=\log(X/X_0)\). For \(0<t_1\le\bar t\), retain the analytic axis profile through \(y=t_1\), then prescribe on \((t_1,2t_1)\)
\[
\partial_y\log\phi_r=(1-\sigma((y-t_1)/t_1))D_X\log\phi_{\rm nat},
\quad \partial_yU_r=(1-\sigma((y-t_1)/t_1))D_XU_{\rm nat}.
\]
After \(2t_1\) keep \(\phi_r,U_r\) constant in \(y\). All endpoint jets match because the step is flat. Pressure and the integrated coefficients continue to be computed from the axis by the original integral definitions.

The axis approximation bounds \(U_{\rm nat}-U_*\) and its fixed parameter derivatives by \(O(\Lambda^{-1})\); its cutoff variation integrates over an interval of length \(t_1\) and is \(O(t_1/\Lambda)\). Thus \(U_r-U_*\) and its radial average remain small uniformly through \(X_i\): explicitly
\[
\|\mathcal A_XU_r-U_*\|_{C^k_\eta}
\le\sup_{0\le X\le X_i}\|U_r-U_*\|_{C^k_\eta}.
\]
No factor equal to the long logarithmic interval appears. Likewise integrate the bounded natural logarithmic slope to bound \(\log\phi_r-\log\phi_*\). Its leading parameter derivative remains \(\xi_0\), with the \(O(\chi)+O(\Lambda^{-1})\) weighted-gradient errors proved for the natural solution and an additional error tending to zero with \(t_1\) after \(\Lambda\) is fixed. In particular \(CE_r=\sqrt{2X}\phi_r\), its reciprocal on \([X_0,X_i]\), and all their fixed parameter derivatives have finite bounds independent of subsequent large \(C\) and sufficiently small \(t_1\).

Pressure satisfies the exact identity and estimate
\[
\Pi_r-\Pi_0=C^{-2}\int_0^X\phi_r(x,\eta)^2\,dx,
\qquad \sup_{X\le X_i}\|\Pi_r-\Pi_0\|_{C^k_\eta}\le K_kC^{-2}.
\]
The axis factor makes this integral finite at zero. The natural shear has \(a=p_1>0\); cutting its nonpositive \(D_X\log\phi\) to zero proves \(l_r\le1\). In the angular source the unchanged large term is \(-H_*\xi_0=\Lambda L\chi\). Replacing \(H_*\) by \(H_{c,r}\) costs \(K_{\sigma_*}\sqrt\chi+o_{t_1}(1)\); the other weighted gradients cost \(K\chi+K/\Lambda\). Young's inequality as in `axis_exact.md`, now allocating a total \(0.06\Lambda L\chi\), and the strict \(-W_*>2.8\) margin give
\[
S_{q,r}\ge0.94\Lambda L\chi+2.4.
\]
Here one first enlarges \(\Lambda\), then \(C\), and then decreases \(t_1\); all residual constant errors have a strictly positive allowance. The axial source is
\[
S_{n,r}=Z_*+O(\Lambda^{-1})+o_{t_1}(1)+O(C^{-2})
\]
uniformly on the finite interval. Indeed all changes of \(U\) and of its parameter derivative are small, the logarithmic radial derivative is \(O(\Lambda^{-1})\) on the cutoff and zero later, and pressure is controlled by the preceding exact integral.

The defining primitive equations imply
\[
D_Xp_{1,r}=XS_{q,r}/L-l_rp_{1,r},\qquad
D_Xn_{s,r}+n_{s,r}=S_{n,r}/L.
\]
Positive regular initial data and \(l_r\le1\) imply \(p_{1,r}>0\). Multiplying the first inequality by the integrating factor \(e^y\), keeping the two positive source terms separately, gives
\[
p_{1,r}(y)\ge p_{1,r}(0)e^{-y}
+1.88\chi(e^y-e^{-y}),
\]
\[
p_{1,r}(X)\ge p_{1,r}(X_0)X_0/X
+1.2(X-X_0^2/X).
\]
For the first, \(X=X_0e^y=(4/\Lambda)e^y\) supplies the exact factor \(0.94\Lambda X_0/2=1.88\). For the second, use \(L\le1\), integrate \(2.4X\) against the same factor, and convert back to \(X\). On \(\chi>0.99\), the first lower bound remains above 2.3: replace its initial value by 2.3; its derivative is positive for \(y\ge0\), since \(1.88\chi>2.3/2\). On \(\chi\le0.99\), \(|Z_*|>\delta_*\), and the exact primitive for \(n_{s,r}\) retains its sign and a fixed positive lower bound when the displayed errors are small. Because \(p_{2,r}=Xn_{s,r}/E_r\), increasing \(C\) then makes \(p_{2,r}^2/p_{1,r}\) large uniformly. This proves
\[
v_r:=p_{1,r}+p_{2,r}^2/p_{1,r}>2+c
\]
on the entire reference interval, for a fixed \(c>0\). The second comparison yields \(p_{1,r}>3\) on \([100,110]\), since \(X_0\le4\). Upper bounds for \(p_{1,r},n_{s,r}\) and their fixed parameter derivatives follow directly from their integral representations and the finite coefficient bounds. They are independent of subsequent \(C\) and of the small reference widths.

## 2. Activation of stress, with division by the flat factor proved

Fix a sufficiently large finite \(C\). Choose \(t_*>0\) so the preceding bounds hold for every \(0<t_1\le t_*\). On this family, \(v_r\) has a finite common upper bound \(V_{\max}\); it may depend on \(C\), which has already been fixed. Choose \(0<\kappa_0<1/2\) later small enough relative to this bound. On \(0<y<t_1\) put
\[
e_a=(1-\kappa_0)\sigma(y/t_1),\quad\kappa=1-e_a,
\quad a=\kappa p_{1,r},\quad D_XU=-\kappa Xn_{s,r}/2,
\quad \partial_y\log\phi=-\kappa p_{1,r}/2.
\]
The natural reference is stress-free here. Therefore the exact differences obey
\[
\partial_y(\log\phi-\log\phi_r)=e_ap_{1,r}/2,
\quad \partial_y(U-U_r)=e_aXn_{s,r}/2.
\]
For a fixed parameter derivative, the integral from zero is bounded by a constant times \(ye_a(y)\), since \(e_a\) is increasing. The constants are uniform in smaller \(t_1,\kappa_0\) after \(\Lambda,C\) are fixed. The five moment differences are integrals of these value differences, with fixed smooth weights on the activation interval; their parameter derivatives have the same bound. The proved moment map in `core_exact.md`, using one further parameter derivative, then gives
\[
p_s-p_{s,r}=O(ye_a),\qquad E_r/E=1+O(ye_a).
\]
The actual shear vector is exactly
\[
s_{\rm shear}=\kappa(p_{1,r},p_{2,r}E_r/E).
\]
Because \(\kappa\) cancels before forming its slope, there is no inverse power of \(\kappa_0\) in
\[
t_s=(p_{2,r}/p_{1,r})(E_r/E),\quad
v_s=\kappa v_r+O(ye_a),\quad P_c=v_r+O(ye_a),\quad J_c=O(ye_a).
\]
Consequently \(P_c-v_s=e_av_r+O(ye_a)\ge ce_a\) for small fixed \(t_1\), and \(P_c>2+c'\). The ratio
\((v_s-2)_+J_c^2/(P_c-v_s)^2\) is at most a fixed constant times \(y^2\), hence below 2 for small \(t_1\). The exact cone equivalence proves admissibility wherever \(v_s>2\) and the relaxed condition everywhere else. Since \(v_s(0)=v_r(0)>2+c\), continuity on the compact parameter interval supplies a first collar of positive width with \(v_s>2+c/2\).

The stronger endpoint assertion requires more than an \(O(ye_a)\) estimate. Here is the exact flat-integral calculation. For \(c>0\) and smooth \(b\), substitute \(u=y/\sqrt{1+y^2v}\) to obtain
\[
\int_0^y e^{-c/u^2}u^{-j}b(u,\eta)\,du
=\tfrac12e^{-c/y^2}y^{3-j}
\int_0^\infty e^{-cv}(1+y^2v)^{(j-3)/2}
b\left(\frac y{\sqrt{1+y^2v}},\eta\right)\,dv.
\]
For each fixed derivative the final integrand is bounded by \(e^{-cv}\) times a polynomial in \(v\), uniformly on the compact parameter set; denominators \(1+y^2v\) are at least one. Differentiation under the integral proves a smooth coefficient through \(y=0\), with limiting value \(b(0,\eta)/c\). This proves the needed result from Appendix A.9 directly.

Near zero, the specific step gives \(e_a=e^{-t_1^2/y^2}g_a(y)\), where
\[
g_a(y)=\frac{1-\kappa_0}{e^{-t_1^2/y^2}+e^{-1/(1-y/t_1)^2}}
\]
extends smoothly with \(g_a(0)=(1-\kappa_0)e>0\). Taking \(j=0\) in the flat-integral formula proves
\[
\log\phi-\log\phi_r,\ U-U_r\ \in e_ay^3C^\infty.
\]
This class is preserved by smooth compositions, products with smooth functions, and division by nonvanishing fields: for example \((e^{e_ay^3b}-1)/(e_ay^3)=b\int_0^1e^{ve_ay^3b}\,dv\) is smooth. Moment and pressure differences acquire a second integration and belong to \(e_ay^6C^\infty\). Substitution into the exact moment formulas therefore shows
\[
T_0=e_aB_0(y,\eta),\qquad
B_0\in C^\infty,\qquad
B_0(0,\eta)=F(X_0,\eta)p_{s,r}(X_0,\eta)\ne0.
\]
At the endpoint the latter vector is a positive multiple of the limiting shear. Its component along \((1,t_s)\) is positive, and that along \((-t_s,1)\) is zero. Both cone-direction margins consequently stay positive on a smaller collar. Every derivative of the exponential adds only finitely many powers of \(y^{-1}\), so for every fixed mixed derivative
\[
|T_0|\ge c e^{-t_1^2/y^2},\qquad
|\partial^\alpha T_0|\le C_\alpha e^{-t_1^2/y^2}y^{-N_\alpha}.
\]
Since \(X_0>0\), converting \(y\)-derivatives to \(X\)-derivatives changes only fixed smooth coefficients. Thus the vector direction is smooth through the zero-stress edge, not merely convergent along individual paths.

## 3. Continuation to 110 and preservation of parameter analyticity

After activation retain the same shear prescription with \(\kappa=\kappa_0\) through the reference cutoff and then through \(X=100\). The natural reference slopes are nonzero only in its initial interval of length \(2t_1\). Integrating the difference on that interval gives \(O(t_1)\). Beyond it, the reference slopes vanish, and the new slopes have size at most \(\kappa_0\) times the bounded functions \(p_{1,r}/2\), \(Xn_{s,r}/2\). Integration on the fixed interval gives \(O(\kappa_0)\). Thus field values, logarithms and the required parameter derivatives differ from reference by \(O(t_1+\kappa_0)\). Their integrated coefficients obey the same estimate with finite constants depending on the already fixed \(C,\Lambda\).

Choose \(\kappa_0\) small enough that \(\kappa_0V_{\max}<1/4\) and that its comparison errors use at most one quarter of the minimum \(v_r-2\). Then choose \(t_1\) small for the other error quarters and for the activation inequalities. The same exact slope formula yields \(P_c>2+c/2\), \(v_s<1\). The relaxed cone therefore holds regardless of \(J_c\). This order works for the entire family of reference widths, avoiding a circular choice of \(\kappa_0\) from a width that itself depends on \(\kappa_0\).

Starting at \(X=100\), multiply the axial prescription by a smooth \(\beta\) from one to zero on a short logarithmic interval. The integrated coefficients change by arbitrarily small errors when the interval is short, while
\[
P_c=p_{1,r}+\beta p_{2,r}^2/p_{1,r}+o(1)>2,
\quad v_s<1,
\]
using \(p_{1,r}>3\) there. Then hold \(D_XU=0\) and interpolate \(a\) convexly from \(\kappa_0p_{1,r}\) to 0.8, after arranging \(\kappa_0\sup p_{1,r}<0.8\). During this second interval \(v_s=a\le0.8\), \(P_c=p_1>2\) by continuity and its strictly positive initial margin. Both intervals can fit strictly between 100 and 110.

On the final interval, \(a=0.8\), \(l=0.6\), \(D_XU=0\). The unchanged leading gradient and the already small field changes give \(S_q>1\): its constant source contribution is \(0.6(-W_*)>1.68\), while the large \(\Lambda L\chi\) term absorbs the previously identified weighted errors. At a hypothetical first downward crossing \(p_1=2\),
\[
D_Xp_1=XS_q/L-0.6p_1>X-1.2>0,
\]
a contradiction. Hence \(p_1>2\) persists through \(X_i=110\).

On a small first collar, all reference coefficients arise from the analytic axis solution, its derivatives and forward integrals. The only cutoffs depend on \(y\), not on \(\eta\). Choose a compact complex neighborhood on which the natural \(\Phi\), \(L\), and the relevant denominators do not vanish. Integration in the real radial variable preserves holomorphy with uniform bounds on that neighborhood. Exponentiating the prescribed logarithm preserves nonvanishing. Radial differentiation changes the cutoff bounds but does not change the holomorphic parameter domain. A smaller fixed \(t_c\in(0,t_1)\), with \(4e^{t_c}<4.1\), therefore gives the common parameter domain for \(F,U,V_0/X,\Pi\) and every fixed radial derivative throughout \([0,X_0e^{t_c}]\). Subsequent changes have later support, so their forward primitives leave this rectangle exactly unchanged.

## 4. Transition length fixed before amplitude

Let \(\ell_i=\log(CE(X_i,\eta))\), \(G_i=U(X_i,\eta)\), and \(L_0=\log(X_i/X_0)\). Write \(M_k,N_k\) for the reference bounds on \(p_{1,r},n_{s,r}\), which are independent of subsequent \(C\). Before the final interpolation the logarithmic \(\phi\) slope is \(-\kappa p_{1,r}/2\); during it the slope is a convex interpolation with \(-0.4\); after it the slope is exactly \(-0.4\). Hence
\[
\|\log\phi(X_i)\|_{C^k_\eta}
\le\|\log\phi_*+\log\Phi(4,\cdot)\|_{C^k_\eta}
+\tfrac12(M_k+0.8)L_0.
\]
Adding \(\frac12\log(2X_i)\) proves \(\|\ell_i\|_{C^k_\eta}\le B_k\), where \(B_k\) is independent of subsequent \(C\) and smaller transition widths. The axial change on activation is at most \(X_0e^{\bar t}N_kt_1/2\); the remaining small-shear part contributes at most \(X_iN_k\kappa_0/2\). The natural-axis difference is \(O(\Lambda^{-1})\) with a constant independent of \(\Lambda\). Therefore
\[
\|G_i-U_*\|_{C^k_\eta}
\le C_k^{\rm nat}/\Lambda+C_k^{\rm join}(\Lambda)(t_1+\kappa_0+\omega_{\rm fin}),
\]
where \(\omega_{\rm fin}\) is the sum of the two final logarithmic widths. No inverse cutoff width occurs in these integrals.

With \(f=(1+\eta^2)^{-1}\), choose a finite positive \(T_{\rm sh}\) satisfying exactly the source lower bound
\[
T_{\rm sh}\ge20\|\sigma'\|_\infty(B_0+\|\log f\|_\infty).
\]
For \(y_i=\log(X/X_i)\), prescribe
\[
\log E=-\log C+y_i/10+(1-\sigma(y_i/T_{\rm sh}))\ell_i
+\sigma(y_i/T_{\rm sh})\log f,\qquad U=G_i.
\]
At the left endpoint this matches \(E(X_i)\) and its radial jet, because both original and new profiles have \(D_X\log E=0.1\) there and the step is flat. At the right endpoint it matches \(C^{-1}f(X/X_i)^{1/10}\) with its entire radial jet. Direct differentiation gives
\[
l=0.6+T_{\rm sh}^{-1}\sigma'(y_i/T_{\rm sh})(\log f-\ell_i)
\in[0.55,0.65],\quad a\in[0.7,0.9],\quad b_s=0.
\]
The old parameter gradient satisfies
\(-H_c\ell_i'\ge\Lambda L\chi-K\chi-K_{\sigma_*}\sqrt\chi-K/\Lambda-o(1)\).
The new one is
\[
-H_c(\log f)'=\frac{2\eta H_c}{1+\eta^2}
\ge-Kj_0^2-K/\Lambda-o(1).
\]
For the latter bound, the exact identity
\(\eta H_*=(D+4d)\eta^2+dj_0\eta\)
and completion of the square bound its negative part by \(Kj_0^2\); the \(U-U_*\) error is already controlled. These gradients are combined with nonnegative coefficients summing to one. The old large positive term absorbs its correspondingly weighted errors, and the new negative part is small. Since \(-W\) is close to \(-W_*>2.8\) and \(l\ge0.55\), the constant contribution exceeds 1.54 before the small \(h,j_0,\Lambda^{-1}\) errors. Thus \(S_q>1\). The same crossing argument at \(p_1=2\), now \(l\le0.65\), gives \(D_Xp_1>X-1.3>0\). Since \(b_s=0\), this proves \(P_c=p_1>2\), \(v_s=a<1\), hence the relaxed cone, along the full transition and the following ideal-angular interval.

## 5. The five matching equations, including all scaling factors

Set
\[
X_R=110(CP_*)^{10},\quad x=X/X_R,\quad
X_{\rm sep}=110e^{T_{\rm sh}},\quad
x_{\rm sep}=\frac{e^{T_{\rm sh}}}{(CP_*)^{10}}.
\]
Here \(X_{\rm sep}\) is fixed before \(C\). The ideal pair is \(U_0=4\eta\), \(E_0=P_*fx^{1/10}\). The exact normalized moments are
\[
\widehat M_0=4\eta x,\quad\widehat I_0=\frac{5\sqrt2}{8}P_*fx^{8/5},
\quad\widehat J_0=4\eta\widehat I_0,
\]
\[
\widehat S_0=16\eta^2x-\frac5{12}P_*^2f^2x^{6/5},
\quad C_{p,0}=\frac52P_*^2f^2x^{1/5}.
\]
These follow by direct integration, retaining the factors
\((M,I,J,S,C_p)=(X_R\widehat M,X_R^{3/2}\widehat I,
X_R^{3/2}\widehat J,X_R\widehat S,C_p)\).

On \([0,X_{\rm sep}]\), fixed parameter derivatives of \(U\) and \(CE\) are bounded independently of later \(C\); near zero \(CE=O(\sqrt X)\). Thus
\[
\|\widehat M\|_{C^k}+\|\widehat S\|_{C^k}\le K_kx_{\rm sep},
\quad\|\widehat I\|_{C^k}+\|\widehat J\|_{C^k}
\le K_kC^{-1}x_{\rm sep}^{3/2},
\quad\|C_p\|_{C^k}\le K_kC^{-2}
\]
at \(x=x_{\rm sep}\). For pressure the proof uses the physical integral \(C^{-2}\int_0^{X_{\rm sep}}(CE)^2/(2X)\,dX\), finite because \(CE=O(\sqrt X)\). All constants are fixed before increasing \(C\). The ideal moments also tend to zero with the displayed exact powers. Their pressure increment is \(O(C^{-2})\), because \(x_{\rm sep}^{1/5}=e^{T_{\rm sh}/5}(CP_*)^{-2}\).

Beyond \(X_{\rm sep}\), the angular profile is exactly ideal, since
\(C^{-1}f(X/X_i)^{1/10}=P_*fx^{1/10}\). Choose \(C\) so \(x_{\rm sep}<e^{-8}\). Restore \(G_i\) to \(4\eta\) by a fixed smooth step on \(-8<\log x<-7\), retaining \(E_0\). The size of this change, and its fixed logarithmic radial and parameter derivatives, is bounded by fixed constants times \(\|G_i-4\eta\|\). The moment errors accumulated to the correction interval are bounded by
\[
K_k\|G_i-4\eta\|_{C^{k+1}_\eta}+o_C(1).
\]
Every relevant radial weight is integrable at zero: their actual exponents are \(0,3/5,1/5\) and \(-4/5\) for the pressure integrand, all greater than \(-1\). No divergent contribution is discarded.

On \(-6<\log x<-5\), choose two fixed ordered nonnegative bumps for \(U\), three for \(E\). At the ideal pair make the invertible row operations \(J\mapsto J-4\eta I\), \(S\mapsto S-8\eta M\), with \(4\eta\) held at its base value. The linearized axial block has weights \(1,fx^{3/5}\); the azimuthal block has weights \(x^{1/2},fx^{1/10},fx^{-9/10}\), retaining fixed nonzero factors \(P_*,\sqrt2\) in the matrix. The exponents in each block are distinct. The Chebyshev determinant proof and quadratic contraction in `core_exact.md` therefore solve all five moment equations exactly, with small smooth coefficients. The row operations do not impose that the corrected \(U\) remain constant; the full nonlinear differences still include \(\delta U\delta E\), \((\delta U)^2\), and \((\delta E)^2\).

To verify one tolerance can precede \(C\), put \(R=[e^{-8},e^{-5}]\), \(Q_{\min}=\min Q_{s,0}>0\), \(e_* =\min E_0>0\), and \(w_*=1+\max|N_{s,0}/(E_0Q_{s,0})|\) on \(R\times[-1,1]\). The ideal source is positive directly: for this pair
\[
S_{q,0}=\frac95-h+\frac{16}{5}h\eta^2
+\frac{2\eta^2(D+4d)}{1+\eta^2}>0,
\]
as \(W=-3+8h\eta^2\), \(l=3/5\), \(H_c=(D+4d)\eta\). Its regular weighted primitive gives \(Q_{s,0}>0\). The compact minima thus exist without importing the positivity of a separate abbreviated formula. The exact moment map has no \(X_R\) in \(Q_s,N_s\), so a fixed small tolerance in the fields and normalized moments through one extra parameter derivative ensures
\[
Q_s\ge Q_{\min}/2,\quad E\ge e_*/2,\quad |a-0.8|\le0.1,
\quad|N_s/(EQ_s)|\le w_*,\quad |b_s|\le0.1/(1+w_*).
\]
Then, retaining the source numbers,
\[
v_s\le0.9+0.01/0.7<1,
\quad G:=Q_s-b_sN_s/(aE)\ge(1-1/7)Q_s\ge3Q_{\min}/7,
\quad P_c=X_RxG/L.
\]
Choosing \(X_R\) large now gives \(P_c>2\) without shrinking the tolerance. First choose \(j_0\), then \(\Lambda\), so \(j_0+C_k^{\rm nat}/\Lambda\) fits the tolerance. Next fix the \(B_k\) and \(T_{\rm sh}\), then enlarge \(C\) for the vanishing moment contributions. Finally decrease \(\kappa_0,t_1,\omega_{\rm fin}\) for the remaining \(G_i\) error. These choices prove the exact order
\[
(M_d,T_d,P_*,\lambda,h)\to\text{moment tolerance},j_0
\to\delta_*,\sigma_*,\Lambda\to(B_k),T_{\rm sh}
\to C,X_R\to\kappa_0,t_1,\text{final widths}.
\]
Only finitely many parameter derivative orders need to be small. Smooth implicit differentiation supplies all remaining fixed orders after the choices. At \(X_h=X_Re^{-5}\), all five moments and both fields agree with the ideal pair, with the same axis pressure \(\Pi_0\), so the exact exterior-preservation map from `core_exact.md` applies.

## 6. The finite-frequency assembly in Section 4

The outer construction in Appendix A supplies the separate profile, its exact total moments, pressure datum and reserved intervals. The loop construction in Appendix C supplies the periodic shear family. These two existence constructions are dependencies allocated to the other audit lanes. The operations performed with their outputs in Section 4 can be checked exactly here.

The join at \(X_h\) is smooth because both pairs coincide with the same ideal pair on a neighborhood, not only at one radius. Their five matching moments and common axis pressure imply exact agreement of every integrated exterior field. In particular all total moments and the outer heat field persist. The perturbation interval \(I=[X_-,X_+]\) lies after the reserved analytic collar and before the first repair interval; its endpoints already have the admissible cone.

For the loop input \(t_\ell,\rho_\ell\) with mean \(t_s\), variance \(\rho_\ell/a\), and \(v_\ell=v_s+\rho_\ell>2\), Section 4 changes the angular parameter by
\[
\frac{d\varphi}{d\theta'}=\frac{a(1+t_\ell^2)}{2\pi v_\ell},
\quad(a_L,-b_L)=\frac{v_\ell(1,t_\ell)}{1+t_\ell^2}.
\]
The derivative is positive and its integral over \([0,2\pi]\) is
\(a(1+t_s^2+\rho_\ell/a)/v_\ell=1\). Thus it defines an orientation-preserving smooth circle coordinate of period one. Its shear mean is
\[
\int_0^1(a_L,-b_L)\,d\varphi
=\frac a{2\pi}\int_0^{2\pi}(1,t_\ell)\,d\theta'
=(a,-b_s).
\]
The compact positive derivative gives a smooth inverse including all endpoint parameter derivatives. This establishes exactly the reparameterization asserted in Lemma 4.11; the existence of \(t_\ell,\rho_\ell\) itself remains the separately audited Appendix C construction.

Take zero-mean periodic primitives \(\mathscr A,\mathscr B\) with
\[
\partial_\varphi\mathscr A=-(a_L-a_0)/2,
\quad\partial_\varphi\mathscr B=E_0(b_L-b_0)/2.
\]
They exist because the two means vanish, and they vanish near both endpoints where the loop is constant. Set
\[
E_N=E_0\exp(\mathscr A(X,\eta,N\log X)/N),
\quad U_N=U_0+\mathscr B(X,\eta,N\log X)/N.
\]
Holding phase fixed in the following slow derivatives, direct differentiation gives exactly
\[
a_N=a_L-2D_X\mathscr A/N,
\quad b_N=e^{-\mathscr A/N}
\left(b_L+2D_X\mathscr B/(NE_0)\right).
\]
Since the phase has no \(\eta\)-dependence and all intervals are fixed, field differences and fixed parameter derivatives are \(O(N^{-1})\), while the actual shear differs from the desired loop by \(O(N^{-1})\). The five exact integrands of the changes, writing \(u_N=U_N-U_0\), \(e_N=E_N-E_0\), are
\[
u_N,\quad\sqrt{2X}e_N,\quad H_0u_N+U_0\sqrt{2X}e_N+\sqrt{2X}u_Ne_N,
\]
\[
2U_0u_N+u_N^2-E_0e_N-e_N^2/2,
\quad E_0e_N/X+e_N^2/(2X).
\]
Integration on the fixed interval preserves \(O(N^{-1})\) bounds. The moment map, using one extra parameter derivative, gives \(p_{s,N}-p_{s,0}=O(N^{-1})\) without assuming small radial derivatives of the field changes.

The four defining gaps are the components of the smooth map
\[
\Psi(a,b,p)=\left(a,v-2,c-v,2(c-v)^2-(v-2)j^2\right),
\quad v=a+b^2/a,\ c=p_1-bp_2/a,\ j=p_2+bp_1/a.
\]
The loop and unchanged admissible part have positive compact minima \(\mu_L,\mu_R\). Fix a compact neighborhood with \(a>0\), and let \(C_\Psi\) be the supremum norm of its derivative. Choosing \(N\) so the preceding errors are below \(\min(\mu_L,\mu_R)/(2C_\Psi)\) leaves each relevant gap at least half its original minimum. This is a finite uniform choice after every radial scale and loop has been fixed.

On a later repair interval \((Y_0,Y_1)\subset I_1\), the unchanged pair is \(U_0=0\), \(E_0=K(\eta)X^{-1/2-\lambda}\), \(K=c_{\rm patch}(1+\eta^2)^{-1}>0\). Two \(U\) bumps and three \(E\) bumps have the exact quadratic moment changes, in order \((M,J,I,S,C_p)\),
\[
\int u_c,\quad\int(H_0u_c+\sqrt{2X}u_ce_c),\quad\int\sqrt{2X}e_c,
\]
\[
\int(u_c^2-E_0e_c-e_c^2/2),\quad\int(E_0e_c/X+e_c^2/(2X)).
\]
The linear blocks have weights \((1,X^{-\lambda})\) and \((X^{1/2},X^{-1/2-\lambda},X^{-3/2-\lambda})\) with their fixed positive \(K,\sqrt2\) factors. Distinctness follows from the actual \(\lambda>0\). The determinant and quadratic-solve proofs in `core_exact.md` apply. With \(\|d_N\|_{C^k}\le D_k/N\), the source's explicit requirement
\[
N\ge8\max_{k=0,2}\nu_k^2q_kD_k
\]
gives a smooth correction with \(\|c\|_{C^2}\le2\nu_2D_2/N\). Fixed bump shapes also make its first radial derivative \(O(N^{-1})\). Increasing \(N\) so \(N\ge4C_\Psi C_{\rm rep}/\mu_R\) leaves the repair gaps at least \(\mu_R/4\). At \(Y_1\) every moment is restored exactly. Below the first perturbation and above \(Y_1\), the full field and stress are therefore exactly the original joined ones. No later modification reaches the analytic collar or the reserved intervals \(I_3,I_4\).

## 7. Endpoint, weight and total-moment conclusions

The exact inner factor already proved gives \(T_0=e^{-t_1^2/y_a^2}g_aB_a\), where \(y_a=\log(X/X_a)\), \(g_a(0)>0\), and \(B_a(0)=Fs_{\rm shear}\ne0\). The imported outer endpoint computation has the exact factors
\[
T_{0,\theta}=e^{-4/y_b^2}y_b^{-3}b_\theta,
\quad T_{0,z}=e^{-4/y_b^2}y_b^3b_z,
\quad y_b=\log(X_b/X),\quad b_\theta(0)>0.
\]
Consequently the unit direction is \(B_a/|B_a|\) near the inner edge and
\((b_\theta,y_b^6b_z)/(b_\theta^2+y_b^{12}b_z^2)^{1/2}\) near the outer edge. Both extend smoothly. The endpoint directions are respectively \((1,t_s)/(1+t_s^2)^{1/2}\) and \((1,0)\), with \(t_s=0\) at the latter edge.

Let \(n=T_0/|T_0|\), \(A_n=n_\theta+t_sn_z\), \(B_n=n_z-t_sn_\theta\). In the interior,
\[
A_n=(P_c-v_s)/|p_s-s_{\rm shear}|>0,
\quad G_n:=2-(v_s-2)B_n^2/A_n^2>0.
\]
At either edge \(B_n=0\), while \(A_n>0\), so \(G_n=2\). Compactness of the closed annulus gives positive minima for \(A_n,G_n,F,a,v_s-2\). The choice
\(\kappa=\min\{1,\min A_n,\min G_n\}>0\)
proves exactly the two directional bounds in source (4.26), with \(\kappa<2\).

The exact weight
\[
\zeta(X)=\exp(-t_1^2/y_a^2-4/y_b^2)\quad(X_a<X<X_b),\qquad \zeta=0\text{ otherwise}
\]
is smooth and flat at both edges. On either fixed collar its ratio to the local exponential has positive upper and lower bounds. The nonzero vector coefficients and finite powers introduced by differentiation therefore prove
\[
|T_0|\ge c\zeta,\qquad
|\partial^\alpha T_0|\le C_\alpha\zeta\,
\min\{1,y_a,y_b\}^{-m_\alpha}.
\]
On the compact region between the collars this follows from positivity and smoothness directly. Thus all six conclusions concerning stress direction and weight follow from the actual endpoint factors, not from a claim that every flat function has a smooth normalized direction.

Every completed join restores all five cumulative integrals at a finite radius. Therefore total \(M,J,S\) remain zero, \(C_p(\infty)=-\Pi_0\), and the renormalized angular moment remains unchanged because the perturbation of \(H\) is compactly supported and has total integral zero. The pressure is hence exactly
\[
\Pi(X)=\Pi_0+C_p(X)=C_p(X)-C_p(\infty)
=-\int_X^\infty E(x)^2/(2x)\,dx.
\]
Above the retained \(X_v\), the outer data have \(U=M=J=0\); the formula
\(V_0=(2\eta XU-2D\eta M-dM_\eta)/L\)
then gives \(V_0=0\) exactly. The heat formula was proved directly in `core_exact.md`. The compensation used only \(I_2\), the last repair only \(I_1\); therefore \(I_{\rm pos}=I_3\) and \(I_{\rm mean}=I_4\) retain their exact specified profiles. These are dependency-preserving assembly statements; they do not by themselves validate any later residual summation or wave realization.
