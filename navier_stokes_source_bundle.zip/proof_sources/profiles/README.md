# Section 4 and Appendix B audit deliverables

All proof text in Section 4 (printed pp. 24-45, ending before Section 5) and Appendix B (printed pp. 144-157, ending before Appendix C) has been read. The source PDF is the public *Finite Time Blowup for Navier-Stokes*, SHA-256 `8c8a94ad9ac824c8b605b9827cadf7beaca48bd10b380de3cfc872a2c37afa81`, at [the manuscript's source URL](https://cdn.openai.com/pdf/32d9f210-8b73-45e0-91bc-82a30aef8a9a/navier-stokes.pdf).

The independent bodies are `core_exact.md`, `axis_exact.md`, and `continuation_exact.md`. They retain the chosen source range `0 < h < 1/100`, every coordinate and pressure constant, and the source parameter order. `profiles_body.tex` contains all three mathematical bodies for direct inclusion with standard amsmath/amssymb. `build_tex.py` verifies byte-for-byte preservation of every inline and display math span when generating that body. It changes no parent manuscript.

`exact_checks.py` performs complete exact rational-identity checks for the two radial primitives, the full rescaled nonlinear remainders, cone algebra and heat-integral ODE; it also verifies the stated rational scalar comparison endpoints. All 14 checks pass. The finite series check is explicitly through degree 10; the universal recurrence is proved in the written derivation. These checks supplement the proof and do not certify the full manuscript.

No established algebraic contradiction or failed local implication was found in the bounded Section 4/Appendix B reconstruction. The following ledger distinguishes independently derived operations from construction results merely supplied as inputs to this lane.

| Source result | Lane status and exact extent |
| --- | --- |
| Lemma 4.1, equations (4.1)-(4.7) | Independently derived unique physical-to-profile map, all time/axial derivatives, Cartesian axis extension, incompressibility, and radial pressure balance. The smaller final h range is retained. |
| Proposition 4.2, (4.8)-(4.14) | Independently derived all sources, regular primitives, both cylindrical divergence signs, radial viscosity and equivalence of zero stress with the two axis equations. |
| Lemmas 4.3-4.4, (4.15)-(4.19) | Independently derived both moment primitives, the five-data exterior-preservation map, one-extra-parameter-derivative continuity estimate and all dilation factors. |
| Lemma 4.5, (4.20)-(4.23) | Independently proved root characterization, sufficient threshold with its original constants, and stress-coordinate map. |
| Lemma 4.7 | Independently proved the Chebyshev moment determinant and exact quadratic contraction, including smoothness in all higher fixed parameter orders. |
| Lemmas 4.8-4.9 | Their full statements and proof text were read. The prepared outer profile, outer pressure datum and terminal stress-direction estimates are imported from Appendix A and are NOT independently reconstructed in this lane. The heat formula itself is independently proved here. |
| Proposition 4.10 | Axis construction, activation, continuation, all five matching equations and the parameter order are independently reconstructed from Appendix B. Its specified outer datum remains the Appendix A dependency. |
| Lemma 4.11 | Entire proof read. The reparameterization, period, mean, orientation and smooth inverse are independently proved. Existence of the initial variance loop from Lemma C.1 is NOT proved in this lane. |
| Theorem 4.6, Section 4.6 | All assembly operations are independently checked: finite radial frequency, field/shear derivatives, integrated errors, exact five-moment repair, preservation of margins, and conclusions from the endpoint factors. The two imported existence constructions above must be supplied by the other audit lanes; this lane alone does NOT close Theorem 4.6. |
| B.1 | Independently checked unique root and its size, sign of Z at that root, the complementary chi/Z regions and analytic axis datum. The outer pressure hypotheses are supplied by Appendix A. |
| Lemma B.1 | Independently proved completeness, multiplication, all radial inverse and derivative-loss estimates, including differentiated nonlinear products. |
| Proposition B.2 | Independently reconstructed exact rescaled equations, uniform analytic coefficient control, full angular resolvent, Banach contraction and recovery of a common analytic neighborhood. |
| Proposition B.3 | Independently proved positivity, source lower bound, both endpoint alternatives and original numerical margins. |
| Lemma B.4 | Independently reconstructed cutoff-reference bounds, source estimates, both integrated comparisons and amplitude-independent parameter bounds. |
| Proposition B.5 | Independently reconstructed actual-shear activation, error estimates without inverse kappa, flat factorization, cone inequalities, continuation and final crossing barrier. |
| Corollary B.6 | Independently justified common parameter-analytic domain for every fixed radial derivative and preservation under later-supported modifications. |
| Lemma B.7, (B.33)-(B.34) | Independently derived amplitude-independent logarithmic bounds, transition length, exact matching jets, source bounds and barrier. |
| Proposition B.8 | Independently proved all five normalized error scales and exact quadratic moment repair. The ideal Q positivity is derived directly in the body, without leaving it as a reference to (A.25). |
| Remark B.9, Corollary B.10 | Independently checked finite-order requirements, parameter order and assembly. No infinite list of smallness requirements is substituted for a finite choice. |
| A.9, as used in B.5 | Read on pp. 141-142 and independently proved by its exact substitution, including smoothness after division by the flat factor. |

Visual inspection covered the full rendered pages 27, 31, 145, 146, 147, 152, 154 and 156, resolving the extracted fraction in (4.13), the coefficient weights, both nonlinear remainders, the positive-part subscript in the activation inequality and the matching scales. Extra source text read for exact dependencies: p. 6 (viscosity-one definition), p. 128 (moment Jacobian and scales), p. 129 (the step function and reference pair), pp. 141-142 (backward stress and the flat-integral lemma). Initial source metadata/title excerpts are not treated as mathematical validation.

No Lean/Lake/Elan process was started. No remote publication, source modification, parent-main modification or further agent delegation occurred. Local logs and source page renderings are provenance/inspection artifacts and should be excluded from any public mathematical edition. The full Navier-Stokes theorem, Appendix A/C existence constructions and Sections 5-10 are outside this lane's validation claim.
