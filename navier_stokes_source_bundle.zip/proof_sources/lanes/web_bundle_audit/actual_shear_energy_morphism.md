# Actual shear, frozen leading shear, and the exact pulse force–pressure correspondence

This note independently verifies the concrete pulse interpretation correction identified in `research/global_analytic_closure_review/base_pulse/pulse_check.md`, relative to the programme root. The complete pulse audit was read, together with the original reconstruction `research/released_ns/oscillations/02_pulse_equation.md`, its covariance calculation, and the exact chart/base interface (B11)–(B12) in `BASE_TO_PULSE_AUDIT.md`. The latter two reconstruction components are maintained by the originating task. This note changes none of them and does not change the immutable published 162-page snapshot.

The primary source used for the direct page check is the retained historical 165-page capture, `programme/lanes/web_bundle_audit/coordination/claimed_proof/openai_navier_stokes.pdf`, SHA256 `8c8a94ad9ac824c8b605b9827cadf7beaca48bd10b380de3cfc872a2c37afa81`. Its retrieval URL is [the primary manuscript URL](https://cdn.openai.com/pdf/32d9f210-8b73-45e0-91bc-82a30aef8a9a/navier-stokes.pdf); that URL later returned the separately preserved 166-page edition, so the hash identifies the exact capture used here. Original page 81 was rendered and visually inspected; pages 73–76 and 81 were also read through their retained source transcriptions.

The full energy equation already contains the actual shear. The missing term occurs in the sentence that identifies its production with the frozen leading expression. Below the difference is a retained jet coordinate, an explicit invertible force–pressure map, and a quantitatively controlled energy contribution. The complete source background and homogeneous pulse used here are the constructed objects in the cited audit, not new assumed solutions of the Navier–Stokes problem.

The original source page 73 explicitly defines a subscript zero as the order-zero quantity at the chosen representative, and page 81 repeats the frozen production statement immediately after its actual-shear energy equation (7.22). Thus the same explanatory qualification also applies to that primary-source sentence when read as the exact actual production. The source page 76 already gives the correct polynomial derivative allowance for the radial transport product; the narrower derivative sentence being corrected belongs to the reconstruction. These local statements do not establish a failure of the primary pulse equation or its proved bounds.

## 1. Original chart and the two contributions to the shear difference

Retain the source parameters and coordinates
\[
0<h<1/100,\quad A=1/2+h,\quad D=1/2-h,
\quad Q=2^{-\ell},\quad\varepsilon=Q^h,\quad S_*=\ell^2,
\quad R=r/\sqrt Q,\quad Z=z/Q^D,\quad T=(1-t)/Q.
\tag{AS1}
\]
The value of \(h\) is the one selected by the preceding profile construction. Constants below may depend on that value and the fixed source profiles. No uniform threshold as \(h\downarrow0\) is asserted. Work on the original compact enlarged chart annulus, whose inner radius is denoted by \(R_->0\). The label and its representative \(p_0=(R_0,Z_0,T_0)\) are held fixed under every continuous derivative.

Write \(s_Q=q/Q\). The exact leading tangential chart fields and the actual Borel fields are
\[
V^{(0)}=s_Q^{-A}E_0(X,\eta),\quad
G^{(0)}=s_Q^{-A}U_0(X,\eta),\quad
X=R^2/(2s_Q),\quad Z=s_Q^D\eta,\quad T=s_Q(1-\eta^2),
\tag{AS2}
\]
\[
\delta V=V-V^{(0)},\qquad \delta G=G-G^{(0)}.
\tag{AS3}
\]
The constructed base estimate (B12), on this fixed enlarged annulus, gives for each fixed slow multi-index \(I\) actual constants
\[
|\partial^I\delta V|\le C_{V,I}\varepsilon^2,
\qquad |\partial^I\delta G|\le C_{G,I}\varepsilon^2.
\tag{AS4}
\]
The base is independent of the auxiliary torus variables. The source supplies (AS4) through its Borel and chart constructions; this note does not replace that construction by a hypothesis about arbitrary fields.

Define the actual, varying leading, and frozen shear coordinates by
\[
F=V/R,\quad F^{(0)}=V^{(0)}/R,\quad F_0=F^{(0)}(p_0),
\quad g=(R\partial_RF,\partial_RG),
\quad g^{(0)}=(R\partial_RF^{(0)},\partial_RG^{(0)}),
\quad g_0=g^{(0)}(p_0).
\tag{AS5}
\]
Their exact difference is
\[
\begin{aligned}
\delta g&:=g-g^{(0)}=(\partial_R\delta V-\delta V/R,\partial_R\delta G),\\
\Delta g&:=g-g_0=\delta g+g^{(0)}(p)-g^{(0)}(p_0),\\
\Delta F&:=F-F_0=\delta V/R+F^{(0)}(p)-F^{(0)}(p_0).
\end{aligned}
\tag{AS6}
\]
At the representative the varying-leading differences in the second terms vanish exactly. The Borel differences in the first terms have not been shown to vanish, and are retained.

For \(I=(i_R,i_Z,i_T)\), the full derivative formula is
\[
\begin{aligned}
\partial^I\delta g_\theta
&=\partial^{I+e_R}\delta V
-\sum_{j=0}^{i_R}\binom{i_R}{j}(-1)^j j!R^{-j-1}
\partial^{I-je_R}\delta V,\\
\partial^I\delta g_z&=\partial^{I+e_R}\delta G.
\end{aligned}
\tag{AS7}
\]
Indeed \(\partial_R^j(R^{-1})=(-1)^jj!R^{-j-1}\); applying the full product rule to the first line of (AS6) gives exactly (AS7). Consequently the respective constants in the bounds for the two entries are
\[
C_{\theta,I}=C_{V,I+e_R}
+\sum_{j=0}^{i_R}\binom{i_R}{j}j!R_-^{-j-1}C_{V,I-je_R},
\qquad C_{z,I}=C_{G,I+e_R},
\tag{AS8}
\]
and the Euclidean vector bound is \(|\partial^I\delta g|\le(C_{\theta,I}^2+C_{z,I}^2)^{1/2}\varepsilon^2\). Every factor of the original radius and every derivative is present. The frozen difference \(\Delta g\) has a different derivative identity: for \(|I|>0\),
\[
\partial^I\Delta g=\partial^I\delta g+\partial^Ig^{(0)}.
\tag{AS9}
\]
Thus its higher derivatives are not inferred to be \(O(\varepsilon^2)\) from a small value difference on a narrow box.

Let the original box satisfy \(|p-p_0|\le C_{\rm box}S_*^{-3}\), with the connecting segment inside the enlarged domain. Let \(L_g\) be a bound for the Euclidean operator norm of \(D_pg^{(0)}\) there, and set \(C_B=(C_{\theta,0}^2+C_{z,0}^2)^{1/2}\). Integration along that segment gives
\[
|\Delta g|\le C_B\varepsilon^2+L_gC_{\rm box}S_*^{-3}.
\tag{AS10}
\]
This proves the precise value bound used by the pulse audit. It retains the independent Borel and box-variation contributions.

## 2. Complete first-jet coordinate map and both inverses

For each original \(R>0\), regard the first radial jet difference as the four-coordinate vector
\(j=(v,v_R,w,w_R)\in\mathbb C^4\). The shear map and its retained fibre coordinates are
\[
L_Rj=\begin{pmatrix}-1/R&1&0&0\\0&0&0&1\end{pmatrix}j,
\qquad
\mathcal J_Rj=(L_Rj,v,w)\in\mathbb C^2\oplus\mathbb C^2.
\tag{AS11}
\]
They apply to \(j=(\delta V,\partial_R\delta V,\delta G,\partial_R\delta G)\), without identifying a field value with its derivative. The complete inverse is
\[
\mathcal J_R^{-1}(a,b,v,w)=(v,a+v/R,w,b).
\tag{AS12}
\]
Substitution gives \((a+v/R)-v/R=a\), leaves the fourth entry \(b\), and recovers \(v,w\). Conversely, substituting \(a=v_R-v/R\) and \(b=w_R\) into (AS12) returns the original four entries. This proves both inverse compositions. In particular \(L_R\) is onto, has right inverse \((a,b)\mapsto(0,a,0,b)\), and has exactly the kernel
\[
\ker L_R=\{(v,v/R,w,0):v,w\in\mathbb C\}.
\tag{AS13}
\]
All these maps are smooth in the original positive radius. The entire jet has been retained in the bijection; a small shear difference does not erase the two fibre coordinates.

## 3. The same actual phase in the two background operators

Use the source's actual phase \(\Phi\), actual nonzero normal \(n=n_\Phi\), and its derivative \(n'=\partial_vn\). They are fixed as the same functions on both sides of the following comparison. Retain the original harmonic \(m\in\mathbb Z\setminus\{0\}\), source choice \(k=\lceil\varepsilon^{-1/2}\rceil\ge1\), and damping \(d=\varepsilon k^2|n|^2\). In particular \(km\ne0\) on the original domain of every pressure formula below. Define
\[
\mathcal K(F,g)=
\begin{pmatrix}0&-2F&0\\2F+g_\theta&0&0\\g_z&0&0\end{pmatrix},
\quad \mathcal K_0=\mathcal K(F_0,g_0),
\quad \Pi_n=I-\frac{nn^T}{|n|^2}.
\tag{AS14}
\]
Their exact matrix difference is
\[
\Delta\mathcal K=
\begin{pmatrix}0&-2\Delta F&0\\2\Delta F+\Delta g_\theta&0&0\\\Delta g_z&0&0\end{pmatrix}.
\tag{AS15}
\]
The comparison operator uses frozen background entries and the actual phase. The ideal reference phase \(B_s(s(v),K)\) is not silently substituted for \(n\).

The complex constrained equation is
\[
t'+\mathcal Kt+m^2dt+ikm n\pi=-f,
\qquad n^Tt=0.
\tag{AS16}
\]
Differentiating the constraint gives \(n^Tt'=-n'^Tt\). Multiplying the first equation by \(n^T\) and solving the scalar equation gives the unique pressure
\[
\pi=\frac{i}{km}\frac{n^T\mathcal Kt-n'^Tt+n^Tf}{|n|^2}.
\tag{AS17}
\]
Substituting this value, including \(i^2=-1\), gives
\[
t'=\mathcal A t-m^2dt-\Pi_nf,
\qquad
\mathcal A=-\mathcal K+
\frac{n(n^T\mathcal K-n'^T)}{|n|^2}.
\tag{AS18}
\]
The same formula with \(\mathcal K_0\) gives \(\mathcal A_0\), and direct subtraction proves
\[
\mathcal A-\mathcal A_0=-\Pi_n\Delta\mathcal K.
\tag{AS19}
\]
The normal-motion term cancels because it is the same actual term, not because it is zero.

## 4. Exact force–pressure bijection on the full constrained solution data

For each datum \((t,f,\pi)\) satisfying (AS16), set
\[
t_0=t,\qquad f_0=f+\Pi_n\Delta\mathcal Kt,
\qquad \pi_0=\pi-\frac{i}{km}\frac{n^T\Delta\mathcal Kt}{|n|^2}.
\tag{AS20}
\]
The data satisfy the equation with \(\mathcal K_0\), the same normal and damping, and right side \(-f_0\). To check the complete equation, calculate
\[
\begin{aligned}
t_0'+\mathcal K_0t_0+m^2dt_0+ikm n\pi_0
&=-f-\Delta\mathcal Kt
+n\frac{n^T\Delta\mathcal Kt}{|n|^2}\\
&=-f-\Pi_n\Delta\mathcal Kt=-f_0.
\end{aligned}
\tag{AS21}
\]
The constraint remains \(n^Tt_0=0\). Conversely, the exact inverse on the full solution data is
\[
t=t_0,\qquad f=f_0-\Pi_n\Delta\mathcal Kt_0,
\qquad \pi=\pi_0+\frac{i}{km}\frac{n^T\Delta\mathcal Kt_0}{|n|^2}.
\tag{AS22}
\]
Both compositions return every component because the unchanged vector \(t\) appears in equal and opposite increments. Substitution in (AS21) also proves the converse equation, so this is a bijection of the constrained solution-data spaces, including their pressure. For the actual homogeneous pulse \(f=0\), the comparison force is exactly \(\Pi_n\Delta\mathcal Kt\); it is not asserted zero. Smoothness follows from the explicit expressions and the source's positive normal denominator. The force increment can have support wherever \(t\) and the background difference overlap; no unsupported support equality is claimed.

## 5. Exact real energy production and an explicit finite positivity threshold

Restrict now to the original real homogeneous pulse, \(m=1\) and \(f=0\). Put
\[
T=t_r(t_\theta,t_z)\in\mathbb R^2.
\tag{AS23}
\]
Multiplication of the original matrix gives
\[
t^T\mathcal Kt=-2Ft_rt_\theta+(2F+g_\theta)t_rt_\theta+g_zt_rt_z=g\cdot T.
\tag{AS24}
\]
Because \(n^Tt=0\), the normal term in (AS18) has zero inner product with \(t\). Thus the exact energy identity is
\[
\frac12\partial_v|t|^2=-g\cdot T-d|t|^2.
\tag{AS25}
\]
Let \(N=g_0/|g_0|\), with the nonzero frozen shear supplied by the compact cone, and \(K=(-N_z,N_\theta)\). Then \((N,K)\) is an orthonormal ordered basis in the original \((\theta,z)\) plane. Writing \(T=T_NN+T_KK\), the exact replacement for the disputed sentence is
\[
-g\cdot T=-|g_0|T_N-\Delta g\cdot T.
\tag{AS26}
\]
In particular (AS26) is still the formula at \(p_0\), where \(\Delta g=\delta g\). Equation (AS24) with the matrix difference also gives \(t^T\Delta\mathcal Kt=\Delta g\cdot T\): both \(2\Delta F\) contributions cancel algebraically. No component of \(\Delta\mathcal K\) is removed from (AS20).

For the actual prescribed source stress cone, write its positive compact margin as \(-T_N\ge c_T|T|\), and write \(|g_0|\ge g_->0\). The Cauchy–Schwarz inequality and (AS10) give
\[
-g\cdot T\ge
\bigl[g_-c_T-C_B2^{-2h\ell}-L_gC_{\rm box}\ell^{-6}\bigr]|T|.
\tag{AS27}
\]
This includes \(T=0\), without division by its norm. One explicit sufficient integer threshold is
\[
\ell\ge\left\lceil\max\left\{
1,\left(\frac{4L_gC_{\rm box}}{g_-c_T}\right)^{1/6},
\frac{\log\max\{1,4C_B/(g_-c_T)\}}{2h\log2}
\right\}\right\rceil.
\tag{AS28}
\]
The first power bound makes the box term at most \(g_-c_T/4\); the logarithmic bound makes the Borel term at most the same number. Hence (AS27) gives the proved bound \(-g\cdot T\ge(g_-c_T/2)|T|\). The threshold is added to the already selected finite source value thresholds, never substituted for them.

## 6. Quantitative production for the actual homogeneous pulse

For that pulse use its actual frame
\[
K_a=n_{\tan}/|n_{\tan}|,\quad N_a=((K_a)_z,-(K_a)_\theta),
\quad s_a=n_r/|n_{\tan}|,\quad
t=x(e_r-s_aK_a)+yN_a.
\tag{AS29}
\]
The source's fixed-label reference has \(B_s\ge B_->0\),
\(s(v)=\sigma(u_*/2+u_*v/L_s)\), and \(|s(v)|\le s_{\max}=3u_*/2\) on \(0\le v\le L_s\). Write the actual proved phase and ratio bounds with constants as
\[
|n-B_s(s,K)|\le E_n/S_*,\quad
|y/x-\gamma_0|\le E_\gamma/S_*,\quad
\gamma_0=c_0\sqrt{1+s^2},\quad c_0<0,
\quad c_xP\le x\le C_xP.
\tag{AS30}
\]
These are the constructed pulse bounds; their invariant-band and propagator proofs were read in the complete pulse audit. Choose \(S_*\ge2E_n/B_-\), so \(|n_{\tan}|\ge B_-/2\). For any nonzero vectors \(a,b\), direct addition and subtraction of \(a/|b|\) proves
\(|a/|a|-b/|b||\le2|a-b|/|b|\). Applying this to \(a=n_{\tan}\), \(b=B_sK\), and using (AS30), gives
\[
|K_a-K|=|N_a-N|\le\frac{2E_n}{B_-S_*},
\qquad
|s_a-s|\le\frac{2(1+s_{\max})E_n}{B_-S_*}.
\tag{AS31}
\]
The second inequality follows by writing the numerator as
\(n_r-s|n_{\tan}|=(n_r-B_ss)+s(B_s-|n_{\tan}|)\), with denominator \(|n_{\tan}|\).

Let \(c_+\) bound \(|c_0|\), let \(c_->0\) bound it below, and set
\[
\Gamma_{\max}=c_+\sqrt{1+s_{\max}^2},\quad
C_T=\frac{2E_n}{B_-}(1+2s_{\max}+\Gamma_{\max})+E_\gamma.
\tag{AS32}
\]
The exact stress has the form
\[
T=x^2[-sK+\gamma_0N+e_T],\qquad
e_T=-(s_aK_a-sK)+(y/x)N_a-\gamma_0N,
\quad |e_T|\le C_T/S_*.
\tag{AS33}
\]
For this bound, expand \(s_aK_a-sK=(s_a-s)K_a+s(K_a-K)\) and
\((y/x)N_a-\gamma_0N=(y/x-\gamma_0)N_a+\gamma_0(N_a-N)\), then use (AS30)–(AS32). Every summand is retained.

Let \(g_+\) bound \(|g_0|\). The exact production is
\[
\frac{-g\cdot T}{x^2}=-|g_0|\gamma_0
-g_0\cdot e_T-\Delta g\cdot(-sK+\gamma_0N+e_T).
\tag{AS34}
\]
The last two terms have total absolute value at most
\[
\mathcal E_\ell=
g_+C_T\ell^{-2}
+\bigl(C_B2^{-2h\ell}+L_gC_{\rm box}\ell^{-6}\bigr)
\bigl(s_{\max}+\Gamma_{\max}+C_T\ell^{-2}\bigr).
\tag{AS35}
\]
This is a concrete nonnegative expression decreasing to zero. Set \(W=s_{\max}+\Gamma_{\max}+C_T>0\). In addition to the prior source and (AS31) thresholds, it suffices to choose
\[
\ell\ge\left\lceil\max\left\{
1,\left(\frac{4g_+C_T}{g_-c_-}\right)^{1/2},
\left(\frac{8WL_gC_{\rm box}}{g_-c_-}\right)^{1/6},
\frac{\log\max\{1,8WC_B/(g_-c_-)\}}{2h\log2}
\right\}\right\rceil.
\tag{AS36}
\]
The three resulting error contributions are at most \(g_-c_-/4\), \(g_-c_-/8\), and \(g_-c_-/8\). Thus \(\mathcal E_\ell\le g_-c_-/2\). The leading coefficient in (AS34) is at least \(g_-c_-\), because \(-\gamma_0=|c_0|\sqrt{1+s^2}\ge c_-\). Consequently
\[
\frac12g_-c_-c_x^2P(v)^2\le -g\cdot T
\le\bigl(g_+\Gamma_{\max}+g_-c_-/2\bigr)C_x^2P(v)^2.
\tag{AS37}
\]
This proves the two-sided production bound with every remainder retained. It does not assert that \(\partial_v|t|^2\) is positive: the original damping term in (AS25) is still present. The exact norm identity
\[
|t|^2=(1+s_a^2)x^2+y^2
\tag{AS38}
\]
also follows from the actual orthonormal frame; no ideal frame is substituted into this identity.

## 7. The derivative bound for the radial transport product

For the actual phase let
\[
H_\Phi=pF+p_zG,\qquad n_{\Phi,r}=x_0-v\partial_RH_\Phi,
\qquad
E_{\rm ik}=\varepsilon v(\partial_TH_\Phi-G\partial_ZH_\Phi)+bn_{\Phi,r}.
\tag{AS39}
\]
Here \(p,p_z,x_0\) and the label are fixed; \(v\) is the original affine pulse coordinate. Let \(D^I\) be the ordinary coefficient derivatives in \((R,Z,T,H_1,H_2)\), not the evaluated physical derivative operator. The actual source gives \(|D^Jb|\le C_{b,J}\varepsilon\), and the full phase formula gives \(|D^Jn_{\Phi,r}|\le C_{n,J}S_*^{d_J}\) for each fixed \(J\). Their exact product rule and resulting bound are
\[
D^I(bn_{\Phi,r})=
\sum_{J\le I}\binom IJ(D^Jb)(D^{I-J}n_{\Phi,r}),
\qquad
|D^I(bn_{\Phi,r})|
\le\varepsilon\sum_{J\le I}\binom IJ C_{b,J}C_{n,I-J}S_*^{d_{I-J}}.
\tag{AS40}
\]
For fixed \(I\) the sum is finite; since \(S_*\ge1\), it is bounded by
\(\varepsilon S_*^{\max_{J\le I}d_{I-J}}\sum_{J\le I}\binom IJ C_{b,J}C_{n,I-J}\).
Already \(\partial_Rn_{\Phi,r}=-v\partial_R^2H_\Phi\) may carry the interval-length factor \(L_s\). The bounds do not supply a uniform derivative-free \(C_I\varepsilon\) estimate for the entire product. Applying the same full finite product rule to the first term in (AS39), with the retained \(v\) and its affine derivatives, gives the source's stated \(C_I\varepsilon S_*^{b_I}\) transport-defect bound. Thus the corrected derivative sentence proves exactly the coefficient class used subsequently.

## 8. Proven scope and propagation

The note proves the full shear-jet map with both inverse compositions, the complete force–pressure bijection at the actual phase, the exact energy identity and missing remainder, two explicit finite positivity thresholds, all actual-frame stress errors with constants, and the original coefficient product bound. The primary pulse audit's construction and support estimates were read; the new calculation does not independently re-prove the whole background, every later correction, the infinite realization or a complete Navier–Stokes counterexample.

The affected reconstruction copies should use (AS26) and the bound (AS27), or the actual pulse bound (AS37), in place of the literal frozen-shear production equality. They should retain (AS40) in the derivative sentence. These are reader corrections to explanatory claims; no defect in the written actual pulse differential equation has been established. The source's covariance mass derives from its constructed \(x\ge c_xP\) and positive integral, rather than from deleting damping in the energy equation. The originating task owns propagation into canonical components and the cumulative TeX. No existing source, immutable publication, formal process or public record was changed here.
