# Independent review receipt: radial stress reconstruction

Reviewed at 2026-09-08 20:52 UTC by the `shear_series_review` lane, with an independent tensor/chart check by `radial_chart_check`. The review was read-only for the audited manuscript and parent/source files. This receipt is the sole new review artifact. No Lean, Lake, Elan, source script, or symbolic checker was executed.

Audited file: `radial_stress_reconstruction_audit.md`, 19,166 bytes, SHA256 `9dc583fd7d3264a5eb424d1e009d58a935b0a3ffd8981c6a686ed11165e2f8b1`.

Original source PDF: `../../downloaded_public_release/navier-stokes.pdf`, SHA256 independently recomputed as `0e779481c4da40bd28d1e642e1d8ca57447d129610df28dfa5a11e9af8ae228f`.

Inspected page image: `../../downloaded_public_release/radial-stress-audit-page-109.png`, SHA256 `7d4b6e77365ce785de95ee2bb0348b9e1f416b25e60ecfb1fec56e0b02030128`. The displayed original page 109 agrees with the audit's weighted profile, moment integral, lower endpoint zero, inverse minus sign, and representatives with factors \(Q^{2A+1/2}\) and \(Q^{2A}\).

## Result

No algebraic error was found in the requested operator calculation. Two precision edits are recommended for the reviewed snapshot:

1. Before (R25), state the derivative-order ranges explicitly: for (R25) require \(a+b\le m\), and for (R27)–(R29) require \(k+a+b\le m\). The displayed fixed seminorm \(N_{\lambda,P;m}(F)\) only controls derivatives through order \(m\). All constants and the final same-order operator estimate (R30) are correct under these ranges.
2. In (R35), explicitly identify the measure as \(dr\,dz\,dt\). Its factor is correctly \(Q^{3/2+D}\). With the angular variable retained, the full Cartesian spacetime measure is instead
   \[
   dx_1\,dx_2\,dz\,dt
   =r\,dr\,d\theta\,dz\,dt
   =Q^{2+D}R\,dR\,d\theta\,dZ\,dT
   \]
   for positive volume measure. The written determinant \(-Q^{3/2+D}\) is correct for the stated ordered three-coordinate chart \((R,Z,T)\mapsto(r,z,t)\).

These edits clarify derivative and measure scope; they do not require changing the reconstruction, constant formulas, divergence, or chart identities. The parent has been informed; this review did not apply changes to its file.

## Complete reviewed scope

- (R4)–(R12): The profile section has exact weighted moment one. The moment projection identities, vanishing moments, radial inverse signs, injectivity, surjectivity, and both inverse compositions in the complete source-to-(stress,moment) bijection are correct. Common annular support of both source and profile makes the stress zero below the annulus; the zero weighted moment makes it zero above. Smooth zero extension and common support on compact parameter sets justify all parameter derivatives.
- (R13)–(R19): The repeated scalar-q operator product is correct. The two-variable Faà di Bruno coefficient is exactly \(a!b!/[\prod n_{u,v}!(u!v!)^{n_{u,v}}]\); its empty-family convention handles \(a=b=0\). The total q power is exactly the displayed one. The constants retain every profile factor and every supplied derivative bound for q.
- (R20)–(R30): Fixed-endpoint moment differentiation and the complete source/profile Leibniz sum are correct. The integral derivative in (R22), including both signed rising factors and falling factors, is correct at every radial order. The first term of (R28) has the required annular moment factor; every subsequent radial exponent \(j-k-\ell\) is nonpositive, so the chosen lower-radius factor gives the claimed upper bound. Each q power gives the same gain \(q^{1/2}\). Logarithmic factors are not differentiated or changed. The final estimate uses no derivatives of F above the selected order m.
- (R31)–(R34): All four individual cylindrical tensor divergences are correct with the specified Cartesian row-divergence convention. In particular \((\partial_z\sigma_1)e_r\) is present in the full force. Smooth extension at the axis follows from the locally positive inner radius, not from a cancellation of a coordinate singularity at zero radius.
- (R35)–(R42): The inverse chart, coordinate determinant, moment scaling, profile scaling, projected-source scaling, integral conjugacy, and the radial force factor \(Q^{1/2-D}=Q^h\) are correct. The mixed derivative factor is exactly \((-1)^bQ^{2A+k/2+aD+b}\). The same physical object and its chart representative are used throughout.

The proof explicitly depends on the previously supplied q-derivative bounds (R2), incoming source estimates when a finite weighted seminorm is asserted, and the original construction's cross-chart and covariance statements. This review did not re-prove those upstream inputs. It verifies the full displayed radial operator, its moment coordinate and inverse, its finite-order estimates, and its tensor/chart correspondence. It does not certify the complete Navier–Stokes construction, a finite-time singularity, or formal kernel acceptance.

## Addendum: flat-edge preservation and corrected derivative/measure scope

The expanded snapshot reviewed after the original receipt has SHA256 `264c0b26bde37e71ef962fbcefe9b5e33cea9117b35ef5154042cffedc34182a`. It contains (R43)–(R53), including the subsequent correction (R50a). The original receipt above remains a record of the earlier snapshot; the present addendum records the expanded scope.

The finite derivative-order restriction before (R25) and both distinct coordinate measures after (R35) are now present and correct. The extracted original source used for this review is `../../downloaded_public_release/current_pdf_extracted.txt`, SHA256 `f83414ea543ffd89910b9b8a35d1680a2e3295246c91cbedf54e719a7bc316d0`. Lines 3648–3674 supply the original weight and coefficient-class definition. Lines 5447–5473 supply the source's forward/backward radial integration argument. The separate original dyadic-chart statement occurs around lines 3295–3308.

The added calculation was independently checked as follows.

1. The substitution in (R45) gives exactly the factor \(a^{(1-M)/2}/2\) and the exponent \((M-3)/2\). For positive \(p=(M-3)/2\), the restriction \(a/d^2\ge2p\) gives the factor two in (R46), hence the explicit constant \(1/a\) in (R47). For \(p\le0\), the same displayed upper constant remains valid.
2. The polynomial recursion (R48) has the correct signs. Direct differentiation gives \(P_1(y)=2ay^3\) and \(P_2(y)=4a^2y^6-6ay^4\); the general recursion increases degree by at most three. The coefficient-sum estimate in (R49) follows on \(0<s\le1\).
3. The first version of the new section restricted \(d_0\) only by \(L/2\) and the profile gap. The reviewed expanded snapshot now includes (R50a), which additionally imposes \(d_0\le1\) and both scalar-tail thresholds for the fixed exponent M. Therefore \(\delta=s\) and the displayed constants apply on the entire chosen edge interval. The text correctly permits \(d_0\) to depend on the fixed derivative order; it does not assert one interval for unbounded M.
4. The exact radial substitution in (R51) gives the factor \(-\sqrt{q/2}\,X^{-e/2}\). The zero weighted moment turns its lower integral into the negative of the upper tail and gives precisely the plus sign in (R52). The radial Jacobian and the original powers of two and q are retained.
5. In (R53), the logarithmic substitution contributes \((X_ae^s)^{(e+1)/2}\). Bounding the other-edge factor above inside the integral and dividing by its positive infimum restores the full original \(\zeta\) at the evaluation point. The resulting displayed constant is correct under (R50a). The corresponding right-edge constant has the stated literal replacements.
6. Parameter differentiation preserves the zero moment because it is an identity of smooth parameter functions. Thus the differentiated integral term in (R22) has both forward and backward forms. The interior profile and all its derivatives are zero in the chosen edge neighborhoods, so the differentiated projected source there equals the actual differentiated source. Each nonintegral term of (R22) has the same flat factor with a finite inverse power of \(\delta\). The minimum defining \(\delta\) is used only as a weight and is never differentiated.

These checks prove the full physical flat-edge operator estimate. To make the final assertion about band-uniform source classes explicit, the following precise linkage uses the source's actual chart property; it was also sent to the parent for incorporation into the standalone audit.

The original Section 6.1 places each chart in a region where q is comparable to its fixed band scale Q. Denote its fixed comparison bounds by \(0<c_-\le q/Q\le c_+<\infty\). These are the source's chart bounds, not an additional assumption about an arbitrary positive q on an arbitrary domain. With \(\widetilde q=q_Q/Q\), direct differentiation of the retained chart gives

\[
\partial_Z^a\partial_T^b\widetilde q
=(-1)^bQ^{aD+b-1}
(\partial_z^a\partial_t^bq)\circ\Psi_Q,
\]

and (R2) therefore yields

\[
|\partial_Z^a\partial_T^b\widetilde q|
\le C_{a,b}\widetilde q^{1-aD-b}
\le C_{a,b}\max\{c_-^{1-aD-b},c_+^{1-aD-b}\}.
\]

All these constants are independent of the band Q. Formula (R40) is precisely the same radial integral in the original chart coordinate R with profile variable \(X=R^2/(2\widetilde q)\). Its edge factor is \(\sqrt{\widetilde q/2}\), since the original physical factor combines with the fixed source/stress representatives as

\[
Q^{2A}\sqrt{q/2}\,Q^{-2A-1/2}
=\sqrt{(q/Q)/2}.
\]

The original chart shell therefore has a uniformly positive inner radius and uniformly bounded outer radius. Every power of \(\widetilde q\), every fixed-order derivative of it, and every radial factor in the operator estimates is bounded by constants depending only on the stated comparison interval and the original profiles. Applying the already verified derivative formulas directly in that chart retains \(\zeta\) and a finite power of \(\delta^{-1}\), with no additional power of \(\varepsilon\). The source explicitly keeps Q, \(\varepsilon\), and \(S_*\) fixed during chart differentiation and radial integration. Thus the incoming amplitude exponent is unchanged by this radial operation. The selected averaged inputs are independent of the auxiliary torus coordinates, so their positive-order auxiliary derivatives, and those of the radial reconstruction, are zero.

The geometric descent and the estimates of the actual incoming residual remain upstream source properties, as the audit states. The reviewed calculation proves preservation by the radial operator once those actual source properties have been supplied; it does not independently verify the entire preceding construction. No full Navier–Stokes or formal-kernel certificate is implied. No source or parent-proof file was edited by this review.

## Final radial snapshot: chart linkage incorporated

At 2026-09-08 21:05 UTC the final radial audit SHA256 was independently recomputed as `9e5b8cb382ec6e9061d7868217277c5b4aab1dbfcc3912d2fabdf50363058b2b`, matching the parent's supplied final identity. The new (R54)–(R57) and their surrounding paragraphs were read directly.

The standalone audit now includes the source's actual comparison bounds, the exact differentiated ratio formula and time sign, the factor \(\sqrt{\widetilde q/2}\), both first profile-coordinate derivatives and their time counterpart, and the complete higher inverse-derivative recurrence. The recurrence in (R57) follows by isolating the zero-index term in the full multi-index Leibniz derivative of \(\widetilde q\widetilde q^{-1}=1\); every other index is retained. Its induction uses the lower bound \(c_-\) and the already displayed uniform derivative bounds, so it introduces no band-dependent constant. The fixed Q, \(\varepsilon\), and \(S_*\) factors and the vanishing auxiliary derivatives of the selected averaged source are also explicitly present.

These additions correctly incorporate the chart linkage proved in the preceding review addendum. The earlier finite-order, measure, and edge-width corrections remain present. No further correction was found in the final radial snapshot within the full reviewed operator/support/derivative/tensor/chart scope. The upstream construction and full-proof exclusions above remain unchanged.
