# Four-step correction-cycle gain and invariant audit

## Finding and exact scope

The displayed exponent arithmetic in Proposition 9.6 closes. With the original \(\kappa_s=10^{-5}\), the retained estimates after the full cycle give a wave-residual gain of at least \(0.39999\), a full tangential-mean gain of \(0.17\), and a defect gain of \(0.89996\). Each exceeds the proposition's required \(1/10\). The exact covariance, mean-residual and nonlinear defect identities checked below retain all cross products, self-products, pressure changes and the axial reconstruction remainder.

These calculations verify the numerical closure and the algebraic identities used by this particular cycle. They do not, by themselves, construct the pulse inverse, prove the earlier amplitude-class estimates, prove label separation or uniform flatness over infinitely many labels, or certify the whole Navier–Stokes construction. A class membership is attributed below to the source result that supplies it. The conclusion of this audit is not obtained by assuming an unproved additional estimate and calling it a theorem.

The exact source is the frozen 166-page PDF `downloaded_public_release/navier-stokes.pdf` under

`programme/`.

PDF SHA256: `0e779481c4da40bd28d1e642e1d8ca57447d129610df28dfa5a11e9af8ae228f`.

The full Proposition 9.6 statement and proof were read from `downloaded_public_release/current_pdf_extracted.txt`, lines 5613–5802, and its main formulas were visually checked on PDF pages 108–111. The statement begins on page 107. Additional directly read source:

| Source | Physical pages / layout-text lines | Purpose |
| --- | --- | --- |
| Definition 6.4 and (6.23)–(6.24) | pp.69–70; 3654–3682 | Full mean class, shell-edge weight and smooth zero extension; local base multiplier correction. |
| Proposition 8.1 and exact equations (8.3) | p.89; 4641–4680 | Complete mean balances and pressure source. |
| Definitions (8.15), Proposition 8.4 and (8.16) | p.94; 4909–4942 | Weighted moments, pressure contribution and exact axial product derivative. |
| Lemma 8.6 and (8.19)–(8.22) | pp.95–96; 4987–5032 | Mean inverse, prescribed versus actual axial increment, flat remainder. |
| Lemma 8.7, (8.24)–(8.25) | p.97; 5061–5089 | Five linear rows and their declared supported inverse. |
| Lemma 8.8 and (8.26)–(8.27) | pp.98–99; 5151–5208 | Exact nonlinear remainder after the defect update. |
| Proposition 9.1 statement and selected proof bounds | pp.101–102; 5284–5350 | Linear wave remainder, curl correction and pulse-cutoff tails. |
| Lemma 9.2, full statement and proof | pp.102–103; 5355–5374 | Wave–mean and same-label wave–wave exponents. |
| Proposition 9.3, statement and relevant full residual/support proof | pp.103–105; 5375–5518 | Supported source closure, actual mean equations, finite-stage flat remainder. |
| Definition 9.4 and Proposition 9.5 conclusion | pp.106–107; 5527–5562; 5593–5612 | Exact state, initialization and preserved low-order classes. |
| Lemmas 9.7–9.8 and (9.15)–(9.19) | pp.111–114; 5804–5937 | Common-domain and physical derivative interface to (9.18). |

The coordinating task has written the compact radial stress inverse and its moving-\(q\) physical rescaling in the separate `radial_stress_reconstruction_audit.md`, including its flat-edge preservation calculation. This note records their exact interface and sign but does not duplicate that inverse construction. No Lean, Lake or Elan was run; no source PDF or parent manuscript was modified.

## 1. Original state, parameters and class interpretation

Keep the original fixed quantities

\[
0<h<\frac1{100},\quad A=\frac12+h,\quad D=\frac12-h,
\quad Q=2^{-\ell},\quad\varepsilon=Q^h,\quad
\kappa_s=10^{-5}=\frac1{100000}.
\tag{C1}
\]

The finite stage is \(j\in\mathbb N_0\), with

\[
\sigma_j=\frac15+\frac j{10},\quad
B=B_j=\frac12+\sigma_j=\frac7{10}+\frac j{10},\quad
C^*=C_j^*=1+\sigma_j=B+\frac12,
\quad H=C^*-2\kappa_s.
\tag{C2}
\]

In particular \(B\ge0.7\), \(C^*\ge1.2\), \(H\ge1.19998\). Decimal constants such as 0.68, 0.9 and 0.17 below are the exact finite decimals used in the source, not rounded estimates of a different number.

The original class symbols \(\mathcal W_\alpha,\mathcal M_\alpha,\mathcal S_\alpha\) include more than a power of \(\varepsilon\): they include amplitude-derivative bounds, logarithmic-scale factors, edge weights, supports and extension conditions. On the fixed range \(0<\varepsilon\le1\), an already proved bound with exponent \(\alpha'\ge\alpha\) implies the corresponding bound with exponent \(\alpha\), with the same support and derivative properties, because \(\varepsilon^{\alpha'}\le\varepsilon^\alpha\). This elementary comparison is the only class inclusion inferred purely from exponent arithmetic. The product, inverse and support rules themselves remain the earlier analytical claims identified below.

The normalized state is

\[
u_*=(b+\beta,V+v,G+\gamma)+w,\qquad
p_*=p_{B,*}+p_m+p_w,\qquad
\langle w\rangle_\theta=\langle p_w\rangle_\theta=0.
\tag{C3}
\]

Its residual classes are \(\mathcal G_{*,\mathrm{wave}}^{[j]}\in\mathcal W_B\),
\(E_\theta,E_z\in\mathcal M_{C^*}\), and
\((\mathcal P,J_\theta,J_z)\in\mathcal S_{C^*}\). Its cumulative correction bounds are

\[
w\in\mathcal W_{1/2},\qquad
w-w_0^{\mathrm{tan}}\in\mathcal W_{0.68},\qquad
v,\gamma,p_m\in\mathcal M_{0.9},\qquad
\beta\in\mathcal M_{1.9}.
\tag{C4}
\]

The two exact constraints are

\[
M_\theta:=\int_0^\infty R^2\langle v\rangle_Y\,dR=0,
\qquad
M_z:=\int_0^\infty R\langle\gamma\rangle_Y\,dR=0.
\tag{C5}
\]

These are not assertions that the three defects \(\mathcal P,J_\theta,J_z\) vanish. The state allows those defects to be nonzero with the stated increasing decay order.

Angular average \(\langle\cdot\rangle_\theta\) holds the auxiliary torus coordinate fixed; auxiliary average \(\langle\cdot\rangle_Y\) integrates that independent coordinate before physical evaluation. Their composition is retained explicitly in every covariance below. No assertion that either operation commutes with physical phase evaluation is used.

## 2. Full residual and exact recomputation rule

At every update use the actual fields, including all cutoff-curl and mean-reconstruction terms. With \(\Delta_0=D_r^2+R^{-1}D_r+D_z^2\), the exact source balances are

\[
\begin{aligned}
E_\theta={}&t_*v+(D_r+2/R)(bv+\beta V+\beta v+W_{r\theta})\\
&+D_z(Gv+V\gamma+\gamma v+W_{z\theta})
-\varepsilon(\Delta_0-R^{-2})v-(D_r+2/R)\Sigma_\theta,\\
E_z={}&t_*\gamma+(D_r+1/R)(b\gamma+\beta G+\beta\gamma+W_{rz})\\
&+D_z(2G\gamma+\gamma^2+W_{zz}+p_m)
-\varepsilon\Delta_0\gamma-(D_r+1/R)\Sigma_z,\\
g_r={}&-t_*\beta-(D_r+1/R)(2b\beta+\beta^2+W_{rr})\\
&-D_z(b\gamma+G\beta+\beta\gamma+W_{zr})
+(2Vv+v^2+W_{\theta\theta})/R
+\varepsilon(\Delta_0-R^{-2})\beta,
\end{aligned}
\tag{C6}
\]

where \(W_{ab}=\langle w_aw_b\rangle_\theta\) contains the complete waves. The source fixes the radial pressure reconstruction by

\[
\mathcal P=\int\langle g_r\rangle_Y\,dR,
\qquad p_m=\mathcal T_0(g_r-\rho\mathcal P).
\tag{C7}
\]

The prescribed \(\rho\) and linear map \(\mathcal T_0\) remain fixed. For each update,
\(\Delta\mathcal P=\int\langle\Delta g_r\rangle_YdR\) and
\(\Delta p_m=\mathcal T_0(\Delta g_r-\rho\Delta\mathcal P)\) follow from linearity, but \(\Delta g_r\) itself is recomputed from all the quadratic products in (C6). The improved bounds for \(\Delta g_r\) and \(\Delta p_m\) do not replace the total-field bounds (C4).

In physical Cartesian variables the exact update identity is

\[
\mathcal R(u+\delta u,p+\delta p)-\mathcal R(u,p)
=\partial_t\delta u-\Delta\delta u+\nabla\delta p
+(u\cdot\nabla)\delta u+(\delta u\cdot\nabla)u
+(\delta u\cdot\nabla)\delta u.
\tag{C8}
\]

This is proved componentwise by expanding
\((u_k+\delta u_k)\partial_k(u_i+\delta u_i)-u_k\partial_ku_i\), giving the three displayed transport products with positive signs. The viscosity here is the source's local value one; no rescaling of \(h,Q,\varepsilon\) or the physical variables has been made.

## 3. Step 1: particular supported harmonics

For every supported source coefficient \(f_m\), the source applies the fixed inverse with sign
\(\mathcal L_m(t_m,\pi_m)=-f_m\), and realizes

\[
\Delta w_m=\operatorname{curl}_*
\left(\frac{i\,n_\Phi\times(\psi t_m)}{km|n_\Phi|^2}e^{ikm\Phi}\right),
\qquad
\Delta p_{w,m}=\psi\pi_me^{ikm\Phi}.
\tag{C9}
\]

Taking the curl after multiplying by \(\psi\) retains its derivative terms. Complex conjugate harmonics are paired in the actual real field. Existence of this supported inverse is Proposition 7.2; its remainder and pressure estimates are Proposition 9.1. Applying those results at exponent \(B\) supplies velocity class \(\mathcal W_B\) and pressure class \(\mathcal W_{B+1/2}\).

The four source rows and their arithmetic are:

| New nonzero-harmonic term | Exponent | Gain relative to \(B\) | Source of class estimate |
| --- | --- | --- | --- |
| Linear remainder, including curl correction | \(B+1/2-3\kappa_s\) | \(0.49997\) | Proposition 9.1. |
| Cross with old exact wave in \(\mathcal W_{1/2}\) | \(B+1/2-\kappa_s\) | \(0.49999\) | Lemma 9.2. |
| Particular-correction self-interaction | \(2B-\kappa_s\) | \(B-\kappa_s\ge0.69999\) | Lemma 9.2 and the exact self-product in (C8). |
| Interaction with total means \(\mu=0.9\) | \(B+0.9-1/2=B+0.4\) | \(0.4\) | Lemma 9.2 with the radial mean one order higher. |

The minimum gain is \(0.4\), since each of the first three gains is at least \(0.4\) and the fourth equals it. This is the first closing inequality on page 111.

The new covariance has terms bilinear in the old wave and \(\Delta w\), and quadratic in \(\Delta w\). Their tensor exponents are at least \(B+1/2=C^*\), using \(2B\ge B+1/2\) because \(B\ge0.7\). Applying the earlier derivative and mean-reconstruction bounds yields
\(E_\theta,E_z,\Delta g_r,\Delta p_m\in\mathcal M_{C^*-\kappa_s}\),
\((\mathcal P,J_\theta,J_z)\in\mathcal S_{C^*-\kappa_s}\). That class assignment uses (C6)–(C7), Proposition 9.3 and its weighted derivative rules; the numeric inequality alone would not prove it.

The one-extra-order moment gain in (9.12) uses the exact integrated identities

\[
\int R^2\langle E_\theta\rangle_YdR=\varepsilon\partial_ZJ_\theta,
\qquad
\int R\langle E_z\rangle_YdR
=\varepsilon\partial_Z(J_z+c_\rho\mathcal P),
\quad c_\rho=\frac12\int R^2\rho\,dR.
\tag{C10}
\]

To check the pressure sign, the reconstruction gives
\(\partial_R\langle p_m\rangle_Y=\langle g_r\rangle_Y-\rho\mathcal P\) after auxiliary averaging. Integration by parts of the compact pressure gives

\[
\int R\langle p_m\rangle_YdR
=-\frac12\int R^2\langle g_r\rangle_YdR+c_\rho\mathcal P.
\tag{C11}
\]

It is the positive last term in (C11) that appears in (C10). The weighted radial divergence terms integrate to zero, radial viscosity gives coefficients \(2-1-1=0\) for the angular equation and \(-1+1=0\) for the axial equation, and time/axial-viscosity terms differentiate the zero moments (C5). Thus (C10) follows from (C6), compact support, the exact constraints and the pressure reconstruction. The full derivative of \(c_\rho\mathcal P\) is retained: \(c_\rho\) can depend on \((Z,T)\).

The previously proved moment/coefficient bounds then give exponent \(C^*+1-\kappa_s\), because the displayed factor \(\varepsilon\) supplies one power while fixed coefficient derivatives retain the class exponent. This gain is not the result of identifying weighted moments with unweighted residuals.

## 4. Step 2: signed stress-amplitude change and its exact covariance

The physical radial inverse is not reproved here. Its exact interface in the source is

\[
F_2=Q^{-2A-1/2}\langle E_\theta\rangle_Y,
\qquad F_1=Q^{-2A-1/2}\langle E_z\rangle_Y,
\]
\[
\mathcal M_e=\int_0^\infty r^eF_e(r)\,dr,
\quad b_e=q^{-(e+1)/2}\widehat b_e(r/\sqrt q),
\quad\int x^e\widehat b_e(x)\,dx=1,
\]
\[
\sigma_e(r)=-r^{-e}\int_0^r(r')^e[F_e(r')-b_e(r')\mathcal M_e]\,dr',
\qquad(\partial_r+e/r)\sigma_e=-F_e+b_e\mathcal M_e,
\tag{C12}
\]

for \(e=2,1\), respectively. The negative sign cancels the supported averaged source, and the positive bump term is retained. The normalized stress pair is \(\Sigma=Q^{2A}(\sigma_2,\sigma_1)\in\mathcal M_{C^*-\kappa_s}\), independent of auxiliary coordinates. The companion `radial_stress_reconstruction_audit.md` supplies the support and moving-scale proof for this interface. The integral's differential in (C12) was repaired from the draft's literal `],dr'` to `]\,dr'`; this is a transcription repair with no change of integrand, sign or domain.

The fixed signed-amplitude operator uses the original positive primary amplitudes in its denominator. It gives a transverse signed correction with exponent
\((C^*-\kappa_s)-1/2=B-\kappa_s\). It does not replace the current covariance by a square root. The velocity is again realized as a curl, with the homogeneous pressure coefficient. Lemma 7.7 supplies the curl remainder; Proposition 7.6 and the covariance identity (7.36) supply the prescribed linear stress.

The nonzero-harmonic estimates are:

| Term | Original exponent | Gain relative to \(B\) |
| --- | --- | --- |
| Linear remainder | \(B+1/2-4\kappa_s\) | \(0.49996\) |
| Mean interaction | \(B+0.4-\kappa_s\) | \(0.39999\) |
| Old-wave cross | \(B+1/2-2\kappa_s\) | \(0.49998\) |
| Signed self-interaction | \(2B-3\kappa_s\) | \(B-3\kappa_s\ge0.69997\) |

The minimum is \(0.4-\kappa_s=0.39999\). Each row is obtained from the Step-1 estimate with input exponent \(B-\kappa_s\), except the self-row, which is \(2(B-\kappa_s)-\kappa_s\). This explicitly accounts for all three losses in that row.

For the auxiliary-averaged tensor, let \(s=t_s+r_s\) be the complete signed increment, decomposed into its transverse and curl pieces. Define the exact bilinear map on the extended angular/auxiliary fields by

\[
\mathcal B(a,b)=\langle\langle a\otimes b+b\otimes a\rangle_\theta\rangle_Y.
\tag{C13}
\]

Expanding the tensor product before either average gives

\[
\begin{aligned}
\langle\Delta W\rangle_Y
={}&\mathcal B(w_0^{\rm tan},t_s)
+\mathcal B(w-w_0^{\rm tan},t_s)
+\mathcal B(w,r_s)
+\langle\langle s\otimes s\rangle_\theta\rangle_Y.
\end{aligned}
\tag{C14}
\]

Indeed, the first two terms sum to \(\mathcal B(w,t_s)\), which together with the third equals \(\mathcal B(w,s)\). Adding \(s\otimes s\) is the exact difference between \((w+s)\otimes(w+s)\) and \(w\otimes w\). Thus no cross term or signed self-term was dropped. The first term's radial–tangential components equal \(\Sigma\) by the separately proved signed covariance map. Only their specified divergence cancels the source in (C12); the other tensor components and the pressure response remain.

The three remaining tensor exponents before radial divergence, and their resulting radial-flux gains relative to \(C^*\), are:

| Exact covariance term | Tensor exponent | After one \(\kappa_s\) loss |
| --- | --- | --- |
| Old-wave remainder times transverse signed correction | \(B+0.68-\kappa_s=C^*+0.18-\kappa_s\) | \(C^*+0.17998\) |
| Old exact wave times signed curl correction | \(C^*+1/2-2\kappa_s\) | \(C^*+0.49997\) |
| Signed self-product | \(2B-2\kappa_s=C^*+\sigma_j-2\kappa_s\) | \(C^*+\sigma_j-3\kappa_s\ge C^*+0.19997\) |

Other retained mean terms have gains \(1-\kappa_s\) for axial fluxes of the prescribed stress, \(1-2\kappa_s\) for the pressure effect on \(E_z\), and \(1-\kappa_s\) for the moment bump in (C12), using (C10). Every listed gain exceeds 0.17. Hence the source can retain the weaker common bound

\[
\langle E_\theta\rangle_Y,\langle E_z\rangle_Y\in\mathcal M_{C^*+0.17},
\quad E_\theta,E_z\in\mathcal M_H,
\quad(\mathcal P,J_\theta,J_z)\in\mathcal S_H,
\quad H=C^*-2\kappa_s.
\tag{C15}
\]

The bounds for the full auxiliary-dependent residual and pressure source at order \(H\) use the exact mean formulas and previous mean-operator estimates. They are not consequences of the covariance average alone.

## 5. Step 3: nonconstant auxiliary means, with the full axial remainder

For each current exact mean residual, define \(E_a^\circ=E_a-\langle E_a\rangle_Y\), \(a=\theta,z\). The prescribed update and its actual potential realization are

\[
\Delta v=-c_{i_0}^{-1}N_{i_0}^{-1}E_\theta^\circ,
\qquad\gamma_d=-c_{i_0}^{-1}N_{i_0}^{-1}E_z^\circ,
\]
\[
\Psi_* =\mathcal T_1\gamma_d,\qquad
\Delta\beta=-\varepsilon\partial_Z\Psi_*,\qquad
\Delta\gamma=(D_r+R^{-1})\Psi_*.
\tag{C16}
\]

The inverse is the zero-average Fourier inverse of Lemma 8.6. That lemma supplies the stated \(\mathcal M_H\) bounds for \(\Delta v,\gamma_d,\Delta\gamma\), \(\mathcal M_{H+1}\) for \(\Delta\beta\), and preservation of the two exact moments. The actual axial value is \(\Delta\gamma=\gamma_d-\mathcal A_1\gamma_d\), so its remainder must remain present:

\[
c_{i_0}N_{i_0}\Delta v=-E_\theta^\circ,
\qquad c_{i_0}N_{i_0}\Delta\gamma=-E_z^\circ+F_{\rm ax},
\qquad F_{\rm ax}=c_{i_0}N_{i_0}(\Delta\gamma-\gamma_d).
\tag{C17}
\]

The sign is positive in the axial cancellation equation, despite the axial increment's representation as \(\gamma_d-\mathcal A_1\gamma_d\). Here \(F_{\rm ax}=-c_{i_0}N_{i_0}\mathcal A_1\gamma_d\). It is a flat additive remainder by the earlier reconstruction estimate. Its absence is not assumed.

The wave \(w\), hence its complete covariance \(W\), stays fixed during this step. Subtracting the two versions of (C6), using \(t_*=-\varepsilon\partial_T+c_{i_0}N_{i_0}\) and (C17), gives exactly

\[
\begin{aligned}
E_{\theta,\mathrm{new}}-\langle E_\theta\rangle_Y
={}&-\varepsilon\partial_T\Delta v-\varepsilon(\Delta_0-R^{-2})\Delta v\\
&+(D_r+2/R)[(b+\beta)\Delta v+(V+v)\Delta\beta+\Delta\beta\Delta v]\\
&+D_z[(G+\gamma)\Delta v+(V+v)\Delta\gamma+\Delta\gamma\Delta v],\\
E_{z,\mathrm{new}}-\langle E_z\rangle_Y
={}&-\varepsilon\partial_T\Delta\gamma-\varepsilon\Delta_0\Delta\gamma+F_{\rm ax}\\
&+(D_r+1/R)[(b+\beta)\Delta\gamma+(G+\gamma)\Delta\beta+\Delta\beta\Delta\gamma]\\
&+D_z[2(G+\gamma)\Delta\gamma+(\Delta\gamma)^2+\Delta p_m].
\end{aligned}
\tag{C18}
\]

For example, the radial angular flux difference is
\(b\Delta v+V\Delta\beta+\beta\Delta v+v\Delta\beta+\Delta\beta\Delta v\), which is exactly the bracket in (C18). The axial square difference is \(2\gamma\Delta\gamma+(\Delta\gamma)^2\), together with the base \(2G\Delta\gamma\) and pressure \(\Delta p_m\). All quadratic terms in both equations are retained.

The class arithmetic uses the source's local base estimate

\[
|D^I b|\le C_I\varepsilon S_*^{b_I}
\quad\text{on the shell, for every fixed coefficient multi-index }I,
\tag{C18a}
\]

with \(V,G\) of order zero, the cumulative bounds (C4), and the known mean-operator estimates. Equation (C18a), stated on source page 110, does not assert \(b\in\mathcal M_1\): it does not give \(b\) the mean class's shell-edge factor \(\zeta\) or smooth zero extension. Those properties in \(b\Delta v\), \(b\Delta\gamma\), and \(b\Delta\beta\) are supplied by the actual increments.

More precisely, for an actual increment \(f\in\mathcal M_\alpha\), the exact coefficient Leibniz formula and Definition 6.4 give

\[
\begin{aligned}
D^I(bf)&=\sum_{J\le I}\binom IJ(D^Jb)(D^{I-J}f),\\
|D^I(bf)|&\le\sum_{J\le I}\binom IJ
C_JC_{j,I-J}\varepsilon^{1+\alpha}
S_*^{b_J+b_{j,I-J}}\zeta\,\delta^{-d_{j,I-J}}.
\end{aligned}
\tag{C18b}
\]

Every summand retains the increment's \(\zeta\) factor and its original edge exponent; none is replaced by a bound for the base's support. The sum is finite for fixed \(I\), and thus has the finite-constant form required by (6.24). On the bounded active shell, any change to a common edge exponent uses only the shell's fixed upper bound for \(\delta\) and adjusts constants. The product is zero wherever the zero extension of \(f\) is zero. At the two shell edges, each displayed derivative tends to zero by (6.23), since \(\zeta\delta^{-d}\) tends to zero faster than every power for every fixed \(d\). It therefore has the smooth zero extension required of the product. The base's angular and auxiliary independence and its original chart coherence preserve the corresponding properties of \(f\). This proves the multiplication passage used for these terms from the local estimate, without attributing those support properties to \(b\) itself.

| Term group in (C18) | Lowest exponent retained |
| --- | --- |
| Slow time | \(H+1\) |
| Radial flux | \(H+1-\kappa_s\) |
| Axial flux, including \(\Delta p_m\in\mathcal M_H\) | \(H+1\) |
| Viscosity with up to two radial losses | \(H+1-2\kappa_s\) |

Every product in the radial bracket has at least order \(H+1\): terms containing \(b\) supply 1; terms containing \(\Delta\beta\) supply its \(H+1\); old radial \(\beta\) supplies 1.9; and new quadratic terms have at least \(2H+1\). Axial differentiation supplies one to products of order at least \(H\). This verifies the minimum table using the stated input classes.

Thus the supported mean changes, after retaining \(F_{\rm ax}\) in the additive flat part, lie in
\(\mathcal M_{H+1-2\kappa_s}=\mathcal M_{C^*+1-4\kappa_s}\). With (C15),

\[
E_\theta,E_z\in\mathcal M_{\min(C^*+0.17,C^*+1-4\kappa_s)}
=\mathcal M_{C^*+0.17},
\tag{C19}
\]

because \(1-4\kappa_s=0.99996>0.17\). Here (C18) is the identity for the actual recomputed mean expressions; (C19) follows the source's supported-mean convention after transferring \(F_{\rm ax}\), together with the specified modified-integral remainders, into the separately retained additive flat residual of Proposition 9.3. In explicit component form this convention preserves the identity

\[
E^{\rm actual}_{a,\rm new}
=E^{\rm good}_{a,\rm new}+F^{\rm mean}_{a,\rm new},
\qquad a\in\{\theta,z\},
\tag{C19a}
\]

The exact dictionary to the source's decomposition (9.3) is fixed by its complete mean identity (9.6). Let \(\pi_\theta(v_r,v_\theta,v_z)=v_\theta\) and \(\pi_z(v_r,v_\theta,v_z)=v_z\). For the recomputed state, retain the source's complete supported vector \(G_{*,\rm new}\), additive flat vector \(F_{*,\rm new}\), and unchanged base error \(E_{B,*}\). Then

\[
\begin{aligned}
\bigl(D_rp_{m,\rm new}-g_{r,\rm new},
E^{\rm actual}_{\theta,\rm new},E^{\rm actual}_{z,\rm new}\bigr)
&=\langle G_{*,\rm new}+F_{*,\rm new}-E_{B,*}\rangle_\theta,\\
E^{\rm good}_{a,\rm new}&=\pi_a\langle G_{*,\rm new}\rangle_\theta,\\
F^{\rm mean}_{a,\rm new}&=\pi_a\langle F_{*,\rm new}-E_{B,*}\rangle_\theta,
\qquad a\in\{\theta,z\}.
\end{aligned}
\tag{C19b}
\]

Linearity of angular averaging and of the displayed component projections proves (C19a) from (C19b) with the original base-error subtraction retained. In particular, \(F^{\rm mean}\) is not being identified with the tangential components of \(\langle F_*\rangle_\theta\) alone. The base field has already been subtracted in the exact conservative correction balances (C6), while it remains part of the full physical residual decomposition. This dictionary changes none of the velocity, pressure, or nonlinear products.

Here (C19) is the class estimate for \(E^{\rm good}\), and the axial \(F^{\rm mean}\) retains the explicit \(+F_{\rm ax}\) in (C18). Its remaining terms are exactly those transferred by the source's additive residual decomposition. At a fixed stage, all-order \(q\)-flatness bounds this additive residual by any prescribed finite power of \(q\); it does not, by itself, prove the \(\zeta\)-weighted derivative, shell support, or smooth-extension requirements of \(\mathcal M_\alpha\). No such class membership for a flat term is inferred here unless the earlier support or interior construction also supplies those properties. In particular \(F_{\rm ax}\) remains present in (C18) and (C19a), and the actual \(\Delta\gamma\), including its reconstruction remainder, remains in every nonlinear product.

The new nonzero-harmonic interaction uses Lemma 9.2 with old wave exponent \(1/2\) and new mean exponent \(H\), yielding \(1/2+H-1/2=H\). Therefore its gain relative to \(B\) is

\[
H-B=\frac12-2\kappa_s=0.49998.
\tag{C20}
\]

The defects remain in \(\mathcal S_H\) after this mean step; this estimate uses their recomputed definitions, not an assertion that the temporal inverse corrects the three scalar defects.

## 6. Step 4: two exact moment constraints and three nonlinear residual defects

The five-equation inverse is applied to the current triple \((\mathcal P,J_\theta,J_z)\), with its original right-hand signs:

\[
\int R^2\Delta v\,dR=0,\qquad\int R\gamma_d\,dR=0,
\]
\[
\int(2V/R)\Delta v\,dR=-\mathcal P,
\quad\int R^2(G\Delta v+V\gamma_d)\,dR=-J_\theta,
\]
\[
\int(2RG\gamma_d-RV\Delta v)\,dR=-J_z.
\tag{C21}
\]

Lemma 8.7 supplies its fixed supported linear inverse under the stated reserved-patch base conditions, with \(\Delta\gamma=\gamma_d\) exactly, \(\Delta v,\Delta\gamma\in\mathcal M_H\) and \(\Delta\beta\in\mathcal M_{H+1}\). These increments are independent of both angular and auxiliary variables. Their existence, boundedness and the equality \(\Delta\gamma=\gamma_d\) do not follow just from displaying five equations; they are the earlier construction used at this step.

Keeping the wave and base fixed, define
\(R_g=g_{r,\mathrm{new}}-g_r-(2V/R)\Delta v\). Expansion of (C6) gives

\[
\begin{aligned}
R_g={}&-t_*\Delta\beta
-(D_r+1/R)[2b\Delta\beta+2\beta\Delta\beta+(\Delta\beta)^2]\\
&-D_z[b\Delta\gamma+G\Delta\beta+\beta\Delta\gamma
+\gamma\Delta\beta+\Delta\beta\Delta\gamma]\\
&+[2v\Delta v+(\Delta v)^2]/R
+\varepsilon(\Delta_0-R^{-2})\Delta\beta.
\end{aligned}
\tag{C22}
\]

In particular the centrifugal contribution beyond \((2V/R)\Delta v\) has a positive sign. The wave covariance has no change because this is a pure mean update.

The three defects use the original definitions

\[
J_\theta=\int R^2\langle Gv+V\gamma+\gamma v+W_{z\theta}\rangle_YdR,
\]
\[
J_z=\int R\langle2G\gamma+\gamma^2+W_{zz}\rangle_YdR
-\frac12\int R^2\langle g_r\rangle_YdR.
\tag{C23}
\]

Substitute \(g_{r,\mathrm{new}}=g_r+(2V/R)\Delta v+R_g\) and expand all products. The last three rows of (C21), with \(\Delta\gamma=\gamma_d\), cancel the old triple plus its base-linear changes. What remains exactly is

\[
\mathcal P_{\rm new}=\int\langle R_g\rangle_YdR,
\]
\[
(J_\theta)_{\rm new}
=\int R^2\langle\gamma\Delta v+v\Delta\gamma+\Delta\gamma\Delta v\rangle_YdR,
\]
\[
(J_z)_{\rm new}
=\int R\langle2\gamma\Delta\gamma+(\Delta\gamma)^2\rangle_YdR
-\frac12\int R^2\langle R_g\rangle_YdR.
\tag{C24}
\]

The coefficient \(-RV\Delta v\) in the last linear row of (C21) is exactly
\(-\frac12R^2(2V/R)\Delta v\) from the pressure-source moment in (C23). Therefore the minus sign in that row and the minus-half remainder in (C24) agree. The final defects are not identically zero: (C24) retains every nonlinear remainder.

The estimates are checked term by term from the same supported base and cumulative classes. Since the update is slow, \(t_*\Delta\beta=-\varepsilon\partial_T\Delta\beta\). The principal bounds in (C22) are

| Term | Exponent |
| --- | --- |
| \(-t_*\Delta\beta\) | \(H+2\) |
| \((D_r+1/R)(2b\Delta\beta)\) | \(H+2-\kappa_s\) |
| \(D_z(b\Delta\gamma+G\Delta\beta)\) | \(H+2\) |
| \(2v\Delta v/R\) | \(H+0.9\) |
| \((\Delta v)^2/R\) | \(2H\) |
| \(\varepsilon(\Delta_0-R^{-2})\Delta\beta\) | \(H+2-2\kappa_s\) |

The transport terms with old means have no lower exponent, using \(v,\gamma\in\mathcal M_{0.9}\), \(\beta\in\mathcal M_{1.9}\). Since \(H\ge1.19998>0.9\), also \(2H\ge H+0.9\). Thus every term is at least \(H+0.9-2\kappa_s\). The remaining moment products in (C24) have exponents \(H+0.9\) or \(2H\), and the earlier normalized moment estimates preserve their powers. Therefore

\[
(\mathcal P,J_\theta,J_z)_{\rm new}
\in\mathcal S_{H+0.9-2\kappa_s}
=\mathcal S_{C^*+0.9-4\kappa_s}
=\mathcal S_{C^*+0.89996}.
\tag{C25}
\]

The changes in wave and tangential residuals obey the same bounds as Step 3; there is no fast-time cancellation term in the slow update. Hence its added mean residual has order \(C^*+0.99996\), and its added nonzero wave residual has gain \(H-B=0.49998\).

## 7. Exact invariant checks and the completed exponent ledger

The structural invariants are preserved for the following precise reasons:

1. **Divergence and real fields.** Wave updates in Steps 1–2 are curls of the complete cutoff potentials. In Cartesian coordinates, \(\partial_i\epsilon_{ikl}\partial_kA_l=0\) by antisymmetry and commuting mixed derivatives. Mean meridional updates are curls of azimuthal potentials, and a direct angular field independent of \(\theta\) has zero divergence. Pairing conjugate harmonic coefficients preserves reality. These arguments require the stated smooth representatives, which Proposition 9.3 supplies for the generated sources and updates.

2. **Two zero moments.** Steps 1–2 change \(w\) and its pressure harmonics; every nonzero angular harmonic has zero angular average, so the direct mean components \(v,\gamma\) and (C5) are unchanged. Step 3's prescribed increments have zero auxiliary mean. Its actual axial reconstruction preserves the axial-flux moment by the identity in Lemma 8.6; it is not identified with the prescribed field without the remainder. Equivalently, for the smooth supported azimuthal potential, averaging \((D_r+R^{-1})\Psi_*\) gives \((\partial_R+R^{-1})\langle\Psi_*\rangle_Y\), whose \(R\)-weighted integral is the zero boundary term \([R\langle\Psi_*\rangle_Y]_0^\infty\). Step 4 preserves both moments by the first two rows of (C21), because \(\Delta\gamma=\gamma_d\) there.

3. **Complete pressure and nonlinear defects.** Each step uses (C7) on the complete new fields. The radial residual is the reconstructed one, \(-\rho\mathcal P\) plus the recorded flat reconstruction remainder, not an omitted radial equation. The three nonlinear defects are estimated by (C24) rather than declared zero.

4. **Cumulative low-order bounds.** Particular wave increments begin at \(B\ge0.7\); signed increments begin at \(B-\kappa_s\ge0.69999>0.68>1/2\). They therefore preserve both wave bounds in (C4) by finite addition. Mean updates have tangential and pressure order at least \(H\ge1.19998>0.9\), while radial updates have order \(H+1\ge2.19998>1.9\). Earlier wave-pressure increments have order at least \(C^*-\kappa_s\ge1.19999\). All improved \(\Delta g_r,\Delta p_m\) estimates concern increments; the total \(g_r,p_m\) need not acquire those high orders.

5. **Supports, common torus and harmonic closure.** These do not follow from scalar exponent inequalities. Proposition 9.3 supplies closure under differentiation, products, curl, pressure reconstruction, mean maps and fixed inverses, with smooth zero extensions. Same-label harmonics add integer multipliers; a quadratic product can double the finite harmonic range at one fixed stage. The range may grow with the stage but is finite and independent of the band at that stage. Distinct-label products vanish only by the earlier support-separation proof. Mean inverses may fill the auxiliary torus, but a nonzero harmonic product retains a wave factor and its source support. These are the specific upstream facts needed to use the next inverse.

Taking the minimum of the new nonzero-harmonic gains from all four steps gives

\[
\min\{0.4,0.4-\kappa_s,1/2-2\kappa_s,1/2-2\kappa_s\}
=0.39999>0.1.
\tag{C26}
\]

For the tangential mean after Steps 2–4,

\[
\min\{0.17,1-4\kappa_s,1-4\kappa_s\}=0.17>0.1.
\tag{C27}
\]

For defects the final gain is \(0.9-4\kappa_s=0.89996>0.1\). Hence the already established class bounds imply the weaker state requirements

\[
\mathcal G_{*,\mathrm{wave}}^{[j+1]}\in\mathcal W_{B+1/10},\quad
E_\theta,E_z\in\mathcal M_{C^*+1/10},\quad
(\mathcal P,J_\theta,J_z)\in\mathcal S_{C^*+1/10}.
\tag{C28}
\]

These indices are exactly \(B_{j+1}\) and \(C^*_{j+1}\) from (C2). No altered stage increment or smaller \(\kappa_s\) is needed.

## 8. Flat remainders and the use in the physical estimate (9.18)

The actual finite residual is decomposed in Proposition 9.3 as

\[
\mathcal R(u^{[j]},p^{[j]})=G^{[j]}+F^{[j]},\qquad
|F^{[j]}|_m\le C_{j,m,N}q^N\quad\text{for every fixed }j,m,N.
\tag{C29}
\]

The terms in \(F^{[j]}\) include the slow-base error, pulse-cutoff tails, modified radial-integral remainders and the axial \(F_{\rm ax}\) from (C17). The full velocity, including its reconstruction remainders, is still used in every nonlinear term of (C8), (C14), (C18) and (C22). Thus isolating an additive flat residual does not authorize deleting the associated velocity from later products.

The old additive flat term enters (C8) once. Newly generated flat terms are added; a term actually canceled by a fixed mean inverse is removed from that decomposition after cancellation. At any fixed stage the source proves there are finitely many types, uniformly estimated over labels. This is the role of Proposition 9.3; the exponent closure table alone cannot establish it.

For pulse tails the source bound has the form \(CQ^{-M}S_*^Pe^{-cS_*}\), with \(S_*=\ell^2\), \(Q=2^{-\ell}\). Dividing by a target \(Q^N\) leaves
\(C\ell^{2P}\exp[-c\ell^2+(M+N)\ell\log2]\). Its exponent tends to minus infinity because the negative quadratic dominates the fixed linear term and logarithmic power; explicitly, beyond a fixed \(\ell\), the latter contributions total at most \(c\ell^2/2\). It is therefore bounded by \(Ce^{-c\ell^2/2}\), which is bounded on the remaining half-line. Polynomially many labels alter \(P\) but retain this argument. Modified radial-integral flatness instead uses its separately proved all-order integration estimate; it is not replaced by this Gaussian argument.

In a fixed chart, the supported normalized residual at stage \(j\) has nonzero-wave order \(B_j=1/2+\sigma_j\), tangential mean order \(C_j^*=1+\sigma_j\), and radial defect order \(C_j^*\). Each is at least \(\sigma_j\). Keeping the original physical residual factor,

\[
\mathcal R=Q^{-2A-1/2}\mathcal R_*.
\tag{C30}
\]

Lemma 9.8 supplies mixed derivative costs independent of stage. In the actual coordinates these are dominated by \(s_x=1/2+h/2\) per spatial derivative and \(s_t=1+3h/2\) per time derivative, including evaluated phase factors and frame derivatives. For total order \(m\), a sufficient fixed loss for a supported residual coefficient is
\(2A+1/2+m(1+3h/2)\), enlarged if needed to a common loss for the stated background and supported terms. Its coefficient constants and powers of \(1+|\log q|\) may depend on \(j,m\). Converting \(Q\asymp q\) changes constants, not the stage independence of the loss.

Consequently the source's analytic class estimates plus this fixed conversion yield precisely the form

\[
|\mathcal R(u^{[j]},p^{[j]})|_m
\le C_{j,m}q^{h\sigma_j-K_m}(1+|\log q|)^{P_{j,m}}+E_{j,m},
\quad E_{j,m}\le C_{j,m,N}q^N,
\tag{C31}
\]

with \(h\sigma_j=h/5+hj/10\to\infty\) and \(K_m\) independent of \(j\). This is (9.18). Exponent arithmetic proves that the gain tends to infinity; the coefficient estimates, actual residual decomposition, uniformity over labels and physical phase differentiation are the preceding analytical work required for the inequality itself. No uniformity in \(j\) of the constants is inferred.

The companion `summation_realization_audit.md` proves how one fixed-stage comparison uses (C31), including its fixed \(E_{j,m}\), to obtain all-order flatness of the realized residual. The flat remainders are not summed over \(j\). That later summation is not repeated here.

## 9. Verification boundary

The following have been checked directly in this bounded audit: all displayed four-step exponent substitutions and closing inequalities; the covariance identity (C14); exact mean-update identities (C18); exact nonlinear radial and defect remainders (C22)–(C24); the pressure sign and retained product \(\partial_Z(c_\rho\mathcal P)\); the distinction between the two exactly preserved zero moments and the three nonzero improved defects; preservation of low-order classes by the specified finite increments; and the arithmetic passage to a gain \(h\sigma_j\) with a fixed derivative loss.

The following remain upstream source assertions, with their precise supplying results identified above: existence and uniform bounds for the pulse inverse; the full wave-amplitude estimates behind Propositions 9.1 and Lemma 9.2; the signed covariance operator; the temporal and five-equation inverse constructions; all-label support/flatness closure in Proposition 9.3; and the common domain in Lemma 9.7. The companion `radial_stress_reconstruction_audit.md` now proves the Step-2 compact radial inverse, its complete retained moment coordinate, mixed derivatives, full tensor force and chart correspondence, and flat-edge and uniform-band preservation. The actual incoming residual estimates, covariance realization, and inter-chart descent remain their respective source dependencies. This report does not replace the remaining claims with new assumptions or claim to prove the whole construction without them. It records exactly what the audited calculation establishes and where the actual earlier proof content must be verified.

No concrete exponent or algebraic sign defect was found in the audited cycle. The material interpretation is that Step 4 removes the old defects and their linear changes while retaining the nonlinear expressions (C24), whose higher order closes the next stage. Calling all three final defects identically zero would misstate the source.

## 10. Static formal-source correspondence

The following bounded six-file locator was completed by the subsidiary source-audit worker. The declaration bodies around `CorrectionAnalyticStep.step` and `ActualCyclePreservation.state_runInvariant` were also read directly in this lane. All line numbers refer to the exact hashed files below, under `formal/released_ns_validation/NavierStokes/`. No Lean was executed and no transitive proof-closure audit was made.

The scalar dictionary is literal: take Lean's stage index `n` to be the paper's \(j\), its real argument `σ` to be \(\sigma_j=1/5+j/10\), and its `κ` to be \(\kappa_s=1/100000\). Then `waveExponent σ`, `meanExponent σ`, and `meanUpdateExponent σ κ` unfold to \(1/2+\sigma_j=B\), \(1+\sigma_j=C^*\), and \(1+\sigma_j-2\kappa_s=H\). Under this dictionary the stage successor `σ + 1/10` is exactly \(\sigma_{j+1}\), because \(1/5+j/10+1/10=1/5+(j+1)/10\). Thus the following arithmetic declarations address the same scalar expressions, without changing the source's parameters.

| File and exact declarations | What the inspected source contains |
| --- | --- |
| `ExponentLedger.lean`: `waveExponent` 24, `meanExponent` 27, `meanUpdateExponent` 30; `particular_gain_eq` 80; `signed_gain_eq` 114 | Definitions \(B,C^*,H\); particular gain \(2/5\); signed gain \(2/5-\kappa\) for the displayed admissible parameters. |
| `ExponentLedger.lean`: `signedBarGain` 44; `signed_bar_gain_exceeds_seventeen_hundredths` 178 | The complete five-term minimum \(\min\{9/50-2\kappa,1/2-3\kappa,\sigma-3\kappa,1-\kappa,1-2\kappa\}\), and its strict comparison with \(17/100\). These are exactly the three tensor remainders, axial/moment contribution and pressure contribution retained in Section 4. |
| `ExponentLedger.lean`: `mean_update_wave_margin` 193; `completed_mean_gain_eq` 203; `completed_mean_margin` 208; `completed_defect_margin` 220; `stageParameter` 286; `all_stage_arithmetic` 304 | The mean-update wave margin, \(\min(17/100,1-4\kappa)=17/100\), the mean and defect stage margins, and their package at \(1/5+n/10\). These declarations state comparisons of real numbers, without asserting the existence of fields. |
| `ActualIterationLedger.lean`: `gain` 29, `kappa` 32, `sigma_formula` 36, `all_cycle_margins` 119; `residualWave_formula` 231, `residualMean_formula` 235, `cycle_wave_output` 239, `cycle_mean_output` 243, `residual_physical_gap` 252 | The fixed \(\kappa=1/100000\), \(\sigma_j=1/5+j/10\), \(B_j=j/10+7/10\), \(C_j^*=j/10+6/5\), successor comparisons, and the exact identity \(hB_j=hj/10+7h/10\). `gain` is \(hj/10\). This ledger does not by itself establish an estimate for an actual residual. |
| `CorrectionState.lean`: `MeanResidualBounds` 216; `radialMoment` 226; `pressureDefect` 229; `thetaDefect` 232; `axialDefect` 236; `debt` 242; `DefectBounds` 246; `ZeroMasses` 250 | Mean angular/axial residual membership at \(1+\sigma\); weighted radial moments; the stored defect vector in the order \((\mathcal P,J_\theta,J_z)\); its class membership at \(1+\sigma\); and the two exactly vanishing masses. |
| `CorrectionStep.lean`: `CycleParameters.afterParticular` 5042, `afterSigned` 5066, `afterTemporal` 5073, `afterRank` 5079, `next` 5084; `CycleState.step` 6947 | The four successive actual updates and subsequent radial-pressure alias refresh, including the represented state, coefficients and axisymmetric alias. |
| `CorrectionStep.lean`: `CycleParameters.next_zeroMassesOn` 9144; `CycleAnalyticInvariant` 9408, especially 9440–9448 and 9457–9459 | The analytic invariant stores harmonic residual membership at \(1/2+\sigma\), mean/debt membership at \(1+\sigma\), the reconstructed-state identity, exact zero masses on its slow carrier, zero Gaussian angular mean, zero alias coefficients and all-power axis-alias bounds. The zero-mass preservation theorem uses the primitive regularity, moving covariance, rank geometry, matching-length and radial-containment data; it is not an arithmetic declaration. |
| `CorrectionAnalyticStep.lean`: `StepData` 470, `cross_tail` 500, `StepResult` 506, `step` 521 | `step` produces the invariant at \(\sigma+1/10\), temporal/rank increments and pressure difference at \(1+\sigma-2\kappa\), velocity-coefficient difference at \(1/2+\sigma-\kappa\), and pressure-coefficient difference at \(1+\sigma-\kappa\). Its actual inputs include `StaticData`, incoming invariant and `StepData`: wave estimates and regularity, supports, assembly, rank geometry and the exact tail cross-stress identity. |
| `ActualCyclePreservation.lean`: `RunInvariant` 768; `next_runInvariant_of_particular` 800; `particularData` 812; `next_runInvariant` 817; `state_runInvariant` 826; `state_result` 882; `state_afterTemporal_debt` 894 | The actual iteration combines the analytic invariant, chart coherence and periodicity. `particularData` invokes the construction of particular-solver data internally. Accordingly `state_runInvariant B N0 hN j` has the fixed construction indices, the displayed geometric-threshold premise and stage index as its arguments; it does not leave particular-solver data as a separately supplied argument. `state_result` retains the corresponding `StepResult`. |

The exact component dictionary for the stored defects can be read without identifying any unexamined function spaces. At line 226, `radialMoment k f` is `fun n p => PressureStream.pressureMass (fun x => x.1 ^ k * f n x) p`. Substitution into the three definitions gives:

\[
\begin{aligned}
\texttt{pressureDefect}&=\texttt{radialMoment 0 }(u.g_r),\\
\texttt{thetaDefect}&=\texttt{radialMoment 2 }
  (\texttt{thetaAxial}(c.\mathrm{base},u.\mathrm{mean})+u.\mathrm{covariance}_{2,1}),\\
\texttt{axialDefect}&=\texttt{radialMoment 1 }
  (\texttt{axialAxial}(c.\mathrm{base},u.\mathrm{mean})+u.\mathrm{covariance}_{2,2})
  -\tfrac12\,\texttt{radialMoment 2 }(u.g_r).
\end{aligned}
\tag{C32}
\]

Here formal indices \(0,1,2\) encode the radial, angular and axial component slots, respectively. Formula (C32) preserves the paper's weighted powers \(0,2,1,2\), the covariance positions \((z,\theta),(z,z)\), and the negative \(1/2\) pressure-source term. The `ZeroMasses` fields are the weighted angular and axial mean moments of orders 2 and 1. This is a declaration-level component correspondence; this bounded lookup does not assert that all carrier definitions, evaluations, regularity classes and reconstruction operators are fully equivalent to the manuscript presentations. The exact construction/proof content for those operators remains in the upstream source identified in the table.

In particular, reading a generic analytic theorem with structured inputs does not justify claiming that the released actual iteration merely assumes those inputs: the inspected `particularData` and `state_runInvariant` declarations explicitly supply that interface at the actual iteration. Conversely, seeing those declarations in text does not establish that the complete dependency closure passes a kernel or configured comparator check. This report makes neither claim.

### Frozen source identities

| Relative file under the research root | Bytes | SHA256 |
| --- | ---: | --- |
| `downloaded_public_release/navier-stokes.pdf` | 2959204 | `0e779481c4da40bd28d1e642e1d8ca57447d129610df28dfa5a11e9af8ae228f` |
| `downloaded_public_release/current_pdf_extracted.txt` | 683841 | `f83414ea543ffd89910b9b8a35d1680a2e3295246c91cbedf54e719a7bc316d0` |
| `formal/released_ns_validation/NavierStokes/ExponentLedger.lean` | 11470 | `06b9d8d6439b0bdd72f44ce404b1ce986e68f367c03c7dfd5edca8e2d2a0140a` |
| `formal/released_ns_validation/NavierStokes/ActualIterationLedger.lean` | 19306 | `25a1b7e920cfe0af7cdda488c4d0407ee47c526abcfa3a6491a8fb335a1a6a31` |
| `formal/released_ns_validation/NavierStokes/CorrectionState.lean` | 23856 | `22eeff8985d8e546ad4fac61a9f87f778c0f152413bbb8e0e2b55fe7d06b7a1d` |
| `formal/released_ns_validation/NavierStokes/CorrectionStep.lean` | 575619 | `a5ab01cd25d186deec3f136cc15d2d31032151ae7ddb5213a7f3d6b244ec8f8f` |
| `formal/released_ns_validation/NavierStokes/CorrectionAnalyticStep.lean` | 39528 | `cdb8d393c22b2d11e39e7589bcb3cbfa0ed8cc8837835dea69e17f4863821ab2` |
| `formal/released_ns_validation/NavierStokes/ActualCyclePreservation.lean` | 47390 | `f6d26b802063ee803bcc2e7923555481144e6919f64ddcb4d265cdd4d0d4674c` |

The historical `stage_cycle_gain_audit_receipt.json` records its earlier note snapshot, exact source identities and hashes of the four rendered pages inspected. The later `stage_cycle_precision_review.md` records the amended note hash and the precise added mean-residual dictionary and companion coverage. The audited bounded task is complete; no whole-construction or Navier–Stokes proof conclusion is asserted.
