# Independent precision review: local base multiplier and exact residual decomposition

Review completed 2026-09-08 21:05 UTC, with the subsequently authorized final scope correction recorded below. The reviewed `stage_cycle_gain_audit.md` snapshot immediately after adding (C19b) had SHA256 `7d222a3661fd0b18162dc2fad86e9097be2f036c11437a79d55e09b8d13578e3`. This receipt is an addendum to the historical `stage_cycle_gain_audit_receipt.json`; that earlier receipt has not been overwritten or represented as covering later text.

The preserved original PDF SHA256 is `0e779481c4da40bd28d1e642e1d8ca57447d129610df28dfa5a11e9af8ae228f`. Its `../../downloaded_public_release/current_pdf_extracted.txt` has SHA256 `f83414ea543ffd89910b9b8a35d1680a2e3295246c91cbedf54e719a7bc316d0`.

The bounded task was to check (C18a)–(C19a), its supporting source class definitions, and the exact relation between actual conservative mean balances and the supported-plus-flat source decomposition. The parent then explicitly authorized the reviewer to add the precise source dictionary (C19b) and its explanatory paragraph to the stage note. That amendment was made and the resulting (C18a)–(C19b) was read again. The parent subsequently authorized the final editorial scope correction recorded below. No additional mathematical expansion or source-file modification was made. No Lean, Lake, Elan, symbolic checker, or source script was executed.

## Local base multiplier

The all-order shell estimate in (C18a) is literally used on source page 110 (extracted text around line 5763). Equation (5.42), page 60, supplies the realized base estimates on a fixed enlargement of the closed active shell for every composition of \(q\partial_q,\partial_X,\partial_\eta\). The earlier chart argument on pages 73–74 and 77 transfers the retained radial \(\varepsilon\) factor to fixed slow coefficient derivatives. Lemma 8.8, page 99, also explicitly states the local derivative bounds for b and the order-zero bounds for V and G that its estimate uses. These source statements were inspected; their complete upstream base construction is not re-certified by this review.

The derivative \(D^I\) in (C18a)–(C18b) is the ordinary coefficient multi-derivative of Definition 6.4 in \((R,Z,T,H_1,H_2)\), with the band, representative, and harmonic index held fixed. It is not the evaluated variable-coefficient operator \(D_r\). With that exact meaning, the displayed multi-index Leibniz sum is correct and contains every term with coefficient \(\binom I J\).

For each term, the product of the source bounds is exactly

\[
\binom I J C_JC_{j,I-J}\varepsilon^{1+\alpha}
S_*^{b_J+b_{j,I-J}}\zeta\delta^{-d_{j,I-J}}.
\]

The base supplies its derivative bound and its one power of \(\varepsilon\); the established increment supplies the original \(\zeta\), edge exponent, and support. All sums are finite at a fixed I. Since \(0<\delta\le1\), replacing its finitely many exponents by their maximum is a valid upper bound. On the source's active bands \(S_*=\ell^2\ge1\), its finitely many exponents can also be bounded by their maximum. Equivalently, the uncombined finite sum in (C18b) already retains all original factors and proves the product estimate.

The product is zero outside the increment's supported shell. Every displayed derivative tends to zero at its edges because the source's \(\zeta\delta^{-d}\) vanishes faster than every power for each fixed d. Near an edge, X is a smooth transverse coordinate with nonzero radial derivative, and the bounded coordinate changes preserve these zero derivative limits. Extending by zero therefore gives the required jointly smooth product. Angular independence and common-torus coherence are preserved because the base is independent of the angular and auxiliary variables and is the same original base coefficient in the overlapping representations.

Thus the proof establishes the multiplier passage used in (C18). It neither asserts \(b\in\mathcal M_1\) nor manufactures the increment's \(\mathcal M_\alpha\) membership from an unweighted size bound.

## Term groups and retained axial remainder

The complete brackets in (C18) retain the old/new cross terms and the new quadratic products. The local multiplier estimate gives order at least \(H+1\) to the radial-bracket terms containing b. Terms containing \(\Delta\beta\) also have order at least \(H+1\); old radial \(\beta\) supplies its original order 1.9, and the new quadratic terms have order at least \(2H+1\). One explicit \(D_r\) loses at most \(\kappa_s\). In the axial bracket the products have order at least H and \(D_z\) supplies one. Slow time supplies one. The viscous operator has at most two radial losses and its original explicit \(\varepsilon\). This verifies all four rows leading to \(H+1-2\kappa_s=C^*+1-4\kappa_s\) from the displayed input classes.

The actual reconstruction remains \(\Delta\gamma=\gamma_d-\mathcal A_1\gamma_d\), giving exactly

\[
c_{i_0}N_{i_0}\Delta\gamma=-E_z^\circ+F_{\rm ax},
\qquad F_{\rm ax}=-c_{i_0}N_{i_0}\mathcal A_1\gamma_d.
\]

Its sign in the actual axial equation is positive. The note retains that term and uses the complete actual \(\Delta\gamma\) in every nonlinear product. The source page 110 expressly estimates the mean change after subtracting this additive axial remainder and retains it in the flat part. The audited convention follows that distinction.

## Exact source dictionary added as (C19b)

The relevant original identity is (9.6), rather than an unspecified decomposition of a scalar mean. With the same component ordering \((r,\theta,z)\) as the source it is

\[
\langle G_{*,\rm new}+F_{*,\rm new}-E_{B,*}\rangle_\theta
=\bigl(D_rp_{m,\rm new}-g_{r,\rm new},
E^{\rm actual}_{\theta,\rm new},E^{\rm actual}_{z,\rm new}\bigr).
\]

The amendment defines the literal component projections and sets

\[
E^{\rm good}_{a,\rm new}=\pi_a\langle G_{*,\rm new}\rangle_\theta,
\qquad
F^{\rm mean}_{a,\rm new}=\pi_a\langle F_{*,\rm new}-E_{B,*}\rangle_\theta.
\]

Linearity proves (C19a) exactly. In particular, the minus sign on the unchanged base error is retained; the conservative correction balance has already removed that base contribution. Only angular averaging occurs in this dictionary. No auxiliary averaging, physical phase evaluation, or identification of independent coordinate representations was inserted.

The class estimate (C19) applies to the supported term under the source's stated convention. All-order q-flatness alone does not establish the shell-edge weight or support required by Definition 6.4; the note explicitly preserves that limit on the inference. Whether a particular reconstructed flat remainder also belongs to every \(\mathcal M_\alpha\) requires its actual support and edge properties from the upstream construction. The current note does not claim to derive those properties from q-flatness alone.

No remaining sign or product-rule correction was found within (C18a)–(C19b). This receipt does not re-audit all earlier cycle inverses, prove the complete finite-stage support construction, or certify the whole Navier–Stokes proof.

## Final scope correction and current note hash

The final stage note has SHA256 `51999132c55de1984538b276517cf8dc6b00a743c00a4eb617e88da0c9480ed7`. Section 9 now records the exact completed companion coverage: the compact radial inverse and moment coordinate, all mixed derivatives, full force/chart correspondence, and edge/band preservation. It retains the actual incoming residual, covariance realization, and inter-chart descent as their respective source dependencies. This replaces the stale classification of the entire radial inverse as still unaudited.

The provenance footer now correctly describes the earlier JSON receipt as historical and points to this precision receipt for the amended note hash. The mathematics of (C18a)–(C19b) is unchanged from the directly reread snapshot above. No further expansion was made.
