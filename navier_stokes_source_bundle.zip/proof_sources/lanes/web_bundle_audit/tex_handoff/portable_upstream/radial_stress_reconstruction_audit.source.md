# Compact radial stress reconstruction with every moment, derivative and chart factor

This is a full independent calculation of the radial stress map in Proposition 9.6 Step 2, physical page 109 of the frozen 166-page manuscript. The source is `programme/downloaded_public_release/navier-stokes.pdf`, SHA256 `0e779481c4da40bd28d1e642e1d8ca57447d129610df28dfa5a11e9af8ae228f`. Page 109 was rendered and visually inspected in this lane; its profile factor, lower integration endpoint, moment, sign and chart power are the ones below. This calculation proves the displayed operator and its full force correspondence. It does not establish the upstream amplitude or finite-stage residual bounds to which the operator is applied.

## 1. Original parameters and supported spaces

Keep the source physical variables \((r,z,t)\), \(r>0\), and its positive smooth function \(q=q(z,t)\). Write \(\Omega\) for its parameter domain. In the source application
\[
\tau=1-t,\qquad A=\frac12+h,\qquad D=\frac12-h,\qquad 0<h<\frac1{100},
\quad q-z^2q^{2h}=\tau,
\tag{R1}
\]
on the specified positive branch. The complete inverse and derivative formulas for this branch were proved in Sections 2–3 of `summation_realization_audit.md`; in particular
\[
|\partial_z^a\partial_t^bq|\le C_{a,b}q^{1-aD-b}.
\tag{R2}
\]
No value of \(q\), \(Q\), \(h\), \(A\), \(D\), viscosity or physical coordinate is set to one in this calculation.

Fix positive constants \(0<a_-<a_+<\infty\) covering the source annulus and the interior profile supports. Let \(\mathcal E\) be the vector space of smooth scalar fields \(F(r,z,t)\) supported in
\[
a_-\sqrt{q(z,t)}\le r\le a_+\sqrt{q(z,t)}.
\tag{R3}
\]
Smooth zero extensions are part of this space. Thus all derivatives vanish at either boundary when continued outside; on a compact subset of \(\Omega\), the radial supports lie in one compact interval bounded away from zero. The source uses \(e=2\) for its angular residual and \(e=1\) for its axial residual. The constructions below are given separately for each \(e\in\{1,2\}\), with that original weight retained.

Choose the source interior profile \(\widehat b_e\in C_c^\infty((a_-,a_+))\) with
\[
\int_0^\infty x^e\widehat b_e(x)\,dx=1,
\qquad
b_e(r,z,t)=q^{-(e+1)/2}\widehat b_e(r/\sqrt q).
\tag{R4}
\]
Such a profile exists explicitly: take a nonnegative nonzero smooth bump \(\eta\) supported inside \((a_-,a_+)\), keep its positive number \(d_e=\int x^e\eta(x)dx\), and set \(\widehat b_e=\eta/d_e\). This division retains the complete chosen profile and its moment factor. With \(x=r/\sqrt q\), the exact moment calculation is
\[
\int_0^\infty r^eb_e(r,z,t)\,dr
=q^{e/2}q^{-(e+1)/2}q^{1/2}\int_0^\infty x^e\widehat b_e(x)\,dx=1.
\tag{R5}
\]

## 2. Exact moment complement and radial inverse

Define the moment map, its section, and its complementary projection by
\[
M_eF(z,t)=\int_0^\infty r^eF(r,z,t)\,dr,\quad
S_em=b_em,\quad
P_eF=F-b_eM_eF.
\tag{R6}
\]
The parameter function \(m\) belongs to \(C^\infty(\Omega)\). Differentiation under the integral is justified on every compact parameter set by the common radial support described after (R3). Equation (R5) proves
\[
M_eS_e=I,\quad P_e^2=P_e,\quad
\operatorname{ran}P_e=\ker M_e,\quad
\ker P_e=\operatorname{ran}S_e.
\tag{R7}
\]
For example \(M_eP_eF=M_eF-M_eF=0\); if \(M_eF=0\), then \(P_eF=F\); if \(P_eF=0\), then \(F=S_eM_eF\). These establish the displayed range and kernel identities in both directions.

The compact stress operator and radial differential operator are
\[
\mathcal T_eF(r,z,t)=-r^{-e}\int_0^r s^e(P_eF)(s,z,t)\,ds,
\qquad \mathcal D_e\sigma=\partial_r\sigma+\frac e r\sigma.
\tag{R8}
\]
For brevity write \(H=P_eF\), \(I(r)=\int_0^rs^eH(s)ds\), \(\sigma=\mathcal T_eF=-r^{-e}I\). Differentiating with all signs gives
\[
\partial_r\sigma=e r^{-e-1}I-H,\qquad
\mathcal D_e\sigma=e r^{-e-1}I-H-e r^{-e-1}I=-H=-F+b_eM_eF.
\tag{R9}
\]
Below the annulus the integral is zero. Above the annulus it equals \(M_eH=0\). Thus \(\sigma\) has exactly the common support property (R3) and is smooth across both boundaries. This support statement uses the full moment subtraction; it would be false for an arbitrary uncorrected source.

Conversely every \(\sigma\in\mathcal E\) satisfies
\[
M_e(\mathcal D_e\sigma)=\int_0^\infty\partial_r(r^e\sigma)\,dr=0.
\tag{R10}
\]
For such a stress,
\[
\mathcal T_e(-\mathcal D_e\sigma)
=r^{-e}\int_0^r\partial_s(s^e\sigma(s))\,ds=\sigma(r),
\tag{R11}
\]
because \(s^e\sigma(s)\) vanishes near zero. Thus \(-\mathcal D_e:\mathcal E\to\ker M_e\) is one-to-one and onto, with inverse the restriction of \(\mathcal T_e\). Injectivity also follows directly: the homogeneous equation gives \(\sigma=c(z,t)r^{-e}\), and compact radial support forces \(c=0\).

The complete map retaining the scalar moment is therefore the exact bijection
\[
\mathfrak T_e:\mathcal E\longrightarrow\mathcal E\oplus C^\infty(\Omega),
\quad F\longmapsto(\mathcal T_eF,M_eF),
\qquad
\mathfrak T_e^{-1}(\sigma,m)=-\mathcal D_e\sigma+b_em.
\tag{R12}
\]
To check surjectivity and both inverse identities, apply (R10) and (R5) to the last expression, obtaining moment \(m\) and moment-zero part \(-\mathcal D_e\sigma\). Equation (R11) returns \(\sigma\). Conversely (R9) reconstructs the original \(F\). Hence a source with nonzero moment has not been replaced by its moment-zero part; its complete missing coordinate is the displayed scalar \(M_eF\).

## 3. Every moving-q profile derivative

Put \(\alpha_e=(e+1)/2\), \(\xi=rq^{-1/2}\), and \(\mathscr E=-\xi\partial_\xi/2\). For \(k\ge0\), first differentiate in the original physical radial coordinate:
\[
\partial_r^kb_e=q^{-\beta}\widehat b_e^{(k)}(\xi),\qquad \beta=\alpha_e+k/2.
\tag{R13}
\]
At fixed \(r\), every derivative with respect to the scalar \(q\) obeys the exact identity
\[
\frac{d^n}{dq^n}\big[q^{-\beta}f(rq^{-1/2})\big]
=q^{-\beta-n}\left[\prod_{\ell=0}^{n-1}(\mathscr E-\beta-\ell)f\right](\xi).
\tag{R14}
\]
For \(n=0\) the product is the identity. For the induction step, differentiating \(q^{-\beta-n}\) contributes \(-\beta-n\), and differentiating the profile contributes \(\mathscr E\), both with one additional factor \(q^{-1}\). Their sum is the next factor in (R14), proving the formula at every order.

For nonnegative integers \(a,b\), let \(\mathcal P_{a,b}\) be the finite set of families of integers \(n_{u,v}\ge0\), indexed by \(u,v\ge0\), \(u+v>0\), satisfying
\[
\sum_{u,v}u n_{u,v}=a,\quad \sum_{u,v}v n_{u,v}=b,
\qquad n=\sum_{u,v}n_{u,v}.
\tag{R15}
\]
Only \(u\le a,v\le b\) can occur. For \(a=b=0\), this set has the single empty family with \(n=0\). The full multivariate chain rule is
\[
\begin{aligned}
\partial_r^k\partial_z^a\partial_t^bb_e
=a!b!\sum_{\mathcal P_{a,b}}&q^{-\beta-n}
\left[\prod_{\ell=0}^{n-1}(\mathscr E-\beta-\ell)\widehat b_e^{(k)}\right](\xi)\\
&\times\prod_{u,v}
\frac{(\partial_z^u\partial_t^vq)^{n_{u,v}}}
{n_{u,v}!(u!v!)^{n_{u,v}}}.
\end{aligned}
\tag{R16}
\]
For justification, distribute the labeled \(a\) axial and \(b\) time derivatives into nonempty blocks striking \(q\). A block with \(u\) axial and \(v\) time derivatives gives \(\partial_z^u\partial_t^vq\); unordered repetitions give the denominator \(n_{u,v}!\), and permutations inside each block give \((u!v!)^{n_{u,v}}\). The outside labels give \(a!b!\), and the number of blocks is the order \(n\) of the scalar derivative in (R14). This enumerates every product-rule term exactly once.

Combining (R2), (R15) and (R16) preserves the exact power
\[
q^{-\beta-n}\prod_{u,v}q^{(1-uD-v)n_{u,v}}
=q^{-\alpha_e-k/2-aD-b}.
\tag{R17}
\]
An explicit finite derivative constant is
\[
\mathfrak B_{k,a,b}=a!b!\sum_{\mathcal P_{a,b}}
\left\|\prod_{\ell=0}^{n-1}(\mathscr E-\beta-\ell)\widehat b_e^{(k)}\right\|_\infty
\prod_{u,v}\frac{C_{u,v}^{n_{u,v}}}{n_{u,v}!(u!v!)^{n_{u,v}}}.
\tag{R18}
\]
The profile norm is on its original compact interval; all derivatives remain supported there. Therefore
\[
|\partial_r^k\partial_z^a\partial_t^bb_e|
\le\mathfrak B_{k,a,b}q^{-\alpha_e-k/2-aD-b}.
\tag{R19}
\]
No moving-boundary term or derivative of \(q\) has been dropped.

## 4. Full stress derivatives and finite operator estimates

The moment derivative formula and complete derivative of the projected source are
\[
\partial_z^a\partial_t^bM_eF=\int_0^\infty r^e\partial_z^a\partial_t^bF\,dr,
\tag{R20}
\]
\[
\partial_r^k\partial_z^a\partial_t^bH
=\partial_r^k\partial_z^a\partial_t^bF
-\sum_{a'=0}^a\sum_{b'=0}^b\binom a{a'}\binom b{b'}
(\partial_r^k\partial_z^{a'}\partial_t^{b'}b_e)
(\partial_z^{a-a'}\partial_t^{b-b'}M_eF).
\tag{R21}
\]
The integration limits in (R20) are fixed. The smooth supported extension, rather than a discarded moving-boundary derivative, justifies differentiation.

Let \((e)_k=e(e+1)\cdots(e+k-1)\), with \((e)_0=1\), and \(e_{\underline\ell}=e(e-1)\cdots(e-\ell+1)\), with \(e_{\underline0}=1\) and value zero when \(\ell>e\). Put \(I_{a,b}(r)=\int_0^rs^e\partial_z^a\partial_t^bH(s)ds\). The complete radial product rule in (R8) gives
\[
\begin{aligned}
\partial_r^k\partial_z^a\partial_t^b\sigma
={}&-(-1)^k(e)_k r^{-e-k}I_{a,b}(r)\\
&-\sum_{j=1}^k\binom kj(-1)^{k-j}(e)_{k-j}r^{-e-k+j}
\sum_{\ell=0}^{j-1}\binom{j-1}\ell e_{\underline\ell}r^{e-\ell}
\partial_r^{j-1-\ell}\partial_z^a\partial_t^bH.
\end{aligned}
\tag{R22}
\]
Indeed derivatives of \(r^{-e}\) give the first signed rising factors, while for \(j\ge1\), \(\partial_r^jI_{a,b}=\partial_r^{j-1}(r^e\partial_z^a\partial_t^bH)\), giving the inner finite sum. When \(k=0\) the second sum is empty. Thus (R22) includes every derivative of the integral and every exterior weight.

Here is a quantitative operator estimate preserving general exponents and logarithms. Write
\[
\Lambda(q)=1+|\log q|,\qquad
c_e=\frac{a_+^{e+1}-a_-^{e+1}}{e+1},
\tag{R23}
\]
and for real \(\lambda,P\) and integer \(m\ge0\) define the actual weighted seminorm
\[
N_{\lambda,P;m}(F)=
\max_{k+a+b\le m}\sup_{r,z,t}
q^{-\lambda+k/2+aD+b}\Lambda(q)^{-P}
|\partial_r^k\partial_z^a\partial_t^bF|.
\tag{R24}
\]
For (R25)–(R29), require \(a+b\le m\) when no radial derivative index is present, and \(k+a+b\le m\) otherwise. All inequalities below are valid also as inequalities with an infinite right side. For finite \(N=N_{\lambda,P;m}(F)\), the exact annular integral \(\int_{a_-\sqrt q}^{a_+\sqrt q}r^e dr=c_eq^{\alpha_e}\) gives
\[
|\partial_z^a\partial_t^bM_eF|
\le c_eN q^{\lambda+\alpha_e-aD-b}\Lambda(q)^P.
\tag{R25}
\]
Define the finite constants
\[
\mathfrak H_{k,a,b}=1+c_e\sum_{a'=0}^a\sum_{b'=0}^b
\binom a{a'}\binom b{b'}\mathfrak B_{k,a',b'}.
\tag{R26}
\]
Equations (R19), (R21) and (R25) then give
\[
|\partial_r^k\partial_z^a\partial_t^bH|
\le\mathfrak H_{k,a,b}N q^{\lambda-k/2-aD-b}\Lambda(q)^P.
\tag{R27}
\]
The two profile/moment powers cancel their \(\alpha_e\) exactly. No logarithmic exponent is changed, since \(q\) is constant during the radial integration and derivatives of the complete source already occur in (R24).

On the support (R3), \(r\ge a_-\sqrt q\). Apply (R27) to (R22), retaining each power, and define
\[
\begin{aligned}
\mathfrak S_{k,a,b}={}&(e)_k a_-^{-e-k}c_e\mathfrak H_{0,a,b}\\
&+\sum_{j=1}^k\sum_{\ell=0}^{j-1}
\binom kj(e)_{k-j}\binom{j-1}\ell e_{\underline\ell}
a_-^{j-k-\ell}\mathfrak H_{j-1-\ell,a,b}.
\end{aligned}
\tag{R28}
\]
Every exponent \(j-k-\ell\) is nonpositive, so the lower radial bound gives the displayed upper factor. The integral term has power \(q^{\lambda+\alpha_e-(e+k)/2-aD-b}=q^{\lambda+1/2-k/2-aD-b}\). Every nonintegral term has power
\(q^{(j-k-\ell)/2}q^{\lambda-(j-1-\ell)/2-aD-b}\), which is the same power. Thus
\[
|\partial_r^k\partial_z^a\partial_t^b\mathcal T_eF|
\le\mathfrak S_{k,a,b}N q^{\lambda+1/2-k/2-aD-b}\Lambda(q)^P,
\tag{R29}
\]
and outside the annulus both sides of the differentiated field are zero. Taking the finite maximum proves
\[
N_{\lambda+1/2,P;m}(\mathcal T_eF)
\le\max_{k+a+b\le m}\mathfrak S_{k,a,b}\,N_{\lambda,P;m}(F).
\tag{R30}
\]
Equations (R18), (R26), and (R28) are explicit formulas for every constant. They depend on the original annulus, profile and derivatives of \(q\), not on a correction-stage amplitude. This proves the half-power radial integration gain and full mixed-derivative continuity, without deriving any unavailable estimate for the source \(F\) itself.

## 5. Full symmetric tensor and all three force components

Use the original right-handed cylindrical frame
\[
e_r=(x_1/r,x_2/r,0),\quad e_\theta=(-x_2/r,x_1/r,0),\quad e_z=(0,0,1).
\tag{R31}
\]
For the source pair \((F_2,F_1)\), put \(\sigma_2=\mathcal T_2F_2\), \(\sigma_1=\mathcal T_1F_1\). The symmetric tensor with precisely these radial–tangential entries is
\[
\mathbb T=\sigma_2(e_r\otimes e_\theta+e_\theta\otimes e_r)
+\sigma_1(e_r\otimes e_z+e_z\otimes e_r).
\tag{R32}
\]
The Cartesian divergence convention is \((\operatorname{div}\mathbb T)_i=\sum_j\partial_{x_j}\mathbb T_{ij}\). For any smooth vectors \(a,b\), the product rule gives
\(\operatorname{div}(a\otimes b)=(b\cdot\nabla)a+a\operatorname{div}b\). Here \(\operatorname{div}e_r=1/r\), \(\operatorname{div}e_\theta=\operatorname{div}e_z=0\), \((e_\theta\cdot\nabla)e_r=e_\theta/r\), and radial or axial derivatives of both planar unit vectors are zero. These identities follow by differentiating (R31) component by component. The scalar stresses depend only on \((r,z,t)\), so their angular derivatives vanish. Therefore the four tensor terms have divergences
\[
\begin{aligned}
\operatorname{div}(\sigma_2e_r\otimes e_\theta)&=(\sigma_2/r)e_\theta,\\
\operatorname{div}(\sigma_2e_\theta\otimes e_r)&=(\partial_r\sigma_2+\sigma_2/r)e_\theta,\\
\operatorname{div}(\sigma_1e_r\otimes e_z)&=(\partial_z\sigma_1)e_r,\\
\operatorname{div}(\sigma_1e_z\otimes e_r)&=(\partial_r\sigma_1+\sigma_1/r)e_z.
\end{aligned}
\tag{R33}
\]
Adding and applying (R9) proves the full physical force identity
\[
\operatorname{div}\mathbb T
=(\partial_z\sigma_1)e_r
 +(-F_2+b_2M_2F_2)e_\theta
 +(-F_1+b_1M_1F_1)e_z.
\tag{R34}
\]
In particular the radial force \(\partial_z\sigma_1\) is present. The tensor and force extend smoothly across the axis because they vanish in a neighborhood of it at each point of the open parameter domain. This proves a full tensor-to-force map, not just the two selected tangential rows.

## 6. Exact physical-to-chart correspondence with Q fixed

Retain a particular original source chart with \(Q>0\) fixed while differentiating:
\[
r=\sqrt Q R,\qquad z=Q^D Z,\qquad t=1-QT,\qquad
q_Q(Z,T)=q(Q^DZ,1-QT),\quad \widetilde q=q_Q/Q.
\tag{R35}
\]
Its inverse is \((R,Z,T)=(r/\sqrt Q,z/Q^D,(1-t)/Q)\), and its Jacobian determinant in this order is \(-Q^{3/2+D}\). For these three coordinates the absolute measure is \(dr\,dz\,dt=Q^{3/2+D}dR\,dZ\,dT\). With the unchanged angular coordinate retained, the full Cartesian spacetime measure has the additional radial factor: \(dx_1\,dx_2\,dz\,dt=Q^{2+D}R\,dR\,d\theta\,dZ\,dT\). The time derivative is \(\partial_T=-Q\partial_t\), and the spatial derivatives are \(\partial_R=\sqrt Q\partial_r\), \(\partial_Z=Q^D\partial_z\). These signs and factors are retained.

The source's chart representatives are
\[
E_e(R,Z,T)=Q^{2A+1/2}F_e(\sqrt QR,Q^DZ,1-QT),\quad
\Sigma_e(R,Z,T)=Q^{2A}\sigma_e(\sqrt QR,Q^DZ,1-QT),
\tag{R36}
\]
and define the complete chart moment and profile by
\[
\mathcal M_e=\int_0^\infty R^eE_e(R,Z,T)\,dR,\qquad
\widetilde b_e=\widetilde q^{-\alpha_e}\widehat b_e(R/\sqrt{\widetilde q}).
\tag{R37}
\]
Substitution \(r=\sqrt QR\), with all powers shown, gives
\[
M_eF_e=Q^{(e+1)/2}Q^{-2A-1/2}\mathcal M_e
=Q^{e/2-2A}\mathcal M_e,
\qquad b_e\circ\Psi_Q=Q^{-\alpha_e}\widetilde b_e,
\tag{R38}
\]
where \(\Psi_Q\) is the map (R35). Hence
\[
Q^{2A+1/2}(b_eM_eF_e)\circ\Psi_Q
=Q^{2A+1/2-\alpha_e+e/2-2A}\widetilde b_e\mathcal M_e
=\widetilde b_e\mathcal M_e.
\tag{R39}
\]
The exponent vanishes because \(\alpha_e=(e+1)/2\); the original factors are displayed rather than discarded.

Applying the same substitution directly to the lower-endpoint integral in (R8) gives
\[
\begin{aligned}
\Sigma_e(R)&=-Q^{2A}Q^{-e/2}R^{-e}
Q^{(e+1)/2}Q^{-2A-1/2}
\int_0^R s^e(E_e(s)-\widetilde b_e(s)\mathcal M_e)\,ds\\
&=-R^{-e}\int_0^R s^e(E_e(s)-\widetilde b_e(s)\mathcal M_e)\,ds,\\
(\partial_R+e/R)\Sigma_e&=-E_e+\widetilde b_e\mathcal M_e.
\end{aligned}
\tag{R40}
\]
Thus the moment-complement diagram commutes exactly for the same physical source and its representative, with the full inverse maps in (R12), (R35) and (R36). It does not identify arbitrary independently chosen chart sources.

The previously retained radial force transforms as
\[
Q^{2A+1/2}(\partial_z\sigma_1)\circ\Psi_Q
=Q^{2A+1/2}Q^{-2A-D}\partial_Z\Sigma_1
=Q^{1/2-D}\partial_Z\Sigma_1
=Q^h\partial_Z\Sigma_1.
\tag{R41}
\]
This is exactly the source parameter \(\varepsilon=Q^h\) multiplying that axial derivative; it accounts for the additional radial contribution's axial gain. In particular it is not a zero force component.

For every \(k,a,b\), differentiation of the same fixed chart gives the exact general identity
\[
\partial_R^k\partial_Z^a\partial_T^b\Sigma_e
=(-1)^bQ^{2A+k/2+aD+b}
(\partial_r^k\partial_z^a\partial_t^b\sigma_e)\circ\Psi_Q,
\tag{R42}
\]
with an analogous formula replacing \(2A\) by \(2A+1/2\) for \(E_e\). Thus all mixed derivative statements and their original time orientation have an explicit inverse correspondence.

## 7. The original flat edge weight is preserved by the radial integral

The source class also retains its flat radial-edge weight, which is stronger than the power/logarithm estimates alone. Equations (6.23) and the radial-integral paragraph in Proposition 9.3 give the original objects
\[
X=\frac{r^2}{2q},\quad X_a<X<X_b,\quad L=\log(X_b/X_a)>0,
\tag{R43}
\]
\[
\zeta(X)=\exp\left(-\frac{a_a}{\log^2(X/X_a)}-\frac{a_b}{\log^2(X_b/X)}\right),
\quad\delta(X)=\min\{1,\log(X/X_a),\log(X_b/X)\},
\quad a_a,a_b>0.
\tag{R44}
\]
The two positive constants are retained separately. The physical source shell corresponds to \(a_-=\sqrt{2X_a}\), \(a_+=\sqrt{2X_b}\) in the preceding formulas. The interior moment profile has support a positive logarithmic distance from either endpoint.

First prove the exact scalar estimate used at an edge. For \(a>0\), \(M\ge0\), and \(d>0\), substitution \(v=a/s^2\) gives
\[
\int_0^d s^{-M}e^{-a/s^2}\,ds
=\frac12 a^{(1-M)/2}\int_{a/d^2}^\infty v^{(M-3)/2}e^{-v}\,dv.
\tag{R45}
\]
Put \(p=(M-3)/2\) and \(x=a/d^2\). If \(p\le0\), then \(v^p\le x^p\) on \(v\ge x\), so the right side is at most \(d^{3-M}e^{-a/d^2}/(2a)\). If \(p>0\) and \(x\ge2p\), the elementary inequality \(\log(v/x)\le(v-x)/x\) implies
\[
v^pe^{-v}\le x^pe^{-x}e^{-(v-x)/2},
\qquad \int_x^\infty v^pe^{-v}dv\le2x^pe^{-x}.
\tag{R46}
\]
Hence in both cases the explicit bound
\[
\int_0^d s^{-M}e^{-a/s^2}\,ds
\le\frac1a d^{3-M}e^{-a/d^2}
\tag{R47}
\]
holds for
\(0<d\le\min\{1,\sqrt{a/\max\{1,M-3\}}\}\). The upper restriction is sufficient rather than an asserted largest possible interval.

Every scalar derivative can also be retained exactly. Let \(P_0(y)=1\) and
\[
P_{k+1}(y)=2ay^3P_k(y)-y^2P_k'(y).
\tag{R48}
\]
Induction with \(y=1/s\) gives
\[
\frac{d^k}{ds^k}e^{-a/s^2}=e^{-a/s^2}P_k(1/s),
\qquad\deg P_k\le3k.
\tag{R49}
\]
Thus on \(0<s\le1\), the bound is \(c_{k,a}s^{-3k}e^{-a/s^2}\), where \(c_{k,a}\) is the sum of the absolute values of the finitely many coefficients of the explicitly recursive polynomial \(P_k\). This proves the source's all-order scalar derivative estimate with every parameter retained.

For the left edge set \(s=\log(X/X_a)\). On \(0\le s\le d_0<L/2\),
\[
\zeta(X_ae^s)=e^{-a_a/s^2}g_a(s),\qquad
g_a(s)=e^{-a_b/(L-s)^2}>0.
\tag{R50}
\]
The function \(g_a\), all of its fixed-order derivatives, and its reciprocal are bounded on this compact interval. Also \(dX=X_ae^sds\), so each original radial weight becomes a smooth bounded positive factor there. The right edge instead uses \(s=\log(X_b/X)\), with the roles of \(a_a\), \(a_b\) interchanged and \(dX=-X_be^{-s}ds\). The reversed integration limits absorb this last minus sign when bounding an absolute integral. For each fixed exponent \(M\) and fixed derivative order being estimated, choose \(d_0>0\) with \(d_0<L/2\) and
\[
d_0\le\min\left\{1,\sqrt{\frac{a_a}{\max\{1,M-3\}}},
\sqrt{\frac{a_b}{\max\{1,M-3\}}}\right\},
\tag{R50a}
\]
and additionally smaller than the positive logarithmic distance of the moment-profile support from either endpoint. These choices give \(\delta(X)=s\) on both edge intervals and permit (R47) with its displayed constant on the whole chosen interval. The number \(d_0\) may depend on the fixed \(M\) and derivative order; no one positive edge interval is asserted to meet these restrictions for unbounded \(M\). The profile and all its derivatives vanish on these intervals, so \(H=F\) there, including every mixed derivative in (R21).

The original radial integral, in the exact variable \(X\), is
\[
\sigma(r,z,t)=-\sqrt{q/2}\,X^{-e/2}
\int_{X_a}^{X}Y^{(e-1)/2}H(\sqrt{2qY},z,t)\,dY.
\tag{R51}
\]
Indeed \(r^{-e}=(2qX)^{-e/2}\) and \(s^eds=2^{(e-1)/2}q^{(e+1)/2}Y^{(e-1)/2}dY\); their product is the displayed \(\sqrt{q/2}\) factor. At the right edge, the moment-zero identity makes (R51) exactly
\[
\sigma(r,z,t)=+\sqrt{q/2}\,X^{-e/2}
\int_X^{X_b}Y^{(e-1)/2}H(\sqrt{2qY},z,t)\,dY.
\tag{R52}
\]
Both signs and endpoints are fixed by the same inverse (R8).

Suppose a fixed original derivative of \(F\) is bounded by its actual parameter factor times \(\zeta(X)\delta(X)^{-M}\); the parameter factor is constant during the radial integration and may contain the original \(q\), \(\varepsilon\), \(S_*\) and logarithmic powers. Apply (R47), (R50), and the bounded radial factors to the left representation (R51) or right representation (R52). On either edge, the integral is bounded by that same parameter factor times a fixed constant and
\(\zeta(X)\delta(X)^{3-M}\), with the explicit additional \(\sqrt{q/2}\) from (R51)–(R52). For example, the left-edge constant can be taken as
\[
\frac1{a_a}
\left(\sup_{0\le s\le d_0}(X_ae^s)^{(e+1)/2}g_a(s)\right)
\left(\inf_{0\le s\le d_0}g_a(s)\right)^{-1}
\sup_{X_a\le X\le X_ae^{d_0}}X^{-e/2},
\tag{R53}
\]
apart from the already displayed \(\sqrt{q/2}\) and the source derivative bound. The right constant has the analogous literal \(X_b e^{-s}\), \(a_b\), and right-edge positive factor. Both are finite and keep the original endpoints and weights.

Every mixed derivative of \(\sigma\) is already exactly (R22), with (R20)–(R21) for its source. The integral term therefore has the preceding forward/backward edge estimate for its actual differentiated source. The nonintegral terms in (R22) are radial powers times differentiated sources; these preserve \(\zeta\) and enlarge only a finite power of \(\delta^{-1}\). No derivatives of the nonsmooth capped minimum \(\delta\) are taken: it is only an estimate weight. In the interior, \(\zeta\) has a positive lower bound, and the general compact radial estimates (R25)–(R30) apply. Thus at each fixed derivative order the full original flat weight is retained, with a finite edge-power loss and the same source amplitude exponent.

To retain uniformity over the source's actual bands, use its Section 6.1 chart property: \(q\) is comparable to the fixed band scale \(Q\). Write the original fixed comparison bounds as \(0<c_-\le q/Q\le c_+<\infty\). No numerical value for either comparison bound is introduced. With the same chart and the same \(\widetilde q=(q\circ\Psi_Q)/Q\) as in (R37), differentiation gives
\[
\partial_Z^a\partial_T^b\widetilde q
=(-1)^bQ^{aD+b-1}(\partial_z^a\partial_t^bq)\circ\Psi_Q,
\qquad
|\partial_Z^a\partial_T^b\widetilde q|
\le C_{a,b}\widetilde q^{1-aD-b}
\le C_{a,b}\max\{c_-^{1-aD-b},c_+^{1-aD-b}\}.
\tag{R54}
\]
Here the first inequality is exactly (R2) with the displayed powers of \(Q\) multiplied out. The original physical factor in (R51)–(R52), together with the source and stress representatives (R36), is exactly
\[
Q^{2A}\sqrt{q/2}\,Q^{-2A-1/2}
=\sqrt{(q/Q)/2}=\sqrt{\widetilde q/2},
\qquad
X=\frac{R^2}{2\widetilde q}.
\tag{R55}
\]
In particular the chart shell has inner radius at least \(\sqrt{2c_-X_a}>0\) and outer radius at most \(\sqrt{2c_+X_b}\). The original profile variable and its first derivatives are
\[
\partial_RX=R/\widetilde q,\qquad
\partial_ZX=-X\,\partial_Z\widetilde q/\widetilde q,\qquad
\partial_TX=-X\,\partial_T\widetilde q/\widetilde q.
\tag{R56}
\]
For completeness, all higher inverse-factor derivatives follow from differentiating \(\widetilde q\,\widetilde q^{-1}=1\). For a nonzero two-index \(\beta=(a,b)\), the exact recurrence is
\[
\partial^\beta(\widetilde q^{-1})
=-\widetilde q^{-1}
\sum_{0<\gamma\le\beta}\binom{\beta}{\gamma}
(\partial^\gamma\widetilde q)
\partial^{\beta-\gamma}(\widetilde q^{-1}),
\qquad \partial^\beta=\partial_Z^a\partial_T^b.
\tag{R57}
\]
The initial inverse is bounded by \(c_-^{-1}\). Induction using (R54) and this finite sum bounds every fixed-order inverse derivative by constants independent of \(Q\). Applying the exact product rule to \(R^2\widetilde q^{-1}/2\) proves the same assertion for every mixed derivative of \(X\) on the original shell. The same argument applies to every fixed real power of \(\widetilde q\), by the scalar power derivative formula and the finite composition rule already proved in (R16)–(R19). Thus every coefficient in (R20)–(R30) and in the edge estimate has a uniform chart bound with the original comparison constants retained.

The source keeps \(Q\), \(\varepsilon=Q^h\), and \(S_*\) fixed during chart differentiation and radial integration. Applying the proved operator formulas directly to (R40), with its literal ratio \(\widetilde q\), therefore preserves the incoming power of \(\varepsilon\) and every original \(S_*\) derivative factor. It retains \(\zeta\) with only the finite edge-power losses proved above. The selected averaged source is independent of the auxiliary torus coordinates; the profile and the radial operator are also independent of them. All positive-order auxiliary derivatives of this reconstruction are consequently exactly zero.

This proves the radial integration part of the source's \(\mathcal M_\alpha\)-class preservation, including its uniform band factors and the edge behavior needed before division by the fixed primary amplitude. The source's auxiliary covariance and inter-chart descent are further properties of its input and chosen amplitude map, not consequences of an endpoint integral estimate. They remain separately identified below.

## 8. Exact role in the source correction and remaining dependencies

The source defines its physical averaged residuals by \(F_2=Q^{-2A-1/2}\langle E_\theta\rangle_Y\) and \(F_1=Q^{-2A-1/2}\langle E_z\rangle_Y\). Here \(E_\theta,E_z\) are its original chart fields; the \(E_e\) of (R36) are exactly their displayed averaged representatives. The averaging is an actual projection onto the auxiliary-coordinate-independent fields. The radial operators above then act on those physical functions; they do not treat an auxiliary variable as a physical angle or differentiate it as a spatial coordinate.

For the given averaged source, (R9) cancels \(F_e-b_eM_eF_e\) and retains \(b_eM_eF_e\) as an exact residual coordinate. The higher-order estimate for that retained term in the source uses its separate moment estimate (9.12). Equations (R25), (R38) and (R39) explain its full scaling, but do not prove (9.12) from an unavailable source bound.

The source's signed amplitude operator prescribes the radial–tangential entries of the symmetrized cross covariance. Its complete covariance has further entries, curl terms and the correction's quadratic self-interaction. The symmetric tensor (R32) records exactly the force contribution of the prescribed two entries, including its radial component. It does not assert equality of (R32) with the entire newly generated covariance. Those other entries are retained by the full source expansion (9.13), to which the separate four-step gain audit applies.

Consequently this proof establishes a complete compact radial reconstruction, moment-preserving inverse, all original moving-q derivatives and quantitative constants, full tensor divergence and chart correspondence. The source's actual incoming residual estimates, cross-chart agreement of its independently constructed averaged fields, amplitude covariance identity and later nonlinear residual bounds remain their respective upstream calculations. No source-existence or kernel certificate is inferred. No Lean, Lake, Elan, new publication or parent-source modification was performed for this note.
