# Portable fragment rendering identity review

Reviewed UTC: 2026-09-08T22:56:45.587440+00:00

PASS for the bounded byte identity and current integration checks below. This is a read-only review of the repair, source snapshots, current fragments, parent TeX and existing parent log. I did not run the repair script, compile TeX, execute Lean/Lake/Elan, or edit mathematical/source/parent files. Only this review report was written.

The repair script and the entire JSON receipt were read. Independent Python checks read every byte of both historical and current TeX fragments, independently reconstructed the result from the recorded insertion positions, and applied the exact inverse. Pandoc separately parsed all four complete fragments without warnings. The current cumulative TeX and log were captured before the checks and read again after them; both remained byte-identical during this review.

## Exact identity checks

| Fragment | Math expressions | Changed code labels | Inserted discretionary breaks | Pandoc Code nodes |
| --- | ---: | ---: | ---: | ---: |
| radial_stress_reconstruction_audit | 269 | 3 | 144 | 3 |
| stage_cycle_gain_audit | 334 | 63 | 2243 | 109 |

Every recorded code range lies wholly outside all mathematical spans, begins immediately after an original `\texttt{`, ends at its corresponding original closing brace, and retains its exact original body after deletion of `\allowbreak{}`. The complete original Pandoc Code-node sequence equals the complete final sequence, including code attributes and every character. The original snapshots contain no `\allowbreak{}`; deleting exactly the newly inserted commands is therefore unambiguous. The 66 changed labels retain every original character, including underscores, Greek letters, operators, spaces and hashes.

Radial: all 269 math spans are literal byte-identical and in original order. Stage-cycle: 333 of 334 spans are literal byte-identical and in original order. The only changed span is C32, zero-based index 329. Immediately after the unique original `+u.\mathrm{covariance}_{2,2})`, the repair inserts exactly the characters shown here:

```tex
\\
  &\quad{}
```

The original next line `  -\tfrac12\,\texttt{radialMoment 2 }(u.g_r).` is unchanged, including its leading minus, fraction, thin space, operator text, argument and terminal punctuation. The added aligned row therefore continues the same axial-defect right-hand side on a new line. No original mathematical token is deleted or substituted. Deleting this sole recorded C32 layout insertion and then the outside-math discretionary commands reconstructs all original TeX bytes exactly. The expression totals remain 269 + 334 = 603.

## Current cumulative inclusion and existing build log

Both complete current fragment strings occur exactly once in the inspected cumulative TeX after only converting that parent file's CRLF line endings to LF for comparison. No heading conversion or other content adjustment was needed. This is a complete-fragment comparison, not a label-only or selected-equation check.

The existing cumulative log reports:

```text
Output written on released_ns_reader_corrected_20260909.pdf (208 pages, 1993960
```

The full existing log contains no `Overfull`, no TeX error line beginning `!`, no `Fatal error`, and no `Emergency stop`. This establishes what the inspected existing log records; I did not run a build and do not certify PDF visual layout from this text-only review. The parent TeX/log hashes below remained unchanged over the review interval.

## SHA-256 identities

- `lanes/web_bundle_audit/coordination/repair_portable_rendering.py`: `dd71629595b4908940d278f88b923511d3a26f0a4a65c7cc109d11e720e5642f`.
- `lanes/web_bundle_audit/tex_handoff/portable_upstream/render_repair_receipt.json`: `b13aa05eab8f3c145455a3701aea4f6e89fc9645c6129f7928048418548e61aa`.
- `lanes/web_bundle_audit/tex_handoff/portable_upstream/display_render_patch.json`: `a0dcc4614f646ff1b294dc9f7fd8be4d71aa41951a864d401ba7042e338741b8`.
- `lanes/web_bundle_audit/tex_handoff/portable_upstream/handoff_preamble.tex`: `1101086d66b2a56a5dc4f79a239a4569af4a58a5dbb60c249123f664046c5260`.
- `lanes/web_bundle_audit/tex_handoff/portable_upstream/manifest.json`: `6a051fa883618ad31f295ca35e74f29094baebea89d65f64e5bd802e0787991a`.
- `lanes/web_bundle_audit/tex_handoff/portable_upstream/history_before_render_repair/radial_stress_reconstruction_audit.tex`: `8c726ed08a505efc4ce158c41f2a4ac68dcd7c203d7fa81f6f7824fbd7fbcc32`.
- `lanes/web_bundle_audit/tex_handoff/portable_upstream/radial_stress_reconstruction_audit.tex`: `dd6c119670316f1804226723caaefe062a580e40d2101efab86d823b5858ed8a`.
- `lanes/web_bundle_audit/tex_handoff/portable_upstream/history_before_render_repair/stage_cycle_gain_audit.tex`: `35ad3bacf394b225fa1361e41b1172e2a8a6bf2d80b1189dcebd40aae52f4351`.
- `lanes/web_bundle_audit/tex_handoff/portable_upstream/stage_cycle_gain_audit.tex`: `497cb07b95a651bd5ed76f74c004722dc2172c1ef0575ddfea43c95cd56b361e`.
- `tex/released_ns_reader_corrected_20260909.tex`: `0b5b832e1845469b316b992880b4731a88681e018b58fd50f9f38e1c0a1ec263`.
- `tex/released_ns_reader_corrected_20260909.log`: `932ff84f39edf8d8718c5c650250428e6da1b9117d4706062a79c8b487b217fb`.

Scope limitation: this review certifies the described reversible typography and current inclusion/log observations. It does not independently re-prove the radial/stage-cycle mathematics, certify the whole Navier–Stokes manuscript or kernel closure, or assert publication of the current cumulative file.
