"""Exact supplemental algebra checks for derivation.tex; no PDE solver or Lean.

The proofs and analytic estimates are in derivation.tex. These checks reproduce
selected finite algebra identities and do not certify outside-lane dependencies.
"""
import json
import sympy as s
from pathlib import Path

r, q, X, h, Z, v = s.symbols("r q X h Z v", positive=True)
A = s.Rational(1, 2) + h
phi = s.Function("phi")
U = s.Function("U")
V = s.Function("V")
xx = r**2 / (2*q)
checks = {}

def zero(name, expr):
    value = s.simplify(s.expand(expr))
    if value != 0:
        raise AssertionError((name, value))
    checks[name] = "exact zero"

def vector_laplacian(f):
    return s.diff(f,r,2)+s.diff(f,r)/r-f/r**2

zero("angular radial vector Laplacian",
     vector_laplacian(r*phi(xx))
     - 2*r/q*(xx*s.diff(phi(X),X,2).subs(X,xx)
               +2*s.diff(phi(X),X).subs(X,xx)))
zero("axial radial scalar Laplacian",
     s.diff(U(xx),r,2)+s.diff(U(xx),r)/r
     -2/q*(xx*s.diff(U(X),X,2).subs(X,xx)
             +s.diff(U(X),X).subs(X,xx)))
zero("radial vector Laplacian",
     vector_laplacian(V(xx)/r)
     -2*xx/(q*r)*s.diff(V(X),X,2).subs(X,xx))
heat_poly = ((1+h)*Z**2*v**2
             -(1+2*(1+h)*Z)*v*(1+Z*v)
             +(1+h)*(1+Z*v)**2)
zero("heat ODE integration-by-parts polynomial",
     heat_poly-((1+h)-v-Z*v**2))

a, bs, w = s.symbols("a bs w", real=True, nonzero=True)
c = 1-bs*w/a
j = w+bs/a
vs = a+bs**2/a
zero("sufficient cone factorization",
     2*c**2-(vs-2)*j**2
     -(1+bs**2/a**2)*(2-2*bs*w-bs**2/a-(a-2)*w**2))

lam, eta = s.symbols("lambda eta", real=True)
D = s.Rational(1,2)-h
d = 1-eta**2
L = 1-2*h*eta**2
Fn = s.Function("F")(X,eta)
Un = s.diff(Fn,X)
bn = D+lam
stream_z = (2*bn*eta*Fn+d*s.diff(Fn,eta)-2*eta*X*Un)/L
Vn = (2*eta*X*Un-2*eta*(D+lam)*Fn-d*s.diff(Fn,eta))/L
zero("streamfunction radial coefficient", stream_z+Vn)
zero("positive-order divergence",
     s.diff(Vn,X)
     +(2*(-A+lam)*eta*Un+d*s.diff(Un,eta)-2*eta*X*s.diff(Un,X))/L)

Kb_lower = s.exp(-s.Rational(4,100))/4 * (
    1-s.exp(-s.Rational(1796,100))*(
        1+s.Rational(1796,100)+2*s.Rational(898,100)**2))
checks["pulse lower bound evaluation (supplement, not proof)"] = str(s.N(Kb_lower,30))
checks["first cone quadratic maximum"] = str(s.Rational(241,100)**2/8)
checks["second cone quadratic maximum"] = str(s.Rational(482,100)**2/14)
checks["interpretation"] = (
    "Exact symbolic identities supplement the explicit derivations; they are "
    "not an acceptance of the manuscript's unexamined sections."
)
out = Path(__file__).with_name("identity_check_results.json")
out.write_text(json.dumps(checks,indent=2)+"\n",encoding="utf-8")
print(json.dumps(checks,indent=2))
