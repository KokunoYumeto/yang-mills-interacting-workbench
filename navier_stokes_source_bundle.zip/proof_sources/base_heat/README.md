# Base coefficients and heat exterior: independent bounded audit

The proof body is derivation.tex; its readable version is derivation.pdf. It reconstructs Section 5 and Appendix A of the 165-page manuscript identified by the SHA-256 in read_scope_ledger.md.

The read-scope ledger identifies every covered result and every outside-lane dependency. No contradiction was found in the assigned subsystem; this does not certify the leading-axis gluing, wave argument, or global blowup theorem.

Build locally with:

    pdflatex -interaction=nonstopmode -halt-on-error -file-line-error derivation.tex
    pdflatex -interaction=nonstopmode -halt-on-error -file-line-error derivation.tex
    python verify_identities.py

The Python script requires SymPy. It verifies finite exact identities supplementary to the complete analytic derivations in the proof body.

For cumulative TeX integration, the root programme can take the body between the document begin/end commands, omit the local title if needed, and retain the source/dependency boundary. The local macros are declared before the document. No external images or bibliography files are needed.
