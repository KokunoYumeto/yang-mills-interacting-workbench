# Read scope, source dependencies, and status

Source: *Finite Time Blowup for Navier–Stokes*, 165-page PDF, public URL [source PDF](https://cdn.openai.com/pdf/32d9f210-8b73-45e0-91bc-82a30aef8a9a/navier-stokes.pdf).

SHA-256: 8c8a94ad9ac824c8b605b9827cadf7beaca48bd10b380de3cfc872a2c37afa81.

The complete assigned text was read in the local extraction, with every proof followed through its end. This is a bounded audit, not a declaration that the source's global theorem has been accepted.

| Source item | Source pages | Independent derivation section | Status |
|---|---:|---|---|
| Coordinate and cylindrical identities (4.1)–(4.7), (5.1)–(5.6) | 24–25, 45–47 | 1 | Exact chain rule, powers, radial Laplacians, pressure sign, and regular quotients derived. |
| Leading moment/stress maps (4.8)–(4.23) | 26–31 | 3, 7.2 | Definitions and proofs read; exact moment-to-stress map and cone factorization independently derived. |
| Lemma 5.1 | 47–48 | 2 | Sparse derivative matrix verified; Volterra convergence, uniqueness, parity, and fixed radial interval proved from the specified leading analytic data. |
| Lemma 5.2 | 49–54 | 3.2, 4, 9.4 | Exact affine moment blocks, supports, conservative cancellations, exceptional order-one edge term proved. |
| Proposition 5.3 | 54–56 | 5 | Coefficient induction and finite residual derived; an explicit valid loss is K_m = 2A + 1/2 + m. |
| Lemma 5.4 and summation discussion | 56–59 | 5 | Divergence-preserving cutoff, diagonal sequence, tail, and finite-polynomial residual comparison proved. |
| Proposition 5.5 | 60–62 | 5 | Exact curl commutator, all normalized bounds, weighted stress bound, asymptotic coefficients, and closed-parameter uniformity derived. |
| Lemma A.1 | 126–127 | 3.1 | Distinct-power zero count, determinant sign, inverse derivatives, and near-coincident O(lambda^-1) inverse derived. |
| Lemma A.2 | 127–128 | 3.1 | Exact quadratic contraction and smooth branch, with stated constants, derived. |
| Corollary A.3 | 128 | 3.1 | All scale factors and row operations retained; both power-weight blocks derived. |
| Proposition A.4, all schedule and moment steps | 129–133, 134–137 | 6, 7 | Complete schedule, exact finite moment systems and pulse quadratic, amplitude bracket, and every outer cone stage reconstructed. |
| Lemma A.5 | 133–134 | 7.1 | Exact pressure datum, complex neighborhood, domination, parity, sign, and -(5/2)P_*^2 f^2 contribution proved. |
| Lemma A.6 | 137–138 | 8.1 | Heat integral differentiated; exact integration-by-parts polynomial and physical heat equation proved, including sign and all endpoint derivatives. |
| Proposition A.7 | 139–140 | 8.2 | Three discrepancies, 1/h angular integral, exact compensation map and cone preservation proved. |
| Lemma A.8 | 140–141 | 9.1 | Convergent subtracted moment, all boundary limits, exact pressure Fubini integral and backward stress representation proved once specified axis matching is supplied. |
| Lemma A.9 | 141–142 | 9.2 | Exact substitution, factor 1/2, endpoint coefficient, all fixed derivative bounds proved. |
| Proposition A.10 | 142–144 | 9.3 | Exact positive angular stress formula, pressure formula, cone, flat powers -3,+3, coefficient, and ratio power 6 proved. |

## Dependencies deliberately not certified in this lane

1. **Leading analytic axis and inner collar:** Theorem 4.6(i), Proposition B.2, and the continuation that supplies the fixed analytic rectangle. Section 2 identifies this input precisely. Appendix B was not read in full here; its proof belongs to the profiles lane.
2. **Final leading profile, preserved reserved intervals, and all five matched moments:** Theorem 4.6, Corollary B.10, and Appendix C. Section 9.1 identifies the regular-axis and matching input precisely. Appendix A itself constructs the outer schedule and its moments; it does not by itself prove the axis gluing.
3. **Wave realization of stress and final global construction:** Sections 6–10. These were not audited in this lane. The last lines of Section 10 on source p.126 and the opening of Section 6 on p.62 were encountered at the assigned boundary only, not counted as an audit of either theorem.
4. **Leading global profile support facts used by Section 5:** The final leading axial pulse lies before a finite radius, and the positive-order and mean patches retain the exact stated power law. These are explicit Theorem 4.6 outputs, not inferred from the positive-order equations.

## Visual source checks

- Source p.136: inspected its rendered PDF page. The estimate preceding (A.30) is O(C_pre e^26 / lambda), **not** O(C_pre exp(26/lambda)). This matters because the ensuing small-error bound uses a constant independent of small lambda apart from its explicit inverse.
- Source p.143: inspected its rendered PDF page. The normalized boundary coefficient is divided by sqrt(2X); its endpoint coefficient is 16 rho_o E_pow(X_b) H(2d/X_b) g(0) / sqrt(2X_b).
- Neither visual resolution is a source erratum. Both resolve limitations of the text extraction.

## Mathematical findings and repairs

No contradiction was found within the audited subsystem after the written derivations. The five moments, sparse Volterra derivative count, heat ODE, source and stress signs, and endpoint factors agree with the source.

The manuscript applies the summation construction on every fixed compact profile range. The independent derivation supplies the explicit simultaneous choice: all positive-order velocity/pressure terms lie below the common X_+, all stresses below X_b, and the exact exterior has zero augmented residual. One cutoff sequence chosen on a rectangle containing those supports therefore works on every larger compact rectangle. This is a local elaboration of the domain argument, not an extra hypothesis.

The positive-order velocity vanishes on the mean patch, but the positive-order pressure need not yet vanish there: the leading radial source can persist until the leading axial pulse ends. The derivation preserves this distinction and places the common pressure support radius after that pulse.

No theorem has been replaced by a new assumption in this lane. The unproved external inputs listed above are the actual source dependency boundary and remain assigned to the other lanes.

## Reproducibility and output review

- derivation.tex is the independent proof body.
- derivation.pdf is its compiled readable artifact.
- verify_identities.py supplies exact symbolic reproductions of selected finite algebra identities already proved in the text. These calculations do not replace the analytic arguments.
- identity_check_results.json records those outputs.
- logbook.md records assignment provenance, reading, decisions, and validation.
- All 22 output PDF pages were rendered and visually inspected in four contact sheets; no clipped equations or layout defects were found. The final LaTeX build has no overfull/underfull boxes and no warnings.
- No Lean/Lake/Elan process, remote upload, source-PDF edit, or other lane's edit was performed.
